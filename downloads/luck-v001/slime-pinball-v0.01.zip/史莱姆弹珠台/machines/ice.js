/*
 * 第 4 台 · 冰窟（进洞；小台 64 宽，11-11 从两堆改成一堆）
 *   一堆冰块，2 列 × 3 层，坐在冰笋上；底下 9 个洞，亮着的是中奖洞（每发重抽，【签】亮几个）。
 *   按住拉弹簧、松手打铁珠（发射道、力度同基础机）。
 *   铁珠撞冰块一下掉一格（【速】几下碎），碎了冻在里面的珠子蹦出来（【救】一块最多冻几颗；每块几颗是抽的，冰里看得见）。
 *   铁珠、珠子落进亮洞，一颗吐【价】个。一列底下那块碎了，上面的砸下来，落地自己裂一格（裂光了接着碎，一列就塌了）。
 *   一发打完（台上的珠子都落了洞），冰块补满、重抽亮洞。
 *   金冰珠（碰运气）：补冰时 2% 一块冻着金珠，碎出来落进亮洞 ×5。冰镐（手上功夫 = 大奖）：亲手一发砸塌一整堆（6 块）。
 *   冰灯（打得深）：这一局砸碎 100 块。保底、力度刻度（技能树进洞那枝）同火山坑。
 */
Machines.def('ice', env => {
  'use strict';
  const { A, sfx } = env;
  const I = window.Ice, S = MK.sprites(), INK = A.INK, FX = A.FX, FY = A.FY, DX = I.DX;
  const s = I.create((Date.now() ^ (Math.random() * 1e9)) >>> 0);
  const pl = MK.plunger(sfx);
  const ironIm = MK.ball7(A.MARB.iron);
  const gemIm = A.sprite(['.kkk.', 'khwwk', 'kwwsk', 'kwssk', '.kkk.'], { k: INK, h: '#ffffff', w: '#a8e8ff', s: '#4fb0d8' });
  const goldIm = A.sprite(['.kkk.', 'khwwk', 'kwwsk', 'kwssk', '.kkk.'], { k: INK, h: '#fff6c0', w: '#ffd23a', s: '#c47a10' });
  const flake = A.outlined(['x.x.x', '.xxx.', 'xxwxx', '.xxx.', 'x.x.x'], { x: '#a8e8ff', w: '#ffffff' }, INK);
  const st = { phase: 'ready', acc: { t: 0 }, time: 0, lit: [], flashHole: new Map(), pegFlash: new Map(), labels: [], shards: [], trail: [], auto: null, shot: null, gauge: null, born: new Map() };
  const m = () => env.m();
  const gemsLeft = () => s.blocks.reduce((a, b) => a + b.n, 0);

  // ---------- 冰块 ----------
  function fill() {
    const added = I.refill(s, env.val('k'), env.val('h'), 0);
    for (const b of added) { b.gold = env.luck(0.02); st.born.set(b, 0.35); }
    if (added.length) { sfx.clink(); st.gauge = null; }
  }
  // 亮洞：每发重抽（保底同火山坑）
  function drawLit() {
    let n = env.val('n');
    const pity = env.lv('pity'), need = pity === 2 ? 2 : pity === 1 ? 3 : Infinity;
    if (m().misses >= need) { n += 1; m().misses = 0; env.toast('保底：这一发多亮一个洞'); }
    const all = []; for (let i = 0; i < I.HOLES; i++) all.push(i);
    for (let i = all.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [all[i], all[j]] = [all[j], all[i]]; }
    st.lit = all.slice(0, Math.min(I.HOLES, n)).sort((a, b) => a - b);
    sfx.settle(st.lit.length);
    st.gauge = null;
  }
  fill(); drawLit();
  const ironFlying = () => s.balls.some(b => b.kind === 'iron');

  // ---------- 一发 ----------
  function startCharge(by) { if (st.phase !== 'ready' || I.busy(s)) return false; if (env.marbles() <= 0) { env.deny('marbles'); return false; } pl.start(by); st.phase = 'charge'; return true; }
  function release() {
    if (st.phase !== 'charge') return;
    const p = pl.release();
    if (!env.spend()) { st.phase = 'ready'; return; }
    I.launch(s, p);
    st.phase = 'fly'; st.trail.length = 0;
    st.shot = { broke: 0, pile: [0, 0], paid: 0 };
    sfx.launch(p);
  }
  function endShot() {
    const sh = st.shot;
    if (sh) {
      if (sh.paid > 0) m().misses = 0; else m().misses += 1;
      if (sh.pile.some(k => k >= 6)) env.jackpot();
      if (sh.broke >= 2) st.labels.push({ s: '碎了 ' + sh.broke + ' 块', x: 64, y: 34, t: 0, c: '#a8e8ff' });
    }
    st.shot = null; st.phase = 'ready';
    fill(); drawLit(); env.save();
  }
  function pay(base, hole, label) {
    const n = env.award(base, { at: [I.holeCx(hole), 146], n: Math.min(10, Math.ceil(base / 2)) });
    st.flashHole.set(hole, 0.5);
    if (st.shot) st.shot.paid += n;
    if (label) st.labels.push({ s: label, x: I.holeCx(hole), y: 136, t: 0 });
    return n;
  }
  function shards(x, y, gold) {
    for (let i = 0; i < 10; i++) { const a = Math.random() * Math.PI * 2, v = 30 + Math.random() * 50; st.shards.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 30, t: 0, c: i % 3 ? '#e6fbff' : gold ? '#ffd23a' : '#9fe6ff' }); }
  }
  function onEvent(e) {
    if (e.type === 'hit') {
      if (e.kind === 'peg') { sfx.pin(e.impact, e.id); st.pegFlash.set(e.id, 0.12); }
      else if (e.kind === 'roof') sfx.rim(e.impact);
      else if (e.kind === 'spike') sfx.clink();
      else if (e.kind !== 'head' && e.kind !== 'block') sfx.wall(e.impact);
    } else if (e.type === 'tink') { if (!e.gem) sfx.clack(e.impact); }
    else if (e.type === 'crack') { sfx.crack(e.by === 'fall' ? 300 : 700); if (e.b.hp > 0) st.labels.push({ s: '裂', x: e.x, y: e.y - 8, t: 0, c: '#ffffff' }); }
    else if (e.type === 'break') {
      sfx.shatter(); shards(e.x, e.y, e.b.gold);
      const pile = I.COLS[e.b.col].pile;
      if (st.shot) { st.shot.broke += 1; st.shot.pile[pile] += 1; }
      m().iceBroke = (m().iceBroke || 0) + 1;
      if (m().iceBroke >= 100) env.find('deep');
      st.gauge = null;
    } else if (e.type === 'thud') { if (e.v > 40) env.shake(0.12); }
    else if (e.type === 'fallback') { env.refund(); sfx.fallback(); st.phase = 'ready'; st.shot = null; }
    else if (e.type === 'land') {
      const b = e.b, lit = st.lit.includes(e.hole);
      if (b.kind === 'iron') {
        if (lit) { pay(env.val('v'), e.hole); sfx.win(); m().hits += 1; } else sfx.miss();
      } else if (lit) {
        pay(env.val('v') * (b.gold ? 5 : 1), e.hole, b.gold ? '金 ×5' : null);
        sfx.win();
        if (b.gold) env.find('luck');
      } else sfx.clink();
    }
  }

  // ---------- 力度刻度：每个力度先碰到哪（冰块变了、亮洞变了就重算，一帧算几个） ----------
  function gaugeStep() {
    if (!env.lv('gauge') && !st.auto) return;
    if (!st.gauge) st.gauge = { out: new Array(101).fill(undefined), i: 0 };
    const G = st.gauge;
    for (let k = 0; k < 6 && G.i <= 100; k++, G.i++) G.out[G.i] = I.probe(s, G.i / 100);
  }
  const gaugeColor = o => (!o ? null : o.col != null ? '#9fe6ff' : o.hole != null && st.lit.includes(o.hole) ? A.GOLD[0] : null);

  // 自动打（自测、领航用）：照力度刻度挑——先打冻得多、裂过的、靠底下的冰块，没有就打亮洞
  function auto(dt) {
    const A_ = st.auto || (st.auto = { t: 0, target: 0.5 });
    if (st.phase === 'ready' && !I.busy(s)) {
      A_.t += dt;
      if (!st.gauge || st.gauge.i <= 100) { st.gauge = st.gauge || null; for (let k = 0; k < 4; k++) gaugeStep(); return; }
      if (A_.t < 0.3) return; A_.t = 0;
      const out = st.gauge.out;
      let best = -1, bp = Math.random();
      for (let i = 2; i <= 100; i++) {
        const o = out[i]; if (!o) continue;
        let v = 0;
        if (o.col != null) { const b = s.blocks.find(k => k.col === o.col && k.row === o.row); if (b) v = b.n * (1 + (b.hp0 - b.hp)) * (o.row === 0 ? 2 : 1) + (o.hard ? 1 : 0); }
        else if (o.hole != null && st.lit.includes(o.hole)) v = 1;
        v += Math.random() * 0.5;
        if (v > best) { best = v; bp = i / 100; }
      }
      const k = window.__autoNoise || 0;
      A_.target = Math.max(0.02, Math.min(0.99, bp + (k ? Math.sqrt(-2 * Math.log(1 - Math.random())) * Math.cos(2 * Math.PI * Math.random()) * 0.03 * k : 0)));
      startCharge('auto');
    } else if (st.phase === 'charge' && pl.by === 'auto' && Sim.holdPower(pl.t) >= A_.target) release();
  }

  // ---------- 画 ----------
  const blockCache = new Map();
  function blockIm(b) {
    const crack = b.hp0 - b.hp, key = b.n + (b.gold ? 'g' : '') + crack + '/' + b.hp0;
    if (!blockCache.has(key)) {
      const W = I.BW, H = I.BH, rows = [];
      for (let y = 0; y < H; y++) { let r = ''; for (let x = 0; x < W; x++) r += x === 0 || y === 0 || x === W - 1 || y === H - 1 ? 'k' : y === 1 || x === 1 ? 'h' : y === H - 2 || x === W - 2 ? 's' : 'w'; rows.push(r.split('')); }
      // 冻着的珠子：一颗一个 2×2 的点，排在冰块中间
      const n = b.n, gap = 3, x0 = Math.round(W / 2 - (n * gap - 1) / 2);
      for (let i = 0; i < n; i++) { const X = x0 + i * gap; for (const [dx, dy] of [[0, 0], [1, 0], [0, 1], [1, 1]]) rows[4 + dy][X + dx] = b.gold && i === 0 ? (dx + dy === 0 ? 'G' : 'g') : dx + dy === 0 ? 'm' : 'b'; }
      // 裂纹：一裂一道白折线
      const CR = [[[3, 2], [4, 3], [5, 3], [6, 4]], [[11, 6], [12, 5], [13, 5], [12, 3]], [[7, 7], [8, 6], [9, 7], [10, 8]]];
      for (let c = 0; c < Math.min(crack, CR.length); c++) for (const [x, y] of CR[c]) rows[y][x] = 'c';
      blockCache.set(key, A.sprite(rows.map(r => r.join('')), { k: INK, h: '#e6fbff', w: '#9fe6ff', s: '#5ab8e0', m: '#ffffff', b: '#4f7fd8', G: '#fff6c0', g: '#ffb21a', c: '#ffffff' }));
    }
    return blockCache.get(key);
  }
  function fineSpikes(f) {
    for (const sp of I.SPIKES) {
      for (let y = sp.y; y < I.STRIP; y++) {
        const t = (y - sp.y) / (I.STRIP - sp.y), xl = Math.round(sp.x0 + (sp.b0 - sp.x0) * t), xr = Math.round(sp.x1 + (sp.b1 - sp.x1) * t);
        for (let x = xl; x <= xr; x++) f.px(x, y, x === xl || x === xr || y === sp.y ? INK : x === xl + 1 ? '#e6fbff' : x >= xr - 2 ? '#5ab8e0' : '#9fe6ff');
      }
    }
  }

  return {
    s,
    fine(f) {
      MK.fineHoles(f, I.HOLES);   // 最右那个洞一直通到发射道（同小台）
      MK.fineLane(f, Sim.DEFAULTS.guard, DX);
      MK.finePegs(f, I.pegs());
      fineSpikes(f);
      f.fineMeter(DX);
    },
    update(dt) {
      st.time += dt;
      if (st.phase === 'charge') pl.update(dt);
      if (st.phase === 'fly' || I.busy(s)) {
        I.advance(s, dt * 1.3, st.acc);
        const iron = s.balls.find(b => b.kind === 'iron');
        if (iron) { st.trail.unshift([iron.x, iron.y]); if (st.trail.length > 6) st.trail.length = 6; }
        for (const e of s.events.splice(0)) onEvent(e);
        if (st.phase === 'fly' && !I.busy(s)) endShot();
      } else { s.events.length = 0; if (st.phase === 'ready' && env.lv('gauge')) gaugeStep(); }
      for (const mp of [st.flashHole, st.pegFlash, st.born]) for (const [k, t] of mp) { if (t - dt <= 0) mp.delete(k); else mp.set(k, t - dt); }
      for (const l of st.labels) l.t += dt;
      st.labels = st.labels.filter(l => l.t < 1);
      for (const p of st.shards) { p.t += dt; p.x += p.vx * dt; p.y += p.vy * dt; p.vy += 160 * dt; }
      st.shards = st.shards.filter(p => p.t < 0.6);
    },
    draw(ctx) {
      // 洞：亮洞一盏黄灯 + 一朵雪花
      for (let i = 0; i < I.HOLES; i++) {
        const lit = st.lit.includes(i), fl = st.flashHole.get(i);
        MK.spr(ctx, lit || (fl && Math.sin(fl * 30) > 0) ? S.lampOn : S.lampOff, 16 + 10 * i, 149);
        if (lit) MK.spr(ctx, flake, I.holeCx(i) - 2.5, 139 + (Math.sin(st.time * 5 + i) > 0 ? 0 : -1));
      }
      // 冰块
      for (const b of s.blocks) {
        const born = st.born.get(b);
        if (born && Math.sin(born * 40) > 0) { ctx.fillStyle = '#ffffff'; ctx.fillRect(FX(b.x), FY(Math.round(b.y)), I.BW * 2, I.BH * 2); continue; }
        MK.spr(ctx, blockIm(b), b.x, Math.round(b.y));
      }
      MK.lane(ctx, st.phase === 'charge' ? pl.pull() : 0, env.marbles() > 0 && (st.phase === 'ready' || st.phase === 'charge') && !I.busy(s) ? ironIm : null, DX);
      A.drawMeter(ctx, pl.power(), st.phase === 'charge', DX);
      if (env.lv('gauge') && st.gauge && (st.phase === 'ready' || st.phase === 'charge')) MK.gaugeTicks(ctx, st.gauge.out, gaugeColor, DX);
      for (const [id] of st.pegFlash) { const c = s.colliders[id]; if (c && c.kind === 'peg') MK.spr(ctx, S.pegHit, c.x - 2, c.y - 2); }
      for (const p of st.shards) MK.px(ctx, p.x, p.y, p.c);
      const t1 = st.trail[2];
      if (t1) MK.px(ctx, t1[0], t1[1], '#c8d0d4');
      for (const b of s.balls) {
        if (b.kind === 'iron') MK.spr(ctx, ironIm, Math.round(b.x - 3.5), Math.round(b.y - 3.5));
        else MK.spr(ctx, b.gold ? goldIm : gemIm, Math.round(b.x - 2.5), Math.round(b.y - 2.5));
      }
      for (const l of st.labels) MK.label(ctx, l.s, l.x, l.y - l.t * 8, l.c || A.GOLD[0], 'center');
      MK.led(ctx, env.marbles(), env.marbles() <= 0, st.time);
    },
    down(p) {
      if (!p.inCard || p.btn !== 0) return false;
      if (st.phase === 'ready') { startCharge(p.id); return true; }
      return st.phase !== 'ready';
    },
    up(p) { if (st.phase === 'charge' && pl.by === p.id) release(); },
    key(code, down) {
      if (code !== 'Space' && code !== 'ArrowDown' && code !== 'Enter') return false;
      if (down) startCharge('key'); else if (st.phase === 'charge' && pl.by === 'key') release();
      return true;
    },
    cancel() { if (st.phase === 'charge') { pl.cancel(); st.phase = 'ready'; } },
    leave() { if (st.phase === 'charge') { pl.cancel(); st.phase = 'ready'; } },
    auto,
    inPlay: () => st.phase === 'charge' || st.phase === 'fly' || I.busy(s),
    busy: () => st.phase === 'charge',
    hint() {
      if (st.phase === 'charge') return '松手发射';
      if (st.phase === 'fly' && st.shot && st.shot.broke) return '冰碎了：珠子落进亮洞吐筹码';
      if (st.phase === 'ready' && env.marbles() > 0 && m().shots < 5) return '按住拉弹簧、松手打铁珠：砸碎冰块，放出来的珠子落进亮洞吐筹码';
      return '';
    },
    // 大台的左栏窄（一行七八个字）：一行只说一件事
    info() {
      const k = env.val('k'), lo = Math.ceil(k / 2);
      const out = [
        ['亮 ' + st.lit.length + ' 个洞', null],
        ['进一颗吐 ' + env.val('v') + ' 个', null],
        [env.val('h') + ' 下砸碎一块冰', null],
        ['一块冻 ' + (lo === k ? k : lo + '–' + k) + ' 颗', null],
        ['台上冻着 ' + gemsLeft() + ' 颗', null],
      ];
      if (st.shot && st.shot.broke) out.push(['这一发碎 ' + st.shot.broke + ' 块', A.GOLD[0]], ['一堆 6 块全碎：大奖', A.GOLD[0]]);
      out.push(['这一局碎了 ' + (m().iceBroke || 0) + ' 块', null]);
      const pity = env.lv('pity');
      if (pity) out.push(['连空 ' + (pity === 2 ? 2 : 3) + ' 发多亮一个', null], ['（已空 ' + m().misses + ' 发）', null]);
      return out;
    },
    onUpgrade(k) {
      if (k === 'h') { I.capHp(s, env.val('h')); st.gauge = null; }
      if (k === 'k') { const N = env.val('k'); for (const b of s.blocks) b.n = Math.max(b.n, Math.ceil(N / 2)); }
    },
    debug: () => ({ phase: st.phase, lit: st.lit, blocks: s.blocks.length, gems: gemsLeft(), broke: m().iceBroke || 0 }),
  };
});
