/*
 * 主线的平台面（弹指、保龄、足球三套共用，11-11 全套粗做）。台面格坐标跟 sims/mainline.js 一样：x 14..178、y 20..145（底下那条槽留给珠袋）。
 *   没有坡、没有发射道、没有挡板；顶上两个斜角跟卡面一样是墙。珠子、史莱姆都是圆盘。
 *   珠子撞史莱姆先问台子（s.onHit(m, b, impact, nx, ny)，n 从史莱姆指向珠子），回：
 *     'pass' 碾过去：不弹、不减速    'plow' 很重的推着走：史莱姆跟着往前滑，珠子慢一点
 *     'hit' 打着了：两个都弹开（史莱姆被撞开，滑出去）    'ding' 打不动：珠子弹回来，史莱姆不动    'soft' 太轻、刚挨过：轻轻分开
 *   史莱姆被撞开（m.vx、m.vy，还记着 m.knock = { b, depth }）滑着撞上别的史莱姆，发 'knock' 事件（台子决定别的挨不挨一下、传不传下去）。
 *     不动的（m.still、boss）撞不开。
 *   三种规矩（s.mode）：
 *     flick 弹指：摩擦大，珠子自己停（停下发 'rest'），停在哪下一杆从哪打
 *     bowl  保龄：摩擦小，从台底滚上去；滚过台顶那条线、或者停了，这一颗就完（'end'）。两边是沟：碰了台边慢一半
 *     kick  足球：摩擦中，台边弹得狠；台顶正中一个门，从门里过线发 'goal'，珠子弹回来
 *   珠子 b.hold > 0：被粘住、冻住，原地不动，数完了接着走。
 * 定步长 1/480 秒。
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.MainFlat = api;
}(typeof self !== 'undefined' ? self : globalThis, function () {
  'use strict';
  const DT = 1 / 480;
  const X0 = 14, X1 = 178, Y0 = 20, Y1 = 145, CH = 20, BALL_R = 3.5;
  // 顶上两个斜角（跟卡面的直顶加斜角一样）
  const SEGS = [[X0, Y0 + CH, X0 + CH, Y0], [X1 - CH, Y0, X1, Y0 + CH]];
  const GOAL = { x0: 80, x1: 112, y: Y0 };          // 足球：台顶正中的门
  const HOME = { flick: { x: 96, y: 134 }, bowl: { x: 96, y: 138 }, kick: { x: 96, y: 132 } };
  // 史莱姆能趴的地方（每套不一样：保龄留出底下那截球道，足球离门远一点）
  const ZONES = { flick: { x0: 26, x1: 166, y0: 36, y1: 112 }, bowl: { x0: 28, x1: 164, y0: 30, y1: 96 }, kick: { x0: 26, x1: 166, y0: 44, y1: 112 } };
  const MODES = {
    flick: { mu: 46, drag: 0.7, we: 0.6, vmax: 240 },
    bowl: { mu: 6, drag: 0.04, we: 0.5, vmax: 210 },
    kick: { mu: 16, drag: 0.22, we: 0.85, vmax: 270 },
  };
  const SLIME_MU = 130, SLIME_DRAG = 1.2;
  const massOf = m => (m.still || m.boss ? Infinity : m.size === 'b' ? 2 : m.size === 's' ? 0.8 : 1.2);
  const WMASS = [0.6, 1, 2, 4];

  function create(opts) {
    opts = opts || {};
    return { mode: opts.mode || 'flick', balls: [], slimes: [], events: [], flippers: [], parts: {}, cover: 0, time: 0, seq: 0, onHit: null, quiet: false };
  }
  const emit = (s, e) => { if (!s.quiet) s.events.push(e); };
  const cfg = s => MODES[s.mode] || MODES.flick;
  function setMode(s, mode) { s.mode = mode; }
  const home = s => HOME[s.mode] || HOME.flick;
  // 放一颗在发球点（发球点上已经有一颗就往旁边挪一点）
  function load(s, extra) {
    const H = home(s);
    const b = Object.assign({ id: ++s.seq, x: H.x, y: H.y, vx: 0, vy: 0, r: BALL_R, state: 'rest', age: 0, m: 1, hold: 0, shot: null }, extra || {});
    s.balls.push(b);
    return b;
  }
  // 弹出去：(vx, vy) 是速度
  function launch(s, b, vx, vy) {
    b.vx = vx; b.vy = vy; b.state = 'play'; b.age = 0; b.slowT = 0;
    emit(s, { type: 'launch', b });
    return b;
  }
  // 史莱姆贴着台边、或者贴着别的史莱姆（铁母珠"夹住"用）
  function pinned(s, m, skip) {
    const pad = 1.5;
    if (m.x - m.r < X0 + pad || m.x + m.r > X1 - pad || m.y - m.r < Y0 + pad || m.y + m.r > Y1 - pad) return true;
    for (const o of s.slimes) {
      if (o === m || o === skip || !o.solid || o.state === 'pop') continue;
      if (Math.hypot(o.x - m.x, o.y - m.y) < o.r + m.r + pad) return true;
    }
    return false;
  }
  // 圆和线段（斜角）
  function segPush(o, a, b, e) {
    const [x0, y0] = a, [x1, y1] = b, vx = x1 - x0, vy = y1 - y0, L2 = vx * vx + vy * vy;
    let t = ((o.x - x0) * vx + (o.y - y0) * vy) / L2; t = t < 0 ? 0 : t > 1 ? 1 : t;
    const qx = x0 + vx * t, qy = y0 + vy * t, dx = o.x - qx, dy = o.y - qy, d = Math.hypot(dx, dy);
    if (d >= o.r || d < 1e-6) return 0;
    const nx = dx / d, ny = dy / d;
    o.x = qx + nx * o.r; o.y = qy + ny * o.r;
    const vn = o.vx * nx + o.vy * ny;
    if (vn >= 0) return 0;
    o.vx -= (1 + e) * vn * nx; o.vy -= (1 + e) * vn * ny;
    return -vn;
  }
  // 台边：返回撞得多重（0 是没撞）。bowl 的球碰了两边的沟就慢一半；kick 从门里过线发 goal
  function walls(s, o, e, isBall) {
    let hit = 0;
    if (o.x - o.r < X0) { o.x = X0 + o.r; if (o.vx < 0) { hit = Math.max(hit, -o.vx); o.vx = -o.vx * e; } }
    if (o.x + o.r > X1) { o.x = X1 - o.r; if (o.vx > 0) { hit = Math.max(hit, o.vx); o.vx = -o.vx * e; } }
    if (o.y + o.r > Y1) { o.y = Y1 - o.r; if (o.vy > 0) { hit = Math.max(hit, o.vy); o.vy = -o.vy * e; } }
    if (o.y - o.r < Y0) {
      if (isBall && s.mode === 'bowl') return -1;   // 保龄：滚过台顶，这一颗完了
      const inGoal = isBall && s.mode === 'kick' && o.x > GOAL.x0 + o.r && o.x < GOAL.x1 - o.r;
      o.y = Y0 + o.r;
      if (o.vy < 0) { hit = Math.max(hit, -o.vy); o.vy = -o.vy * e; if (inGoal) emit(s, { type: 'goal', b: o, x: o.x, y: Y0 }); }
    }
    for (const sg of SEGS) hit = Math.max(hit, segPush(o, [sg[0], sg[1]], [sg[2], sg[3]], e));
    return hit;
  }
  function slow(o, mu, drag) {
    const sp = Math.hypot(o.vx, o.vy);
    if (sp <= 0) return 0;
    const dec = (mu + drag * sp) * DT;
    if (dec >= sp) { o.vx = 0; o.vy = 0; return 0; }
    const k = (sp - dec) / sp; o.vx *= k; o.vy *= k;
    return sp - dec;
  }
  // 珠子碰史莱姆
  function ballSlime(s, b, m) {
    const dx = b.x - m.x, dy = b.y - m.y, rr = m.r + b.r, d2 = dx * dx + dy * dy;
    if (d2 >= rr * rr) return;
    const d = Math.sqrt(d2) || 1e-6, nx = dx / d, ny = dy / d;
    const vn = b.vx * nx + b.vy * ny;   // 珠子朝着史莱姆走是负的
    const mvn = (m.vx || 0) * nx + (m.vy || 0) * ny;
    const rel = vn - mvn;
    if (rel >= 0) { b.x = m.x + nx * rr; b.y = m.y + ny * rr; return; }
    const impact = -rel;
    const res = s.onHit ? s.onHit(m, b, impact, nx, ny) : 'hit';
    const ev = { type: 'slime', m, b, impact, nx, ny, x: m.x + nx * m.r, y: m.y + ny * m.r, res };
    if (res === 'pass' || m.state === 'pop') { emit(s, ev); return; }
    const mb = b.m || 1, mm = massOf(m);
    if (res === 'plow' && mm < Infinity) {
      // 推着走：史莱姆跟着珠子往前滑，珠子慢两成
      m.x = b.x - nx * rr; m.y = b.y - ny * rr;
      m.vx = (m.vx || 0) + (-vn) * -nx * 1.1; m.vy = (m.vy || 0) + (-vn) * -ny * 1.1;
      b.vx *= 0.8; b.vy *= 0.8;
      if (!m.knock || m.knock.b !== b) m.knock = { b, depth: 1 };
      emit(s, ev); return;
    }
    b.x = m.x + nx * rr; b.y = m.y + ny * rr;
    if (res === 'ding' || res === 'soft' || mm === Infinity) {
      const e = res === 'soft' ? 0.4 : m.bump || 0.9;
      b.vx -= (1 + e) * rel * nx; b.vy -= (1 + e) * rel * ny;
      emit(s, ev); return;
    }
    // 打着了：按质量交换（史莱姆被撞开）
    const e = 0.8, j = -(1 + e) * rel / (1 / mb + 1 / mm);
    b.vx += j / mb * nx; b.vy += j / mb * ny;
    m.vx = (m.vx || 0) - j / mm * nx; m.vy = (m.vy || 0) - j / mm * ny;
    m.knock = { b, depth: 1 };
    emit(s, ev);
  }
  // 史莱姆碰史莱姆：滑着的撞上别的，发 knock
  function slimeSlime(s, a, c) {
    const dx = c.x - a.x, dy = c.y - a.y, rr = a.r + c.r, d2 = dx * dx + dy * dy;
    if (d2 >= rr * rr) return;
    const d = Math.sqrt(d2) || 1e-6, nx = dx / d, ny = dy / d, ma = massOf(a), mc = massOf(c);
    const rv = ((c.vx || 0) - (a.vx || 0)) * nx + ((c.vy || 0) - (a.vy || 0)) * ny;
    // 分开
    const ia = ma === Infinity ? 0 : 1 / ma, ic = mc === Infinity ? 0 : 1 / mc, tot = ia + ic;
    if (tot > 0) {
      const pen = rr - d;
      a.x -= nx * pen * ia / tot; a.y -= ny * pen * ia / tot;
      c.x += nx * pen * ic / tot; c.y += ny * pen * ic / tot;
      if (ia) { a.tx = a.x; a.ty = a.y; } if (ic) { c.tx = c.x; c.ty = c.y; }
    }
    if (rv >= 0 || tot === 0) return;
    const j = -(1.6) * rv / tot;
    if (ia) { a.vx = (a.vx || 0) - j * ia * nx; a.vy = (a.vy || 0) - j * ia * ny; }
    if (ic) { c.vx = (c.vx || 0) + j * ic * nx; c.vy = (c.vy || 0) + j * ic * ny; }
    if (-rv > 25) {
      // 谁是滑着撞过来的：速度大的那个
      const sa = Math.hypot(a.vx || 0, a.vy || 0), sc = Math.hypot(c.vx || 0, c.vy || 0), mover = a.knock && (!c.knock || sa >= sc) ? a : c.knock ? c : null;
      if (mover) emit(s, { type: 'knock', a: mover, c: mover === a ? c : a, impact: -rv, x: a.x + nx * a.r, y: a.y + ny * a.r });
    }
  }
  function ballBall(s, a, b) {
    const dx = b.x - a.x, dy = b.y - a.y, rr = a.r + b.r, d2 = dx * dx + dy * dy;
    if (d2 >= rr * rr || d2 < 1e-9) return;
    const d = Math.sqrt(d2), nx = dx / d, ny = dy / d, ia = 1 / (a.m || 1), ib = 1 / (b.m || 1), pen = rr - d;
    a.x -= nx * pen * ia / (ia + ib); a.y -= ny * pen * ia / (ia + ib); b.x += nx * pen * ib / (ia + ib); b.y += ny * pen * ib / (ia + ib);
    const rv = (b.vx - a.vx) * nx + (b.vy - a.vy) * ny;
    if (rv >= 0) return;
    const j = -1.9 * rv / (ia + ib);
    a.vx -= j * ia * nx; a.vy -= j * ia * ny; b.vx += j * ib * nx; b.vy += j * ib * ny;
    if (b.state === 'rest') b.state = 'play'; if (a.state === 'rest') a.state = 'play';
    if (-rv > 25) emit(s, { type: 'clack', impact: -rv, x: a.x + nx * a.r, y: a.y + ny * a.r });
  }
  function step(s) {
    s.time += DT;
    const C = cfg(s);
    for (const b of s.balls) {
      if (b.state !== 'play') continue;
      if (b.hold > 0) { b.hold -= DT; continue; }
      b.age += DT;
      const sp = slow(b, C.mu * (b.mu || 1), C.drag * (b.mu || 1));
      b.x += b.vx * DT; b.y += b.vy * DT;
      const e = b.bouncy ? 1 : C.we;
      const h = walls(s, b, e, true);
      if (h < 0) { b.state = 'end'; emit(s, { type: 'end', b, top: true }); continue; }
      if (h > 0) {
        if (s.mode === 'bowl') { b.vx *= 0.5; b.vy *= 0.85; }   // 沟：碰了台边慢下来
        if (b.bouncy && b.bounceV) { const v = Math.hypot(b.vx, b.vy), want = Math.max(v, b.bounceV); if (v > 1e-6) { b.vx *= want / v; b.vy *= want / v; } }
        if (h > 12) emit(s, { type: 'hit', kind: 'wall', impact: h, x: b.x, y: b.y, b });
      }
      for (const m of s.slimes) { if (m.solid && m.state !== 'pop' && m.state !== 'wait') ballSlime(s, b, m); if (b.state !== 'play') break; }
      const v = Math.hypot(b.vx, b.vy), vmax = C.vmax * (b.vboost || 1);
      if (v > vmax) { b.vx *= vmax / v; b.vy *= vmax / v; }
      // 停了：弹指、足球停在原地等下一杆；保龄这一颗完了
      if (v < 4) {
        b.slowT = (b.slowT || 0) + DT;
        if (b.slowT > 0.12) {
          b.vx = b.vy = 0;
          if (s.mode === 'bowl') { b.state = 'end'; emit(s, { type: 'end', b }); }
          else { b.state = 'rest'; emit(s, { type: 'rest', b }); }
        }
      } else b.slowT = 0;
    }
    // 史莱姆：被撞开的滑、碰台边弹回来、碰别的发 knock
    for (const m of s.slimes) {
      if (m.state === 'pop' || m.state === 'wait' || (!m.vx && !m.vy)) continue;
      if (m.still || m.boss) { m.vx = m.vy = 0; continue; }
      slow(m, SLIME_MU, SLIME_DRAG);
      m.x += m.vx * DT; m.y += m.vy * DT;
      walls(s, m, 0.5, false);
      m.tx = m.x; m.ty = m.y;
      if (Math.hypot(m.vx, m.vy) < 3) { m.vx = 0; m.vy = 0; m.knock = null; }
    }
    const live = s.slimes.filter(m => m.solid && m.state !== 'pop' && m.state !== 'wait');
    for (let i = 0; i < live.length; i++) for (let j = i + 1; j < live.length; j++) {
      const a = live[i], c = live[j];
      if (!(a.vx || a.vy || c.vx || c.vy)) continue;
      slimeSlime(s, a, c);
    }
    const bs = s.balls.filter(b => b.state === 'play' || b.state === 'rest');
    for (let i = 0; i < bs.length; i++) for (let j = i + 1; j < bs.length; j++) if (bs[i].state === 'play' || bs[j].state === 'play') ballBall(s, bs[i], bs[j]);
    s.balls = s.balls.filter(b => b.state !== 'gone');
  }
  // 预测：从球心沿 (ux, uy) 走，先碰到哪只（瞄准线用）
  function firstHit(s, b, ux, uy, maxD) {
    let best = null;
    for (const m of s.slimes) {
      if (!m.solid || m.state === 'pop') continue;
      const rr = m.r + b.r, fx = m.x - b.x, fy = m.y - b.y, t = fx * ux + fy * uy;
      if (t < 0) continue;
      const q = fx * fx + fy * fy - t * t;
      if (q > rr * rr) continue;
      const tt = t - Math.sqrt(rr * rr - q);
      if (tt < 0 || tt > maxD || (best && tt >= best.t)) continue;
      best = { t: tt, m, hx: b.x + ux * tt, hy: b.y + uy * tt };
    }
    return best;
  }
  return { DT, X0, X1, Y0, Y1, YB: 154, CH, BALL_R, SEGS, GOAL, HOME, ZONES, MODES, WMASS, massOf, create, setMode, home, load, launch, step, pinned, firstHit,
    setCover() {}, setParts() { return false; } };
}));
