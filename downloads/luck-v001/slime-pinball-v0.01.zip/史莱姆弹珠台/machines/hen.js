/*
 * 鸡飞蛋打（鸡窝；进洞，小台 64 宽，11-11 粗做）。谷仓里一只母鸡趴在窝上，底下 9 个洞，亮着的三个是中奖洞。
 *   按住拉弹簧、松手打海绵珠（发射道、力度同基础机）。每打一发，母鸡在窝里下一个蛋（窝里最多【签】个，满了再打不多）。
 *   海绵珠撞到母鸡惹她一下；惹够【速】下，她扑腾飞走，窝里的蛋滚出来，落进亮洞一个吐【价】张券（摔进别的洞碎了）。
 *   蛋都落了洞，母鸡飞回来，重抽亮洞。海绵珠自己落洞不算钱。
 *   金蛋（碰运气）：飞走那一下 3% 有一个蛋是金的（×5）。鸡毛掸子（手上功夫 = 大奖）：一次飞走 4 个蛋落进亮洞。草编篮（打得深）：收满 150 个蛋。
 */
Machines.def('hen', env => {
  'use strict';
  const { A, sfx } = env;
  const K = A.kit, INK = A.INK;
  const HEN = { x: 60, y: 74, r: 10 }, NEST = [[48, 88, 7], [60, 90, 8], [72, 88, 7]];
  const s = Sim.createMachine((Date.now() ^ (Math.random() * 1e9)) >>> 0, { door: { cx: 60, cy: 80, r: 24 } });
  for (const [x, y, r] of NEST) Sim.addCircle(s, x, y, r, 'nest', 0.25, 0.1);
  Sim.addCircle(s, HEN.x, HEN.y, HEN.r, 'hen', 0.45, 0.05);
  const henCol = s.colliders[s.colliders.length - 1];
  Sim.buildGrid(s);
  const pegList = Sim.pegPositions({ door: { cx: 60, cy: 80, r: 24 } });
  const pl = MK.plunger(sfx);
  const st = { phase: 'ready', acc: { t: 0 }, time: 0, balls: [], eggs: 2, annoy: 0, lit: [], fly: null, back: 0, hitT: 0, labels: [], flash: new Map(), trail: [], gaugeT: null, caught: 0, auto: null };
  const m = () => env.m();
  const SPONGE = ['#e0a010', '#ffd23a', '#fff3a0'];
  const ballIm = MK.ball7(SPONGE);
  const EGG = ['.ab.', 'abbb', 'bbbc', '.bc.'];
  const eggIm = A.outlined(EGG, { a: '#ffffff', b: '#f6f0e2', c: '#d8ccb4' }, INK);
  const goldEgg = A.outlined(EGG, { a: '#fff6c0', b: '#ffd23a', c: '#c47a10' }, INK);
  const splatIm = A.outlined(['.y.y.', 'wwyww', '.www.'], { w: '#ffffff', y: '#ffd23a' }, INK);
  // 母鸡（台面格，2 倍画）：照桌面小预览那只放大 1.8 倍；飞的时候翅膀举起来；被惹到发红
  function henPaint(L, cx, cy, dir, k, flying) {
    const W3 = ['#ffffff', '#f0ece4', '#c8c0b4'];
    K.lP(L, [[cx - dir * 4 * k, cy - k], [cx - dir * 9 * k, cy - 7 * k], [cx - dir * 9 * k, cy - 2 * k], [cx - dir * 6 * k, cy + 2 * k]], W3[2]);
    K.lE(L, cx, cy, 6.2 * k, 4.6 * k, W3);
    K.lE(L, cx + dir * 4.5 * k, cy - 4.5 * k, 3 * k, 2.8 * k, W3);
    K.lE(L, cx + dir * 4 * k, cy - 7.6 * k, 1.2 * k, 1.1 * k, '#fe4c40'); K.lE(L, cx + dir * 5.6 * k, cy - 7.4 * k, 1.1 * k, 1.1 * k, '#fe4c40');
    K.lP(L, [[cx + dir * 7 * k, cy - 5.5 * k], [cx + dir * 9.5 * k, cy - 4.6 * k], [cx + dir * 7 * k, cy - 3.6 * k]], '#ff9700');
    K.lE(L, cx + dir * 6.4 * k, cy - 2.4 * k, 0.7 * k, 0.9 * k, '#fe4c40');
    if (flying) { K.lP(L, [[cx - 3 * k, cy - 1 * k], [cx - 1 * k, cy - 9 * k], [cx + 2 * k, cy - 1 * k]], W3[1]); K.lP(L, [[cx - 6 * k, cy], [cx - 9 * k, cy - 6 * k], [cx - 3 * k, cy - 2 * k]], W3[2]); }
    else K.lE(L, cx - dir * 0.6 * k, cy + 0.4 * k, 3.4 * k, 2.2 * k, ['#f0ece4', '#e6e0d4', '#b8b0a4']);
    for (const [dx, dy] of [[0, 0], [1, 0], [0, 1], [1, 1]]) K.lset(L, Math.floor(cx + dir * 4.8 * k) + dx, Math.floor(cy - 5.4 * k) + dy, INK);
  }
  const RED = c => (c === INK ? INK : A.mix(c, '#ff6a5a', 0.35));
  const henIm = (flying, mad) => A.layerSprite('hen:' + flying + mad, 40, 32, L => henPaint(L, 20, 19, 1, 1.8, flying), mad ? RED : null);

  // ---------- 亮洞 ----------
  function drawLit() {
    const all = [0, 1, 2, 3, 4, 5, 6, 7, 8];
    for (let i = 0; i < 3; i++) { const j = i + Math.floor(Math.random() * (9 - i)); [all[i], all[j]] = [all[j], all[i]]; }
    st.lit = all.slice(0, 3).sort((a, b) => a - b);
  }
  drawLit();

  // ---------- 打 ----------
  const canShoot = () => st.phase === 'ready' && env.marbles() > 0;
  function startCharge(by) { if (!canShoot()) { if (st.phase === 'ready') env.deny('marbles'); return false; } pl.start(by); st.phase = 'charge'; return true; }
  function release() {
    if (st.phase !== 'charge') return;
    const p = pl.release();
    if (!env.spend()) { st.phase = 'ready'; return; }
    st.balls.push({ x: Sim.LANE_CX, y: Sim.REST_Y, vx: 0, vy: -Sim.launchSpeed(s.cfg, p), r: Sim.BALL_R, t: 0, alive: true, lane: true, kind: 'shot' });
    st.phase = 'fly'; st.trail.length = 0; st.hits = 0;
    sfx.launch(p);
  }
  function cancel() { if (st.phase === 'charge') { pl.cancel(); st.phase = 'ready'; } }
  // 撞到母鸡：惹她一下（同一颗珠子贴着蹭不算两下）
  function onCol(b, col, impact) {
    if (col.kind === 'peg') { if (impact > 12) { sfx.pin(impact, col.id); st.flash.set(col.id, 0.12); } return; }
    if (col.kind === 'hen' && b.kind === 'shot' && impact > 15 && st.time - (b.henT || -1) > 0.2) {
      b.henT = st.time; st.annoy += 1; st.hitT = 0.25; st.hits += 1;
      sfx.pop(); env.shake(0.05);
      st.labels.push({ s: st.annoy + '/' + env.val('s'), x: HEN.x + 14, y: HEN.y - 14, t: 0, c: '#ff8a7a' });
      return;
    }
    if (impact > 20) sfx.wall(impact * 0.5);
  }
  function onLand(e) {
    const b = e.b;
    if (b.kind === 'shot') {
      // 一发打完：下一个蛋（窝满了不下）；惹够了飞走
      if (st.eggs < env.val('n')) { st.eggs += 1; st.labels.push({ s: '咯！', x: HEN.x - 16, y: HEN.y - 12, t: 0, c: '#ffffff' }); sfx.hop(6); }
      sfx.miss();
      return;
    }
    // 蛋落洞
    const lit = st.lit.includes(e.hole);
    if (lit) {
      const base = env.val('v') * (b.gold ? 5 : 1);
      env.award(base, { at: [Sim.holeCx(e.hole), 146], n: Math.min(6, base) });
      st.fly.won += 1; st.flashHole = { i: e.hole, t: 0.3 };
      if (b.gold) { env.toast('金蛋！×5', A.GOLD[0]); env.find('luck'); }
      sfx.win();
    } else { st.splats.push({ x: Sim.holeCx(e.hole), t: 0 }); sfx.splat(); }
    m().kills = (m().kills || 0) + 1;
    if (m().kills >= 150) env.find('deep');
  }
  st.splats = [];
  // 飞走：母鸡往左上扑腾出去，窝里的蛋往两边滚
  function flyOff() {
    st.phase = 'flyoff';
    st.fly = { t: 0, won: 0, eggs: st.eggs };
    henCol.x = -200; Sim.buildGrid(s);
    const n = st.eggs, goldAt = env.luck(0.03) ? Math.floor(Math.random() * n) : -1;
    for (let i = 0; i < n; i++) {
      const x = 48 + (n > 1 ? 24 * i / (n - 1) : 12), dir = x < 60 ? -1 : 1;
      st.balls.push({ x, y: 80 - (i % 2) * 2, vx: dir * (25 + Math.random() * 35) + (Math.random() - 0.5) * 10, vy: -40 - Math.random() * 30, r: 2.5, t: 0, alive: true, kind: 'egg', gold: i === goldAt });
    }
    st.eggs = 0; st.annoy = 0;
    sfx.flip();
    env.toast('母鸡飞走了！蛋滚出来了', '#ffffff');
  }
  function backHome() {
    henCol.x = HEN.x; Sim.buildGrid(s);
    if (st.fly && st.fly.won >= 4) env.jackpot();
    st.fly = null; st.phase = 'ready'; drawLit();
    env.save();
  }

  // ---------- 自动打（自测、截图用）：试过的力度里挑打得中母鸡的 ----------
  let table = null;
  function calcTable() {
    if (table) return table;
    table = [];
    for (let i = 0; i <= 100; i++) {
      const b = { x: Sim.LANE_CX, y: Sim.REST_Y, vx: 0, vy: -Sim.launchSpeed(s.cfg, i / 100), r: Sim.BALL_R, t: 0, alive: true, lane: true, kind: 'shot' };
      let hit = false; const q = s.quiet; s.quiet = true;
      for (let k = 0; k < 480 * 6 && b.alive && !hit; k++) MK.sideStep(s, [b], (bb, col, imp) => { if (col.kind === 'hen' && imp > 15) hit = true; });
      s.quiet = q; s.events.length = 0;
      table.push(hit);
    }
    return table;
  }
  function auto(dt) {
    const A_ = st.auto || (st.auto = { t: 0, target: 0.5 });
    if (st.phase === 'ready') {
      A_.t += dt; if (A_.t < 0.4 || env.marbles() <= 0) return; A_.t = 0;
      const T = calcTable(), good = []; T.forEach((h, i) => { if (h) good.push(i); });
      const k = window.__autoNoise || 0;
      A_.target = Math.max(0.06, Math.min(0.99, (good.length ? good[Math.floor(Math.random() * good.length)] : 50) / 100 + (Math.random() - 0.5) * 0.04 * k));
      startCharge('auto');
    } else if (st.phase === 'charge' && pl.by === 'auto') {
      const now = Sim.holdPower(pl.t), next = Sim.holdPower(pl.t + dt);
      if (now >= A_.target || next - A_.target > A_.target - now) release();
    }
  }

  return {
    sim: s,
    fine(f) {
      MK.fineHoles(f);
      MK.fineLane(f, Sim.DEFAULTS.guard);
      MK.finePegs(f, pegList);
      // 草窝：三团稻草叠成一个碗
      const L = f.layer(44, 18), STRAW = ['#ffe070', '#f0c040', '#c89820'];
      f.lE(L, 22, 10, 19, 6, STRAW);
      for (let x = 5; x < 40; x += 3) f.lset(L, x, 8 + (x % 2), '#c89820');
      f.lE(L, 22, 13, 17, 3.5, (x, y, u, v) => (v > 0.2 ? '#c89820' : '#e0a830'));
      f.outl(L);
      f.put(L, 38, 80);
      f.fineMeter();
    },
    update(dt) {
      st.time += dt;
      st.hitT = Math.max(0, st.hitT - dt);
      for (const [id, t] of st.flash) { if (t - dt <= 0) st.flash.delete(id); else st.flash.set(id, t - dt); }
      st.labels = st.labels.filter(l => (l.t += dt) < 0.8);
      st.splats = st.splats.filter(q => (q.t += dt) < 0.5);
      if (st.flashHole && (st.flashHole.t -= dt) <= 0) st.flashHole = null;
      if (st.phase === 'charge') pl.update(dt);
      if (st.balls.length) {
        st.acc.t += dt * 1.3;
        let n = 0;
        while (st.acc.t >= Sim.DT && n < 2000 && st.balls.length) {
          for (const e of MK.sideStep(s, st.balls, onCol)) {
            if (e.type === 'fallback') { env.refund(); sfx.fallback(); st.phase = 'ready'; }
            else onLand(e);
          }
          st.balls = st.balls.filter(b => b.alive);
          st.acc.t -= Sim.DT; n++;
        }
        s.events.length = 0;
        const sb = st.balls.find(b => b.kind === 'shot');
        if (sb) { st.trail.unshift([sb.x, sb.y]); if (st.trail.length > 6) st.trail.length = 6; }
      } else st.acc.t = 0;
      if (st.phase === 'fly' && !st.balls.length) {
        if (st.annoy >= env.val('s')) flyOff(); else { st.phase = 'ready'; env.save(); }
      }
      if (st.phase === 'flyoff') {
        st.fly.t += dt;
        if (!st.balls.length && st.fly.t > 1) { st.phase = 'back'; st.back = 0; }
      }
      if (st.phase === 'back') { st.back += dt / 0.6; if (st.back >= 1) backHome(); }
    },
    draw(ctx) {
      MK.holeLamps(ctx, st.lit, i => st.flashHole && st.flashHole.i === i && Math.sin(st.time * 40) > 0);
      // 窝里的蛋（母鸡挡住中间那几个）
      const n = st.eggs;
      for (let i = 0; i < n; i++) { const x = 47 + (n > 1 ? 26 * i / (n - 1) : 13); MK.spr(ctx, eggIm, Math.round(x - 3), 79 + (i % 2)); }
      // 母鸡：在窝上（被惹到抖一下、发红）；飞走 / 飞回来
      let hx = HEN.x, hy = HEN.y, flying = false;
      if (st.phase === 'flyoff') { const t = Math.min(1, st.fly.t / 0.7); hx = HEN.x - 50 * t; hy = HEN.y - 110 * t + 20 * Math.sin(Math.PI * t); flying = true; }
      if (st.phase === 'back') { const t = MK.ease(st.back); hx = HEN.x + 50 * (1 - t); hy = HEN.y - 110 * (1 - t); flying = t < 0.9; }
      if (st.hitT > 0) hx += Math.round(Math.sin(st.time * 60));
      if (!(st.phase === 'flyoff' && st.fly.t > 0.7)) MK.spr(ctx, henIm(flying, st.hitT > 0 || (st.annoy >= env.val('s') - 1 && st.annoy > 0 && Math.sin(st.time * 8) > 0.5)), Math.round(hx - 20), Math.round(hy - 19));
      for (const [id] of st.flash) { const c = s.colliders[id]; if (c && c.kind === 'peg') MK.spr(ctx, MK.sprites().pegHit, c.x - 2, c.y - 2); }
      for (const b of st.balls) {
        if (b.kind === 'egg') { const im = b.gold ? goldEgg : eggIm; MK.spr(ctx, im, Math.round(b.x - 3), Math.round(b.y - 3)); continue; }
        MK.spr(ctx, ballIm, Math.round(b.x - 3.5), Math.round(b.y - 3.5));
      }
      for (const q of st.splats) MK.spr(ctx, splatIm, q.x - 3, 141);
      MK.lane(ctx, st.phase === 'charge' ? pl.pull() : 0, env.marbles() > 0 && (st.phase === 'ready' || st.phase === 'charge') ? ballIm : null);
      A.drawMeter(ctx, pl.power(), st.phase === 'charge');
      for (const l of st.labels) MK.label(ctx, l.s, l.x, l.y - l.t * 10, l.c, 'center');
      MK.led(ctx, env.marbles(), env.marbles() <= 0, st.time);
    },
    down(p) {
      if (!p.inCard || p.btn !== 0) return false;
      if (st.phase === 'ready') { startCharge(p.id); return true; }
      return st.phase !== 'ready';
    },
    up(p) { if (st.phase === 'charge' && pl.by === p.id) release(); },
    key(code, down) {
      if (code !== 'Space' && code !== 'ArrowDown' && code !== 'Enter') return false;
      if (down) { if (st.phase === 'ready') startCharge('key'); }
      else if (st.phase === 'charge' && pl.by === 'key') release();
      return true;
    },
    cancel,
    leave: cancel,
    auto,
    inPlay: () => st.phase !== 'ready',
    busy: () => st.phase === 'charge' || st.phase === 'fly',
    hint() {
      if (st.phase === 'ready') return env.marbles() > 0 ? '按住拉弹簧（鼠标或空格），松手打。打中母鸡惹她，惹够了她飞走，蛋滚出来' : '';
      if (st.phase === 'charge') return '松手发射';
      if (st.phase === 'flyoff') return '蛋落进亮洞才算';
      return '';
    },
    info() {
      return [
        ['窝里 ' + st.eggs + '/' + env.val('n') + ' 个蛋（一发下一个）', null],
        ['惹了母鸡 ' + st.annoy + '/' + env.val('s') + ' 下就飞', st.annoy ? '#ff8a7a' : null],
        ['蛋落进亮洞一个吐 ' + env.val('v') + ' 张', null],
      ];
    },
    onUpgrade() {},
    debug: () => ({ phase: st.phase, eggs: st.eggs, annoy: st.annoy, marbles: env.marbles(), shots: m().shots, lit: st.lit.join(',') }),
  };
});
