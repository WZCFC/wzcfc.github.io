/*
 * 接二连三（马戏团；进洞，小台 64 宽，11-11 粗做）。幕布前一只海豹站在鼓上，底下 9 个洞，亮着的三个是中奖洞。
 *   按住拉弹簧、松手打橡胶珠（发射道、力度同基础机）。珠子撞到海豹，海豹顶它一下（往外弹），倍数加一。
 *   珠子落进亮洞：吐【价】×倍数 张券，倍数回到 1；落进别的洞，倍数留着，下一发接着加。
 *   海豹一共顶满【速】下谢幕：从鼻子上抛出【救】个球，落进亮洞的也照现在的倍数算；抛完倍数回到 1。
 *   金球（碰运气）：谢幕抛的球 3% 是金的（×5）。小丑鼻子（手上功夫 = 大奖）：一发让海豹顶 5 下。门票本（打得深）：谢幕 20 次。
 */
Machines.def('circus', env => {
  'use strict';
  const { A, sfx } = env;
  const K = A.kit, INK = A.INK;
  const SEAL = { x: 64, y: 78, r: 10 }, DRUM = { x: 64, y: 101, r: 13 }, KICK = 70, VMAX = 230;
  const DOOR = { cx: 64, cy: 84, r: 22 };
  const s = Sim.createMachine((Date.now() ^ (Math.random() * 1e9)) >>> 0, { door: DOOR });
  Sim.addCircle(s, DRUM.x, DRUM.y, DRUM.r, 'drum', 0.3, 0.08);
  Sim.addCircle(s, SEAL.x, SEAL.y, SEAL.r, 'seal', 0.55, 0.02);
  Sim.buildGrid(s);
  const pegList = Sim.pegPositions({ door: DOOR });
  const pl = MK.plunger(sfx);
  const st = { phase: 'ready', acc: { t: 0 }, time: 0, balls: [], mult: 1, hits: 0, shotHits: 0, lit: [], show: null, nod: 0, flash: new Map(), labels: [], auto: null };
  const m = () => env.m();
  const RUBBER = ['#b8322a', '#fe4c40', '#ff8a7a'];
  const ballIm = MK.ball7(RUBBER), goldIm = MK.ball7(['#c47a10', '#ffd23a', '#fff3a0']), toyIm = MK.ball7(['#1a5fb0', '#2f86ea', '#7ac0ff']);
  // 海豹（台面格，2 倍画）：照桌面小预览那只放大 2.2 倍，鼻子上顶个球；被撞到点一下头
  const sealIm = nod => A.layerSprite('seal:' + nod, 30, 36, L => {
    const S3 = ['#9ab8d4', '#6a8aa8', '#4a6a88'], k = 2.2, cx = 15, yb = 34;
    K.lE(L, cx, yb - 4 * k, 3.2 * k, 4.2 * k, S3);
    K.lE(L, cx + 1.2 * k, yb - (9 - nod) * k, 2.2 * k, 1.9 * k, S3);
    for (const [dx, dy] of [[0, 0], [1, 0], [0, 1], [1, 1]]) K.lset(L, Math.floor(cx + 3 * k) + dx, Math.floor(yb - (9.6 - nod) * k) + dy, INK);
    K.lE(L, cx - 0.5 * k, yb - 2 * k, 1.4 * k, 2 * k, S3[2]);
    K.lP(L, [[cx - 3 * k, yb - 1], [cx - 6 * k, yb], [cx - 3 * k, yb - 3 * k]], S3[2]);
  });

  function drawLit() {
    const all = [0, 1, 2, 3, 4, 5, 6, 7, 8];
    for (let i = 0; i < 3; i++) { const j = i + Math.floor(Math.random() * (9 - i)); [all[i], all[j]] = [all[j], all[i]]; }
    st.lit = all.slice(0, 3).sort((a, b) => a - b);
  }
  drawLit();

  // ---------- 打 ----------
  const canShoot = () => st.phase === 'ready' && env.marbles() > 0;
  function startCharge(by) { if (!canShoot()) { if (st.phase === 'ready') env.deny('marbles'); return false; } pl.start(by); st.phase = 'charge'; return true; }
  function release() {
    if (st.phase !== 'charge') return;
    const p = pl.release();
    if (!env.spend()) { st.phase = 'ready'; return; }
    st.balls.push({ x: Sim.LANE_CX, y: Sim.REST_Y, vx: 0, vy: -Sim.launchSpeed(s.cfg, p), r: Sim.BALL_R, t: 0, alive: true, lane: true, kind: 'shot' });
    st.phase = 'fly'; st.shotHits = 0;
    sfx.launch(p);
  }
  function cancel() { if (st.phase === 'charge') { pl.cancel(); st.phase = 'ready'; } }
  // 撞到海豹：顶出去（沿撞上的那个方向加一把速度），倍数加一
  function onCol(b, col, impact, h) {
    if (col.kind === 'peg') { if (impact > 12) { sfx.pin(impact, col.id); st.flash.set(col.id, 0.12); } return; }
    if (col.kind === 'seal' && impact > 10 && st.time - (b.sealT || -1) > 0.15) {
      b.sealT = st.time;
      b.vx += h.nx * KICK; b.vy += h.ny * KICK;
      const v = Math.hypot(b.vx, b.vy); if (v > VMAX) { b.vx *= VMAX / v; b.vy *= VMAX / v; }
      if (b.kind === 'shot') { st.mult += 1; st.hits += 1; st.shotHits += 1; }
      st.nod = 0.18;
      sfx.bump(impact + 60);
      st.labels.push({ s: '×' + st.mult, x: SEAL.x + 12, y: SEAL.y - 16, t: 0, c: A.GOLD[0] });
      return;
    }
    if (impact > 20) sfx.wall(impact * 0.5);
  }
  function pay(hole, gold) {
    const base = env.val('v') * st.mult * (gold ? 5 : 1);
    env.award(base, { at: [Sim.holeCx(hole), 146], n: Math.min(8, Math.ceil(base / 2)) });
    st.flashHole = { i: hole, t: 0.3 };
    sfx.win();
  }
  function onLand(e) {
    const b = e.b, lit = st.lit.includes(e.hole);
    if (b.kind === 'shot') {
      if (st.shotHits >= 5) env.jackpot();
      if (lit) { pay(e.hole, false); st.mult = 1; m().kills = (m().kills || 0) + 1; }
      else sfx.miss();
      return;
    }
    // 谢幕抛的球
    if (lit) { pay(e.hole, b.gold); if (b.gold) { env.toast('金球！×5', A.GOLD[0]); env.find('luck'); } }
  }
  // 谢幕：海豹从鼻子上把球一个一个抛出去
  function curtain() {
    st.phase = 'show';
    const n = env.val('n'), goldAt = env.luck(0.03) ? Math.floor(Math.random() * n) : -1;
    st.show = { t: 0, n, thrown: 0, goldAt };
    env.toast('谢幕！海豹抛 ' + n + ' 个球，照 ×' + st.mult + ' 算', A.GOLD[0]);
    sfx.open();
  }

  // ---------- 自动打：挑打得到海豹的力度 ----------
  let table = null;
  function calcTable() {
    if (table) return table;
    table = [];
    for (let i = 0; i <= 100; i++) {
      const b = { x: Sim.LANE_CX, y: Sim.REST_Y, vx: 0, vy: -Sim.launchSpeed(s.cfg, i / 100), r: Sim.BALL_R, t: 0, alive: true, lane: true, kind: 'probe' };
      let hit = 0; const q = s.quiet; s.quiet = true;
      for (let k = 0; k < 480 * 8 && b.alive; k++) MK.sideStep(s, [b], (bb, col, imp, h) => { if (col.kind === 'seal' && imp > 10 && k - (bb.k || -99) > 70) { bb.k = k; hit++; bb.vx += h.nx * KICK; bb.vy += h.ny * KICK; } });
      s.quiet = q; s.events.length = 0;
      table.push(hit);
    }
    return table;
  }
  function auto(dt) {
    const A_ = st.auto || (st.auto = { t: 0, target: 0.5 });
    if (st.phase === 'ready') {
      A_.t += dt; if (A_.t < 0.4 || env.marbles() <= 0) return; A_.t = 0;
      const T = calcTable(), good = []; T.forEach((h, i) => { if (h > 0) good.push(i); });
      const k = window.__autoNoise || 0;
      A_.target = Math.max(0.06, Math.min(0.99, (good.length ? good[Math.floor(Math.random() * good.length)] : 50) / 100 + (Math.random() - 0.5) * 0.04 * k));
      startCharge('auto');
    } else if (st.phase === 'charge' && pl.by === 'auto') {
      const now = Sim.holdPower(pl.t), next = Sim.holdPower(pl.t + dt);
      if (now >= A_.target || next - A_.target > A_.target - now) release();
    }
  }

  return {
    sim: s,
    fine(f) {
      MK.fineHoles(f);
      MK.fineLane(f, Sim.DEFAULTS.guard);
      MK.finePegs(f, pegList);
      // 鼓：蓝鼓身、金边、红色鼓面
      const L = f.layer(30, 26), x0 = DRUM.x - 15, y0 = DRUM.y - 13;
      f.lR(L, 2, 6, 26, 16, (x, y) => (y === 6 || y === 21 ? '#ffd23a' : y === 7 || y === 20 ? '#e0a010' : (x + y) % 6 < 3 ? '#2f86ea' : '#1a5fb0'));
      f.lE(L, 15, 6, 13, 3, (x, y, u, v) => (u * u + v * v > 0.6 ? '#ffd23a' : '#fe4c40'));
      f.outl(L);
      f.put(L, x0, y0);
      f.fineMeter();
    },
    update(dt) {
      st.time += dt;
      st.nod = Math.max(0, st.nod - dt);
      for (const [id, t] of st.flash) { if (t - dt <= 0) st.flash.delete(id); else st.flash.set(id, t - dt); }
      st.labels = st.labels.filter(l => (l.t += dt) < 0.8);
      if (st.flashHole && (st.flashHole.t -= dt) <= 0) st.flashHole = null;
      if (st.phase === 'charge') pl.update(dt);
      if (st.phase === 'show') {
        const sh = st.show; sh.t += dt;
        while (sh.thrown < sh.n && sh.t > 0.3 + sh.thrown * 0.22) {
          const side = sh.thrown % 2 ? 1 : -1;
          st.balls.push({ x: SEAL.x + 4, y: SEAL.y - 16, vx: side * (30 + Math.random() * 50), vy: -70 - Math.random() * 40, r: 2.8, t: 0, alive: true, kind: 'toy', gold: sh.thrown === sh.goldAt });
          sh.thrown++; st.nod = 0.15; sfx.pop();
        }
        if (sh.thrown >= sh.n && !st.balls.length && sh.t > 1) {
          st.show = null; st.mult = 1; st.hits = 0; drawLit(); st.phase = 'ready';
          m().deep = (m().deep || 0) + 1; if (m().deep >= 20) env.find('deep');
          env.save();
        }
      }
      if (st.balls.length) {
        st.acc.t += dt * 1.3;
        let n = 0;
        while (st.acc.t >= Sim.DT && n < 2000 && st.balls.length) {
          for (const e of MK.sideStep(s, st.balls, onCol)) {
            if (e.type === 'fallback') { env.refund(); sfx.fallback(); st.phase = 'ready'; }
            else onLand(e);
          }
          st.balls = st.balls.filter(b => b.alive);
          st.acc.t -= Sim.DT; n++;
        }
        s.events.length = 0;
      } else st.acc.t = 0;
      if (st.phase === 'fly' && !st.balls.length) {
        if (st.hits >= env.val('s')) curtain();
        else { if (st.mult === 1) drawLit(); st.phase = 'ready'; env.save(); }
      }
    },
    draw(ctx) {
      MK.holeLamps(ctx, st.lit, i => st.flashHole && st.flashHole.i === i && Math.sin(st.time * 40) > 0);
      // 海豹：站在鼓上，鼻子上的球（被顶的时候点头）
      const nod = st.nod > 0 ? 1 : 0;
      MK.spr(ctx, sealIm(nod), SEAL.x - 15, DRUM.y - 13 - 34 + 2);
      if (st.phase !== 'show' || st.show.thrown < st.show.n) MK.spr(ctx, toyIm, SEAL.x + 1, Math.round(SEAL.y - 22 + nod * 2 - (st.phase === 'show' ? Math.abs(Math.sin(st.time * 12)) * 4 : 0)));
      for (const [id] of st.flash) { const c = s.colliders[id]; if (c && c.kind === 'peg') MK.spr(ctx, MK.sprites().pegHit, c.x - 2, c.y - 2); }
      for (const b of st.balls) MK.spr(ctx, b.kind === 'shot' ? ballIm : b.gold ? goldIm : toyIm, Math.round(b.x - 3.5), Math.round(b.y - 3.5));
      // 倍数：鼓上一行
      if (st.mult > 1) MK.label(ctx, '×' + st.mult, DRUM.x, DRUM.y + 2, A.GOLD[0], 'center');
      MK.lane(ctx, st.phase === 'charge' ? pl.pull() : 0, env.marbles() > 0 && (st.phase === 'ready' || st.phase === 'charge') ? ballIm : null);
      A.drawMeter(ctx, pl.power(), st.phase === 'charge');
      for (const l of st.labels) MK.label(ctx, l.s, l.x, l.y - l.t * 10, l.c, 'center');
      MK.led(ctx, env.marbles(), env.marbles() <= 0, st.time);
    },
    down(p) {
      if (!p.inCard || p.btn !== 0) return false;
      if (st.phase === 'ready') { startCharge(p.id); return true; }
      return st.phase !== 'ready';
    },
    up(p) { if (st.phase === 'charge' && pl.by === p.id) release(); },
    key(code, down) {
      if (code !== 'Space' && code !== 'ArrowDown' && code !== 'Enter') return false;
      if (down) { if (st.phase === 'ready') startCharge('key'); }
      else if (st.phase === 'charge' && pl.by === 'key') release();
      return true;
    },
    cancel,
    leave: cancel,
    auto,
    inPlay: () => st.phase !== 'ready',
    busy: () => st.phase === 'charge' || st.phase === 'fly',
    hint() {
      if (st.phase === 'ready') return env.marbles() > 0 ? '按住拉弹簧（鼠标或空格），松手打。海豹顶一下倍数加一，落进亮洞才算' : '';
      if (st.phase === 'charge') return '松手发射';
      if (st.phase === 'show') return '谢幕：抛出来的球落进亮洞也算';
      return '';
    },
    info() {
      return [
        ['现在 ×' + st.mult + '，落进亮洞吐 ' + env.val('v') + '×' + st.mult + ' 张', st.mult > 1 ? A.GOLD[0] : null],
        ['顶了 ' + st.hits + '/' + env.val('s') + ' 下谢幕，抛 ' + env.val('n') + ' 个球', null],
      ];
    },
    onUpgrade() {},
    debug: () => ({ phase: st.phase, mult: st.mult, hits: st.hits, marbles: env.marbles(), shots: m().shots, lit: st.lit.join(',') }),
  };
});
