/*
 * 主线的桌子（从上往下看）。原生 640×360，桌上的东西一倍画（一格 = 1 像素），规整的像素画：平涂、深边、木纹按格子排，不撒噪点。
 *   房间：深蓝地毯，斜条纹
 *   桌面：一张木桌铺满整屏（x 4..636，下沿出画），竖着的木板，每块板两道木纹、隔几块一个疤；外圈一道桌沿
 *   史莱姆台：桌子正中偏上，垫一块酒红绒布（金线缝边），卡 2 倍（192×168）
 *   小游戏：一台一个展台（黑底座、铜边、铜名牌），卡 1 倍；没开的盖一块红绒布、挂价签。左右各三列、两排台位（SLOT），
 *     开了的台名牌底下堆着这台吐的券（每帧画，见 game.js）
 *   桌上的东西（OBJ，全局的系统一样一件，有了才摆上）：绒布底下一排，底边对齐在 BASE、铜名牌对齐在 PLATE_Y，柜台在正中、
 *     两边各两个位，间距一样：打卡钟（雇了小人以后）、金币罐（名牌上写多少金币）| 柜台（商店，打掉的 boss 摆在它顶上）| 电话、闹钟（能转生以后）
 *   icon(k)：机台界面左边那一排小图标（柜台、金币罐、打卡钟缩小画）
 *   镜头：拿起一台 = 从整张桌子（1 倍）推近到那一台，推完它正好落在机台界面的位置（史莱姆台 2 倍、小游戏 4 倍）。见 camFor
 */
window.MainDesk = (function () {
  'use strict';
  const A = Art, K = A.kit, INK = A.INK, GOLD = A.GOLD;
  const W = 640, H = 360;
  const canvas = (w, h) => { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; };
  const DESK = { x0: 4, x1: 636, y0: 6 };
  const MAIN = { x: 224, y: 20, w: 192, h: 168 };          // 史莱姆台在桌上（2 倍）
  const PAD = { x: 212, y: 12, w: 216, h: 186 };            // 它底下的绒布
  // 小游戏卡的左上角（1 倍，卡都是 64 宽）：绒布两边各三列、两排，挨着绒布那一列先上（1、2），往外 3、4，最外 5、6；
  //   名牌底下留一行堆券。列和列之间隔 2 格，展台底座比卡宽 1 格，挨着
  const SLOT = {
    L1: [146, 22], L2: [146, 148], L3: [80, 22], L4: [80, 148], L5: [14, 22], L6: [14, 148],
    R1: [430, 22], R2: [430, 148], R3: [496, 22], R4: [496, 148], R5: [562, 22], R6: [562, 148],
  };
  // 桌上的东西（1 倍）：绒布底下一排，底边都在 BASE，名牌都在 PLATE_Y。柜台正对着斩草除根（中线 320），
  //   两边的位中心在 228 / 172、412 / 468（东西之间都隔 30 格左右）
  const BASE = 320, PLATE_Y = 324;
  const OBJ = {
    shop: { x: 272, y: 248, w: 96, h: 72 },
    jar: { x: 214, y: 286, w: 28, h: 34 },
    clock: { x: 160, y: 288, w: 24, h: 32 },
    alarm: { x: 457, y: 296, w: 22, h: 24 },
  };
  const PLAY = { main: { x: 128, y: 12 } };                 // 机台界面里卡的左上角：史莱姆台 128；小游戏看卡宽，跟 Art.setCard 一样居中
  const COLORS = {
    floor: '#1a1d2e', floor2: '#20243a',
    rimHi: '#d8965e', rim: '#b0703e', rimLo: '#7a4626',
    plank: ['#a0643a', '#9a5e36'], seam: '#6a3a20', grain: '#87502e', knot: '#74421f', knot2: '#5e3418',
    felt: '#7a1a30', felt2: '#6c1529', feltHi: '#8e2238', stitch: '#e8c048',
    velv: ['#c8364a', '#a8283a', '#7a1a2a'],
  };
  const fl = Math.floor;

  // ---------- 哪台在哪 ----------
  const cw = id => (id === 'main' ? 96 : A.cwOf(id));
  // 桌上的框（1 倍坐标）
  function deskRect(id) {
    if (id === 'main') return { x: MAIN.x, y: MAIN.y, w: MAIN.w, h: MAIN.h };
    const M = MainData.MINIS.find(m => m.id === id), [x, y] = SLOT[M.slot];
    return { x, y, w: cw(id), h: 84 };
  }
  // 机台界面里卡的框（4 倍）
  function playRect(id) { const w = cw(id) * 4; return { x: id === 'main' ? PLAY.main.x : Math.round((W - w) / 2), y: 12, w, h: 336 }; }
  // 镜头：取桌子的哪一块铺满屏幕，正好把 id 那台放到机台界面的位置
  function camFor(id) {
    const d = deskRect(id), p = playRect(id), z = p.w / d.w;
    return { x: d.x - p.x / z, y: d.y - p.y / z, w: W / z, h: H / z, z };
  }
  const FULL = { x: 0, y: 0, w: W, h: H, z: 1 };
  const lerpCam = (a, b, t) => { const w = a.w + (b.w - a.w) * t; return { x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t, w, h: w * H / W, z: W / w }; };
  // 桌上一点 → 屏幕
  const toScreen = (cam, x, y) => [(x - cam.x) * cam.z, (y - cam.y) * cam.z];

  // ---------- 画桌子（不含卡；卡每帧另画） ----------
  function px(g, x, y, c) { g.fillStyle = c; g.fillRect(x, y, 1, 1); }
  function rect(g, x, y, w, h, c) { g.fillStyle = c; g.fillRect(x, y, w, h); }
  function floor(g) {
    rect(g, 0, 0, W, H, COLORS.floor);
    g.fillStyle = COLORS.floor2;
    for (let y = 0; y < H; y++) for (let x = (12 - (y % 12)) % 12; x < W; x += 12) g.fillRect(x, y, 2, 1);
  }
  function desk(g) {
    const { x0, x1, y0 } = DESK;
    // 桌沿：外一圈深边，上、左亮，右暗；7 像素宽
    rect(g, x0 - 1, y0 - 1, x1 - x0 + 2, H, INK);
    rect(g, x0, y0, x1 - x0, H, COLORS.rim);
    rect(g, x0, y0, x1 - x0, 2, COLORS.rimHi); rect(g, x0, y0, 2, H, COLORS.rimHi);
    rect(g, x1 - 2, y0, 2, H, COLORS.rimLo);
    const ix0 = x0 + 7, ix1 = x1 - 7, iy0 = y0 + 7;
    rect(g, ix0 - 1, iy0 - 1, ix1 - ix0 + 2, H, COLORS.rimLo);
    // 桌面：竖木板，22 宽
    const PW = 22;
    for (let k = 0, x = ix0; x < ix1; k++, x += PW) {
      const w = Math.min(PW, ix1 - x);
      rect(g, x, iy0, w, H, COLORS.plank[k % 2]);
      if (x > ix0) rect(g, x, iy0, 1, H, COLORS.seam);
      // 两道木纹：每 46 行断开 4 行，相邻板错开
      for (const gx of [6, 15]) {
        if (gx >= w - 1) continue;
        for (let y = iy0; y < H; y++) if (((y + k * 17 + gx * 3) % 46) >= 4) px(g, x + gx, y, COLORS.grain);
      }
      // 疤：每三块板一个，高度按板号排开
      if (k % 3 === 1) {
        const ky = iy0 + 40 + ((k * 71) % 230), kx = x + 10;
        rect(g, kx - 1, ky - 2, 3, 5, COLORS.knot); rect(g, kx - 2, ky - 1, 5, 3, COLORS.knot);
        px(g, kx, ky, COLORS.knot2); px(g, kx, ky - 1, COLORS.knot2);
        for (const gx of [6, 15]) for (let y = ky - 4; y <= ky + 4; y++) px(g, x + gx, y, COLORS.plank[k % 2]);
      }
    }
  }
  // 绒布：酒红底、每 4 格一个暗点（错开排），里面一圈金线（2 亮 2 空的虚线）
  function felt(g, x, y, w, h) {
    rect(g, x - 1, y - 1, w + 2, h + 2, INK);
    rect(g, x, y, w, h, COLORS.felt);
    g.fillStyle = COLORS.felt2;
    for (let j = 2; j < h - 2; j += 4) for (let i = ((j / 4) % 2) * 2 + 2; i < w - 2; i += 4) g.fillRect(x + i, y + j, 1, 1);
    rect(g, x, y, w, 1, COLORS.feltHi); rect(g, x, y, 1, h, COLORS.feltHi);
    g.fillStyle = COLORS.stitch;
    for (let i = 3; i < w - 3; i++) if (i % 4 < 2) { g.fillRect(x + i, y + 2, 1, 1); g.fillRect(x + i, y + h - 3, 1, 1); }
    for (let j = 3; j < h - 3; j++) if (j % 4 < 2) { g.fillRect(x + 2, y + j, 1, 1); g.fillRect(x + w - 3, y + j, 1, 1); }
  }
  // 卡的圆角轮廓（卡面格）：影子、发光框都用它
  const maskCache = {};
  function cardMask(pw) {
    if (maskCache[pw]) return maskCache[pw];
    const c = canvas(pw, 84), g = c.getContext('2d'), r = 6;
    g.fillStyle = '#000';
    for (let j = 0; j < 84; j++) for (let i = 0; i < pw; i++) {
      const cx = i < r ? r : i > pw - 1 - r ? pw - 1 - r : i, cy = j < r ? r : j > 83 - r ? 83 - r : j;
      if (Math.hypot(i - cx, j - cy) <= r + 0.3) g.fillRect(i, j, 1, 1);
    }
    return (maskCache[pw] = c);
  }
  // 影子：卡的轮廓往右下挪 3 格，压暗底下（平涂的一层半透明黑）
  function shadow(g, x, y, pw, z) {
    g.save(); g.globalAlpha = 0.42; g.imageSmoothingEnabled = false;
    g.drawImage(cardMask(pw), x + 3, y + 3, pw * z, 84 * z);
    g.restore();
  }
  // 展台：卡底下一条黑底座（铜边），再往下一块铜名牌；底座正中一个出票口
  const TIX_SLOT = 85;
  // 出票口那道缝的正中（桌上 1 倍坐标）
  function slotAt(id) { const r = deskRect(id); return { x: Math.round(r.x + r.w / 2), y: r.y + TIX_SLOT }; }
  function stand(g, id, x, y, w) {
    rect(g, x - 1, y + 78, w + 2, 10, INK);
    rect(g, x, y + 79, w, 1, GOLD[0]);
    rect(g, x, y + 80, w, 7, '#2a2230');
    rect(g, x, y + 80, w, 1, GOLD[2]);
    // 出票口：底座露出来那一截正中，一块铜框、一道黑缝（缝在 TIX_SLOT 那一行），券从这儿吐出来
    const sx0 = Math.round(x + w / 2) - 7;
    rect(g, sx0, y + TIX_SLOT - 1, 14, 3, GOLD[1]); rect(g, sx0, y + TIX_SLOT - 1, 14, 1, GOLD[0]);
    rect(g, sx0 + 1, y + TIX_SLOT, 12, 1, '#0a0610');
    const name = MainData.MINIS.find(m => m.id === id).name, tw = Txt.width(name, 12), pw = tw + 10, px0 = Math.round(x + w / 2 - pw / 2);
    rect(g, px0 - 1, y + 89, pw + 2, 15, INK);
    rect(g, px0, y + 90, pw, 13, GOLD[1]);
    rect(g, px0, y + 90, pw, 1, GOLD[0]); rect(g, px0, y + 102, pw, 1, GOLD[2]);
    for (const sx of [px0 + 2, px0 + pw - 3]) px(g, sx, y + 96, GOLD[2]);
    Txt.draw(g, name, x + w / 2, y + 90, { align: 'center', color: '#3a2410', outline: null });
  }
  // 整张桌子（vm：main 斩草除根摆没摆上、shown 上桌的小游戏、open 开了的、trophies 战利品个数、shop 柜台里摆哪几种弹珠、clock、alarm）
  function render(vm) {
    const c = canvas(W, H), g = c.getContext('2d');
    g.imageSmoothingEnabled = false;
    floor(g);
    desk(g);
    if (vm.main) felt(g, PAD.x, PAD.y, PAD.w, PAD.h);
    if (vm.main > 1) shadow(g, MAIN.x, MAIN.y, 96, 2);
    // 斩草除根的名牌（绒布底边）。vm.main：0 什么都没有、1 只有绒布（开场电话那会儿）、2 台子摆上了
    if (vm.main > 1) {
      // 挂在绒布底边往下（推近到史莱姆台时正好在画面外）
      const name = '斩草除根', tw = Txt.width(name, 12), pw = tw + 12, x0 = Math.round(MAIN.x + MAIN.w / 2 - pw / 2), y0 = PAD.y + PAD.h - 3;
      rect(g, x0 - 1, y0 - 1, pw + 2, 15, INK); rect(g, x0, y0, pw, 13, GOLD[1]); rect(g, x0, y0, pw, 1, GOLD[0]); rect(g, x0, y0 + 12, pw, 1, GOLD[2]);
      Txt.draw(g, name, x0 + pw / 2, y0, { align: 'center', color: '#3a2410', outline: null });
    }
    for (const M of MainData.MINIS) {
      if (!vm.shown.includes(M.id)) continue;
      const r = deskRect(M.id);
      shadow(g, r.x, r.y, r.w, 1);
      stand(g, M.id, r.x, r.y, r.w);
    }
    if (vm.shop) cabinet(g, OBJ.shop.x, OBJ.shop.y, vm.shop);
    // 打卡钟、闹钟底下也挂铜名牌（小人、转生），一眼知道是干什么的；名牌一排对齐
    if (vm.clock) { timeClock(g, OBJ.clock.x, OBJ.clock.y); plate(g, OBJ.clock.x + OBJ.clock.w / 2, PLATE_Y, '小人'); }
    if (vm.alarm) { alarmClock(g, OBJ.alarm.x, OBJ.alarm.y); plate(g, OBJ.alarm.x + OBJ.alarm.w / 2, PLATE_Y, '转生'); }
    return c;
  }
  // 只有地毯和桌子（机台界面两边栏底下垫的那一条用）
  let plainC = null;
  function plain() {
    if (plainC) return plainC;
    plainC = canvas(W, H); const g = plainC.getContext('2d');
    g.imageSmoothingEnabled = false; floor(g); desk(g);
    return plainC;
  }

  // ---------- 柜台：上半玻璃柜（一种弹珠一个罐，一排三个），下半木柜身（四格抽屉、铜把手），底下铜名牌 ----------
  function shade(g, x, y, w, h) { g.save(); g.globalAlpha = 0.42; rect(g, x + 3, y + 3, w, h, '#000'); g.restore(); }
  function plate(g, cx, y, name) {
    const tw = Txt.width(name, 12), pw = tw + 12, x0 = Math.round(cx - pw / 2);
    rect(g, x0 - 1, y - 1, pw + 2, 15, INK); rect(g, x0, y, pw, 13, GOLD[1]); rect(g, x0, y, pw, 1, GOLD[0]); rect(g, x0, y + 12, pw, 1, GOLD[2]);
    Txt.draw(g, name, cx, y, { align: 'center', color: '#3a2410', outline: null });
  }
  // 一个弹珠罐（18×20）：红盖子、玻璃罐，底下两颗、上面一颗
  function ballJar(g, x, y, kind) {
    rect(g, x + 3, y, 12, 5, INK); rect(g, x + 4, y + 1, 10, 3, '#c8364a'); rect(g, x + 4, y + 1, 10, 1, '#e85a6a');
    rect(g, x, y + 4, 18, 16, INK); rect(g, x + 1, y + 5, 16, 14, '#eaf7fb'); rect(g, x + 1, y + 18, 16, 1, '#b8dce8');
    const b = MainArt.ballSprite(kind, 0, false, true);
    g.drawImage(b, x + 5, y + 5);
    g.drawImage(b, x + 1, y + 10); g.drawImage(b, x + 8, y + 10);
    rect(g, x + 15, y + 6, 1, 5, '#ffffff');
  }
  function cabinet(g, x, y, balls) {
    const w = OBJ.shop.w, h = OBJ.shop.h, C = COLORS;
    shade(g, x, y, w, h);
    rect(g, x - 1, y - 1, w + 2, h + 2, INK);
    rect(g, x, y, w, h, C.rim);
    rect(g, x, y, w, 1, C.rimHi); rect(g, x, y, 1, h, C.rimHi); rect(g, x + w - 1, y, 1, h, C.rimLo); rect(g, x, y + h - 1, w, 1, C.rimLo);
    rect(g, x + 1, y + 5, w - 2, 1, C.rimLo);
    // 玻璃柜：一排罐子，底下一条木隔板
    const gx = x + 5, gy = y + 8, gw = w - 10, gh = 28;
    rect(g, gx - 1, gy - 1, gw + 2, gh + 2, INK);
    rect(g, gx, gy, gw, gh, '#bfe4ee');
    rect(g, gx, gy + gh - 3, gw, 3, C.rimLo); rect(g, gx, gy + gh - 3, gw, 1, C.rim);
    (balls || []).slice(0, 3).forEach((k, i) => ballJar(g, gx + 6 + i * 28, gy + 4, k));
    // 玻璃上两道反光（左上角）
    for (let k = 0; k < 6; k++) { px(g, gx + 2 + k, gy + 8 - k, '#ffffff'); px(g, gx + 5 + k, gy + 8 - k, '#ffffff'); }
    // 木柜身：两排抽屉、一排两格，正中一个铜把手
    const by = gy + gh + 3, dh = 12, dw = Math.floor((w - 14) / 2);
    for (let r = 0; r < 2; r++) for (let c = 0; c < 2; c++) {
      const dx = x + 5 + c * (dw + 4), dy = by + r * (dh + 3);
      rect(g, dx - 1, dy - 1, dw + 2, dh + 2, INK);
      rect(g, dx, dy, dw, dh, C.rim); rect(g, dx, dy, dw, 1, C.rimHi); rect(g, dx, dy + dh - 1, dw, 1, C.rimLo);
      const hx = dx + Math.floor(dw / 2) - 3, hy = dy + Math.floor(dh / 2) - 1;
      rect(g, hx, hy, 6, 3, INK); rect(g, hx + 1, hy + 1, 4, 1, GOLD[0]);
    }
    plate(g, x + w / 2, PLATE_Y, '柜台');
  }
  // 打卡钟（24×32）：蓝灰机身、白钟面、正面一道卡槽，顶上插着一张卡
  function timeClock(g, x, y) {
    shade(g, x, y, 24, 32);
    rect(g, x + 7, y - 8, 10, 9, INK); rect(g, x + 8, y - 7, 8, 8, '#fff6e0'); rect(g, x + 9, y - 5, 6, 1, '#c8b48c'); rect(g, x + 9, y - 3, 6, 1, '#c8b48c');
    rect(g, x - 1, y - 1, 26, 34, INK);
    rect(g, x, y, 24, 32, '#7a86b0'); rect(g, x, y, 24, 1, '#a8b4d8'); rect(g, x, y, 1, 32, '#a8b4d8'); rect(g, x + 23, y, 1, 32, '#4a547a'); rect(g, x, y + 31, 24, 1, '#4a547a');
    for (let dy = -7; dy <= 7; dy++) for (let dx = -7; dx <= 7; dx++) { const d = dx * dx + dy * dy; if (d <= 50) px(g, x + 12 + dx, y + 11 + dy, d >= 36 ? INK : '#fff6e0'); }
    rect(g, x + 12, y + 6, 1, 6, INK); rect(g, x + 12, y + 11, 4, 1, INK); px(g, x + 12, y + 11, '#e8343a');
    rect(g, x + 5, y + 22, 14, 3, INK);
    rect(g, x + 18, y + 27, 3, 2, '#e8343a');
  }
  // 闹钟（22×24）：两个铃铛、红钟身、白钟面、两条腿
  function alarmClock(g, x, y) {
    shade(g, x + 2, y + 4, 18, 20);
    const disc = (cx, cy, r, fill, hi) => { for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) { const d = dx * dx + dy * dy; if (d <= r * r + r) px(g, cx + dx, cy + dy, d >= (r - 1) * (r - 1) + r - 1 ? INK : hi && dx + dy < -r * 0.6 ? hi : fill); } };
    disc(x + 4, y + 4, 4, GOLD[1], GOLD[0]); disc(x + 18, y + 4, 4, GOLD[1], GOLD[0]);
    rect(g, x + 10, y, 2, 5, INK);
    rect(g, x + 4, y + 20, 3, 4, INK); rect(g, x + 15, y + 20, 3, 4, INK);
    disc(x + 11, y + 13, 9, '#e8343a', '#ff8a7a');
    disc(x + 11, y + 13, 6, '#fff6e0');
    rect(g, x + 11, y + 9, 1, 5, INK); rect(g, x + 11, y + 13, 4, 1, INK);
  }
  // 机台界面左边那一排的小图标（22×20）：柜台、金币罐、打卡钟缩小画
  const icons = {};
  function icon(k) {
    if (icons[k]) return icons[k];
    const c = canvas(22, 20), g = c.getContext('2d'), C = COLORS;
    if (k === 'shop') {
      rect(g, 0, 0, 22, 20, INK); rect(g, 1, 1, 20, 18, C.rim); rect(g, 1, 1, 20, 1, C.rimHi);
      rect(g, 3, 3, 16, 12, INK); rect(g, 4, 4, 14, 10, '#bfe4ee'); rect(g, 4, 9, 14, 1, C.rim);
      const cols = [['#ffffff', '#9aa6ba'], [A.kit.BONE[0], A.kit.BONE[2]], ['#ffd23a', '#e8452a']];
      cols.forEach(([a, b], i) => { for (const yy of [5, 10]) { rect(g, 5 + i * 5, yy + 1, 3, 3, b); px(g, 5 + i * 5, yy + 1, a); } });
      rect(g, 3, 16, 16, 1, C.rimLo);
    } else if (k === 'jar') {
      rect(g, 5, 0, 12, 5, INK); rect(g, 6, 1, 10, 3, GOLD[1]); rect(g, 6, 1, 10, 1, GOLD[0]);
      rect(g, 4, 5, 14, 15, INK); rect(g, 3, 6, 16, 13, INK); rect(g, 5, 6, 12, 13, GLASS); rect(g, 4, 7, 14, 11, GLASS);
      for (let j = 0; j < 7; j++) rect(g, 4, 17 - j, 14, 1, j === 6 ? '#fff3a0' : j % 3 === 2 ? '#a87a20' : '#e8c048');
      rect(g, 5, 7, 1, 4, '#ffffff');
    } else if (k === 'clock') {
      rect(g, 8, 0, 6, 5, INK); rect(g, 9, 1, 4, 4, '#fff6e0');
      rect(g, 3, 4, 16, 16, INK); rect(g, 4, 5, 14, 14, '#7a86b0'); rect(g, 4, 5, 14, 1, '#a8b4d8');
      for (let dy = -4; dy <= 4; dy++) for (let dx = -4; dx <= 4; dx++) { const d = dx * dx + dy * dy; if (d <= 17) px(g, 11 + dx, 10 + dy, d >= 10 ? INK : '#fff6e0'); }
      rect(g, 11, 7, 1, 4, INK); rect(g, 11, 10, 3, 1, INK);
      rect(g, 7, 16, 8, 2, INK);
    }
    return (icons[k] = c);
  }
  // 机台界面的底：桌子按 camFor(id) 推近（整数倍，最近邻）
  function zoomed(deskCanvas, id) {
    const cam = camFor(id), c = canvas(W, H), g = c.getContext('2d');
    g.imageSmoothingEnabled = false;
    g.drawImage(deskCanvas, cam.x, cam.y, cam.w, cam.h, 0, 0, W, H);
    return c;
  }

  // ---------- 每帧画在桌上的：红布、价签、筹码数、小人、金币罐、战利品 ----------
  // 没开的小游戏：盖一块红绒布（竖褶子、底下一排金穗），挂一张价签
  function cloth(g, x, y, w, h) {
    const V = COLORS.velv, top = y - 2, bot = y + h - 4;
    rect(g, x - 3, top - 1, w + 6, bot - top + 3, INK);
    rect(g, x - 2, top, w + 4, bot - top + 1, V[1]);
    rect(g, x - 2, top, w + 4, 2, V[0]);
    for (let i = 8; i < w; i += 10) { rect(g, x + i, top + 6, 1, bot - top - 6, V[2]); rect(g, x + i + 1, top + 10, 1, bot - top - 10, V[0]); }
    for (let i = -2; i < w + 2; i++) { g.fillStyle = i % 2 ? GOLD[1] : GOLD[2]; g.fillRect(x + i, bot + 1, 1, i % 3 === 0 ? 4 : 3); }
  }
  function tag(g, x, y, s, poor) {
    const tw = Txt.width(s, 12) + 16;
    rect(g, x - 1, y - 1, tw + 2, 15, INK);
    rect(g, x, y, tw, 13, '#fff6e0');
    rect(g, x, y + 12, tw, 1, '#c8b48c');
    g.drawImage(MainArt.COIN, x + 2, y + 4);
    Txt.draw(g, s, x + 10, y, { color: poor ? '#b8322a' : '#3a2410', outline: null });
    return tw;
  }
  // 金币罐（28×34）：铜盖、短瓶口、圆肩的亮玻璃罐；金币从底往上堆 fill（0..1），顶上一排是一枚一枚的金币边。
  //   形状按格子算（里面一格挨着外面就是描边），按堆几行缓存
  const GLASS = '#cde8f0', GLASS2 = '#a8cfdc';
  const jarCache = {};
  function jarSprite(n) {
    if (jarCache[n]) return jarCache[n];
    const c = canvas(32, 38), g = c.getContext('2d'), bw = 28, bh = 26, oy = 8;
    const TOP = [4, 2, 1, 1], BOT = [1, 1, 2, 3];
    const ins = j => (j < 4 ? TOP[j] : j >= bh - 4 ? BOT[j - (bh - 4)] : 0);
    const inside = (i, j) => j >= 0 && j < bh && i >= ins(j) && i < bw - ins(j);
    // 影子（往右下 3 格）
    g.save(); g.globalAlpha = 0.42; g.fillStyle = '#000';
    for (let j = 0; j < bh; j++) g.fillRect(3 + ins(j), oy + 3 + j, bw - 2 * ins(j), 1);
    g.restore();
    for (let j = 0; j < bh; j++) for (let i = 0; i < bw; i++) {
      if (!inside(i, j)) continue;
      const edge = !inside(i - 1, j) || !inside(i + 1, j) || !inside(i, j - 1) || !inside(i, j + 1);
      let col = edge ? INK : (i === bw - ins(j) - 2 || j === bh - 2) ? GLASS2 : GLASS;
      // 金币：从底下（bh-2）往上 n 行
      const k = bh - 2 - j;
      if (!edge && k >= 0 && k < n) col = k === n - 1 ? (i % 6 === 2 ? '#e8c048' : '#fff3a0') : k % 3 === 2 ? '#a87a20' : '#e8c048';
      px(g, i, oy + j, col);
    }
    // 金币顶上两点亮光
    if (n > 1) for (const i of [8, 19]) if (inside(i, bh - 1 - n)) px(g, i, oy + bh - 1 - n, '#ffffff');
    // 瓶口：打通罐顶那条描边
    rect(g, 7, 5, 14, 4, INK); rect(g, 8, 6, 12, 3, GLASS);
    // 铜盖
    rect(g, 5, 0, 18, 6, INK); rect(g, 6, 1, 16, 4, GOLD[1]); rect(g, 6, 1, 16, 1, GOLD[0]); rect(g, 6, 4, 16, 1, GOLD[2]);
    for (const i of [9, 13, 17]) rect(g, i, 2, 1, 2, GOLD[2]);
    // 玻璃反光：左上一道竖线、一点
    rect(g, 4, oy + 4, 1, 10, '#ffffff'); px(g, 5, oy + 3, '#ffffff'); rect(g, 6, oy + 5, 1, 3, '#ffffff');
    return (jarCache[n] = c);
  }
  function jar(g, x, y, fill) {
    const n = fill > 0 ? Math.max(2, Math.round(fill * 22)) : 0;
    g.drawImage(jarSprite(n), x, y);
  }
  // 金币罐的铜名牌：写着多少金币（每帧画；金币图标放铜底上看不清，罐子本身就是图标）
  function goldPlate(g, cx, y, s) { plate(g, cx, y, s); }

  // 电话（桌子右下角）：红色座机，听筒横在上面，正中一个白拨盘。响的时候整台左右抖、听筒一跳一跳、两边冒黄色铃声
  const PHONE = { x: 397, y: 298, w: 30, h: 24 };   // 柜台右边那个位（中心 412），底边对齐 BASE
  const PH_C = ['#ff8a7a', '#e8343a', '#a81a24'];
  function phone(g, x, y, ring, t) {
    const shake = ring ? (Math.floor(t * 22) % 2 ? 1 : -1) : 0, hop = ring && Math.floor(t * 11) % 2 ? -2 : 0;
    x += shake;
    g.save(); g.globalAlpha = 0.4; rect(g, x + 4, y + 21, 24, 3, '#000'); g.restore();
    // 机身：上窄下宽的梯形
    for (let j = 0; j < 14; j++) { const ins = Math.max(0, 4 - (j >> 1)); rect(g, x + 1 + ins, y + 8 + j, 28 - 2 * ins, 1, INK); }
    for (let j = 1; j < 13; j++) { const ins = Math.max(0, 4 - (j >> 1)) + 1; rect(g, x + 1 + ins, y + 8 + j, 28 - 2 * ins, 1, j === 1 ? PH_C[0] : j >= 10 ? PH_C[2] : PH_C[1]); }
    // 拨盘：白圈 + 一圈小孔
    for (let dy = -4; dy <= 4; dy++) for (let dx = -4; dx <= 4; dx++) {
      const d = dx * dx + dy * dy;
      if (d <= 17) px(g, x + 15 + dx, y + 15 + dy, d >= 10 ? INK : d <= 2 ? PH_C[1] : '#fff6e0');
    }
    for (const [dx, dy] of [[0, -3], [2, -2], [3, 0], [2, 2], [-2, 2], [-3, 0], [-2, -2]]) px(g, x + 15 + dx, y + 15 + dy, '#c8b48c');
    // 听筒：两头圆的一根横条
    const hy = y + 3 + hop;
    rect(g, x + 2, hy, 26, 6, INK); rect(g, x + 1, hy + 1, 28, 4, INK);
    rect(g, x + 3, hy + 1, 24, 4, PH_C[1]); rect(g, x + 2, hy + 2, 26, 2, PH_C[1]);
    rect(g, x + 3, hy + 1, 24, 1, PH_C[0]); rect(g, x + 3, hy + 4, 24, 1, PH_C[2]);
    rect(g, x + 9, hy + 2, 12, 1, PH_C[2]);
    if (ring) {
      // 铃声：两边各两道弯
      const on = Math.floor(t * 6) % 2;
      for (const side of [-1, 1]) {
        const cx = side < 0 ? x - 3 : x + 32;
        for (let k = 0; k < 2; k++) {
          if (k === 1 && !on) continue;
          const ox = side * k * 3;
          for (let j = -2; j <= 2; j++) px(g, cx + ox + side * (Math.abs(j) === 2 ? -1 : 0), y + 6 + j, '#ffd84a');
        }
      }
    }
  }
  return { W, H, DESK, MAIN, PAD, SLOT, OBJ, BASE, PLATE_Y, PHONE, COLORS, goldPlate, cw, deskRect, slotAt, playRect, camFor, FULL, lerpCam, toScreen, render, plain, zoomed, cardMask, cloth, tag, jar, felt, phone, icon };
})();
