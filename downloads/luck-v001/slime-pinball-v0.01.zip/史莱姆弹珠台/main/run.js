/*
 * 主线的一轮（不画画，Node 里也能跑；画在 main/game.js）。照《史莱姆主线 · 执行方案 v3》第五、六节。
 *   开头：台上掉下来这一层的史莱姆（这一关的密度那么多只，一开始一只），弹珠袋装满这轮带的那种球，第一颗上推头。
 *   一轮里：按住拉弹簧发球，拉得越满落得越靠左。
 *     撞史莱姆先比档：弹珠比它低 → "叮"，不掉血；一样或高一档 → 正常打（一下 = 份 × 这颗球的力道，金珠 ×2，重击 ×2）；
 *       高两档起 → 碾压：直接爆，弹珠不弹开、不掉耐久，接着往前走。
 *     耐久：弹珠砸一下史莱姆、撞一下栏杆（墙、导轨、柱子）掉 1，掉光就碎；挡板、弹力绳、台顶的弧不磨弹珠。
 *     大个的挨一下裂成两只小的（小的血是这层的一半），各算一只。
 *     一关十层，第 n 层碎够 n 只往下一层（多碎的接着算下一层）；最后一层碎够，boss 从台顶砸下来；打掉 boss，停 0.3 秒，背景炸开，下一关接着打。
 *     史莱姆只在两颗弹珠中间补：这一颗碎了、漏了，下一颗上推头之前补到密度那么多只（boss 在的时候补一半）。
 *     台上打空了，这颗弹珠就算用完（买了"回收"：放回袋子里，收回来的就是这一颗，剩几下是几下）。
 *   本事（跟着球走）：
 *     骨刺：骨球每掉一下耐久，有几率崩几根骨刺往外飞，一根打一下（骨球的档、骨球一下的数），穿透的打碎了接着飞
 *     着火：火山弹砸中的有几率着火，烧几秒、一秒掉几成血；烧死的把火传给离它最近的一只（一把火最多传几只）
 *   复活（一种史莱姆一组）：碎了有几率原地聚回来（几成变两只小的）；每种一轮最多几只，台上最多密度的两倍
 *   一轮完：弹珠袋空了、台上也没弹珠了。停一下自己从第 1 层重开（买了"重来"随时能重开）。
 *   数值的一轮开头才算（买了下一轮生效）；台上的零件（挡板、弹力绳、小孔、重来、回收）买了马上装，见 refresh()。
 *   台面跟着这轮带的珠子走（11-11 全套粗做）：玻璃珠、骨球、火山弹是弹球（sims/mainline.js）；后十颗是平台面（sims/flat.js）的弹指、保龄、足球。
 *     平台面：按住往后拉、松手弹出去；弹指、足球一杆（一脚）掉 1 下耐久，这一杆撞的全是碾过去的不掉；被撞开的史莱姆滑出去撞别的，别的挨一下（传几手看树）。
 *     保龄滚到台顶这一颗就完；足球踢进台顶的门退回 1 下耐久（一颗最多退几次看树）。
 *   一轮从哪一关打起：R.startStage（选关：打通过的关随便挑，没挑的从最深那关打）
 *   hooks（都可以不给）：fx(type, o) 画面上的事、sfx(name, a) 声音、save()、shake(v)、rng()、noise（自动手手生的程度）、
 *          hold() 返回 true 就先别自己重开（电话、开场……）
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('../sims/mainline.js'), require('./data.js'), require('./rules.js'), require('../sim.js'), require('../sims/flat.js'));
  else root.MainRun = factory(root.MainLine, root.MainData, root.MainRules, root.Sim, root.MainFlat);
}(typeof self !== 'undefined' ? self : globalThis, function (P, D, R, Sim, F) {
  'use strict';
  const ZONE = P.ZONE, DT = P.DT;
  const ease = t => 1 - Math.pow(1 - Math.max(0, Math.min(1, t)), 3);
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  // 栏杆磨弹珠：撞得比这个重才算（数在 data.js 的 RAIL_WEAR，先填）
  const RW = () => D.RAIL_WEAR;
  // 一轮完了停几秒自己重开
  const RESTART_T = 1.4;
  // 空台上直接打得到的地方：拉满落到最左，最轻落到最右。y 越低，最左那条线越往左（拿空台量出来的，见 aimTable）
  const reachLo = y => 86 - 1.03 * (y - 40);
  // 第一次玩：台上那一只趴在拉一半多一点就砸得中的地方
  const TUTOR = [100, 68];

  // 力度表：空台上每个力度打一颗，记下往下掉、穿过每一行时的 x（自动手瞄准用）
  let AIM = null;
  function aimTable() {
    if (AIM) return AIM;
    AIM = [];
    for (let i = 0; i <= 50; i++) {
      const p = i / 50, s2 = P.create({});
      const b = P.load(s2, {});
      P.launch(s2, p);
      const xs = {};
      let py = b.y, t = 0;
      while (t < 4 && b.state === 'play') {
        P.step(s2); t += DT; s2.events.length = 0;
        if (b.vy > 0 && b.x < P.LANE_X) for (let y = 30; y <= 96; y += 2) if (xs[y] == null && py < y && b.y >= y) xs[y] = b.x;
        py = b.y;
      }
      AIM.push({ p, xs });
    }
    return AIM;
  }
  function powerFor(x, y) {
    const row = Math.max(30, Math.min(96, Math.round(y / 2) * 2));
    let best = null, bd = Infinity;
    for (const a of aimTable()) { const xx = a.xs[row]; if (xx == null) continue; const d = Math.abs(xx - x); if (d < bd) { bd = d; best = a.p; } }
    return best == null ? 0.6 : best;
  }

  function create(S, hooks) {
    hooks = hooks || {};
    const rnd = hooks.rng || Math.random;
    const fx = (type, o) => { if (hooks.fx) hooks.fx(type, o || {}); };
    const sfx = (k, a) => { if (hooks.sfx) hooks.sfx(k, a); };
    const save = () => { if (hooks.save) hooks.save(); };
    const shake = v => { if (hooks.shake) hooks.shake(v); };
    // 露出来新节点（挣到第一枚金币、第一次看到一关）：画面上闪一下
    const revealed = list => { if (list && list.length) { fx('reveal', { list }); save(); } };
    let K = R.stats(S);
    // 两张台：弹球（sp）和平台面（sf）；一轮开头照这轮带的珠子挑一张（mode：pin、flick、bowl、kick）
    const sp = P.create({ cover: K.cover, parts: { sling: K.sling, lanes: K.lanes } });
    const sf = F.create({ mode: 'flick' });
    sp.onHit = onHit; sf.onHit = onHit;
    let s = sp, mode = 'pin';
    const flat = () => mode !== 'pin';
    const PHY = () => (flat() ? F : P);
    const zone = () => (flat() ? F.ZONES[mode] : ZONE);
    const reach = (y, r) => (flat() ? zone().x0 : Math.max(ZONE.x0, reachLo(y) + r * 0.5));
    const st = {
      phase: 'idle', stage: 1, layer: 1, lk: 0, boss: null, bossDue: -1, stuck: false, hopT: 0, spitT: 0,
      bag: [], keep: [], flips: {}, run: null, wait: 0.3, time: 0, acc: { t: 0 }, hitstop: 0, burst: null, endT: 0, refilled: true,
      hold: { L: new Set(), R: new Set() }, auto: null, seq: 0, flipCool: { L: 0, R: 0 }, shots: 0, flipShots: 0, ends: 0,
      shards: [], revives: [], revived: {},
      aim: null, breathT: 0, eatT: 0, splashes: [],
    };

    // ---------- 弹簧：按住拉，Sim.HOLD_FILL 秒拉满 ----------
    const pl = {
      on: false, t: 0, by: null, tick: -1, last: 0,
      start(by) { this.on = true; this.t = 0; this.by = by; this.tick = -1; },
      cancel() { this.on = false; this.t = 0; },
      power() { return this.on ? Sim.holdPower(this.t) : this.last; },
      pull() { return this.on ? Math.round(Sim.PULL * Sim.holdPower(this.t)) : 0; },
      update(dt) {
        if (!this.on) return;
        this.t += dt;
        const k = Math.floor(this.t / 0.1);
        if (k > this.tick && this.t < Sim.HOLD_FILL) { this.tick = k; sfx('ratchet', Sim.holdPower(this.t)); }
      },
      release() { const p = Sim.holdPower(this.t); this.last = p; this.on = false; return p; },
    };

    const alive = () => s.slimes.filter(o => o.state !== 'pop');
    const normals = () => alive().filter(o => !o.boss);
    const playing = () => s.balls.filter(b => b.state === 'play');
    const laneBall = () => s.balls.find(b => b.state === 'lane');
    // 掉血缩个头；zm 是它那一关的镜头倍数（菜园远一截，个头跟着小一圈）
    const radius = o => Math.max(3 * (o.zm || 1), o.base * (0.5 + 0.5 * Math.max(0, o.hp) / o.maxHp)) * (o.puff > 0 ? 1.5 : 1);
    const ZM = () => R.zoomOf(st.stage);
    const LAY = () => R.layerOf(st.stage, st.layer);
    const count = () => R.countFor(K, st.stage);

    // ---------- 史莱姆 ----------
    function freeSpot(r, self) {
      for (let k = 0; k < 80; k++) {
        const Z = zone(), y = Z.y0 + rnd() * (Z.y1 - Z.y0), x0 = reach(y, r);
        const x = x0 + rnd() * (Z.x1 - x0);
        if (s.slimes.some(o => o !== self && o.state !== 'pop' && Math.hypot(o.tx - x, o.ty - y) < o.r + r + 4)) continue;
        if (playing().some(b => Math.hypot(b.x - x, b.y - y) < r + 10)) continue;
        return [x, y];
      }
      return null;
    }
    // 出场表里挑一种：还没做的不出；from 写了第几层起才有的，没到那层不出
    function pickKind(SD) {
      const ok = SD.mix.filter(([k]) => D.SLIMES[k] && D.SLIMES[k].ready !== false && (!SD.from || !SD.from[k] || st.layer >= SD.from[k]));
      const tot = ok.reduce((a, [, w]) => a + w, 0);
      let x = rnd() * tot;
      for (const [k, w] of ok) { x -= w; if (x <= 0) return k; }
      return ok.length ? ok[ok.length - 1][0] : 'mud';
    }
    function mk(o) {
      return Object.assign({
        id: ++st.seq, kind: 'mud', size: 'm', gold: false, boss: false, hp: 1, maxHp: 1, base: 6, r: 6, tier: 1,
        x: 90, y: 24, sx: 90, sy: 24, tx: 90, ty: 50, state: 'drop', t: 0, dur: 0.45, delay: 0, arc: 8,
        solid: false, cool: 0, flash: 0, squash: 0, hopIn: 3 + rnd() * 3, burn: 0, burnTick: 0, burnPct: 0, chain: 0, frozen: 0, phase: rnd() * 6,
        vx: 0, vy: 0, knock: null, puff: 0, dir: rnd() < 0.5 ? -1 : 1,
      }, o);
    }
    // 掉一只普通的下来。o：delay 晚几秒掉、from 从哪蹦出来（boss 吐的、复活的）、spot 落在哪、hp 定死的血、kind、size、
    //   at 教你瞄的那一只（定死的地方，原地蹦）
    function addNormal(o) {
      o = o || {};
      const SD = R.stage(st.stage), L = LAY(), kind = o.kind || pickKind(SD), size = o.size || (rnd() < L.big ? 'b' : 'm'), KD = D.SLIMES[kind], Z = D.SIZES[size];
      const hp = o.hp || R.niceHp(R.rollHp(L, rnd) * Z.hp * KD.hp), zm = ZM(), r0 = Z.r * zm;
      const spot = o.at || o.spot || freeSpot(r0);
      if (!spot) return null;
      const from = o.from;
      const m = mk({
        kind, size, gold: !o.noGold && rnd() < K.goldChance, hp, maxHp: hp, base: r0, r: r0, zm, tier: KD.tier, still: !!KD.still, move: KD.move || null,
        x: from ? from[0] : spot[0], y: from ? from[1] : 24, sx: from ? from[0] : spot[0], sy: from ? from[1] : 24, tx: spot[0], ty: spot[1],
        state: o.delay ? 'wait' : from ? 'hop' : 'drop', dur: o.hopDur || 0.45, delay: o.delay || 0, arc: from ? (o.arc != null ? o.arc : 14) : 8, stay: !!o.at,
        revived: !!o.revived,
      });
      if (o.at) m.hopIn = 0.6 + rnd() * 0.5;   // 教你瞄的那一只：在原地蹦（不挪窝），开场桌上就看得见它在跳
      if (from) m.solid = true;
      s.slimes.push(m);
      return m;
    }
    // 还没碎过一只：补上来的第一只趴在教你瞄的那个地方
    const tutor = () => (!S.seen.firstKill && !normals().length ? { at: TUTOR, size: 'm', noGold: true } : undefined);
    const want = () => (st.burst ? 0 : st.boss || st.bossDue >= 0 ? Math.max(1, Math.floor(count() / 2)) : count());
    // 补史莱姆（两颗弹珠中间、一轮开头）：补到 want() 只，一只一只往下掉
    function refill(delay) {
      const w = want();
      let n = normals().length, i = 0;
      while (n < w) { if (!addNormal(Object.assign({ delay: (delay || 0) + i * 0.12 }, tutor()))) break; n++; i++; }
      return i;
    }
    function hopNear(o) {
      for (let k = 0; k < 12; k++) {
        const Z = zone(), y = Math.max(Z.y0, Math.min(Z.y1, o.y + (rnd() * 2 - 1) * 6)), x = Math.max(reach(y, o.r), Math.min(Z.x1, o.x + (rnd() * 2 - 1) * 8));
        if (s.slimes.some(p => p !== o && p.state !== 'pop' && Math.hypot(p.tx - x, p.ty - y) < p.r + o.r + 3)) continue;
        o.state = 'hop'; o.t = 0; o.dur = 0.42; o.arc = 6; o.sx = o.x; o.sy = o.y; o.tx = x; o.ty = y;
        return;
      }
    }
    // 原地蹦一下：蹦得低、落得快，大半时间趴着不动（好瞄）
    function hopInPlace(o) { o.state = 'hop'; o.t = 0; o.dur = 0.34; o.arc = 5; o.sx = o.tx = o.x; o.sy = o.ty = o.y; }
    function updateSlimes(dt) {
      for (const o of s.slimes) {
        o.cool = Math.max(0, o.cool - dt); o.flash = Math.max(0, o.flash - dt); o.squash = Math.max(0, o.squash - dt);
        if (o.frozen > 0) o.frozen = Math.max(0, o.frozen - dt);
        if (o.burn > 0 && o.state !== 'pop') {
          o.burn -= dt; o.burnTick -= dt;
          if (o.burnTick <= 0) { o.burnTick += 1; burnHit(o); }
        }
        if (o.state === 'wait') { o.delay -= dt; if (o.delay <= 0) { o.state = 'drop'; o.t = 0; } continue; }
        if (o.state === 'drop' || o.state === 'hop') {
          o.t += dt;
          const t = Math.min(1, o.t / o.dur);
          o.x = o.sx + (o.tx - o.sx) * (o.state === 'drop' ? t : ease(t));
          o.y = o.state === 'drop' ? o.sy + (o.ty - o.sy) * t * t : o.sy + (o.ty - o.sy) * t - o.arc * Math.sin(Math.PI * t);
          if (o.state === 'drop' && t > 0.6) o.solid = true;
          if (t >= 1) {
            const wasDrop = o.state === 'drop';
            o.state = 'live'; o.solid = true; o.x = o.tx; o.y = o.ty; o.squash = 0.2;
            if (o.boss) thud(o, wasDrop);
          }
        } else if (o.state === 'live' && o.puff > 0) {
          o.puff -= dt; if (o.puff <= 0) { o.puff = 0; o.r = radius(o); }
        } else if (o.state === 'live' && !o.boss && !o.frozen && (o.vx || o.vy || o.hookedBy)) {
          // 被撞开、被钩着：物理在挪它
        } else if (o.state === 'live' && !o.boss && !o.frozen && o.move) {
          moveSlime(o, dt);
        } else if (o.state === 'live' && !o.boss && !o.frozen && o.still) {
          // 不动的（琥珀、冰冻、黑石）
        } else if (o.state === 'live' && !o.boss && !o.frozen) {
          o.hopIn -= dt;
          if (o.hopIn <= 0) { if (o.stay) { o.hopIn = 1.1 + rnd() * 0.6; hopInPlace(o); } else { o.hopIn = 3 + rnd() * 3; hopNear(o); } }
        }
        else if (o.state === 'pop') o.t += dt;
      }
      s.slimes = s.slimes.filter(o => !(o.state === 'pop' && o.t > 0.3));
    }

    // 漂（水母）：左右慢慢漂、一上一下；横着走（寄居蟹）：碰边掉头；排队走（卫兵）：一样快、一起掉头
    function moveSlime(o, dt) {
      const Z = zone(), sp = o.move === 'drift' ? 9 : o.move === 'walk' ? 14 : 11;
      o.x += o.dir * sp * dt;
      if (o.move === 'drift') o.y = o.ty + Math.sin(st.time * 1.6 + o.phase) * 3;
      const lo = Math.max(Z.x0, reach(o.y, o.r)) + o.r * 0.3, hi = Z.x1 - o.r * 0.3;
      if (o.x < lo) { o.x = lo; o.dir = 1; } else if (o.x > hi) { o.x = hi; o.dir = -1; }
      if (o.move === 'march' && (o.x <= lo || o.x >= hi)) for (const q of normals()) if (q.move === 'march') q.dir = o.dir;
      o.tx = o.x;
    }
    // ---------- 复活：碎了的原地聚回来 ----------
    // 这一只碎了：这种史莱姆买了复活、这一轮还没到上限、台上没满，掷一下；中了 delay 秒以后原地蹦回来（几成变两只小的）
    function tryRevive(m) {
      const RV = K.revive[m.kind];
      if (!RV || m.boss || st.phase !== 'play' || st.burst) return;
      const used = st.revived[m.kind] || 0, room = D.REVIVE.board * count() - normals().length - st.revives.length;
      if (used >= RV.cap || room <= 0 || rnd() >= RV.p) return;
      const two = used + 2 <= RV.cap && room >= 2 && rnd() < RV.two;
      st.revived[m.kind] = used + (two ? 2 : 1);
      st.revives.push({ t: D.REVIVE.delay, kind: m.kind, hp: m.maxHp, small: m.size === 's', x: m.x, y: m.y, r: m.r, two, gold: false });
      fx('revive', { m, two });
    }
    function updateRevives(dt) {
      for (const q of st.revives) {
        q.t -= dt;
        if (q.t > 0) continue;
        q.done = true;
        if (st.phase !== 'play' || st.burst) continue;
        // 聚回来的血跟碎之前一样；变两只的各一半
        const spots = q.two ? [[q.x - 4, q.y], [q.x + 4, q.y]] : [[q.x, q.y]], hp = q.two ? R.niceHp(q.hp * D.SIZES.s.hp) : q.hp;
        for (const [x, y] of spots) {
          const sp = [clamp(x, ZONE.x0, ZONE.x1), clamp(y, ZONE.y0, ZONE.y1)];
          const o = addNormal({ kind: q.kind, size: q.two || q.small ? 's' : 'm', hp, from: [q.x, q.y], spot: sp, arc: 5, hopDur: 0.3, revived: true });
          if (o) o.cool = 0.15;
        }
        sfx('split'); fx('revived', { x: q.x, y: q.y, r: q.r, two: q.two, kind: q.kind });
      }
      st.revives = st.revives.filter(q => !q.done);
    }

    // ---------- boss ----------
    // boss 站在挡板正上方（def.x 左右两个落点、def.y 高度），每 def.hop 秒蹦到另一边：挡板拍上去的弹珠正好撞它
    const bx = (def, side) => def.x[side === 'L' ? 0 : 1];
    function spawnBoss() {
      const SD = R.stage(st.stage), def = D.BOSSES[SD.boss], zm = ZM(), base = D.SIZES.m.r * def.r * zm;
      const side = rnd() < 0.5 ? 'L' : 'R';
      const hp0 = def.hp * (SD.mul || 1);
      const o = mk({ boss: true, def, kind: def.k, size: 'boss', hp: hp0, maxHp: hp0, base, r: base, base0: base, zm, tier: def.tier, side,
        x: bx(def, side), y: 6, sx: bx(def, side), sy: 6, tx: bx(def, side), ty: def.y, state: 'drop', dur: 0.55 });
      s.slimes.push(o);
      makeRoom(o);
      st.boss = o; st.hopT = def.hop; st.spitT = def.spit * 0.5; st.breathT = def.breath || 0; st.eatT = def.eat || 0;
      if (def.drift) { o.cx = (def.x[0] + def.x[1]) / 2; o.cy = def.y; }
      if (st.run) st.run.bossSeen = def.k;
      sfx('rumble'); fx('boss', { o });
    }
    // boss 要落的地方：小的让开
    function makeRoom(o) {
      for (const p of normals()) {
        if (Math.hypot(p.tx - o.tx, p.ty - o.ty) >= o.r + p.r + 3) continue;
        const sp = freeSpot(p.r, p);
        if (sp) { p.state = 'hop'; p.t = 0; p.dur = 0.4; p.arc = 10; p.sx = p.x; p.sy = p.y; p.tx = sp[0]; p.ty = sp[1]; }
      }
    }
    // 落地：挨着的弹珠弹开
    function thud(o, big) {
      for (const b of playing()) {
        const dx = b.x - o.x, dy = b.y - o.y, d = Math.hypot(dx, dy) || 1, near = o.r + 22;
        if (d >= near) continue;
        const k = Math.max(0.45, 1 - (d - o.r) / 22);
        b.vx += dx / d * 170 * k; b.vy += dy / d * 170 * k - 60;
      }
      shake(big ? 0.35 : 0.2); sfx('thud'); fx('thud', { x: o.x, y: o.y + o.r * 0.7, w: o.r });
    }
    function updateBoss(dt) {
      const o = st.boss;
      if (!o || o.state !== 'live' || o.frozen > 0) return;   // 冻住了：不蹦也不吐
      st.hopT -= dt; st.spitT -= dt;
      // 大水母：画八字漂（不蹦）
      if (o.def.drift) {
        const t = st.time * Math.PI * 2 / 12;
        o.x = o.tx = o.cx + Math.sin(t) * 30; o.y = o.ty = o.cy + Math.sin(2 * t) * 8;
        st.hopT = 99;
      }
      // 冰王：吹一口冷气，离它最近的一颗珠子冻住两秒
      if (o.def.breath) {
        st.breathT -= dt;
        if (st.breathT <= 0) {
          st.breathT = o.def.breath;
          let best = null, bd = Infinity;
          for (const b of playing()) { const d = Math.hypot(b.x - o.x, b.y - o.y); if (d < bd) { bd = d; best = b; } }
          if (best) { best.hold = 2; sfx('freeze'); fx('breath', { o, b: best }); }
        }
      }
      // 史莱姆王：吞掉挨着的一只，回那只三倍的血，大一圈
      if (o.def.eat) {
        st.eatT -= dt;
        if (st.eatT <= 0) {
          st.eatT = o.def.eat;
          let best = null, bd = Infinity;
          for (const q of normals()) { if (!q.solid || q.state !== 'live') continue; const d = Math.hypot(q.x - o.x, q.y - o.y) - q.r - o.r; if (d < bd) { bd = d; best = q; } }
          if (best && bd < 24) {
            best.state = 'pop'; best.t = 0; best.solid = false; best.hp = 0;
            o.hp = Math.min(o.maxHp, o.hp + best.maxHp * 3);
            o.base = Math.min(o.base0 * 1.35, o.base * 1.05); o.r = radius(o); o.squash = 0.3;
            sfx('spit'); fx('eat', { o, m: best });
          }
        }
      }
      if (st.hopT <= 0 && o.def.hop) {
        st.hopT = o.def.hop;
        o.side = o.side === 'L' ? 'R' : 'L';
        o.state = 'hop'; o.t = 0; o.dur = 0.75; o.arc = 30; o.sx = o.x; o.sy = o.y; o.tx = bx(o.def, o.side); o.ty = o.def.y;
        makeRoom(o);
        sfx('hop');
      } else if (st.spitT <= 0) {
        st.spitT = o.def.spit;
        if (normals().length >= count()) return;   // 台上满了就不吐
        const SD = R.stage(st.stage), hp = o.def.spitHp || R.niceHp(R.minHp(SD.layers[SD.layers.length - 1]) / 2);
        for (let i = 0; i < (o.def.spitN || 1); i++) {
          const m = addNormal({ kind: o.def.spitKind || 'mud', size: o.def.spitN ? 'm' : 's', hp, from: [o.x, o.y - o.r * 0.6], noGold: true });
          if (m) { o.squash = 0.25; sfx('spit'); fx('spit', { o, m }); }
        }
      }
    }

    // ---------- 撞上了 ----------
    // 一下打多少：份 × 这颗球的力道（金珠 ×2，重击 ×2）
    const hitDmg = (M, gold, crit) => M.fen * M.power * (gold ? 2 : 1) * (crit ? 2 : 1);
    // 打一下（珠子撞的、撞开的史莱姆砸的、蛋溅的、崩出来的硬币打的都走这里）。o：x、y 打在哪，nx、ny，mult 多打几倍，src 'knock' / 'splash' / 'chip'，gold 金珠
    //   返回 'ding' 打不动、'crush' 碾碎、'split' 大个的裂开、'kill' 打死、'hit' 打着了没死
    function strike(m, M, b, o) {
      o = o || {};
      const x = o.x != null ? o.x : m.x, y = o.y != null ? o.y : m.y;
      if (M.tier < m.tier) { m.squash = 0.1; fx('ding', { m, x, y, b }); sfx('ding'); return 'ding'; }
      if (!m.boss && M.tier >= m.tier + 2) { fx('crush', { m, x: m.x, y: m.y }); kill(m, false, b, { n: m.size === 'b' ? 2 : 1, crush: true, src: o.src }); return 'crush'; }
      if (m.size === 'b' && !m.boss) { split(m, o.nx || 0, o.ny || 0); return 'split'; }
      const crit = K.critP > 0 && rnd() < K.critP, full = m.hp >= m.maxHp - 1e-9;
      const dmg = hitDmg(M, o.gold, crit) * (o.mult || 1);
      m.hp -= dmg; m.flash = 0.08; m.squash = crit ? 0.3 : 0.2;
      if (K.fire && b && b.kind === 'lava' && !o.src && rnd() < K.fire.p) ignite(m, K.fire.spread, M);
      if (m.hp <= 1e-6) { kill(m, crit, b, { smash: full, src: o.src }); return 'kill'; }
      m.r = radius(m);
      fx('hit', { m, dmg, crit, gold: !!o.gold, x, y, nx: o.nx, ny: o.ny, src: o.src });
      sfx(crit ? 'crit' : 'slime', o.impact || 80);
      if (D.SLIMES[m.kind] && D.SLIMES[m.kind].puff && !m.boss) { m.puff = 3; m.r = radius(m); fx('puff', { m }); }
      return 'hit';
    }
    // 物理里撞到史莱姆先问这里：'pass' 压过去（碾压、很重的打死了）、'plow' 很重的推着走、'ding' 打不动、'hit' / 'soft' 照常弹开
    function onHit(m, b, impact, nx, ny) {
      if (!m.solid || m.state === 'pop' || m.state === 'wait') return 'soft';
      if (m.hookedBy === b) return 'pass';           // 钩着的那只：跟着珠子走
      if (impact < 22 || m.cool > 0) return 'soft';
      const M = R.marbleOf(K, b.kind), KD = D.SLIMES[m.kind], def = m.boss ? m.def : null;
      m.cool = 0.1;
      b.hits = (b.hits || 0) + 1;
      const shot = b.shot || (b.shot = { normal: 0, crush: 0 });
      // 蘑菇王的伞：从上面撞只弹开，不掉血（弹得快一点）
      if (def && def.cap && ny < -0.35) { b.vboost = 1.25; fx('cap', { m, x: m.x + nx * m.r, y: m.y + ny * m.r }); sfx('sling'); return 'ding'; }
      // 粘：琥珀（沼泽王）粘住普通重的珠子一会儿（蛋一碰就破、重的拽不住）
      const sticky = (KD && KD.sticky) || (def && def.sticky);
      if (sticky && M.weight === 1 && M.tier < m.tier + 2 && !(b.stickCool > 0)) { b.hold = 1.1; b.stickCool = 2.5; fx('stick', { m, b }); sfx('settle', 3); }
      // 大水母：碰到的慢一半
      if (def && def.slow) { b.vx *= 0.5; b.vy *= 0.5; fx('slowed', { b }); }
      // 烫：慢的珠子碰岩浆史莱姆多掉 1 下
      if (KD && KD.hot && impact < 120 && M.tier < m.tier + 2) { wear(b, 1, 'hot'); fx('sizzle', { x: b.x, y: b.y }); sfx('sizzle'); if (b.state === 'gone') return 'pass'; }
      // 推（铁母珠）：夹在台边、夹在两只中间的一下算几下；雪球每滚大一圈多打两成
      let mult = 1;
      if (flat() && K.push && b.kind === 'iron' && F.pinned(s, m)) { mult *= K.push.x; fx('pinch', { m }); }
      if (b.grow) mult *= 1 + 0.2 * b.grow;
      const r = strike(m, M, b, { x: m.x + nx * m.r, y: m.y + ny * m.r, nx, ny, mult, gold: b.gold, impact });
      if (r === 'ding') { wear(b, 1, 'ding'); return 'ding'; }
      if (r === 'crush') { shot.crush++; return 'pass'; }
      shot.normal++;
      // 雪球：碎一只大一圈
      if (r === 'kill' && K.grow && b.kind === 'snow' && (b.grow || 0) < K.grow.max) { b.grow = (b.grow || 0) + 1; b.r = b.r0 * (1 + 0.15 * b.grow); fx('grow', { b }); }
      // 鱼钩：钩住第一只撞到的（没死、不是不动的、不是 boss）
      if (r === 'hit' && K.hook && b.kind === 'hook' && !m.boss && !m.still && (b.hooked || (b.hooked = [])).length < K.hook.n) { b.hooked.push(m); m.hookedBy = b; fx('hooked', { m, b }); sfx('clink'); }
      wear(b, 1, 'slime');
      if (r === 'kill') return 'hit';
      return M.weight >= 3 ? 'plow' : 'hit';
    }
    // 撞开：滑着的史莱姆 a 砸到 c，c 挨一下（照把 a 撞开的那颗珠子算）；没死的接着传，传到第几手看树（K.chain）
    function knockHit(a, c, e) {
      const kn = a.knock;
      if (!kn || !kn.b || c.state === 'pop' || !c.solid || c.cool > 0 || a.boss) return;
      const M = R.marbleOf(K, kn.b.kind);
      c.cool = 0.12;
      const r = strike(c, M, kn.b, { x: e.x, y: e.y, src: 'knock', gold: kn.b.gold, impact: e.impact });
      if (r === 'ding') return;
      if (kn.b.shot) kn.b.shot.normal += r === 'crush' ? 0 : 1;
      fx('knock', { x: e.x, y: e.y });
      if ((r === 'hit') && kn.depth < K.chain && !c.still && !c.boss) c.knock = { b: kn.b, depth: kn.depth + 1 };
    }
    // 蛋碎了：溅一圈，圈里的各挨一下
    function splash(b) {
      if (!K.splash) return;
      const M = R.marbleOf(K, b.kind), rr = K.splash.r;
      st.splashes.push({ x: b.x, y: b.y, r: rr, t: 0 });
      fx('splash', { x: b.x, y: b.y, r: rr });
      sfx('split');
      for (const m of s.slimes.slice()) {
        if (!m.solid || m.state === 'pop' || m.state === 'wait') continue;
        if (Math.hypot(m.x - b.x, m.y - b.y) > rr + m.r) continue;
        strike(m, M, b, { src: 'splash' });
      }
    }
    // 裂开：大的没了，原地蹦出两只小的（血是它的一半），一左一右
    function split(m, nx, ny) {
      m.state = 'pop'; m.t = 0; m.solid = false; m.hp = 0;
      const Z = D.SIZES.s, hp = R.niceHp(m.maxHp * Z.hp);
      for (const dir of [-1, 1]) {
        const tx = clamp(m.x + dir * (m.r + 2), ZONE.x0, ZONE.x1), ty = clamp(m.y + (rnd() - 0.5) * 4, ZONE.y0, ZONE.y1 + 6);
        s.slimes.push(mk({ kind: m.kind, size: 's', gold: m.gold, hp, maxHp: hp, base: Z.r * (m.zm || 1), r: Z.r * (m.zm || 1), zm: m.zm || 1, tier: m.tier,
          x: m.x, y: m.y, sx: m.x, sy: m.y, tx, ty, state: 'hop', dur: 0.3, arc: 7, solid: true, cool: 0.18 }));
      }
      fx('split', { m, x: m.x, y: m.y, nx, ny });
      sfx('split');
    }
    // 点着：烧 K.fire.dur 秒；chain 是烧死了还能往下传几只。boss 一秒掉火山弹一下那么多（乘火势），不按血的几成算
    function ignite(m, chain, M) {
      if (m.state === 'pop') return;
      if (!(m.burn > 0)) m.burnTick = 1;
      m.burn = K.fire.dur; m.burnPct = K.fire.pct; m.chain = Math.max(m.chain || 0, chain);
      m.burnBoss = M ? hitDmg(M, false, false) * K.fire.pct * 10 : m.burnBoss || 1;
      fx('burn', { m });
    }
    function burnHit(o) {
      if (o.state === 'pop' || o.state === 'wait') return;
      o.hp -= o.boss ? o.burnBoss || 1 : o.maxHp * o.burnPct;
      o.flash = 0.06;
      fx('burnTick', { m: o });
      if (o.hp <= 1e-6) {
        const chain = o.chain || 0, x = o.x, y = o.y;
        kill(o, false, null, { fire: true });
        // 蔓延：烧死的把火传给离它最近、还没着的那一只
        if (chain > 0) {
          let best = null, bd = Infinity;
          for (const q of normals()) { if (q.burn > 0 || q.state === 'wait' || !q.solid) continue; const d = Math.hypot(q.x - x, q.y - y); if (d < bd) { bd = d; best = q; } }
          if (best) { ignite(best, chain - 1, null); fx('spread', { x0: x, y0: y, x1: best.x, y1: best.y }); }
        }
      } else o.r = radius(o);
    }
    // o：n 算几只（碾压大个的算两只）、crush 碾碎的、fire 烧死的、shard 骨刺打的
    function kill(m, crit, b, o) {
      o = o || {};
      m.state = 'pop'; m.t = 0; m.solid = false; m.hp = 0; m.burn = 0;
      // 金币：（血 × 这种史莱姆的金币倍数（boss 照血）+ 赏金）×（1 + 金币加成）× 金史莱姆；小数攒着，凑够一枚下次补上
      const smashX = KD0(m) && o.smash && KD0(m).smash ? KD0(m).smash : 1, chipX = o.src === 'chip' && K.chip ? K.chip.gold : 1;
      const KD = !m.boss && D.SLIMES[m.kind], raw = (m.maxHp * (KD ? KD.gold : 1) + K.goldAdd) * K.goldMult * (m.gold ? K.goldX : 1) * smashX * chipX + (S.goldFrac || 0);
      const g = Math.floor(raw + 1e-9);
      S.goldFrac = raw - g;
      const first = !(S.earned > 0);
      S.gold += g; S.earned += g; S.kills = (S.kills || 0) + (o.n || 1);
      if (st.run) { st.run.kills += o.n || 1; st.run.gold += g; if (o.shard) st.run.shardKills++; if (o.fire) st.run.fireKills++; if (m.revived) st.run.revKills++; }
      if (!S.seen.firstKill) { S.seen.firstKill = 1; for (const q of normals()) if (q.stay) { q.stay = false; q.hopIn = 2 + rnd() * 3; } }
      fx('kill', { m, g, crit, x: m.x, y: m.y, gold: !!(b && b.gold), crush: !!o.crush, fire: !!o.fire, shard: !!o.shard });
      sfx(m.boss ? 'boom' : 'pop');
      // 挣到第一枚金币：露弹珠袋
      if (first) revealed(R.reveal(S, 2));
      if (m.boss) { bossSplit(m); bossDown(m); return; }
      // 蓝史莱姆：碎了裂成两只小的往两边蹦（小的不再裂）
      if (KD && KD.split && m.size !== 's' && !o.crush) {
        const hp = R.niceHp(m.maxHp * KD.split), Z = zone();
        for (const dir of [-1, 1]) {
          const tx = clamp(m.x + dir * (m.r + 5), Z.x0, Z.x1), ty = clamp(m.y + (rnd() - 0.5) * 6, Z.y0, Z.y1);
          const q = mk({ kind: m.kind, size: 's', hp, maxHp: hp, base: D.SIZES.s.r * (m.zm || 1), r: D.SIZES.s.r * (m.zm || 1), zm: m.zm || 1, tier: m.tier,
            x: m.x, y: m.y, sx: m.x, sy: m.y, tx, ty, state: 'hop', dur: 0.3, arc: 8, solid: true, cool: 0.2, noSplit: true });
          if (flat()) { q.vx = dir * 70; q.vy = (rnd() - 0.5) * 30; q.knock = o.src === 'knock' || !b ? null : { b, depth: 1 }; }
          s.slimes.push(q);
        }
        fx('split', { m, x: m.x, y: m.y });
      }
      tryRevive(m);
      if (!st.boss && st.bossDue < 0 && !st.stuck && !st.burst && st.phase === 'play') {
        st.lk += o.n || 1;
        const SD = R.stage(st.stage);
        if (st.lk >= LAY().need) {
          if (st.layer < SD.layers.length) {
            st.layer++; st.lk = 0;
            sfx('layer'); fx('layer', { layer: st.layer });
            noteDepth();
          } else if (D.BOSSES[SD.boss] && D.BOSSES[SD.boss].ready !== false) st.bossDue = 0.9;
          else { st.stuck = true; fx('stuck', {}); }
        }
      }
      checkEmpty();
      save();
    }
    const KD0 = m => (!m.boss && D.SLIMES[m.kind]) || null;
    // 蘑菇王打掉：裂成四只中蓝的
    function bossSplit(m) {
      const n = m.def.dieSplit;
      if (!n) return;
      const SD = R.stage(st.stage), hp = R.niceHp(R.minHp(SD.layers[SD.layers.length - 1]));
      for (let i = 0; i < n; i++) {
        const a = (i + 0.5) / n * Math.PI * 2, Z = zone();
        addNormal({ kind: m.def.spitKind || 'blue', size: 'm', hp, from: [m.x, m.y], spot: [clamp(m.x + Math.cos(a) * 22, Z.x0, Z.x1), clamp(m.y + Math.sin(a) * 14, Z.y0, Z.y1)], noGold: true, delay: 0.32 });
      }
    }
    // 台上打空了（没有 boss 要来、没有要复活的）：台上那颗弹珠这一下就算用完（买了"回收"：放回袋子里）
    function checkEmpty() {
      if (st.boss || st.bossDue >= 0 || st.burst || st.phase !== 'play') return;
      if (normals().length || st.revives.length) return;
      for (const b of s.balls) if ((b.state === 'play' || b.state === 'rest') && b.useT == null) b.useT = 0.3;
    }
    function noteDepth() { if (!st.run) return; const d = { stage: st.stage, layer: st.layer }; if (R.deeper(d, st.run.deep)) st.run.deep = d; }
    // 下一关做好了没有（没做好的：打掉 boss 也不往下，停在这一关，"往下还没挖好"——第一阶段的墙 C）
    const nextReady = () => st.stage < D.STAGES.length && R.stage(st.stage + 1).ready !== false;
    function bossDown(m) {
      st.boss = null; st.bossDue = -1;
      st.hitstop = 0.3;
      const next = nextReady();
      if (next) st.burst = { t: 0, x: m.x, y: m.y, from: st.stage, switched: false };
      else { st.stuck = true; fx('stuck', { end: true }); }
      // 第一次打掉草地大王以外的 boss（大蜗牛只有火山弹打得动）：作者来电
      if (!S.trophies[m.def.k] && m.def.k !== 'grassKing') R.queueCall(S, 'creator');
      S.trophies[m.def.k] = (S.trophies[m.def.k] || 0) + 1;
      if (st.run) st.run.bossKilled = true;
      const k = R.pickOf(S);
      for (let i = 0; i < K.bossBall; i++) st.bag.push(k);
      if (K.bossBall) fx('bagAdd', { n: K.bossBall });
      shake(0.5);
      fx('bossDown', { m, next });
      save();
    }
    function updateBurst(dt) {
      const B = st.burst;
      if (!B.switched) {
        B.switched = true;
        for (const o of normals()) { if (o.state === 'wait') { o.state = 'pop'; o.t = 1; } else kill(o, false, null); }   // 剩下的跟着炸掉，金币照给
        st.revives = [];
        st.stage = Math.min(D.STAGES.length, st.stage + 1); st.layer = 1; st.lk = 0; st.stuck = false;
        noteDepth();
        // 第一次看到这一关：露这一关的节点（密度、过关补珠……）
        if (st.stage > S.maxStage) { fx('band', { band: st.stage }); revealed(R.seeStage(S, st.stage)); if (R.stage(st.stage).night && !R.stage(st.stage - 1).night) R.queueCall(S, 'night'); }
        // 弹珠还在台上打：下一关的史莱姆跟着掉下来，接着打
        for (let i = 0; i < count(); i++) addNormal({ delay: 0.5 + i * 0.12 });
        fx('stage', { stage: st.stage });
      }
      B.t += dt;
      if (B.t > 1.3) st.burst = null;
    }

    // ---------- 骨刺：骨球每掉一下耐久，有几率崩几根往外飞 ----------
    function spikes(b) {
      const SP = K.spike;
      if (!SP || b.kind !== 'bone' || rnd() >= SP.p) return;
      const M = R.marbleOf(K, b.kind), a0 = rnd() * Math.PI * 2, n = SP.n;
      for (let i = 0; i < n; i++) {
        const a = a0 + (n > 1 ? (i / (n - 1) - 0.5) * D.SPIKE.spread * (n - 1) : 0);
        st.shards.push({ x: b.x, y: b.y, vx: Math.cos(a) * D.SPIKE.speed, vy: Math.sin(a) * D.SPIKE.speed, t: 0, pierce: SP.pierce, hit: new Set(), tier: M.tier, M });
      }
      sfx('crack', 900); fx('spikes', { x: b.x, y: b.y, n });
    }
    function updateShards(dt) {
      for (const q of st.shards) {
        q.t += dt; q.x += q.vx * dt; q.y += q.vy * dt;
        if (q.t > D.SPIKE.life || q.x < P.X0 || q.x > (flat() ? F.X1 : P.LANE_X) || q.y < P.Y0 || q.y > (flat() ? F.Y1 : P.YB)) { q.dead = true; continue; }
        for (const m of s.slimes) {
          if (q.dead) break;
          if (!m.solid || m.state === 'pop' || m.state === 'wait' || q.hit.has(m.id)) continue;
          if (Math.hypot(m.x - q.x, m.y - q.y) > m.r + D.SPIKE.r) continue;
          q.hit.add(m.id);
          if (q.tier < m.tier) { fx('ding', { m, x: q.x, y: q.y }); sfx('ding'); q.dead = true; break; }
          if (!m.boss && q.tier >= m.tier + 2) { kill(m, false, null, { n: m.size === 'b' ? 2 : 1, crush: true, shard: true, src: q.coin ? 'chip' : null }); }
          else if (m.size === 'b' && !m.boss) split(m, q.vx, q.vy);
          else {
            const crit = K.critP > 0 && rnd() < K.critP, dmg = hitDmg(q.M, false, crit);
            m.hp -= dmg; m.flash = 0.08; m.squash = 0.2;
            if (m.hp <= 1e-6) kill(m, crit, null, { shard: true, src: q.coin ? 'chip' : null });
            else { m.r = radius(m); fx('hit', { m, dmg, crit, x: q.x, y: q.y, shard: true }); sfx('slime', 200); q.dead = true; break; }
          }
          // 打碎了：穿透的接着飞
          if (q.pierce > 0) q.pierce--; else q.dead = true;
        }
      }
      st.shards = st.shards.filter(q => !q.dead);
    }

    // ---------- 磨损 ----------
    // 弹珠掉耐久：三分之二出一道裂纹，三分之一裂满，掉光碎在台上。why：slime 砸史莱姆、rail 撞栏杆、ding 打不动
    function wear(b, n, why) {
      if (!b || !isFinite(b.dur) || b.state === 'gone') return;
      if (why === 'rail' && b.wearCool > 0) return;
      b.wearCool = 0.08;
      b.dur -= n;
      for (let i = 0; i < n; i++) { spikes(b); chips(b); }
      const c = b.dur <= 0 ? 3 : b.dur <= b.maxDur / 3 ? 2 : b.dur <= b.maxDur * 2 / 3 ? 1 : 0;
      if (c > b.crack) {
        b.crack = c;
        if (c < 3) { sfx('crack', 600); fx('crack', { b }); }
      }
      if (b.dur <= 0) {
        b.state = 'gone';
        s.balls = s.balls.filter(q => q !== b);
        sfx('shatter'); fx('shatter', { x: b.x, y: b.y, kind: b.kind, why });
        if (b.kind === 'egg') splash(b);
        if (b.hooked) for (const m of b.hooked) m.hookedBy = null;
      }
    }
    // 一摞硬币：每掉一下耐久崩出一枚，往外飞，打一只
    function chips(b) {
      if (!K.chip || b.kind !== 'coins') return;
      const M = R.marbleOf(K, b.kind), a = rnd() * Math.PI * 2;
      st.shards.push({ x: b.x, y: b.y, vx: Math.cos(a) * D.SPIKE.speed, vy: Math.sin(a) * D.SPIKE.speed, t: 0, pierce: 0, hit: new Set(), tier: M.tier, M, coin: true });
      sfx('clink'); fx('chip', { x: b.x, y: b.y });
    }
    // 挡板拍一下掉耐久（普通弹珠 1，重的 2，很重的 5）：掉一半出裂纹，掉光就断
    function flipWear(side, n) {
      const F = st.flips[side], f = s.flippers.find(q => q.side === side);
      if (!F || !f || f.broken) return;
      const was = F.dur;
      F.dur = Math.max(0, F.dur - n);
      if (was > F.max / 2 && F.dur <= F.max / 2) { sfx('crack', 300); fx('flipCrack', { side, x: f.px, y: f.py }); }
      if (F.dur <= 0) { f.broken = true; f.on = false; sfx('snap'); fx('flipBreak', { side, x: f.px, y: f.py }); }
    }
    function onEvent(e) {
      if (e.type === 'hit') {
        const k = e.kind;
        if (k === 'sling') { sfx('sling'); fx('sling', e); }
        else if (k === 'post') { sfx('bump', e.impact); if (e.impact > RW().post) wear(e.b, 1, 'rail'); }
        else if (k === 'roof') sfx('rim', e.impact);
        else if (k === 'head' || k === 'lane' || k === 'guard') { /* 发射道里的不算 */ }
        else { sfx('wall', e.impact); if (e.impact > RW().wall) wear(e.b, 1, 'rail'); }
      } else if (e.type === 'slime') {
        if (e.res === 'soft' && e.impact > 15) { e.m.squash = Math.max(e.m.squash, 0.08); sfx('slime', e.impact * 0.5); }
      } else if (e.type === 'flip') {
        if (e.moving) sfx('clack', e.impact);
        if (st.flipCool[e.side] <= 0) {
          st.flipCool[e.side] = 0.12;
          const M = R.marbleOf(K, e.b.kind);
          flipWear(e.side, D.WEAR[M.weight]);
        }
      } else if (e.type === 'clack') sfx('clack', e.impact);
      else if (e.type === 'lane') {
        // 钻过小孔：这颗弹珠变金珠（一下打 2 份），掉下去才没
        sfx('settle', 2); fx('lane', e);
        if (e.b && !e.b.gold && e.b.state === 'play') { e.b.gold = true; sfx('settle', 5); fx('goldBall', { b: e.b }); }
      } else if (e.type === 'drain') { sfx('miss'); fx('drain', e); }
      else if (e.type === 'nudge') sfx('wall', 30);
      else if (e.type === 'knock') knockHit(e.a, e.c, e);
      else if (e.type === 'rest') shotEnd(e.b);
      else if (e.type === 'end') { shotEnd(e.b); used(e.b); }
      else if (e.type === 'goal') {
        // 足球：踢进门退回 1 下耐久（一颗最多退几次看树）
        const b = e.b; sfx('settle', 5); fx('goal', e);
        if ((b.goals || 0) < K.goalBack && b.dur < b.maxDur) { b.goals = (b.goals || 0) + 1; b.dur += 1; b.crack = b.dur <= b.maxDur / 3 ? 2 : b.dur <= b.maxDur * 2 / 3 ? 1 : 0; fx('refund', { b }); }
      }
    }
    // 平台面一杆停了：这一杆撞的全是碾过去的不掉耐久，不然掉 1 下（保龄不算杆）
    function shotEnd(b) {
      if (!b) return;
      // 台球一发带出去的那几颗：停了就收走
      if (b.extra) { b.state = 'gone'; s.balls = s.balls.filter(q => q !== b); fx('poof', { x: b.x, y: b.y, kind: b.kind }); return; }
      const sh = b.shot; b.shot = null;
      if (b.hooked) { for (const m of b.hooked) m.hookedBy = null; b.hooked = null; }
      if (!sh || mode === 'bowl') return;
      if (sh.normal > 0 || sh.crush === 0) wear(b, 1, 'shot');
    }
    // 这一颗用完了（保龄滚到头）
    function used(b) {
      if (b.state === 'gone') return;
      b.state = 'gone';
      s.balls = s.balls.filter(q => q !== b);
      fx('usedUp', { x: b.x, y: Math.max(F.Y0 + 4, b.y), kind: b.kind }); sfx('usedUp');
    }

    // ---------- 一轮 ----------
    function mkBall(kind) {
      const M = R.marbleOf(K, kind);
      const r = P.BALL_R * M.r;
      return { kind, dur: M.dur, maxDur: M.dur, crack: 0, wearCool: 0, r, r0: r, gold: false, hits: 0, m: F.WMASS[M.weight] || 1 };
    }
    function loadNext() {
      if (!st.bag.length) return false;
      const kind = st.bag.shift(), dur = st.keep.length ? st.keep.shift() : null, o = mkBall(kind);
      if (dur != null) { o.dur = Math.min(o.maxDur, dur); o.crack = o.dur <= o.maxDur / 3 ? 2 : o.dur <= o.maxDur * 2 / 3 ? 1 : 0; }
      const b = PHY().load(s, o);
      if (!b) { st.bag.unshift(kind); if (dur != null) st.keep.unshift(dur); return false; }
      sfx('clink');
      return true;
    }
    function newFlips() { st.flips = {}; for (const f of s.flippers) st.flips[f.side] = { dur: K.flipDur, max: K.flipDur }; }
    function startRun(stageN) {
      K = R.stats(S);
      // 这轮带的珠子是哪一套：换台面
      const kind = R.pickOf(S), set = (D.MARBLES[kind] && D.MARBLES[kind].set) || 'pin';
      sp.balls = []; sp.slimes = []; sf.balls = []; sf.slimes = []; sp.events.length = 0; sf.events.length = 0;
      mode = set; s = set === 'pin' ? sp : sf;
      if (flat()) F.setMode(sf, set);
      P.setCover(sp, K.cover); for (const f of sp.flippers) f.broken = false; newFlips();
      P.setParts(sp, { sling: K.sling, lanes: K.lanes });
      if (flat()) R.queueCall(S, set === 'flick' ? 'setFlick' : set === 'bowl' ? 'setBowl' : 'setKick');
      st.stage = stageN || R.startStage(S); st.layer = 1; st.lk = 0; st.boss = null; st.bossDue = -1; st.stuck = false; st.burst = null; st.hitstop = 0; st.endT = 0;
      st.shards = []; st.revives = []; st.revived = {}; st.aim = null; st.splashes = [];
      st.bag = R.bagFor(S, K); st.keep = [];
      if (st.stage > S.maxStage) revealed(R.seeStage(S, st.stage));
      st.run = { kills: 0, gold: 0, shots: 0, deep: { stage: st.stage, layer: 1 }, why: null, t: 0, bossSeen: null, bossKilled: false, kind: R.pickOf(S), shardKills: 0, fireKills: 0, revKills: 0, recycled: 0 };
      st.phase = 'play'; st.wait = 0.25; st.refilled = true;
      pl.cancel(); flipAllOff();
      refill(0.05);
      fx('start', {});
    }
    function endRun(why) {
      if (st.phase !== 'play') return;
      st.phase = 'end'; st.run.why = why; st.endT = 0; st.ends++;
      pl.cancel(); flipAllOff();
      // 收工：台上的、推头上的、弹珠袋里的都收回去
      s.balls = []; st.bag = []; st.keep = []; st.shards = []; st.revives = [];
      st.boss = null; st.bossDue = -1;
      for (const o of s.slimes) if (o.boss) { o.state = 'pop'; o.t = 0; o.solid = false; }
      R.endRun(S, st.run.deep);
      // 转生按钮 11-11 挪到作者来电以后才开（R.hangUp 'creator'）：前半小时一世打到底，不回头重打草地
      fx('end', { why });
      save();
    }
    // 重来（树上买的按钮）：这一轮收工，马上从第 1 层重开，新买的都算进去
    function restart() {
      if (!K.restart || st.phase !== 'play') return false;
      endRun('restart');
      startRun();
      sfx('restart');
      return true;
    }
    // 买了节点：台上的零件马上装（挡板、弹力绳、小孔、重来按钮、回收）；数值的等下一轮
    function refresh() {
      const N = R.stats(S), old = { cover: K.cover, sling: K.sling, lanes: K.lanes };
      K.cover = N.cover; K.sling = N.sling; K.lanes = N.lanes; K.restart = N.restart; K.recycle = N.recycle;
      if (Math.abs(K.cover - sp.cover) > 1e-9) {
        const fresh = !sp.flippers.length;
        P.setCover(sp, K.cover);
        if (fresh) newFlips(); else for (const f of sp.flippers) if (!st.flips[f.side]) st.flips[f.side] = { dur: K.flipDur, max: K.flipDur };
        if (!flat()) fx('flipNew', { first: old.cover === 0 });
      }
      if (P.setParts(sp, { sling: K.sling, lanes: K.lanes }) && !flat()) fx('parts', { sling: K.sling && !old.sling, lanes: K.lanes && !old.lanes });
    }
    // 这一轮还有没发出去的弹珠吗（买了数值的，"重来"才有用）
    const marblesLeft = () => st.bag.length + s.balls.filter(b => b.state === 'lane' || b.state === 'queue' || b.state === 'rest').length;

    function update(dt) {
      st.time += dt;
      pl.update(dt);
      st.flipCool.L = Math.max(0, st.flipCool.L - dt); st.flipCool.R = Math.max(0, st.flipCool.R - dt);
      if (st.hitstop > 0) { st.hitstop -= dt; return; }   // 打掉 boss 那一下：整张台停住
      if (st.phase === 'end') {
        st.endT += dt;
        if (st.endT > RESTART_T && !(hooks.hold && hooks.hold())) startRun();
      }
      if (st.run) st.run.t += st.phase === 'play' ? dt : 0;
      if (st.burst) updateBurst(dt);
      if (st.bossDue >= 0) { st.bossDue -= dt; if (st.bossDue < 0) spawnBoss(); }
      updateSlimes(dt);
      updateBoss(dt);
      updateRevives(dt);
      updateShards(dt);
      for (const q of st.splashes) q.t += dt;
      st.splashes = st.splashes.filter(q => q.t < 0.5);
      for (const b of s.balls) {
        b.wearCool = Math.max(0, (b.wearCool || 0) - dt);
        b.stickCool = Math.max(0, (b.stickCool || 0) - dt);
        // 鱼钩：钩着的那几只贴在珠子前头，跟着走（撞到谁，谁挨一下）
        if (b.hooked && b.hooked.length) {
          b.hooked = b.hooked.filter(m => m.state !== 'pop' && m.solid);
          const v = Math.hypot(b.vx, b.vy), ux = v > 1 ? b.vx / v : 0, uy = v > 1 ? b.vy / v : -1;
          b.hooked.forEach((m, i) => {
            const a = (i - (b.hooked.length - 1) / 2) * 0.9, cx = ux * Math.cos(a) - uy * Math.sin(a), cy = ux * Math.sin(a) + uy * Math.cos(a);
            m.x = m.tx = b.x + cx * (b.r + m.r); m.y = m.ty = b.y + cy * (b.r + m.r); m.vx = b.vx; m.vy = b.vy; m.knock = { b, depth: 1 };
          });
        }
        // 打空了：停一下，这颗收走（买了回收：放回袋子里，下一颗还是它）
        if (b.useT != null && (b.state === 'play' || b.state === 'rest')) {
          if (normals().length || st.revives.length) { b.useT = null; continue; }   // 复活的蹦回来了：接着打
          b.useT -= dt;
          if (b.useT <= 0) {
            b.state = 'gone';
            if (K.recycle) { st.bag.unshift(b.kind); st.keep.unshift(b.dur); if (st.run) st.run.recycled++; fx('recycle', { x: b.x, y: b.y, kind: b.kind }); sfx('usedUp'); }
            else { fx('usedUp', { x: b.x, y: b.y, kind: b.kind }); sfx('usedUp'); }
          }
        }
      }
      s.balls = s.balls.filter(b => b.state !== 'gone');
      if (st.phase === 'play') {
        if (!flat() && !laneBall()) { const q = s.balls.find(b => b.state === 'queue'); if (q) q.state = 'lane'; }
        if (!s.balls.some(b => b.state === 'play' || b.state === 'lane' || b.state === 'queue' || b.state === 'rest')) {
          // 两颗弹珠中间：先补史莱姆，再上下一颗
          if (!st.refilled && st.bag.length) { refill(0); st.refilled = true; }
          if (st.bag.length) { st.wait -= dt; if (st.wait <= 0) { loadNext(); st.wait = 0.35; } }
          else if (!st.burst && !st.shards.length && !st.revives.length) { st.endT += dt; if (st.endT > 0.8) endRun('out'); }
        } else { st.endT = 0; if (playing().length) st.refilled = false; }
      }
      st.acc.t += dt;
      let n = 0;
      const Ph = PHY();
      while (st.acc.t >= DT && n < 400 && st.hitstop <= 0) { Ph.step(s); st.acc.t -= DT; n++; }
      if (st.hitstop > 0) st.acc.t = 0;
      for (const e of s.events.splice(0)) onEvent(e);
    }

    // ---------- 手 ----------
    function setFlip(side, id, on) {
      const set = st.hold[side];
      if (on) set.add(id); else set.delete(id);
      const f = s.flippers.find(q => q.side === side);
      if (!f) return;
      const was = f.on;
      f.on = set.size > 0 && !f.broken;
      if (f.on && !was) sfx('flip');
    }
    function flipAllOff() { st.hold.L.clear(); st.hold.R.clear(); for (const f of s.flippers) f.on = false; }
    function startPlunger(by) { if (st.phase !== 'play' || !laneBall() || pl.on) return false; pl.start(by); return true; }
    function releasePlunger(by) {
      if (!pl.on || (by != null && pl.by !== by)) return;
      const p = pl.release();
      const b = laneBall();
      if (!b) return;
      P.launch(s, p);
      st.shots++; st.run.shots++; if (s.flippers.length) st.flipShots++;
      sfx('launch', p); fx('launch', { p, b });
    }
    // 平台面：按下挑一颗停着的珠子（离手最近的；保龄的珠子挪到按的那一列），往后拉，松手弹出去
    const PULL = 40;
    const restBalls = () => s.balls.filter(b => b.state === 'rest');
    function aimStart(sx, sy, id) {
      const rb = restBalls();
      if (!rb.length || playing().length) return false;
      let b = rb[0], bd = Infinity;
      for (const q of rb) { const d = Math.hypot(q.x - sx, q.y - sy); if (d < bd) { bd = d; b = q; } }
      if (mode === 'bowl') b.x = clamp(sx, F.X0 + b.r + 8, F.X1 - b.r - 8);
      st.aim = { b, id, x0: sx, y0: sy, x: sx, y: sy };
      return true;
    }
    // 拉了多少 → 出手的速度（拉的方向反过来）；保龄最多斜 35°
    function aimShot(A_) {
      let dx = A_.x - A_.x0, dy = A_.y - A_.y0;
      const l = Math.hypot(dx, dy);
      if (l < 3) return null;
      let ux = -dx / l, uy = -dy / l;
      if (mode === 'bowl') { if (uy > -0.2) uy = -0.2; const a = Math.max(-0.61, Math.min(0.61, Math.atan2(ux, -uy))); ux = Math.sin(a); uy = -Math.cos(a); }
      const p = Math.min(1, l / PULL), C = F.MODES[mode], v = C.vmax * (0.25 + 0.75 * p) * (K.bouncy && A_.b.kind === 'rubber' ? K.bouncy.v : 1);
      return { vx: ux * v, vy: uy * v, p, ux, uy };
    }
    function flick(b, vx, vy) {
      if (st.phase !== 'play' || !b || b.state !== 'rest') return false;
      b.shot = { normal: 0, crush: 0 }; b.vboost = 1;
      if (b.kind === 'rubber' && K.bouncy) { b.bouncy = true; b.bounceV = Math.hypot(vx, vy) * 0.55; b.mu = 0.6; }
      F.launch(s, b, vx, vy);
      // 台球：一发几颗，摆成扇面一起出去（跟着这一颗的耐久，不从袋子里拿）
      if (b.kind === 'pool' && K.rack > 1 && !b.extra) {
        const v = Math.hypot(vx, vy), a0 = Math.atan2(vy, vx);
        for (let i = 1; i < K.rack; i++) {
          const k = Math.ceil(i / 2) * (i % 2 ? 1 : -1), a = a0 + k * 0.16;
          const q = F.load(s, mkBall('pool')); q.extra = true;
          q.x = b.x - Math.cos(a0) * 2 + Math.cos(a0 + Math.PI / 2) * k * (b.r * 2.1); q.y = b.y - Math.sin(a0) * 2 + Math.sin(a0 + Math.PI / 2) * k * (b.r * 2.1);
          q.shot = { normal: 0, crush: 0 };
          F.launch(s, q, Math.cos(a) * v * 0.92, Math.sin(a) * v * 0.92);
        }
      }
      st.shots++; if (st.run) st.run.shots++;
      sfx('launch', 0.6); fx('flick', { b });
      return true;
    }
    function aimRelease(id) {
      const A_ = st.aim;
      if (!A_ || (id != null && A_.id !== id)) return;
      st.aim = null;
      const sh = aimShot(A_);
      if (sh) flick(A_.b, sh.vx, sh.vy);
    }
    function move(p) { if (st.aim && p.sx != null) { st.aim.x = p.sx; st.aim.y = p.sy; } }
    function down(p) {
      if (st.phase !== 'play') return false;
      if (flat()) return p.sx != null && aimStart(p.sx, p.sy, p.id);
      const lb = laneBall();
      if (lb && !playing().length) { startPlunger(p.id); return true; }
      if (playing().length && s.flippers.length) { setFlip(p.touch ? (p.x < 320 ? 'L' : 'R') : p.btn === 2 ? 'R' : 'L', p.id, true); return true; }
      if (lb) { startPlunger(p.id); return true; }
      return false;
    }
    function up(p) { if (flat()) { aimRelease(p.id); return; } releasePlunger(p.id); setFlip('L', p.id, false); setFlip('R', p.id, false); }
    // 平台面的空格：照最近那只直接弹（七成力）
    function quickShot() {
      const b = restBalls()[0];
      if (!b || playing().length) return false;
      const ts = alive().filter(o => o.solid && o.state !== 'pop');
      let t = null, bd = Infinity;
      for (const o of ts) { const d = Math.hypot(o.x - b.x, o.y - b.y); if (d < bd) { bd = d; t = o; } }
      const ux = t ? (t.x - b.x) / bd : 0, uy = t ? (t.y - b.y) / bd : -1, v = F.MODES[mode].vmax * 0.7;
      return flick(b, ux * v, uy * v);
    }
    function key(code, isDown) {
      if (flat()) {
        if ((code === 'Space' || code === 'Enter') && isDown) return quickShot();
        if (code === 'KeyR' && isDown) return restart();
        return false;
      }
      if (code === 'Space' || code === 'ArrowDown' || code === 'Enter') { if (isDown) startPlunger('key'); else releasePlunger('key'); return true; }
      if (code === 'KeyZ' || code === 'ArrowLeft' || code === 'ShiftLeft') { setFlip('L', code, isDown); return true; }
      if (code === 'KeyM' || code === 'ArrowRight' || code === 'ShiftRight' || code === 'Slash') { setFlip('R', code, isDown); return true; }
      if (code === 'KeyR' && isDown) return restart();
      return false;
    }
    // 自动手（截图、测节奏用）：挑一只史莱姆，照力度表拉到对的力度（手抖 σ 跟着 noise 走）；弹珠到挡板上方就拍，noise 是漏接的几率
    const gauss = () => Math.sqrt(-2 * Math.log(1 - rnd())) * Math.cos(2 * Math.PI * rnd());
    function autoFlat(dt) {
      const A_ = st.auto || (st.auto = { wait: 0 });
      const b = restBalls()[0];
      if (!b || playing().length || st.aim) { A_.wait = 0; return; }
      A_.wait += dt;
      if (A_.wait < 0.35) return;
      A_.wait = 0;
      const ts = alive().filter(o => o.solid && o.state !== 'pop' && o.state !== 'wait');
      if (!ts.length) return;
      const B = st.boss && st.boss.state === 'live' && st.boss.solid ? st.boss : null;
      const o = B && rnd() < 0.5 ? B : ts[Math.floor(rnd() * ts.length)];
      if (mode === 'bowl') b.x = clamp(o.x + gauss() * 10, F.X0 + b.r + 8, F.X1 - b.r - 8);
      const d = Math.hypot(o.x - b.x, o.y - b.y) || 1;
      let a = Math.atan2(o.y - b.y, o.x - b.x) + gauss() * (0.03 + 0.15 * (hooks.noise || 0));
      if (mode === 'bowl') a = Math.max(-Math.PI / 2 - 0.6, Math.min(-Math.PI / 2 + 0.6, a));
      const p = clamp(0.35 + d / 160 + gauss() * 0.05, 0.3, 1), v = F.MODES[mode].vmax * (0.25 + 0.75 * p);
      flick(b, Math.cos(a) * v, Math.sin(a) * v);
    }
    function auto(dt) {
      if (st.phase !== 'play') return;
      if (flat()) return autoFlat(dt);
      const A_ = st.auto || (st.auto = { near: { L: false, R: false }, skip: { L: false, R: false }, flipT: { L: 0, R: 0 }, hold: 0 });
      const b = laneBall(), live = playing();
      if (b && !live.length) {
        if (!pl.on) {
          const ts = alive().filter(o => o.solid && o.state === 'live');
          // 史莱姆还在往下掉：等它落地再瞄（最多等 1.5 秒）
          if (!ts.length && (A_.wait = (A_.wait || 0) + dt) < 1.5) return;
          A_.wait = 0;
          let p = 0.5 + rnd() * 0.4;
          if (ts.length) { const o = ts[Math.floor(rnd() * ts.length)]; p = powerFor(o.x, o.y - o.r * 0.3); }
          p = Math.max(0.02, Math.min(1, p + gauss() * (0.02 + 0.08 * (hooks.noise || 0))));
          A_.hold = p * Sim.HOLD_FILL;
          startPlunger('auto');
        } else if (pl.by === 'auto' && pl.t >= A_.hold) releasePlunger('auto');
      }
      for (const f of s.flippers) {
        const side = f.side, dir = side === 'L' ? 1 : -1, mid = f.px + dir * f.len * 0.55;
        const near = live.some(o => o.vy > -20 && o.y > 110 && o.y < 140 && Math.abs(o.x - mid) < f.len * 0.55 + 7);
        if (near && !A_.near[side]) { A_.near[side] = true; A_.skip[side] = rnd() < (hooks.noise || 0); }
        if (!near) A_.near[side] = false;
        if (near && !A_.skip[side] && A_.flipT[side] <= 0 && rnd() < 0.5) { setFlip(side, 'auto', true); A_.flipT[side] = 0.18; }
        if (A_.flipT[side] > 0) { A_.flipT[side] -= dt; if (A_.flipT[side] <= 0) setFlip(side, 'auto', false); }
      }
    }
    // 开发者：直接到这一关的 boss
    function jumpBoss() {
      if (st.phase !== 'play') return;
      const SD = R.stage(st.stage);
      st.layer = SD.layers.length; st.lk = LAY().need; noteDepth();
      if (D.BOSSES[SD.boss] && D.BOSSES[SD.boss].ready !== false && !st.boss) st.bossDue = 0.1;
    }
    // 开发者 / 截图：直接到这一关第 n 层（台上的换成这一层的）
    function setLayer(n) {
      if (st.phase !== 'play') return;
      const SD = R.stage(st.stage);
      st.layer = Math.max(1, Math.min(SD.layers.length, n)); st.lk = 0; noteDepth();
      s.slimes = s.slimes.filter(o => o.boss);
      refill(0.05);
    }
    // 开发者：台上的 boss 直接打掉（走真的打死那一套：停住、炸开、下一关）
    function killBoss() {
      const o = st.boss;
      if (!o || st.phase !== 'play' || o.state === 'pop') return false;
      o.hp = 0; kill(o, false, null);
      return true;
    }
    function debug() {
      return { mode, phase: st.phase, stage: st.stage, layer: st.layer, lk: st.lk, need: LAY().need, boss: st.boss ? Math.round(st.boss.hp * 10) / 10 : null, bag: st.bag.slice(), parts: Object.assign({}, s.parts), cover: s.cover, balls: s.balls.map(b => b.state + ':' + b.kind + ':' + b.dur + (b.gold ? ':gold' : '')), slimes: normals().map(o => o.kind + o.size + ':' + o.hp), shards: st.shards.length, revives: st.revives.length, flips: Object.fromEntries(Object.entries(st.flips).map(([k, F]) => [k, F.dur])), gold: Math.round(S.gold * 10) / 10, run: st.run && { kills: st.run.kills, gold: Math.round(st.run.gold * 10) / 10, t: Math.round(st.run.t), deep: st.run.deep } };
    }
    return {
      get s() { return s; }, get mode() { return mode; }, sp, sf, st, pl, get K() { return K; },
      startRun, endRun, quit: () => endRun('quit'), restart, refresh, update, auto, down, up, move, key, setFlip, marblesLeft, flick, aimShot, restBalls,
      cancel() { pl.cancel(); flipAllOff(); },
      laneBall, playing, normals, alive, jumpBoss, killBoss, setLayer, debug, powerFor, ignite,
    };
  }
  return { create, reachLo, aimTable, powerFor, TUTOR, RESTART_T };
}));
