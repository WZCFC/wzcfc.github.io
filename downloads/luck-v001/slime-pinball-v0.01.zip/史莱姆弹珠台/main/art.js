/*
 * 主线的画（卡面、关卡底图、台面上的硬件、碎背景、挡板、珠子、节点图标）。全是像素：平涂、深边、没有光晕渐变。
 *   卡 96×84（大台），4 倍放在正中；台面上的东西 2 倍（一格 = 卡面半格，坐标跟 sims/mainline.js 一样）。
 *   卡分三层画：底图（每关一张，虚化）→ 卡框（每关一样）→ 硬件（导轨、弹弓、发射道、发力灯、口子）。
 *   打掉 boss：底图按 Voronoi 裂成十几块往外飞，底下露出下一关；碎块从卡框底下钻出去。
 * 要先 Art.setCard('swamp')（96 宽，CX0 = 128）。
 */
window.MainArt = (function () {
  'use strict';
  const A = Art, K = A.kit, INK = A.INK, P = window.MainLine;
  const { layer, lset, lget, lE, lR, lP, lL, lPuff, outl, toHex, toRGB, mix, fl, rd } = K;
  const PW = 96, PH = 84, S4 = 4, CW4 = PW * S4, CH4 = PH * S4;
  const LOOKM = { f: ['#c8f080', '#8ad048', '#4a9a2a'], em: '#ff6aa8' }, RAIL = '#fff3a0';
  const inA = K.inArtOf('side', PW);
  const SIDE = K.sideOf(PW);
  const canvas = (w, h) => { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; };

  // ---------- 两关的底图（卡面格子，96×84；台面里 x 7..88、y 10..72） ----------
  const SKY = '#a8e0ff', SKY2 = '#c8f0ff';
  const STAGE_ART = {
    // 草地：早上。两朵云，远处一道矮坡和一排篱笆，近处一条一条的草，几朵小花（太阳虚化以后压成土色，不画）
    grass: {
      bg(x, y) {
        if (y < 23) return SKY;
        if (y < 26) return SKY2;
        if (y < 29 + Math.round(1.5 * Math.sin(x / 8))) return '#6ac85a';
        return fl((y - 29) / 6) % 2 ? '#3f9a38' : '#46a63e';
      },
      paint(art) {
        art(L => { lPuff(L, [[33, 16, 4, 2.6], [37.5, 14.5, 4.2, 3], [42, 16.5, 3.6, 2.2]], A.kit.CLOUD, 17); lPuff(L, [[62, 19, 3.4, 2.2], [66, 17.5, 4, 2.8], [70, 19.5, 3.4, 2]], A.kit.CLOUD, 20); });
        art(L => {
          for (let x = 8; x <= 88; x += 6) lR(L, x, 27, 2, 6, ['#f0c070', '#c08040', '#8a5226']);
          for (let x = 7; x <= 88; x++) { lset(L, x, 28, '#e8a85a'); lset(L, x, 31, '#c07a36'); }
        });
        art(L => { for (const [x, y] of [[12, 40], [30, 47], [52, 39], [72, 46], [20, 58], [44, 62], [64, 56], [82, 62], [36, 36], [80, 37]]) { lset(L, x, y, '#2f7a2e'); lset(L, x + 2, y, '#2f7a2e'); lset(L, x + 1, y + 1, '#2f7a2e'); } }, false);
        art(L => {
          for (const [x, y, c] of [[18, 44, '#ff6aa8'], [40, 52, '#ffffff'], [60, 44, '#ffd23a'], [76, 52, '#ff6aa8'], [26, 64, '#ffd23a'], [56, 66, '#ffffff'], [86, 44, '#ffffff'], [10, 52, '#ffd23a']]) {
            for (const [dx, dy] of [[0, -1], [-1, 0], [1, 0], [0, 1]]) lset(L, x + dx, y + dy, c);
            lset(L, x, y, c === '#ffd23a' ? '#e0a010' : '#ffd23a');
          }
        }, false);
      },
    },
    // 菜园：阴天。远处一排树，地是一垄一垄的土，垄上一棵棵卷心菜，左边一个稻草人，两摊水
    garden: {
      bg(x, y) {
        if (y < 21) return '#b8c8d8';
        if (y < 24) return '#d0dce6';
        if (y < 26) return '#4a6a3a';
        const k = (y - 26) % 6;
        return k === 0 ? '#5a3820' : k < 3 ? '#7e5232' : '#6e4628';
      },
      paint(art) {
        art(L => { lPuff(L, [[10, 23, 4, 2.6], [17, 22, 4.4, 3.2], [25, 23, 4, 2.6], [33, 22.5, 4.4, 3], [43, 23, 4, 2.6], [52, 22, 4.6, 3.2], [61, 23, 4, 2.6], [70, 22.5, 4.4, 3], [79, 23, 4, 2.6], [87, 22, 4, 3]], { light: '#5aa84a', base: '#3a7a34', shade: '#2a5a2a' }, 24); });
        art(L => { lPuff(L, [[30, 13, 4.4, 2.6], [36, 11.5, 5, 3.2], [42, 13, 4.4, 2.4]], { light: '#ffffff', base: '#e6eef4', shade: '#b8c8d8' }, 14); lPuff(L, [[66, 15, 4, 2.4], [71, 13.5, 4.6, 3], [76, 15, 3.8, 2.2]], { light: '#ffffff', base: '#e6eef4', shade: '#b8c8d8' }, 16); });
        art(L => {
          for (const row of [[33, 0], [45, 1], [57, 0], [69, 1]]) {
            const [y, off] = row;
            for (let x = 13 + off * 6; x <= 86; x += 12) {
              lE(L, x, y, 3.4, 2.6, ['#c8f090', '#5ab83a', '#2a7a2a']);
              lset(L, x, y - 1, '#e8ffc0'); lset(L, x - 1, y, '#2a7a2a'); lset(L, x + 1, y, '#2a7a2a');
            }
          }
        });
        art(L => { lE(L, 50, 51, 4, 1.4, ['#c8e8ff', '#7ac0ff', '#2f86ea']); lE(L, 30, 63, 3.4, 1.2, ['#c8e8ff', '#7ac0ff', '#2f86ea']); });
        art(L => {
          // 稻草人：一根杆、一根横杆、草帽、红格子衣服
          for (let y = 27; y <= 46; y++) { lset(L, 13, y, '#8a5226'); lset(L, 14, y, '#c07a36'); }
          for (let x = 7; x <= 20; x++) lset(L, x, 33, '#c07a36');
          lR(L, 10, 33, 8, 7, (x, y) => ((x + y) % 3 === 0 ? '#ffd23a' : '#fe4c40'));
          lE(L, 13.5, 30, 2.6, 2.4, ['#fff0c8', '#f0d090', '#c8a060']);
          lR(L, 9, 27, 10, 1, '#e0a010'); lR(L, 11, 25, 6, 2, '#ffd23a');
          lset(L, 12, 30, INK); lset(L, 15, 30, INK);
        });
      },
    },
    // 蘑菇洞：洞顶一排钟乳石，地是一层一层的土，红的蓝的大蘑菇，几块石头
    cave: {
      bg(x, y) {
        if (y < 14) return '#3a2a48';
        if (y < 20) return '#4a3a5a';
        if (y < 27) return '#5a4868';
        return fl((y - 27) / 6) % 2 ? '#62483a' : '#6a5040';
      },
      paint(art) {
        art(L => { [6, 9, 5, 8, 6, 10, 5, 7, 9].forEach((len, i) => { const x = 10 + i * 9; lP(L, [[x - 2, 10], [x + 3, 10], [x + 0.5, 10 + len]], (xx, yy) => (xx < x ? '#6a5a7a' : '#4a3a5a')); }); });
        art(L => { for (const [x, y] of [[20, 24], [36, 25], [58, 24], [76, 25]]) { lR(L, x, y, 1, 2, '#c8b8a8'); lE(L, x + 0.5, y, 2, 1.3, ['#a8e0ff', '#4a9ae8', '#2a5aa8'], (xx, yy, u, v) => v <= 0.2); } });
        const RED = ['#ff8a7a', '#fe4c40', '#b8322a'], BLUE = ['#a8e0ff', '#4a9ae8', '#2a5aa8'];
        art(L => {
          for (const [x, y, red] of [[14, 40, 1], [80, 44, 0], [26, 62, 0], [70, 64, 1], [48, 36, 1], [58, 52, 0]]) {
            lR(L, x - 1, y, 3, 5, ['#fff0d8', '#f0d8b8', '#c8a888']);
            lE(L, x + 0.5, y + 0.5, 4.4, 3, red ? RED : BLUE, (xx, yy, u, v) => v <= 0.25);
            lset(L, x - 1, y - 1, '#ffffff'); lset(L, x + 2, y - 2, '#ffffff'); lset(L, x + 3, y, '#ffffff');
          }
        });
        art(L => { for (const [x, y, r] of [[36, 46, 2.4], [86, 60, 2], [10, 70, 2.6], [62, 70, 1.8]]) lE(L, x, y, r * 1.3, r, ['#9a8aa8', '#6a5a7a', '#4a3a5a']); });
      },
    },
    // 沼泽：阴天，两棵枯树，水面一片片荷叶，几丛蒲草，两摊黄泥
    swamp: {
      bg(x, y) {
        if (y < 18) return '#9aa88a';
        if (y < 22) return '#aab89a';
        if (y < 26) return '#4a5a3a';
        return fl((y - 26) / 5) % 2 ? '#456448' : '#4a6a52';
      },
      paint(art) {
        art(L => { lPuff(L, [[10, 24, 4, 2.6], [18, 23, 4.4, 3], [28, 24, 4, 2.4], [40, 23.5, 4.4, 2.8], [52, 24, 4, 2.4], [64, 23, 4.6, 3], [74, 24, 4, 2.6], [84, 23.5, 4.4, 2.8]], { light: '#6a8a4a', base: '#4a6a3a', shade: '#3a5a2a' }, 25); });
        art(L => {
          for (const tx of [14, 78]) {
            lR(L, tx, 12, 2, 14, ['#7a6a5a', '#5a4a3a', '#4a3a2a']);
            lL(L, tx, 17, tx - 4, 13, '#5a4a3a'); lL(L, tx + 1, 15, tx + 5, 11, '#5a4a3a'); lL(L, tx + 1, 20, tx + 4, 18, '#5a4a3a');
          }
        });
        art(L => {
          for (const [x, y] of [[20, 36], [44, 44], [66, 38], [30, 56], [58, 60], [80, 52], [12, 66]]) {
            lE(L, x, y, 3.6, 1.8, ['#c8f080', '#7ab83a', '#3a6a1a'], (xx, yy, u, v) => !(u > 0 && Math.abs(v) < 0.3));
          }
          lE(L, 44, 43, 1.2, 1, ['#ffd0e8', '#ff6aa8', '#a83a6a']);
        });
        art(L => {
          for (const [x0, y0] of [[8, 34], [86, 38], [40, 70], [70, 72]]) for (let k = 0; k < 3; k++) {
            const x = x0 + k * 2 - 2, h = 6 - (k % 2) * 2;
            lL(L, x, y0, x, y0 - h, '#6a8a3a'); lR(L, x, y0 - h - 2, 1, 2, '#8a5226');
          }
        });
        art(L => { lE(L, 52, 30, 4, 1.3, ['#f2c98a', '#c8823e', '#7a4a1e']); lE(L, 22, 46, 3.4, 1.2, ['#f2c98a', '#c8823e', '#7a4a1e']); });
      },
    },
    // 冰河：远处一排雪山，冰面一格一格裂，两岸是雪，岸上几棵松树，冰上漂几块冰
    river: {
      bg(x, y) {
        if (y < 18) return '#c8e4f8';
        if (y < 26) return '#e0f0fc';
        if (x < 12 || x > 84) return '#f4faff';
        return (y - 26) % 7 === 0 ? '#d8f0fc' : '#b8e0f4';
      },
      paint(art) {
        art(L => {
          for (const [a, pk, b, py] of [[4, 18, 30, 13], [24, 42, 60, 10], [52, 68, 86, 13], [74, 88, 100, 16]]) {
            lP(L, [[a, 26], [pk, py], [b, 26]], (xx, yy) => (yy < py + 4 ? '#ffffff' : xx < pk ? '#a8c0dc' : '#8aa8c8'));
          }
        });
        art(L => {
          for (const [x0, y0, pts] of [[24, 34, [[4, 3], [3, 6], [6, 8]]], [56, 44, [[-3, 4], [2, 7], [-2, 11]]], [36, 58, [[5, 2], [9, 5], [12, 4]]], [70, 62, [[-4, 3], [-2, 7]]]]) {
            let px = x0, py = y0;
            for (const [dx, dy] of pts) { lL(L, px, py, x0 + dx, y0 + dy, '#7ab8dc'); px = x0 + dx; py = y0 + dy; }
          }
        }, false);
        art(L => { for (const [x, y, w] of [[44, 34, 6], [20, 50, 5], [64, 54, 7], [48, 68, 5]]) lR(L, x, y, w, 2, ['#ffffff', '#e8f6ff', '#c8e4f4']); });
        art(L => { for (const [x, y] of [[5, 34], [9, 52], [4, 68], [88, 30], [90, 48], [86, 64]]) { lP(L, [[x - 3, y + 4], [x, y - 3], [x + 3, y + 4]], (xx, yy) => (xx < x ? '#3a8a4a' : '#2a6a3a')); lR(L, x, y + 4, 1, 2, '#8a5226'); } });
      },
    },
    // 地下海：洞顶压着，水面一道浪线，深蓝的水，底下珊瑚、海草，水里几个泡泡、远处几只水母
    sea: {
      bg(x, y) {
        if (y < 16) return '#2a2a4a';
        if (y < 22) return '#34345a';
        if (y > 62) return '#163a70';
        return fl((y - 22) / 4) % 2 ? '#1a4280' : '#1e4a8a';
      },
      paint(art) {
        art(L => { [5, 8, 4, 7, 9, 5, 6, 8].forEach((len, i) => { const x = 12 + i * 10; lP(L, [[x - 2, 10], [x + 2, 10], [x, 10 + len]], '#44446a'); }); });
        art(L => { for (let x = 7; x <= 88; x++) lset(L, x, 22 + (x % 6 < 3 ? 0 : 1), '#7ac0ff'); }, false);
        art(L => {
          for (const [x, y, c] of [[12, 72, '#ff6aa8'], [40, 72, '#ff9a3a'], [72, 72, '#ff6aa8']]) {
            lL(L, x, y, x, y - 6, c); lL(L, x, y - 3, x - 3, y - 6, c); lL(L, x, y - 4, x + 3, y - 8, c); lL(L, x - 3, y - 6, x - 3, y - 8, c);
          }
          for (const [x, y] of [[24, 72], [56, 72], [84, 72]]) for (let k = 0; k < 8; k++) lset(L, x + (k % 4 < 2 ? 0 : 1), y - k, '#3aa86a');
        });
        art(L => { for (const [x, y] of [[30, 38], [62, 30], [78, 46], [18, 50]]) { lE(L, x, y, 2.6, 1.8, ['#ffe0f8', '#e8a0e8', '#9a5aa8'], (xx, yy, u, v) => v <= 0.3); for (const d of [-1, 0, 1]) lL(L, x + d, y + 1, x + d, y + 3, '#c88ad0'); } });
        art(L => { for (const [x, y] of [[48, 40], [50, 34], [20, 30], [70, 58], [86, 36]]) { lset(L, x, y, '#a8e0ff'); lset(L, x + 1, y - 1, '#ffffff'); } }, false);
      },
    },
    // 岩浆：暗红的天，一座冒火的山，黑石头地上两道弯弯的岩浆河，几块大石头，几颗火星
    lava: {
      bg(x, y) {
        if (y < 16) return '#4a1a1a';
        if (y < 24) return '#6a2a1a';
        return fl((y - 24) / 6) % 2 ? '#342424' : '#3a2a2a';
      },
      paint(art) {
        art(L => {
          lP(L, [[26, 26], [42, 12], [52, 12], [68, 26]], (xx, yy) => (xx < 47 ? '#3a2020' : '#2a1818'));
          lR(L, 43, 11, 8, 2, ['#ffd23a', '#ff7a2a', '#b8321a']);
          lL(L, 46, 13, 43, 20, '#ff7a2a'); lL(L, 48, 13, 52, 22, '#ff7a2a');
        });
        art(L => {
          for (const [y0, a, f] of [[40, 4, 9], [60, 3, 7]]) for (let x = 7; x <= 88; x++) {
            const y = Math.round(y0 + a * Math.sin(x / f + y0));
            lset(L, x, y - 1, '#ff7a2a'); lset(L, x, y, '#ffd23a'); lset(L, x, y + 1, '#ff7a2a');
          }
        });
        art(L => { for (const [x, y, r] of [[16, 50, 2.6], [76, 34, 2.2], [56, 70, 2.8], [30, 68, 2], [84, 54, 2.4]]) lE(L, x, y, r * 1.3, r, ['#7a3a2a', '#4a2018', '#2a1008']); });
        art(L => { for (const [x, y] of [[20, 30], [60, 32], [36, 48], [70, 50], [12, 62]]) lset(L, x, y, '#ffd23a'); }, false);
      },
    },
    // 史莱姆王城：黄昏，四座塔（绿史莱姆的尖顶），一道砖墙，棋盘格的地，当中一条红地毯，地毯头上一把金宝座
    castle: {
      bg(x, y) {
        if (y < 16) return '#5a4a8a';
        if (y < 22) return '#6a5a9a';
        if (y < 30) return (y % 3 === 0 || (x + (fl(y / 3) % 2) * 3) % 6 === 0) ? '#6a5a7a' : '#8a7a9a';
        if (x >= 40 && x <= 55) return x === 40 || x === 55 ? '#ffd23a' : '#c83a3a';
        return (fl(x / 6) + fl((y - 30) / 6)) % 2 ? '#9a8aa8' : '#7a6a8a';
      },
      paint(art) {
        art(L => {
          for (const tx of [8, 28, 62, 82]) {
            lR(L, tx - 3, 14, 7, 16, ['#a89ab8', '#8a7a9a', '#6a5a7a']);
            lP(L, [[tx - 4, 14], [tx + 0.5, 6], [tx + 5, 14]], (xx, yy) => (xx < tx ? '#8af06a' : '#4a9a2a'));
            lR(L, tx - 1, 19, 2, 3, INK);
          }
          for (let x = 12; x <= 84; x += 4) if (x < 40 || x > 56) lR(L, x, 21, 2, 2, ['#a89ab8', '#8a7a9a', '#6a5a7a']);
        });
        art(L => { for (const tx of [18, 74]) { lR(L, tx, 14, 1, 8, '#5a4a3a'); lR(L, tx + 1, 14, 5, 4, ['#c8f080', '#5ac83a', '#2a7a2a']); lset(L, tx + 2, 15, INK); lset(L, tx + 4, 15, INK); } });
        art(L => { lR(L, 44, 20, 8, 10, ['#fff3a0', '#ffd23a', '#c88a10']); lR(L, 45, 24, 6, 3, '#c83a3a'); lset(L, 44, 19, '#ffd23a'); lset(L, 51, 19, '#ffd23a'); });
      },
    },
  };
  // 夜里那几关：白天的景压暗、往藏青里沉（执行方案"全套粗做"第九节）
  const NIGHT_C = '#0c1230';
  const nightCol = c => (c ? mix(c, NIGHT_C, 0.52) : c);
  const dayOf = k => (k.startsWith('night:') ? k.slice(6) : k);

  // ---------- 卡：底图（虚化）、卡框 ----------
  const cardCache = {};
  function cardArray(k) {
    if (!cardCache[k]) {
      if (k !== dayOf(k)) cardCache[k] = cardArray(dayOf(k)).map(r => r.map(nightCol));
      else {
        const def = STAGE_ART[k] || STAGE_ART.grass;
        cardCache[k] = K.blurred(K.makeCard('side', LOOKM, RAIL, def.bg, def.paint, PW), 'side');
      }
    }
    return cardCache[k];
  }
  // 底图那一层（只有台面里面，4 倍）
  const artCache = {};
  function stageCanvas(k) {
    if (!artCache[k]) {
      const arr = cardArray(k), c = canvas(CW4, CH4), x = c.getContext('2d');
      for (let j = 0; j < PH; j++) for (let i = 0; i < PW; i++) if (arr[j][i] && inA(i, j)) { x.fillStyle = arr[j][i]; x.fillRect(i * S4, j * S4, S4, S4); }
      artCache[k] = c;
    }
    return artCache[k];
  }
  // ---------- 放远的关：一张大底图（镜头拉远以后还盖得住台面那一格） ----------
  // 镜头往 ANCHOR（卡面格：口子正中、远处那道地平线）缩。大底图盖住缩到 ZMIN 时台面那一格（卡面格 x 7..88、y 10..72）
  const ANCHOR = { x: 45, y: 25 }, ZMIN = 0.75;
  const WIDE = (() => {
    const x0 = Math.floor(ANCHOR.x + (7 - ANCHOR.x) / ZMIN) - 2, x1 = Math.ceil(ANCHOR.x + (89 - ANCHOR.x) / ZMIN) + 2;
    const y0 = Math.floor(ANCHOR.y + (10 - ANCHOR.y) / ZMIN) - 2, y1 = Math.ceil(ANCHOR.y + (73 - ANCHOR.y) / ZMIN) + 2;
    return { x0, y0, w: x1 - x0, h: y1 - y0 };
  })();
  // 大底图的画法（坐标还是卡面格，可以出卡外）。(L, X, Y)：X(x)、Y(y) 换成图层里的格
  const WIDE_ART = {
    // 菜园放远：同一片菜地，树排、菜垄、水洼往两边、往下接出去；稻草人还在左边
    garden(art) {
      const trees = [[-6, 23, 4, 2.6], [2, 22.5, 4.4, 3], [10, 23, 4, 2.6], [17, 22, 4.4, 3.2], [25, 23, 4, 2.6], [33, 22.5, 4.4, 3], [43, 23, 4, 2.6], [52, 22, 4.6, 3.2], [61, 23, 4, 2.6], [70, 22.5, 4.4, 3], [79, 23, 4, 2.6], [87, 22, 4, 3], [95, 23, 4, 2.6], [103, 22, 4.4, 3.2]];
      art((L, X, Y) => lPuff(L, trees.map(([x, y, rx, ry]) => [X(x), Y(y), rx, ry]), { light: '#5aa84a', base: '#3a7a34', shade: '#2a5a2a' }, Y(24)));
      const CL = { light: '#ffffff', base: '#e6eef4', shade: '#b8c8d8' };
      art((L, X, Y) => {
        for (const [c, fb] of [[[[30, 13, 4.4, 2.6], [36, 11.5, 5, 3.2], [42, 13, 4.4, 2.4]], 14], [[[66, 15, 4, 2.4], [71, 13.5, 4.6, 3], [76, 15, 3.8, 2.2]], 16], [[[-2, 12, 4, 2.4], [3, 10.5, 4.6, 3], [8, 12, 3.8, 2.2]], 13], [[[93, 9, 4.4, 2.6], [99, 7.5, 5, 3.2], [105, 9, 4.4, 2.4]], 10]])
          lPuff(L, c.map(([x, y, rx, ry]) => [X(x), Y(y), rx, ry]), CL, Y(fb));
      });
      art((L, X, Y) => {
        [[33, 0], [45, 1], [57, 0], [69, 1], [81, 0], [93, 1]].forEach(([y, off]) => {
          for (let x = 13 + off * 6 - 24; x <= 110; x += 12) {
            lE(L, X(x), Y(y), 3.4, 2.6, ['#c8f090', '#5ab83a', '#2a7a2a']);
            lset(L, X(x), Y(y - 1), '#e8ffc0'); lset(L, X(x - 1), Y(y), '#2a7a2a'); lset(L, X(x + 1), Y(y), '#2a7a2a');
          }
        });
      });
      art((L, X, Y) => { for (const [x, y, rx, ry] of [[50, 51, 4, 1.4], [30, 63, 3.4, 1.2], [80, 77, 3.8, 1.3], [4, 85, 3.2, 1.2]]) lE(L, X(x), Y(y), rx, ry, ['#c8e8ff', '#7ac0ff', '#2f86ea']); });
      art((L, X, Y) => {
        for (let y = 27; y <= 46; y++) { lset(L, X(13), Y(y), '#8a5226'); lset(L, X(14), Y(y), '#c07a36'); }
        for (let x = 7; x <= 20; x++) lset(L, X(x), Y(33), '#c07a36');
        lR(L, X(10), Y(33), 8, 7, (x, y) => ((x + y) % 3 === 0 ? '#ffd23a' : '#fe4c40'));
        lE(L, X(13.5), Y(30), 2.6, 2.4, ['#fff0c8', '#f0d090', '#c8a060']);
        lR(L, X(9), Y(27), 10, 1, '#e0a010'); lR(L, X(11), Y(25), 6, 2, '#ffd23a');
        lset(L, X(12), Y(30), INK); lset(L, X(15), Y(30), INK);
      });
    },
  };
  // 虚化（跟卡面的一样：深边换成旁边的颜色压暗，整体往藏青压一点），整张都算台面
  function blurArr(arr) {
    const h = arr.length, w = arr[0].length, NAVY = [14, 22, 52], freq = new Map(), at = (x, y) => (x >= 0 && y >= 0 && x < w && y < h ? arr[y][x] : null);
    for (const r of arr) for (const c of r) freq.set(c, (freq.get(c) || 0) + 1);
    const out = arr.map(r => r.slice());
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      if (arr[y][x] !== INK) continue;
      let best = null;
      for (const ring of [[[1, 0], [-1, 0], [0, 1], [0, -1]], [[1, 1], [-1, 1], [1, -1], [-1, -1]]]) {
        for (const [dx, dy] of ring) { const c = at(x + dx, y + dy); if (c && c !== INK && (!best || freq.get(c) < freq.get(best))) best = c; }
        if (best) break;
      }
      out[y][x] = best ? toHex(...toRGB(best).map(v => rd(v * 0.72))) : INK;
    }
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      let [r, g, b] = toRGB(out[y][x]);
      const l = 0.3 * r + 0.59 * g + 0.11 * b;
      [r, g, b] = [r, g, b].map(v => v + (l - v) * 0.1).map((v, k) => rd(v + (NAVY[k] - v) * 0.4));
      out[y][x] = toHex(r, g, b);
    }
    return out;
  }
  // 这一关台面那一层的底图：{ c, cx, cy }（cx、cy 是图左上角在第几个卡面格，可以是负的）。没有大底图的就是卡上那张
  const worldCache = {};
  function worldArt(k) {
    if (worldCache[k]) return worldCache[k];
    const dk = dayOf(k), night = dk !== k;
    if (!WIDE_ART[dk] && !STAGE_ART[dk]) return (worldCache[k] = { c: stageCanvas(k), cx: 0, cy: 0 });
    const def = STAGE_ART[dk], { x0, y0, w, h } = WIDE;
    const arr = [];
    for (let j = 0; j < h; j++) { const row = []; for (let i = 0; i < w; i++) row.push(def.bg(x0 + i, y0 + j)); arr.push(row); }
    const art = (draw, outline = true) => {
      const L = layer(w, h);
      draw(L, x => x - x0, y => y - y0);
      if (outline) outl(L);
      for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) { const c = lget(L, i, j); if (c) arr[j][i] = c; }
    };
    if (WIDE_ART[dk]) WIDE_ART[dk](art);
    // 没写大底图的关：底色往四周铺开（上面 bg 已经铺了），画的东西照卡上的原位画
    else def.paint((draw, outline = true) => {
      const L = layer(PW, PH);
      draw(L);
      if (outline) outl(L);
      for (let j = 0; j < PH; j++) for (let i = 0; i < PW; i++) { const c = lget(L, i, j), a = j - y0, b = i - x0; if (c && a >= 0 && a < h && b >= 0 && b < w) arr[a][b] = c; }
    });
    const out = night ? blurArr(arr).map(r => r.map(nightCol)) : blurArr(arr), c = canvas(w * S4, h * S4), x = c.getContext('2d');
    for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) { x.fillStyle = out[j][i]; x.fillRect(i * S4, j * S4, S4, S4); }
    return (worldCache[k] = { c, cx: x0, cy: y0 });
  }

  // 卡框（台面以外：卡壳、金边、底下那条、数码管那一格）
  let frameC = null;
  // 卡壳的花样（跟 kit 的 makeCard 一样：圆角 6，外一圈深边、一圈亮 / 暗边，里面隔 5 格一个亮点）
  function shell(i, j) {
    const r = 6, w = PW, h = PH, F = LOOKM.f;
    const cx = i < r ? r : i > w - 1 - r ? w - 1 - r : i, cy = j < r ? r : j > h - 1 - r ? h - 1 - r : j;
    const d = Math.hypot(i - cx, j - cy);
    if (d > r + 0.3) return null;
    const inCorner = (i < r || i > w - 1 - r) && (j < r || j > h - 1 - r);
    const de = inCorner ? r - d : Math.min(i, j, w - 1 - i, h - 1 - j);
    return de < 1 ? INK : de < 2 ? (i + j < (w + h) / 2 ? F[0] : F[2]) : i % 5 === 2 && j % 5 === 2 ? F[0] : F[1];
  }
  function frameCanvas() {
    if (frameC) return frameC;
    const arr = cardArray('grass'), c = canvas(CW4, CH4), x = c.getContext('2d');
    for (let j = 0; j < PH; j++) for (let i = 0; i < PW; i++) {
      let col = arr[j][i];
      if (!col || inA(i, j)) continue;
      if (j >= SIDE.hole && j <= SIDE.y1 && i >= SIDE.x0 && i <= SIDE.x1) col = j === SIDE.hole ? INK : A.kit.SLATE;
      // 卡角那两样（左上的数码管、右上的小圆牌）不要：照卡壳的花样涂回去
      if ((i <= 15 && j <= 12) || (i >= PW - 15 && j <= 13)) col = shell(i, j) || col;
      x.fillStyle = col; x.fillRect(i * S4, j * S4, S4, S4);
    }
    frameC = c;
    return c;
  }

  // ---------- 硬件（2 倍，台面格坐标） ----------
  const ALU = A.ALU, FLIP_C = { body: '#fe4c40', hi: '#ff8a7a', lo: '#b8322a' };
  const metal = (dx, dy) => (dx + dy < -0.6 ? ALU[0] : dx + dy > 0.6 ? ALU[2] : ALU[1]);
  function capsule(L, x0, y0, x1, y1, r, col) {
    const vx = x1 - x0, vy = y1 - y0, l2 = vx * vx + vy * vy || 1e-9;
    for (let y = fl(Math.min(y0, y1) - r - 1); y <= Math.ceil(Math.max(y0, y1) + r + 1); y++) for (let x = fl(Math.min(x0, x1) - r - 1); x <= Math.ceil(Math.max(x0, x1) + r + 1); x++) {
      const px = x + 0.5, py = y + 0.5;
      let t = ((px - x0) * vx + (py - y0) * vy) / l2; t = t < 0 ? 0 : t > 1 ? 1 : t;
      const dx = px - (x0 + vx * t), dy = py - (y0 + vy * t), d = Math.hypot(dx, dy);
      if (d <= r) lset(L, x, y, typeof col === 'function' ? col(dx, dy, d) : col);
    }
  }
  // 台上的硬件按买了什么装：parts = { sling, lanes }（挡板另画，会动）。没买的时候台面是空的：墙、发射道、导轨、转轴螺栓
  const hwCache = {};
  function hardwareCanvas(parts) {
    parts = parts || {};
    const key = (parts.sling ? 's' : '') + (parts.lanes ? 'l' : '');
    if (hwCache[key]) return hwCache[key];
    const c = canvas(CW4, CH4), x = c.getContext('2d');
    const px = (sx, sy, col) => { if (col) { x.fillStyle = col; x.fillRect(fl(sx) * 2, fl(sy) * 2, 2, 2); } };
    const f = { px };
    // 台底的口子：两颗转轴中间往下一道黑缝
    for (let y = P.PIT.y + 1; y <= 145; y++) for (let sx = P.PIT.x0 + 1; sx <= P.PIT.x1 - 1; sx++) px(sx, y, y === P.PIT.y + 1 ? '#5a1626' : INK);
    MK.fineLane(f, [6, 4], P.DX);
    const L = layer(192, 160);
    for (const k of ['L', 'R']) {
      const [a, b] = P.GUIDE[k];
      capsule(L, a[0], a[1], b[0], b[1], 1.3, metal);
      if (parts.sling) {
        const S = P.SLING[k];
        lP(L, [S.A, S.B, S.C], (xx, yy) => ((xx + yy) % 4 === 0 ? FLIP_C.lo : FLIP_C.body));
        capsule(L, S.A[0], S.A[1], S.C[0], S.C[1], 1.2, '#ffffff');
        capsule(L, S.cap[0], S.cap[1], S.A[0], S.A[1], 1.1, metal);
        for (const p of [S.A, S.B, S.C]) capsule(L, p[0], p[1], p[0], p[1], 2, metal);
      }
      if (parts.lanes) { const Ln = P.LANES[k]; capsule(L, Ln.x, Ln.y0, Ln.x, Ln.y1, 1.6, metal); }
      // 挡板的转轴螺栓（挡板断了、还没买，它也在）
      capsule(L, P.FLIP[k].px, P.FLIP[k].py, P.FLIP[k].px, P.FLIP[k].py, P.FLIP.rp, metal);
    }
    outl(L);
    for (let j = 0; j < L.h; j++) for (let i = 0; i < L.w; i++) { const col = lget(L, i, j); if (col) px(i, j, col); }
    // 小孔：柱子外侧那条道的地上画一个金圈，钻过去就变金珠
    if (parts.lanes) for (const k of ['L', 'R']) {
      const Ln = P.LANES[k], cx = fl((Ln.sx0 + Ln.sx1) / 2), cy = Ln.sy + 3;
      for (const [dx, dy] of [[-2, 0], [2, 0], [0, -2], [0, 2], [-1, -1], [1, -1], [-1, 1], [1, 1]]) px(cx + dx, cy + dy, A.GOLD[1]);
    }
    const G = P.GATE;
    for (let i = 0; i <= 10; i++) { const gx = G.x0 + (G.x1 - G.x0) * i / 10, gy = G.y0 + (G.y1 - G.y0) * i / 10; px(fl(gx), fl(gy), i % 2 ? ALU[0] : ALU[2]); }
    A.fineMeter(f, P.DX);
    hwCache[key] = c;
    return c;
  }
  const flatCache = {};
  function flatCanvas(mode) {
    if (flatCache[mode]) return flatCache[mode];
    const F = window.MainFlat, c = canvas(CW4, CH4), x = c.getContext('2d');
    const px = (sx, sy, col) => { if (col) { x.fillStyle = col; x.fillRect(fl(sx) * 2, fl(sy) * 2, 2, 2); } };
    const CHALK = '#f4f0e0', H = F.HOME[mode];
    if (mode === 'bowl') {
      // 两条沟：深槽，靠里一道亮边
      for (let y = F.Y0; y <= F.Y1; y++) for (const [a, b] of [[F.X0, F.X0 + 6], [F.X1 - 6, F.X1]]) for (let sx = a; sx <= b; sx++) px(sx, y, sx === a + 6 || sx === b - 6 ? ALU[1] : '#1a1420');
      for (let sx = F.X0 + 8; sx <= F.X1 - 8; sx++) px(sx, 124, '#e8452a');
      for (const ax of [56, 76, 96, 116, 136]) for (const [dx, dy] of [[0, 0], [-1, 1], [1, 1], [-2, 2], [2, 2]]) px(ax + dx, 106 + dy, CHALK);
    }
    if (mode === 'flick') {
      const n = 120;
      for (let i = 0; i < n; i++) { const a = (i / n) * Math.PI * 2; if (i % 2) continue; px(96 + Math.cos(a) * 62, 74 + Math.sin(a) * 34, CHALK); }
      for (let sx = 30; sx <= 162; sx += 4) px(sx, 122, CHALK);
    }
    if (mode === 'kick') {
      const G = F.GOAL;
      for (let sx = G.x0 - 14; sx <= G.x1 + 14; sx += 2) { px(sx, 44, CHALK); }
      for (let y = F.Y0; y <= 44; y += 2) { px(G.x0 - 14, y, CHALK); px(G.x1 + 14, y, CHALK); }
      for (let i = 0; i <= 24; i++) { const a = Math.PI + (i / 24) * Math.PI; if (i % 2) continue; px(H.x + Math.cos(a) * 14, H.y + Math.sin(a) * 10, CHALK); }
      // 门：网（格子）、两根门柱、横梁（压在卡框上）
      for (let y = 13; y < F.Y0; y++) for (let sx = G.x0; sx <= G.x1; sx++) if ((sx + y) % 3 === 0) px(sx, y, '#c8d0dc');
    }
    const L = layer(192, 160);
    for (const sg of F.SEGS) capsule(L, sg[0], sg[1], sg[2], sg[3], 1.3, metal);
    if (mode === 'kick') { const G = F.GOAL; capsule(L, G.x0, 12, G.x0, F.Y0 + 1, 1.2, '#ffffff'); capsule(L, G.x1, 12, G.x1, F.Y0 + 1, 1.2, '#ffffff'); capsule(L, G.x0, 12, G.x1, 12, 1, '#ffffff'); }
    outl(L);
    for (let j = 0; j < L.h; j++) for (let i = 0; i < L.w; i++) { const col = lget(L, i, j); if (col) px(i, j, col); }
    // 发球点：一个粉笔圈
    for (let i = 0; i < 12; i++) { const a = (i / 12) * Math.PI * 2; px(H.x + Math.cos(a) * 5, H.y + Math.sin(a) * 5, CHALK); }
    flatCache[mode] = c;
    return c;
  }
  // 刚装上的零件：白边闪几下（台面格坐标的轮廓点）
  function partOutline(k) {
    const pts = [];
    if (k === 'sling') for (const s of ['L', 'R']) { const S = P.SLING[s]; for (const [a, b] of [[S.A, S.B], [S.B, S.C], [S.A, S.C], [S.cap, S.A]]) { const n = Math.ceil(Math.hypot(b[0] - a[0], b[1] - a[1])); for (let i = 0; i <= n; i++) pts.push([a[0] + (b[0] - a[0]) * i / n, a[1] + (b[1] - a[1]) * i / n]); } }
    if (k === 'lanes') for (const s of ['L', 'R']) { const Ln = P.LANES[s]; for (let y = Ln.y0 - 2; y <= Ln.y1 + 2; y++) { pts.push([Ln.x - 2, y]); pts.push([Ln.x + 2, y]); } }
    if (k === 'flip') for (const s of ['L', 'R']) { const F = P.FLIP[s]; for (let a = 0; a < 16; a++) pts.push([F.px + Math.cos(a / 16 * Math.PI * 2) * 6, F.py + Math.sin(a / 16 * Math.PI * 2) * 6]); }
    return pts;
  }

  // ---------- 碎背景：底图按 Voronoi 裂成块 ----------
  // (cx, cy) 是 boss 碎的地方（台面格）。返回碎块：每块一张 4 倍小图 + 它在卡上的位置、往哪飞
  function shatter(k, cx, cy, seed) {
    const arr = cardArray(k);
    let s = (seed >>> 0) || 7;
    const rnd = () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; };
    const ox = cx / 2, oy = cy / 2;   // 卡面格
    const seeds = [[ox, oy]];
    for (let n = 0; n < 15; n++) seeds.push([SIDE.x0 + rnd() * (SIDE.x1 - SIDE.x0), SIDE.y0 + rnd() * (SIDE.hole - SIDE.y0)]);
    const own = new Int16Array(PW * PH).fill(-1);
    for (let j = 0; j < PH; j++) for (let i = 0; i < PW; i++) {
      if (!inA(i, j)) continue;
      let best = 0, bd = Infinity;
      for (let q = 0; q < seeds.length; q++) { const d = (seeds[q][0] - i - 0.5) ** 2 + (seeds[q][1] - j - 0.5) ** 2; if (d < bd) { bd = d; best = q; } }
      own[j * PW + i] = best;
    }
    const pieces = [];
    for (let q = 0; q < seeds.length; q++) {
      let x0 = PW, y0 = PH, x1 = -1, y1 = -1, sx = 0, sy = 0, n = 0;
      for (let j = 0; j < PH; j++) for (let i = 0; i < PW; i++) if (own[j * PW + i] === q) { x0 = Math.min(x0, i); y0 = Math.min(y0, j); x1 = Math.max(x1, i); y1 = Math.max(y1, j); sx += i; sy += j; n++; }
      if (!n) continue;
      const w = x1 - x0 + 1, h = y1 - y0 + 1, c = canvas(w * S4, h * S4), g = c.getContext('2d');
      for (let j = y0; j <= y1; j++) for (let i = x0; i <= x1; i++) {
        if (own[j * PW + i] !== q) continue;
        const edge = [[1, 0], [-1, 0], [0, 1], [0, -1]].some(([dx, dy]) => { const o = own[(j + dy) * PW + i + dx]; return o !== q && o !== -1 && i + dx >= 0 && i + dx < PW; });
        g.fillStyle = edge ? mix(arr[j][i], INK, 0.55) : arr[j][i];
        g.fillRect((i - x0) * S4, (j - y0) * S4, S4, S4);
      }
      const mx = sx / n, my = sy / n, dx = mx - ox, dy = my - oy, d = Math.hypot(dx, dy) || 1, v = 22 + rnd() * 34;
      pieces.push({ c, x0, y0, vx: dx / d * v, vy: dy / d * v - 26 - rnd() * 30, delay: Math.min(0.15, d / 300) });
    }
    // 裂纹线（停住那一下先画在原图上）
    const crack = canvas(CW4, CH4), cg = crack.getContext('2d');
    cg.fillStyle = INK;
    for (let j = 0; j < PH; j++) for (let i = 0; i < PW; i++) {
      const o = own[j * PW + i];
      if (o < 0) continue;
      if ([[1, 0], [0, 1]].some(([dx, dy]) => { const p = own[(j + dy) * PW + i + dx]; return p >= 0 && p !== o; })) cg.fillRect(i * S4, j * S4, S4, S4);
    }
    return { pieces, crack };
  }

  // ---------- 会动的：挡板、珠子、史莱姆、boss 的草冠、金币 ----------
  const FX = A.FX, FY = A.FY;
  // 挡板：dur/max 掉到一半画一道裂纹；断了只剩转轴边上一截茬
  function drawFlipper(ctx, f, F) {
    const broken = f.broken;
    const [tx, ty] = P.tipOf(f), vx = tx - f.px, vy = ty - f.py, l2 = vx * vx + vy * vy, R0 = f.rp + 0.6;
    const tMax = broken ? 0.32 : 1;
    const x0 = fl(Math.min(f.px, tx) - R0 - 1), x1 = Math.ceil(Math.max(f.px, tx) + R0 + 1), y0 = fl(Math.min(f.py, ty) - R0 - 1), y1 = Math.ceil(Math.max(f.py, ty) + R0 + 1);
    const nx = -vy / Math.sqrt(l2), ny = vx / Math.sqrt(l2), up = ny > 0 ? -1 : 1;
    const cracked = F && F.dur <= F.max / 2 && !broken;
    for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) {
      const px = x + 0.5, py = y + 0.5;
      let t = ((px - f.px) * vx + (py - f.py) * vy) / l2;
      if (broken) { const side = (px - f.px) * nx + (py - f.py) * ny; if (t > tMax + 0.06 * Math.sin(side * 3)) continue; }
      t = t < 0 ? 0 : t > 1 ? 1 : t;
      const dx = px - (f.px + vx * t), dy = py - (f.py + vy * t), d = Math.hypot(dx, dy), r = f.rp + (f.rt - f.rp) * t + 0.4;
      if (d > r + 0.6) continue;
      let c;
      if (d > r - 0.5) c = INK;
      else {
        const side = (dx * nx + dy * ny) * up;
        c = side > r - 1.6 ? FLIP_C.hi : side < -(r - 1.4) ? FLIP_C.lo : FLIP_C.body;
        if (cracked && Math.abs(t - 0.55 - 0.05 * Math.sign(side) * (Math.abs(side) > 0.8 ? 1 : 0)) < 0.045) c = INK;
      }
      ctx.fillStyle = c; ctx.fillRect(FX(x), FY(y), 2, 2);
    }
    ctx.fillStyle = INK; ctx.fillRect(FX(f.px) - 3, FY(f.py) - 3, 6, 6);
    ctx.fillStyle = A.GOLD[0]; ctx.fillRect(FX(f.px) - 1, FY(f.py) - 1, 2, 2);
  }
  // 珠子：玻璃珠、钢珠 7×7（半径 3.5 格），强力珠子按 D.MARBLES 的大小放大（骨头 8、大母珠和保龄球 11）。
  // 三档裂纹（0 没裂、1 一道、2 裂满）；gold = 钻过小孔的金珠
  const MB7 = ['..kkk..', '.khhwk.', 'khhwwwk', 'kwwwwsk', 'kwwwssk', '.kwssk.', '..kkk..'];
  const CRACK = [[], [[4, 2], [3, 3], [3, 4]], [[4, 2], [3, 3], [3, 4], [2, 2], [5, 4], [4, 5], [2, 4]]];
  // [暗, 中, 亮]
  const BALL_C = {
    glass: A.MARB.glass, steel: A.MARB.steel, taw: A.MARB.taw, bowl: A.MARB.bowl, iron: A.MARB.iron,
    bone: ['#c8b48c', '#f0e2c0', '#fff6e0'], lava: ['#a82a1a', '#e8452a', '#ffb070'], freeze: ['#3a98c8', '#a8e8ff', '#ffffff'],
    egg: ['#c8b898', '#f4ecd8', '#ffffff'], snow: ['#9ab8d8', '#e8f4ff', '#ffffff'], hook: ['#a8401a', '#ff7a2a', '#ffd0a0'],
    soccer: ['#8a8a96', '#ffffff', '#ffffff'], coins: ['#a87a20', '#e8c048', '#fff3a0'], rubber: ['#b8227a', '#ff5ab8', '#ffc0e8'], pool: ['#1a6a3a', '#2ab060', '#9af0b8'],
  };
  const GOLD_BALL = ['#c88a10', '#ffd23a', '#fff6c0'];
  // 每种珠子身上的记号（相对珠子正中，单位像素）：一眼分得开
  const MARKS = {
    bone: [[-1, 0, '#c8b48c'], [0, 0, '#c8b48c'], [1, 0, '#c8b48c'], [-2, -1, '#c8b48c'], [-2, 1, '#c8b48c'], [2, -1, '#c8b48c'], [2, 1, '#c8b48c']],
    lava: [[-1, 1, '#ffd23a'], [1, -1, '#ffd23a'], [2, 2, '#ffd23a']],
    freeze: [[0, -1, '#ffffff'], [0, 1, '#ffffff'], [-1, 0, '#ffffff'], [1, 0, '#ffffff'], [0, 0, '#3a98c8']],
    bowl: [[-1, -2, INK], [1, -2, INK], [0, 0, INK]],
    taw: [[-2, 1, '#ffffff'], [-1, 2, '#ffffff'], [1, -2, '#7ac0ff']],
    iron: [[-1, -1, '#c8d0d4']],
    egg: [[1, 1, '#c8a878'], [-1, -1, '#c8a878'], [2, -1, '#c8a878']],
    snow: [[1, 1, '#c8dcf0'], [-2, 0, '#c8dcf0'], [0, -2, '#c8dcf0']],
    hook: [[-2, 0, '#ffffff'], [-1, 0, '#ffffff'], [0, 0, '#ffffff'], [1, 0, '#ffffff'], [2, 0, '#ffffff']],
    soccer: [[0, 0, INK], [-2, -1, INK], [2, -1, INK], [-1, 2, INK], [1, 2, INK]],
    coins: [[0, 0, '#6a4a10'], [1, 0, '#6a4a10'], [0, 1, '#6a4a10'], [1, 1, '#6a4a10']],
    rubber: [[-2, -2, '#ffd23a'], [-1, -1, '#ffd23a'], [0, 0, '#ffd23a'], [1, 1, '#ffd23a'], [2, 2, '#ffd23a']],
    pool: [[0, 0, '#ffffff'], [-1, 0, '#ffffff'], [1, 0, '#ffffff'], [0, -1, '#ffffff'], [0, 1, '#ffffff']],
  };
  const ballCache = {};
  // small：珠袋槽里那颗（一律 7 格，大珠子也缩成 7 格，配色、记号照旧）
  function ballSprite(kind, crack, gold, small, scale) {
    const sc0 = scale && scale > 1 ? Math.round(scale * 8) / 8 : 1;
    const key = kind + (crack || 0) + (gold ? 'g' : '') + (small ? 's' : '') + (sc0 > 1 ? 'x' + sc0 : '');
    if (ballCache[key]) return ballCache[key];
    const M = MainData.MARBLES[kind] || MainData.MARBLES.glass, C = gold ? GOLD_BALL : BALL_C[kind] || A.MARB.glass;
    const d = small ? 7 : Math.max(7, Math.round(7 * (M.r || 1) * sc0));
    let rows;
    if (d === 7) rows = MB7.map(r => r.split(''));
    else {
      rows = [];
      const c = d / 2, R0 = d / 2;
      for (let j = 0; j < d; j++) {
        const row = [];
        for (let i = 0; i < d; i++) {
          const dx = i + 0.5 - c, dy = j + 0.5 - c, r = Math.hypot(dx, dy);
          if (r > R0 - 0.05) row.push('.');
          else if (r > R0 - 1.05) row.push('k');
          else { const s = (dx + dy) / R0; row.push(s < -0.55 ? 'h' : s > 0.5 ? 's' : 'w'); }
        }
        rows.push(row);
      }
      // 左上角一个亮点
      const hx = Math.round(c - R0 * 0.45), hy = Math.round(c - R0 * 0.5);
      if (rows[hy] && rows[hy][hx] && rows[hy][hx] !== 'k') rows[hy][hx] = 'h';
    }
    const map = { k: INK, s: C[0], w: C[1], h: C[2], c: '#4a5a78' };
    const extra = {};
    if (!gold) (MARKS[kind] || []).forEach(([dx, dy, col], n) => { const x = Math.floor(d / 2) + dx, y = Math.floor(d / 2) + dy; if (rows[y] && rows[y][x] && rows[y][x] !== 'k' && rows[y][x] !== '.') { const ch = String.fromCharCode(65 + n); rows[y][x] = ch; extra[ch] = col; } });
    if (gold) { const x = Math.floor(d / 2), y = Math.floor(d / 2); rows[y][x] = 'h'; }
    const sc = d / 7;
    for (const [x, y] of CRACK[crack] || []) { const X = Math.round(x * sc), Y = Math.round(y * sc); if (rows[Y] && rows[Y][X] && rows[Y][X] !== 'k' && rows[Y][X] !== '.') rows[Y][X] = 'c'; }
    ballCache[key] = A.sprite(rows.map(r => r.join('')), Object.assign(map, extra));
    return ballCache[key];
  }
  // 史莱姆的颜色：泥的（土黄）、金的、boss（深一点的泥）；冻住了换成冰的
  const MUD = ['#f2c98a', '#c8823e', '#7a4a1e'], GOLDS = ['#fff6c0', '#ffd23a', '#d89a10'], KING = ['#e8b070', '#b06a2a', '#6a3a14'];
  const ICED = ['#f0fbff', '#9adcf8', '#3a88b8'];
  // 鼻涕虫：亮绿（一身黏液）；蜗牛：灰褐的身子，背一个橙色螺旋壳（大蜗牛的壳是粉的，"花壳"）
  const SLUG = ['#eaffb0', '#9ad04a', '#4a7a1a'], SNAIL = ['#f4e4d4', '#c8a890', '#7a5a48'];
  const SHELL = ['#ffd890', '#e08a3a', '#8a4a1a'], SHELL_K = ['#ffd0e8', '#ff6aa8', '#a83a6a'];
  const isSnail = o => o.kind === 'snail' || o.kind === 'snailKing';
  const PAL = {
    blue: ['#c8e8ff', '#5aa8f0', '#2a5aa8'], amber: ['#fff8c8', '#ffb81a', '#c86a00'], frozen: ['#ffffff', '#b8e8f8', '#5aa0c8'],
    jelly: ['#ffe0f8', '#e8a0e8', '#9a5aa8'], puffer: ['#fff6c0', '#f0d060', '#a88a2a'], crab: ['#ffb8a0', '#f0603a', '#a82a1a'],
    lava: ['#fff3a0', '#ff7a2a', '#b8321a'], rock: ['#c8c8c0', '#8a8a84', '#4a4a48'], guard: ['#e8e0ff', '#8a7ad0', '#4a3a8a'],
    shroomKing: ['#f0e0c8', '#c8a882', '#7a5a3a'], swampKing: ['#d8f0a0', '#7aa83a', '#3a5a1a'], iceKing: ['#ffffff', '#a8e0f8', '#3a88c8'],
    jellyKing: ['#ffd0f0', '#d880d8', '#7a3a8a'], volcanoKing: ['#ffd090', '#e8602a', '#8a2a1a'], slimeKing: ['#c8f080', '#7ac83a', '#2a7a2a'],
  };
  const slimeColors = o => (o.frozen > 0 ? ICED : o.gold ? GOLDS : PAL[o.kind] || (o.kind === 'slug' ? SLUG : isSnail(o) ? SNAIL : o.boss ? KING : MUD));
  // boss 的帽子（一个 boss 一顶）；没有的戴草冠
  const HAT = {
    shroomKing: A.outlined(['....rrrrrrrrr....', '..rrwwrrrrrwwrr..', '.rrrwwrrrrrwwrrr.', 'rrrrrrrwwrrrrrrrr', 'rrwwrrrwwrrrrwwrr', 'ddddddddddddddddd'], { r: '#fe4c40', w: '#ffffff', d: '#b8322a' }, INK),
    swampKing: A.outlined(['....p.p.p....', '...ppwpwpp...', '..ggppppppgg.', 'ggggggggggggg', '.ddddddddddd.'], { p: '#ff6aa8', w: '#ffd0e8', g: '#7ab83a', d: '#3a6a1a' }, INK),
    iceKing: A.outlined(['w...w...w...w', 'ww.wbw.wbw.ww', 'wbwbbbwbbbwbw', 'bbbbbbbbbbbbb'], { w: '#ffffff', b: '#7ac0ff' }, INK),
    jellyKing: A.outlined(['.p..p..p.', 'ppppppppp', '.ddddddd.'], { p: '#fff0fa', d: '#d880d8' }, INK),
    slimeKing: A.outlined(['y...y...y...y', 'yy.yry.yry.yy', 'yyyyyyyyyyyyy', 'ddddddddddddd'], { y: '#ffd23a', r: '#fe4c40', d: '#c88a10' }, INK),
  };
  const CLAW = A.outlined(['.rr', 'r..', '.rr'], { r: '#f0603a' }, INK), CLAW_L = A.outlined(['rr.', '..r', 'rr.'], { r: '#f0603a' }, INK);
  const HELM = A.outlined(['..mmm..', '.mmmmm.', 'mmmmmmm'], { m: ALU[1] }, INK);
  // 螺旋壳：圆，深边，壳上一道阿基米德螺线（深色），左上亮一块
  const shellCache = {};
  function shellSprite(rs, C) {
    const k = Math.max(2.5, Math.round(rs * 2) / 2), key = k + C[1];
    if (shellCache[key]) return shellCache[key];
    const d = Math.ceil(k * 2) + 1, c = d / 2, rows = [];
    for (let j = 0; j < d; j++) {
      let row = '';
      for (let i = 0; i < d; i++) {
        const dx = i + 0.5 - c, dy = j + 0.5 - c, r = Math.hypot(dx, dy);
        if (r > k) { row += '.'; continue; }
        if (r > k - 1) { row += 'k'; continue; }
        const u = (r / (k - 1)) * 1.7 - Math.atan2(dy, dx) / (Math.PI * 2), band = ((u % 1) + 1) % 1;
        row += band < 0.24 && r > 0.8 ? 'd' : dx + dy < -k * 0.5 ? 'h' : 'm';
      }
      rows.push(row);
    }
    return (shellCache[key] = A.sprite(rows, { k: INK, d: C[2], m: C[1], h: C[0] }));
  }
  // 草冠（草地大王头上）
  const CROWN = A.outlined(['.l...l...l.', 'lgl.lgl.lgl', 'ggggggggggg', '.ddddddddd.'], { l: '#c8f080', g: '#5ac83a', d: '#2a7a2a' }, INK);
  // 火苗（着火的史莱姆头上，三帧轮着）、雪花（冻住的）
  const FLAME = [
    A.outlined(['.y.', 'yoy', 'oro', '.r.'], { y: '#fff3a0', o: '#ff9700', r: '#e8452a' }, INK),
    A.outlined(['y..', '.oy', 'oro', '.r.'], { y: '#fff3a0', o: '#ff9700', r: '#e8452a' }, INK),
    A.outlined(['..y', 'yo.', 'oro', '.r.'], { y: '#fff3a0', o: '#ff9700', r: '#e8452a' }, INK),
  ];
  const FLAKE = A.sprite(['.w.', 'www', '.w.'], { w: '#ffffff' });
  // char：烧黑了几档（0～3），每档往焦黑里压一截
  const CHAR = '#2a1a14';
  function drawSlime(ctx, o, time) {
    const C0 = slimeColors(o), C = o.char > 0 ? C0.map(c => mix(c, CHAR, 0.2 * Math.min(3, o.char))) : C0;
    let rx = o.r * 1.18, ry = o.r * 1.05;
    if (o.squash > 0) { const k = Math.sin(o.squash / 0.2 * Math.PI) * 0.1; rx *= 1 + k; ry *= 1 - k; }
    if (o.state === 'pop') { const t = o.t / 0.25; rx *= 1 + t * 0.22; ry *= 1 - t * 0.3; if (t >= 1) return; }
    if (o.state === 'wait') return;
    // 蜗牛的脸不在正中（正中背着壳），身子先画成没脸的，脸画在前头
    const snail = isSnail(o), live = o.state !== 'pop';
    const im = A.slimeSprite(Math.round(rx * 2) / 2, Math.round(ry * 2) / 2, C, !snail, o.flash > 0 || o.state === 'pop');
    const top = Math.round(o.y + o.r * 0.18 - im.height / 2), cy = o.y + o.r * 0.18;
    // 头在哪：鼻涕虫头顶正中；蜗牛在前头（左边），壳让开它
    const hx = snail ? o.x - rx * 0.55 : o.x, headTop = cy - ry * Math.sqrt(1 - (snail ? 0.3 : 0));
    // 触角：两根竿从头里长出来（画在身子后面，根埋在身子里），尖上一个黑点；蜗牛的长一点、个大的更长
    if (live && (o.kind === 'slug' || snail)) {
      const len = snail ? Math.max(3, Math.round(o.r * 0.45)) : 3, sp = Math.max(1, Math.round(rx * (snail ? 0.17 : 0.3)));
      for (const d of [-1, 1]) {
        const bx = Math.round(hx + d * sp);
        for (let k = -1; k <= len; k++) MK.px(ctx, bx + (k >= len - 1 ? d : 0), Math.round(headTop) - k, k === len ? INK : C[1]);
      }
    }
    MK.spr(ctx, im, Math.round(o.x - im.width / 2), top);
    let crownY = top - 1;
    if (live && snail) {
      const sh = shellSprite(o.r * 0.78, o.boss ? SHELL_K : SHELL), sy = Math.round(o.y - ry * 0.3 - sh.height / 2);
      MK.spr(ctx, sh, Math.round(o.x + rx * 0.35 - sh.width / 2), sy);
      crownY = Math.min(crownY, sy - 2);
      // 前头的脸：两颗眼珠（个大的两格高）、个大的再加一道嘴
      if (!(o.flash > 0)) {
        const dx = Math.max(1, Math.round(rx * 0.13)), ey = Math.round(cy - ry * 0.12), ex = Math.round(hx);
        for (const x of [ex - dx, ex + dx]) { MK.px(ctx, x, ey, INK); if (ry >= 4.5) MK.px(ctx, x, ey + 1, INK); }
        if (rx >= 6) { const my = ey + (ry >= 6 ? 3 : 2); MK.px(ctx, ex, my, INK); if (rx >= 12) MK.px(ctx, ex - 1, my, INK); }
      }
    }
    // 后面几种的记号：水母的须、寄居蟹的钳子、河豚鼓起来的刺、黑石的裂纹、卫兵的头盔、岩浆的黑壳、冰冻的雪花
    if (live && !o.boss) {
      const k = o.kind;
      if (k === 'jelly') for (const d of [-0.5, 0, 0.5]) for (let j = 0; j < 3; j++) MK.px(ctx, Math.round(o.x + d * rx + (j === 1 ? Math.sin((time || 0) * 4 + d * 3) : 0)), Math.round(cy + ry * 0.75 + j), C[2]);
      if (k === 'crab') { MK.spr(ctx, CLAW_L, Math.round(o.x - rx - 3), Math.round(cy - 2)); MK.spr(ctx, CLAW, Math.round(o.x + rx), Math.round(cy - 2)); }
      if (k === 'puffer' && o.puff > 0) for (let i = 0; i < 8; i++) { const a = (i / 8) * Math.PI * 2; MK.px(ctx, Math.round(o.x + Math.cos(a) * (rx + 1)), Math.round(cy + Math.sin(a) * (ry + 1)), INK); }
      if (k === 'rock') for (const [dx, dy] of [[-0.3, -0.3], [-0.1, -0.1], [0, 0.1], [0.2, 0.25]]) MK.px(ctx, Math.round(o.x + dx * rx), Math.round(cy + dy * ry), INK);
      if (k === 'lava') for (const [dx, dy] of [[-0.45, 0.3], [0.4, 0.4], [0.1, 0.55]]) MK.px(ctx, Math.round(o.x + dx * rx), Math.round(cy + dy * ry), '#5a1a10');
      if (k === 'guard') MK.spr(ctx, HELM, Math.round(o.x - HELM.width / 2), top - 2);
      if (k === 'amber') { MK.px(ctx, Math.round(o.x - rx * 0.45), Math.round(cy - ry * 0.45), '#ffffff'); MK.px(ctx, Math.round(o.x + rx * 0.3), Math.round(cy + ry * 0.85), C[1]); MK.px(ctx, Math.round(o.x + rx * 0.3), Math.round(cy + ry * 0.85) + 1, C[2]); }
      if (k === 'frozen' && !(o.frozen > 0)) for (const [dx, dy] of [[-0.6, -0.3], [0.5, 0.25]]) MK.spr(ctx, FLAKE, Math.round(o.x + dx * o.r - 1), Math.round(o.y + dy * o.r - 1));
    }
    if (o.boss && o.state !== 'pop') {
      if (o.kind === 'volcanoKing') { const k = Math.floor(((time || 0) * 8) % 3); for (const dx of [-5, 0, 5]) MK.spr(ctx, FLAME[(k + dx / 5 + 3) % 3], Math.round(o.x + dx - 2), crownY - 2); }
      else { const H = HAT[o.kind] || CROWN; MK.spr(ctx, H, Math.round(o.x - H.width / 2), crownY - (H === CROWN ? 0 : H.height - 4)); }
    }
    if (o.state !== 'pop' && o.burn > 0) {
      const k = Math.floor(((time || 0) * 8 + o.id) % 3);
      for (const dx of o.r > 5 ? [-0.5, 0.5] : [0]) MK.spr(ctx, FLAME[(k + (dx > 0 ? 1 : 0)) % 3], Math.round(o.x + dx * o.r - 2), top - 3 + (k === 1 ? -1 : 0));
    }
    if (o.state !== 'pop' && o.frozen > 0) for (const [dx, dy] of [[-0.7, -0.4], [0.6, 0.2]]) MK.spr(ctx, FLAKE, Math.round(o.x + dx * o.r - 1), Math.round(o.y + dy * o.r - 1));
    // 几下碎：这一轮带的球要两下以上才碎的，头上一格一下的小白格（一行五格，多了排两行，最多十格）；
    //   o.hits 是画的那边按这颗球算好的，没给就照血（一下打 1）
    const n = Math.min(10, o.hits != null ? o.hits : Math.ceil(o.hp - 1e-6));
    if (!o.boss && o.state !== 'pop' && o.state !== 'drop' && n >= 2) {
      const per = Math.min(n, 5), rows = Math.ceil(n / 5), w = per * 3 - 1, x0 = Math.round(o.x - w / 2), y0 = Math.round(o.y - o.r * 1.05 - 1 - rows * 2);
      ctx.fillStyle = INK; ctx.fillRect(FX(x0 - 1), FY(y0 - 1), (w + 2) * 2, (rows * 2 + 1) * 2);
      for (let i = 0; i < n; i++) { ctx.fillStyle = o.gold ? A.GOLD[0] : '#ffffff'; ctx.fillRect(FX(x0 + (i % 5) * 3), FY(y0 + Math.floor(i / 5) * 2), 4, 2); }
    }
  }
  const COIN = A.outlined(['.hyy.', 'hyyyd', 'yyyyd', 'yyydd', '.ddd.'], { h: '#fff3a0', y: '#e8c048', d: '#a87a20' }, INK);

  // ---------- 节点图标 12×12（左栏 2 倍） ----------
  const ICON = {
    'st:cave': L => { lR(L, 5, 6, 2, 5, ['#fff0d8', '#f0d8b8', '#c8a888']); lE(L, 6, 6, 5, 3.6, ['#ff8a7a', '#fe4c40', '#b8322a'], (x, y, u, v) => v <= 0.3); lset(L, 4, 4, '#ffffff'); lset(L, 8, 3, '#ffffff'); },
    'st:marsh': L => { lE(L, 6, 7, 5.4, 3, ['#c8f080', '#7ab83a', '#3a6a1a'], (x, y, u, v) => !(u > 0.1 && Math.abs(v) < 0.25)); lE(L, 4, 6, 1.6, 1.4, ['#ffd0e8', '#ff6aa8', '#a83a6a']); },
    'st:river': L => { for (let k = 0; k < 6; k++) { const a = k * Math.PI / 3; for (let r = 0; r <= 5; r++) lset(L, Math.round(6 + Math.cos(a) * r), Math.round(6 + Math.sin(a) * r), r === 5 ? '#7ac0ff' : '#ffffff'); } },
    'st:sea': L => { lE(L, 6, 5, 4.4, 3.4, ['#ffe0f8', '#e8a0e8', '#9a5aa8'], (x, y, u, v) => v <= 0.35); for (const x of [3, 6, 9]) for (let y = 7; y <= 10; y++) lset(L, x + (y === 9 ? 1 : 0), y, '#c88ad0'); },
    'st:magma': L => { lP(L, [[6, 0], [10, 7], [8.5, 11], [3.5, 11], [2, 7]], (x, y) => (Math.hypot(x - 6, y - 8) < 2.6 ? '#fff3a0' : y < 6 ? '#e8452a' : '#ff9700')); },
    'st:castle': L => { lR(L, 2, 5, 8, 6, ['#a89ab8', '#8a7a9a', '#6a5a7a']); lP(L, [[1, 5], [6, 0], [11, 5]], '#5ac83a'); lR(L, 5, 8, 2, 3, INK); },
    night: L => { lE(L, 6, 6, 4.6, 4.6, (x, y, u, v) => (Math.hypot(u - 0.45, v + 0.3) < 0.75 ? null : u + v < -0.6 ? '#fff6c0' : '#ffd23a')); lset(L, 10, 2, '#ffffff'); lset(L, 9, 9, '#ffffff'); },
    flip1: L => { capsule(L, 3, 4, 9, 8, 1.6, (dx, dy) => (dy < -0.5 ? FLIP_C.hi : dy > 0.6 ? FLIP_C.lo : FLIP_C.body)); lset(L, 3, 4, A.GOLD[0]); },
    flip2: L => { capsule(L, 1, 3, 10, 9, 1.7, (dx, dy) => (dy < -0.5 ? FLIP_C.hi : dy > 0.6 ? FLIP_C.lo : FLIP_C.body)); lset(L, 1, 3, A.GOLD[0]); },
    bag: L => { lE(L, 6, 7.5, 4.2, 3.6, ['#e8a85a', '#c07a36', '#8a5226']); lR(L, 4, 2, 4, 2, '#8a5226'); lE(L, 6, 4.5, 1.6, 1.2, A.MARB.glass); lset(L, 3, 6, '#f0c070'); },
    glass: L => { lE(L, 6, 6, 4.4, 4.4, (x, y, u, v) => (u + v < -0.8 ? '#ffffff' : u + v > 0.6 ? '#9aa6ba' : '#dfe7f2')); lset(L, 4, 4, '#ffffff'); lset(L, 5, 3, '#ffffff'); },
    dmg: L => { lP(L, [[6, 0], [7.5, 4], [12, 3], [8.5, 6.5], [11, 11], [6, 8.5], [1, 11], [3.5, 6.5], [0, 3], [4.5, 4]], (x, y) => (Math.hypot(x - 6, y - 6) < 2.5 ? '#fff3a0' : '#ff9700')); },
    gold: L => { lE(L, 6, 6, 4.6, 4.6, (x, y, u, v) => (u + v < -0.8 ? '#fff3a0' : u + v > 0.6 ? '#a87a20' : '#e8c048')); for (let y = 4; y <= 8; y++) lset(L, 6, y, '#a87a20'); },
    count: L => { lE(L, 3, 8, 2.6, 2.2, MUD); lE(L, 9, 8, 2.6, 2.2, MUD); lE(L, 6, 4.5, 2.6, 2.2, MUD); },
    goldSlime: L => { lE(L, 6, 7, 4.8, 4, GOLDS); lset(L, 4, 6, INK); lset(L, 8, 6, INK); lset(L, 3, 4, '#ffffff'); },
    fdur: L => { capsule(L, 1, 4, 10, 9, 1.7, (dx, dy) => (dy < -0.5 ? FLIP_C.hi : dy > 0.6 ? FLIP_C.lo : FLIP_C.body)); for (let k = 0; k < 3; k++) { lset(L, 5 + k, 5 + k, '#ffffff'); lset(L, 5 + k, 7 + k, '#ffffff'); } },
    crit: L => { lE(L, 6, 8.5, 5, 2.6, MUD); lset(L, 4, 8, INK); lset(L, 8, 8, INK); for (const [x, y] of [[6, 1], [5, 2], [6, 2], [7, 2], [6, 3], [2, 3], [10, 3]]) lset(L, x, y, '#ffd23a'); },
    steel: L => { lE(L, 6, 6, 4.4, 4.4, (x, y, u, v) => (u + v < -0.8 ? '#ffffff' : u + v > 0.6 ? '#5f6f76' : '#a3b0b5')); lset(L, 4, 4, '#ffffff'); },
    bone: L => { capsule(L, 3, 9, 9, 3, 1.1, A.kit.BONE[1]); for (const [x, y] of [[2, 8], [4, 10], [8, 2], [10, 4]]) lE(L, x, y, 1.4, 1.4, A.kit.BONE[0]); },
    bossBall: L => { lE(L, 6, 8, 3.4, 3.4, A.MARB.glass); for (const [x, y] of [[2, 3], [6, 2], [10, 3]]) { lset(L, x, y, '#ffd23a'); lset(L, x, y + 1, '#ffd23a'); } lR(L, 2, 4, 9, 2, '#e8c048'); },
    // 弹力绳：红三角 + 白橡皮筋
    sling: L => { lP(L, [[2, 1], [2, 10], [10, 10]], (x, y) => ((x + y) % 4 === 0 ? FLIP_C.lo : FLIP_C.body)); capsule(L, 2, 1, 10, 10, 1, '#ffffff'); },
    // 小孔：两根柱子中间一道缝，金珠从缝里穿过去
    lanes: L => { capsule(L, 3, 1, 3, 10, 1.3, metal); capsule(L, 9, 1, 9, 10, 1.3, metal); lE(L, 6, 5.5, 1.8, 1.8, GOLDS); },
    // 重来：绕一圈的箭头
    restart: L => {
      for (let a = 0.35; a < Math.PI * 2 - 0.5; a += 0.05) { const x = 6 + Math.cos(a) * 4.2, y = 6 + Math.sin(a) * 4.2; lset(L, Math.round(x), Math.round(y), '#8af06a'); lset(L, Math.round(6 + Math.cos(a) * 3.2), Math.round(6 + Math.sin(a) * 3.2), '#3ccf4a'); }
      for (const [x, y] of [[9, 1], [10, 2], [11, 3], [9, 3], [10, 3], [9, 2]]) lset(L, x, y, '#8af06a');
    },
    // 小人（左栏"小人"页）
    helper: L => { lE(L, 6, 4, 2.6, 2.6, ['#fff0c8', '#f0d090', '#c8a060']); lR(L, 3, 7, 7, 4, (x, y) => (y === 7 ? '#7ac0ff' : '#2f86ea')); lset(L, 5, 4, INK); lset(L, 7, 4, INK); },
    // 转生点
    star: L => { lP(L, [[6, 0], [7.6, 4.2], [12, 4.4], [8.6, 7.2], [9.8, 11.6], [6, 9], [2.2, 11.6], [3.4, 7.2], [0, 4.4], [4.4, 4.2]], (x, y) => (y < 5 ? '#fff3a0' : '#ffd84a')); },
    // 草地（右栏页签）：一块草皮、几根草、一朵小花
    grass: L => {
      lR(L, 0, 8, 12, 4, (x, y) => (y === 8 ? '#a8f07a' : y < 11 ? '#4cb848' : '#2e8a3a'));
      for (const [x, h] of [[1, 3], [3, 5], [5, 2], [7, 6], [9, 4], [11, 2]]) for (let k = 1; k <= h; k++) lset(L, x, 8 - k, k === h ? '#a8f07a' : '#5cc84a');
      for (const [x, y] of [[5, 2], [4, 3], [6, 3]]) lset(L, x, y, '#ff8ac8');
      lset(L, 5, 3, '#ffd23a'); lset(L, 5, 4, '#5cc84a'); lset(L, 5, 5, '#5cc84a');
    },
    // 菜园（右栏页签）：一根胡萝卜
    garden: L => {
      lP(L, [[2.5, 4], [9.5, 4], [6.5, 12]], (x, y) => (x < 5 ? '#ffb060' : x > 7 ? '#c85a10' : '#ff8a1e'));
      for (const [x, y] of [[4, 5], [7, 7], [5, 9]]) lset(L, x, y, '#c85a10');
      for (const [x, y] of [[5, 3], [6, 3], [4, 2], [6, 2], [7, 1], [3, 1], [5, 1], [8, 2]]) lset(L, x, y, '#5cc84a');
      lset(L, 6, 0, '#a8f07a'); lset(L, 4, 0, '#a8f07a');
    },
    // 史莱姆台（左栏第一行）
    main: L => { lE(L, 6, 7, 5, 4.2, MUD); lset(L, 4, 6, INK); lset(L, 8, 6, INK); lset(L, 3, 4, '#ffffff'); },
    // 回收：一颗玻璃珠，蓝箭头绕回去
    recycle: L => {
      for (let a = -1.3; a < 1.9; a += 0.05) { lset(L, Math.round(6 + Math.cos(a) * 4.6), Math.round(5.5 - Math.sin(a) * 4.6), '#7ac0ff'); lset(L, Math.round(6 + Math.cos(a) * 3.6), Math.round(5.5 - Math.sin(a) * 3.6), '#2f86ea'); }
      for (const [x, y] of [[2, 0], [1, 1], [2, 1], [3, 1], [2, 2], [0, 2], [1, 2]]) lset(L, x, y, '#7ac0ff');
      lE(L, 4, 8.5, 2.6, 2.6, A.MARB.glass); lset(L, 3, 7, '#ffffff');
    },
    // 骨刺：一根骨头渣斜着飞
    spike: L => { lP(L, [[0.5, 9.5], [2.5, 11.5], [11.5, 0.5]], (x, y) => (x + y < 11 ? A.kit.BONE[0] : A.kit.BONE[2])); lP(L, [[3, 9], [4, 10], [11, 1]], A.kit.BONE[1]); },
    // 骨刺根数：三根散开
    spikes: L => { for (const [tx, ty] of [[5.5, 0], [11.5, 0.5], [12, 6.5]]) { lP(L, [[0.5, 10], [2, 11.5], [tx, ty]], (x, y) => (x + y < 11 ? A.kit.BONE[0] : A.kit.BONE[2])); } },
    // 骨刺穿透：一根穿过史莱姆
    pierce: L => { lE(L, 7, 7.5, 4.4, 3.6, MUD); lset(L, 5, 7, INK); lset(L, 9, 7, INK); capsule(L, 0.5, 10.5, 11.5, 2.5, 0.7, A.kit.BONE[0]); lset(L, 11, 2, '#ffffff'); },
    // 着火：一团火
    fire: L => { lP(L, [[6, 0], [8, 3], [10, 4], [11.5, 8], [9.5, 11.5], [2.5, 11.5], [0.5, 8], [2, 5], [4, 4]], (x, y) => { const d = Math.hypot(x + 0.5 - 6, y + 0.5 - 8.5); return d < 2.2 ? '#fff3a0' : d < 3.8 ? '#ff9700' : '#e8452a'; }); },
    // 火势：火更大，两边冒火星
    heat: L => {
      lP(L, [[6, 0], [7.5, 2.5], [9.5, 3], [10.5, 7.5], [9, 11.5], [3, 11.5], [1.5, 7.5], [2.5, 3], [4.5, 2.5]], (x, y) => { const d = Math.hypot(x + 0.5 - 6, y + 0.5 - 8); return d < 3 ? '#ffffff' : d < 4.2 ? '#fff3a0' : '#ff9700'; });
      for (const [x, y] of [[0, 2], [11, 1], [11, 5], [0, 6]]) lset(L, x, y, '#ffd23a');
    },
    // 蔓延：一团火传给旁边那一团
    spread: L => {
      const flame = (ox, s) => lP(L, [[ox + 2.5 * s, 4], [ox + 4.5 * s, 7], [ox + 4 * s, 10.5], [ox + 1 * s, 10.5], [ox + 0.5 * s, 7]], (x, y) => (Math.hypot(x + 0.5 - (ox + 2.5 * s), y + 0.5 - 8.5) < 1.6 ? '#fff3a0' : '#ff9700'));
      flame(0, 1); flame(7, 1);
      for (const [x, y] of [[4, 3], [5, 2], [6, 2], [7, 3], [6, 1], [7, 2]]) lset(L, x, y, '#e8452a');
    },
    // 复活：史莱姆头上冒绿十字
    revive: L => { lE(L, 6, 8.5, 4.8, 3.2, MUD); lset(L, 4, 8, INK); lset(L, 8, 8, INK); for (const [x, y] of [[6, 0], [5, 1], [6, 1], [7, 1], [6, 2], [2, 3], [10, 3]]) lset(L, x, y, '#8af06a'); },
    // 复活上限：史莱姆顶着一道杠
    reviveCap: L => { lR(L, 1, 1, 10, 2, ['#c8d2d6', '#a3b0b5', '#5f6f76']); lE(L, 6, 8.5, 4.8, 3.2, MUD); lset(L, 4, 8, INK); lset(L, 8, 8, INK); lset(L, 6, 4, '#8af06a'); },
    // 复活成两只：两只小的
    reviveTwo: L => { lE(L, 3, 8.5, 3, 2.6, MUD); lE(L, 9, 8.5, 3, 2.6, MUD); lset(L, 2, 8, INK); lset(L, 4, 8, INK); lset(L, 8, 8, INK); lset(L, 10, 8, INK); for (const [x, y] of [[6, 1], [5, 2], [6, 2], [7, 2], [6, 3]]) lset(L, x, y, '#8af06a'); },
  };
  // ---------- 奖券：票形（长条、两头缺口、一道撕线、一个徽章），一台一色 ----------
  //   跟金币先靠形状分开（金币圆、券长条），再靠颜色（金币黄、券一台一色）
  const TIX_ROWS = ['hhhhhhhhhhhh', 'bbbpbbbbbbbb', '.bbbbbbbbbb.', '.bbpbbbbbbb.', '.bbbbbbbbbb.', 'bbbpbbbbbbbb', 'dddddddddddd'];
  const TIX = {
    dog: { pal: ['#c8e8ff', '#7fc2ff', '#3f8ed8', '#4a9ae0', '#ffffff'], em: ['xx..xx', '.xxxx.', 'xx..xx'] },
    volcano: { pal: ['#ff9a7a', '#e8452a', '#a82a1a', '#b8322a', '#ffd23a'], em: ['..x..', '.xxx.', 'xxxxx'] },
    ring: { pal: ['#e0b0ff', '#a050e8', '#6a2aa8', '#7a38c0', '#ffffff'], em: ['.xxx.', 'x...x', '.xxx.'] },
    // 后九台（11-11 粗做）：票身一台一色、色相拉开（深蓝、奶黄、青、白、橙、草绿、银灰、品红、墨绿），徽章是这台的东西（冰块、蛋、瓶、雪花、鱼、球门、铜钱、星、八号球）
    ice: { pal: ['#b0c4ff', '#3a54c0', '#1a2470', '#2a3a98', '#9af0ff'], em: ['xxxx', 'x..x', 'xxxx'] },
    hen: { pal: ['#fff8e0', '#e8cc78', '#a88a30', '#c0a048', '#ffffff'], em: ['.xx.', 'xxxx', '.xx.'] },
    bowl: { pal: ['#a8f0e8', '#2fb8b0', '#1f8078', '#26968e', '#ffffff'], em: ['.x.', '.x.', 'xxx'] },
    snow: { pal: ['#ffffff', '#dce8f2', '#8aa0b8', '#b0c2d2', '#3a5ab0'], em: ['x.x', '.x.', 'x.x'] },
    fish: { pal: ['#ffd0a0', '#ff9a4a', '#c0601e', '#d8702a', '#ffffff'], em: ['.xx.x', 'xxxxx', '.xx.x'] },
    soccer: { pal: ['#d8ffb0', '#7ad838', '#3a8a20', '#58b02a', '#ffffff'], em: ['xxx', 'x.x', 'xxx'] },
    coin: { pal: ['#d8e0e4', '#8a98a4', '#4a5660', '#6a7884', '#ffb070'], em: ['.xxx.', 'xx.xx', '.xxx.'] },
    circus: { pal: ['#ffc0e0', '#e84aa0', '#901a5a', '#b82a78', '#ffd23a'], em: ['.x.', 'xxx', 'x.x'] },
    pool: { pal: ['#a8e0b8', '#2f9050', '#164a28', '#1f6436', '#ffffff'], em: ['.xx.', 'x..x', '.xx.'] },
  };
  // 券的颜色（飘字、进度条用）：票身那一色
  const TIX_C = Object.fromEntries(Object.entries(TIX).map(([k, T]) => [k, T.pal[1]]));
  const tixCache = {};
  function ticket(id) {
    if (tixCache[id]) return tixCache[id];
    const T = TIX[id] || TIX.dog, rows = TIX_ROWS.map(r => r.split(''));
    const x0 = 5 + Math.floor((6 - T.em[0].length) / 2);
    T.em.forEach((r, j) => { for (let i = 0; i < r.length; i++) if (r[i] === 'x') rows[2 + j][x0 + i] = 'w'; });
    const [h, b, d, p, w] = T.pal;
    return (tixCache[id] = A.outlined(rows.map(r => r.join('')), { h, b, d, p, w }, INK));
  }
  const GRAY = c => (c === INK ? INK : mix(mix(c, '#7a6a70', 0.65), '#2a1a20', 0.25));
  const iconCache = {};
  // 节点图标 14×14。'm:骨头' 这种是强力珠子：直接用珠子的图
  function nodeIcon(k, locked) {
    const key = k + (locked ? '/g' : '');
    if (iconCache[key]) return iconCache[key];
    if (k.startsWith('m:')) {
      const b = ballSprite(k.slice(2), 0), c = canvas(14, 14), g = c.getContext('2d');
      g.drawImage(b, Math.floor((14 - b.width) / 2), Math.floor((14 - b.height) / 2));
      if (locked) { const d = g.getImageData(0, 0, 14, 14); for (let i = 0; i < d.data.length; i += 4) { if (!d.data[i + 3]) continue; const h = toHex(d.data[i], d.data[i + 1], d.data[i + 2]), q = toRGB(GRAY(h)); d.data[i] = q[0]; d.data[i + 1] = q[1]; d.data[i + 2] = q[2]; } g.putImageData(d, 0, 0); }
      return (iconCache[key] = c);
    }
    // 画在 12×12 上，挪进 14×14（四边留一格给深边）
    iconCache[key] = A.layerSprite('main:' + key, 14, 14, L => { const T = layer(12, 12); (ICON[k] || ICON.gold)(T); for (let j = 0; j < 12; j++) for (let i = 0; i < 12; i++) { const c = lget(T, i, j); if (c) lset(L, i + 1, j + 1, c); } }, locked ? GRAY : null);
    return iconCache[key];
  }

  return { PW, PH, CW4, CH4, STAGE_ART, ANCHOR, ZMIN, stageCanvas, worldArt, frameCanvas, hardwareCanvas, flatCanvas, partOutline, PAL, HAT, shatter, drawFlipper, ballSprite, BALL_C, drawSlime, slimeColors, MUD, GOLDS, KING, ICED, CROWN, COIN, FLAME, nodeIcon, ICON, ticket, TIX, TIX_C };
})();
