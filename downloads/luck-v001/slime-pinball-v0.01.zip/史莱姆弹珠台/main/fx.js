/*
 * 主线台面上的特效（照《视觉效果 v1》第二、三节）：画好的小图章，不是方块；一眼看出碎的是什么。数都是先填的。
 *   分两层画：
 *     world：跟史莱姆一层（镜头放远跟着缩）。地上的黏液印子、溅出去的黏液块、蹦出去的眼睛、挨打的"啪"、"叮"的白星
 *     over：跟珠子、挡板一层。玻璃片、骨头渣、挡板断下来那截、漆皮、珠子碾过去的残影、挡板拍的残影
 *   坐标都是台面格（物理坐标）；画 world 那层时 game.js 给 toW(x, y) 换到史莱姆那一层的坐标。
 *   碎一只：先白闪着等一下（一下碎好几只的时候一只一只来），压扁 POP_T 秒，再炸成几团黏液、两只眼睛蹦出去、地上留一滩。
 *   连着碎：隔 COMBO.gap 秒内接着碎就往上数；第几只溅得多大、声音多高，到 COMBO.shakeAt 只起台子震一下。
 *   用法：update(dt, balls, flippers)；look(o, p) 改史莱姆这一帧画成什么样；drawGround / drawWorld / drawOver / drawTrails / drawFlipTrails / drawSpikes 画；
 *         事件：hit、ding、kill、splash、shatter、crack、flipCrack、flipBreak、
 *               spikeOut（骨刺崩出来）、spikeStick（骨刺扎进去）、ignite（点着）、burnTick（烧一下，身子黑一档）、spread（火星划过去）、
 *               revive（这一只要复活：溅出去的往回收）、revived（"啵"站起来）、flyBack（回收：珠子飞回珠袋）、poof（打空了）、
 *               dust（boss 落地扬土）、sparkle（金星：金珠、最后一个 boss）
 *   烧死：塌成一撮灰、冒烟，不溅黏液；蜗牛碎了崩出壳片；鼻涕虫那一滩拖得长
 */
window.MainFX = (function () {
  'use strict';
  const A = Art, INK = A.INK;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const rnd = (a, b) => a + Math.random() * (b - a);
  const COMBO = { gap: 0.8, max: 8, shakeAt: 5 };
  const STAGGER = { step: 0.045, max: 0.22 };   // 一下碎好几只：一只隔多久（最多等多久，史莱姆 0.3 秒就从台上收走了）
  const POP_T = 0.07;                           // 碎之前压扁那一下
  const DECAL = { stay: 2.4, step: 0.14 };      // 地上那一滩停多久，再一档一档缩没
  const CAP = 110;                              // 台上同时最多几块碎屑，多了不冒
  const WHITE = '#ffffff';

  // ---------- 图章 ----------
  const cache = new Map();
  const memo = (key, make) => { if (!cache.has(key)) cache.set(key, make()); return cache.get(key); };
  // 黏液块：三个大小（C 是 [亮, 中, 暗]）
  const BLOB = [['m'], ['hm', 'md'], ['hm.', 'mmd', '.d.']];
  const blob = (n, C) => memo('b' + n + C.join(), () => A.outlined(BLOB[n], { h: C[0], m: C[1], d: C[2] }, INK));
  // 地上那一滩：溅开的一摊，边是花的（几个瓣），旁边甩出几个点；不描边，不画亮面（不然像一只压扁的史莱姆）。
  //   v 是哪一种花边（0..3）
  function puddle(rx, ry, C, v) {
    rx = Math.max(1, Math.round(rx)); ry = Math.max(1, Math.round(ry)); v = v || 0;
    return memo('p' + rx + 'x' + ry + 'v' + v + C.join(), () => {
      const pad = Math.max(2, Math.round(rx * 0.5)), w = rx * 2 + 1 + pad * 2, h = ry * 2 + 1 + pad * 2, ph = v * 1.7 + 0.4, rows = [];
      const cx = pad + rx, cy = pad + ry, dots = new Set();
      // 甩出去的点：四个，大一个、小三个
      for (let s = 0; s < 4; s++) {
        const a = ph + s * 1.65, dist = 1.35 + 0.18 * (s % 2), x = Math.round(cx + Math.cos(a) * rx * dist), y = Math.round(cy + Math.sin(a) * ry * dist);
        dots.add(x + ',' + y); if (s === 0) { dots.add(x + 1 + ',' + y); dots.add(x + ',' + (y + 1)); dots.add(x + 1 + ',' + (y + 1)); }
      }
      for (let j = 0; j < h; j++) {
        let s = '';
        for (let i = 0; i < w; i++) {
          const u = (i - cx) / (rx + 0.5), q = (j - cy) / (ry + 0.5), ang = Math.atan2(q, u);
          const rr = 1 + 0.17 * Math.sin(3 * ang + ph) + 0.1 * Math.sin(5 * ang + 2 * ph), d = Math.hypot(u, q) / rr;
          s += d <= 1 ? (d > 0.7 ? 'd' : 'm') : dots.has(i + ',' + j) ? 'd' : '.';
        }
        rows.push(s);
      }
      return A.sprite(rows, { d: C[2], m: C[1] });
    });
  }
  // 眼睛：一颗黑眼珠，左上一点白
  const EYE = A.sprite(['wk', 'kk'], { w: WHITE, k: INK });
  // 软的挨一下："啪"两帧
  const POW = [A.outlined(['.w.', 'www', '.w.'], { w: WHITE }, INK), A.outlined(['w.w', '...', 'w.w'], { w: WHITE }, INK)];
  // 硬的"叮"：一颗四角白星，大一帧、小一帧；四颗小火星往外飞
  const STAR = [
    A.outlined(['...w...', '...w...', '..www..', 'wwwwwww', '..www..', '...w...', '...w...'], { w: WHITE }, INK),
    A.outlined(['.w.', 'www', '.w.'], { w: WHITE }, INK),
  ];
  const SPARK = memo('spark', () => A.outlined(['w'], { w: WHITE }, INK));
  // 珠子碎：玻璃片（尖的）、骨头渣、黑石块；C 是 [暗, 中, 亮]
  const SHARD = {
    glass: [['l.', 'mm'], ['.l', 'lm', 'md'], ['lm', '.d'], ['l', 'm']],
    steel: [['lm', 'md'], ['l', 'm']],
    bone: [['lmm', 'mmd'], ['lm', 'md'], ['lm']],
    lava: [['mm', 'md'], ['.m', 'md'], ['m']],
  };
  const shard = (kind, n, C) => memo('s' + kind + n + C.join(), () => A.outlined(SHARD[kind][n], { l: C[2], m: C[1], d: C[0] }, INK));
  const EMBER = A.outlined(['o'], { o: '#ff9700' }, INK);
  // 挡板：断下来那截（横的、斜的两帧，转着掉）、漆皮
  const FLIP = { h: '#ff8a7a', b: '#fe4c40', l: '#b8322a' };
  const PIECE = [A.outlined(['.hhhh.', 'bbbbbb', '.llll.'], FLIP, INK), A.outlined(['..hh', '.hbb', 'hbbl', 'bbl.', 'll..'], FLIP, INK)];
  const CHIP = A.outlined(['b'], FLIP, INK);
  // 骨刺：白的尖骨片，八个方向各一张（尖朝前，尾巴粗一点、深一点）
  const BONE = A.kit.BONE;   // [亮, 中, 暗]
  const BONE_D = [BONE[2], BONE[1], BONE[0]];
  const spikeImg = oct => memo('spk' + oct, () => {
    const a = oct * Math.PI / 4, ux = Math.cos(a), uy = Math.sin(a), N = 11, c = 5, rows = [];
    for (let j = 0; j < N; j++) {
      let s = '';
      for (let i = 0; i < N; i++) {
        const dx = i - c, dy = j - c, t = dx * ux + dy * uy, n = Math.abs(-dx * uy + dy * ux);
        s += t <= 1 && t >= -2.5 && n <= 0.35 + Math.max(0, -t) * 0.18 ? (t > -0.4 ? 'l' : t > -1.6 ? 'm' : 'd') : '.';
      }
      rows.push(s);
    }
    return A.outlined(rows, { l: BONE[0], m: BONE[1], d: BONE[2] }, INK);
  });
  const octOf = a => ((Math.round(a / (Math.PI / 4)) % 8) + 8) % 8;
  // 火：蹿起来那一下三帧（小、大、落）；烟三帧（一团、大团、散了）；灰
  const FIRE = { o: '#ff9700', y: '#ffd23a', r: '#e8452a' };
  const FLARE = [
    A.outlined(['.o.', 'oyo'], FIRE, INK),
    A.outlined(['..o..', '.ooo.', 'ooyoo', 'oyyyo', '.ryr.'], FIRE, INK),
    A.outlined(['.o.o.', '.ooo.', 'oyyo.', '.yyr.'], FIRE, INK),
  ];
  const SM = { s: '#9a929e', g: '#625a6a' };
  const SMOKE = [A.outlined(['ss', 'sg'], SM, INK), A.outlined(['.ss.', 'sssg', 'ssgg', '.gg.'], SM, INK), A.sprite(['s..s', '.s..', 's.g.'], SM)];   // 散了那一帧不描边（稀的几个点描了边像棋盘格）
  const ASH = ['#7a7074', '#4e4448', '#2e2628'];
  // "啵"（复活站起来、打空了）：一圈白点，小一帧、大一帧
  //   一圈细白线，不描边（描了边一圈白点会看成棋盘格）；第二帧大一圈、断成点
  const ring = (r, dotted) => { const d = r * 2 + 1, rows = []; for (let j = 0; j < d; j++) { let row = ''; for (let i = 0; i < d; i++) { const q = Math.hypot(i - r, j - r); row += Math.abs(q - r) < 0.5 && (!dotted || (i + j) % 2 === 0) ? 'w' : '.'; } rows.push(row); } return A.sprite(rows, { w: WHITE }); };
  const PUFF = [ring(3), ring(5, true)];
  // 土：一团团扬起来的土（三帧）、土坷垃
  const DU = { c: '#f0dcb8', d: '#c8a878' };
  const DUST = [A.outlined(['.cc.', 'cccd', '.dd.'], DU, INK), A.outlined(['..ccc..', '.ccccc.', 'cccccdd', '.cddd..'], DU, INK), A.outlined(['.c..c.', 'c..c..', '..d..d'], DU, INK)];
  const CLOD = ['#c89060', '#8a5226', '#5a3216'];   // [亮, 中, 暗]
  // 金星（金珠、最后一个 boss 碎）
  const GSTAR = A.outlined(['.y.', 'yhy', '.y.'], { y: '#ffd23a', h: '#fff6c0' }, INK);
  // 蜗牛壳碎片：壳的颜色（跟 main/art.js 一样），[亮, 中, 暗]
  const SHELL = { snail: ['#ffd890', '#e08a3a', '#8a4a1a'], snailKing: ['#ffd0e8', '#ff6aa8', '#a83a6a'] };
  SHARD.shell = [['lm', 'md'], ['.l', 'lm', 'md'], ['lmm', '.dd'], ['lm']];
  // 碾过去的残影：一圈比一圈小的圆，珠子的亮色
  const disc = (r, c) => memo('d' + r + c, () => { const n = Math.ceil(r * 2), rows = []; for (let y = 0; y < n; y++) { let s = ''; for (let x = 0; x < n; x++) s += Math.hypot(x + 0.5 - r, y + 0.5 - r) <= r ? 'x' : '.'; rows.push(s); } return A.sprite(rows, { x: c }); });

  // ---------- 状态 ----------
  let now = 0, combo = 0, lastKill = -9, frameKills = 0;
  let bits = [];                 // 飞的、落地的碎屑
  let stamps = [];               // 一闪就没的图章（啪、白星）
  let decals = [];               // 地上那一滩
  const kills = new Map();       // 史莱姆 id → { t（负的是还在等）, crush, burst }
  const pending = [];            // 等着炸的
  const ballHist = new WeakMap(), crushT = new WeakMap();
  const flipHist = {};
  let onBurst = null;            // game.js 给：炸开那一下（第几只连着碎，boss 不算）放声音、发金币
  let ev = null;                 // 最近一样事（测试用：连拍图等它）
  const chars = new Map();       // 史莱姆 id → 烧黑了几档（0～3）
  let backN = 0;                 // 正往珠袋飞的几颗（珠袋那一排先空着前几格）
  let evN = 0; const evs = [], seen = {};   // 最近 32 样事（连拍图找它要的那一样，免得同一帧后面的事盖掉）
  const mark = (type, x, y, k, kind) => { ev = { type, x, y, k: k || 1, t: now, kind, n: ++evN }; evs.push(ev); if (evs.length > 32) evs.shift(); seen[type] = (seen[type] || 0) + 1; };

  function push(arr, o) { if (bits.length + stamps.length >= CAP) return false; arr.push(o); return true; }
  // 一块碎屑：vh 往上蹦的速度（画的时候往上抬 h 格，落地停住）；drag 台面上的阻力；grav 台子的坡（往下滑）
  //   path：{ x0, y0, x1, y1, arc } 照这条弧走（life 秒走完），onEnd 到了那一下；frames：图照 t / life 换帧；ground：落地以后画在史莱姆底下
  function bit(o) { return push(bits, Object.assign({ t: 0, h: 0, vh: 0, drag: 4, grav: 0, life: 1, layer: 'w', bounce: 0 }, o)); }

  // ---------- 事件 ----------
  // 软的挨一下：撞的那一点"啪"，往珠子那边溅两三滴
  function hit(e) {
    const C = e.cols, nx = e.nx || 0, ny = e.ny || -1;
    mark('hit', e.x, e.y);
    push(stamps, { img: POW, x: e.x, y: e.y, t: 0, dur: 0.12 });
    for (let i = 0; i < 1 + (e.big ? 1 : 0); i++) {
      const a = Math.atan2(ny, nx) + rnd(-0.9, 0.9), v = rnd(20, 36);
      bit({ img: blob(0, C), x: e.x, y: e.y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, vh: rnd(14, 24), life: rnd(0.5, 0.8) });
    }
  }
  // 硬的"叮"：白星 + 四颗火星
  function ding(e) {
    mark('ding', e.x, e.y);
    push(stamps, { img: STAR, x: e.x, y: e.y, t: 0, dur: 0.16 });
    for (let i = 0; i < 4; i++) {
      const a = Math.PI / 4 + i * Math.PI / 2 + rnd(-0.2, 0.2), v = rnd(45, 70);
      bit({ img: SPARK, x: e.x, y: e.y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, drag: 6, life: 0.22 });
    }
  }
  // 碎一只。e：{ id, x, y, r, cols, crush, boss, gold }；返回这一只的炸开要等几秒（金币、飘字跟着等）
  function kill(e) {
    if (now - lastKill > COMBO.gap) combo = 0;
    combo = Math.min(99, combo + 1); lastKill = now;
    const k = combo;
    const delay = e.boss ? 0 : Math.min(STAGGER.max, frameKills * STAGGER.step);
    if (!e.boss) frameKills++;
    mark(e.fire ? 'fireKill' : e.crush ? 'crush' : 'kill', e.x, e.y, k, e.kind);
    const rec = { t: -delay, crush: !!e.crush, e, k, done: false };
    if (e.id != null && !e.boss) kills.set(e.id, rec);
    pending.push(rec);
    return { delay: delay + (e.crush ? 0 : POP_T), k, shake: !e.boss && k >= COMBO.shakeAt };
  }
  function burst(rec) {
    const e = rec.e, k = Math.min(rec.k, COMBO.max), big = e.boss ? 3 : 1, r = e.r || 5;
    // 烧死：塌成一撮灰，冒一缕烟；不溅黏液、没有眼睛
    if (e.fire) {
      for (let i = 0; i < 4; i++) bit({ img: blob(i % 2, ASH), x: e.x + rnd(-r, r) * 0.5, y: e.y + r * 0.3, vx: rnd(-12, 12), vy: rnd(-4, 4), vh: rnd(6, 12), life: DECAL.stay * 0.8, stick: true, size: i % 2, C: ASH });
      for (let i = 0; i < 3; i++) bit({ img: SMOKE, frames: true, x: e.x + rnd(-2, 2), y: e.y - r * 0.3, vx: rnd(-6, 6), vy: rnd(-18, -10), drag: 0.8, life: 0.9, t: -i * 0.12 });
      decals.push({ x: e.x, y: e.y + r * 0.45, rx: r * 0.85 * big, ry: r * 0.3 * big, C: ASH, v: Math.floor(Math.random() * 4), t: 0, life: DECAL.stay });
      if (decals.length > 24) decals.shift();
      if (onBurst) onBurst(e, rec.k);
      return;
    }
    const C = e.cols, RV = rec.revive;
    // 要复活的：溅得近一点，一会儿全往回收（back）
    const back = RV ? { x: e.x, y: e.y, t0: now, end: RV.t0 + RV.dur } : null;
    const n = Math.round((3 + Math.min(k - 1, 3) + (e.crush ? 1 : 0)) * (e.boss ? 2.5 : 1)), sp = (38 + 4 * Math.min(k - 1, 5)) * (e.crush ? 1.15 : 1) * (e.boss ? 1.5 : 1) * (RV ? 0.6 : 1);
    for (let i = 0; i < n; i++) {
      const a = (i / n) * Math.PI * 2 + rnd(-0.3, 0.3), v = sp * rnd(0.55, 1.1);
      const size = i % 4 === 0 && (k >= 4 || e.boss) ? 2 : i % 3 === 0 ? 1 : 0;
      bit({ img: blob(size, C), x: e.x + Math.cos(a) * r * 0.4, y: e.y + Math.sin(a) * r * 0.3, vx: Math.cos(a) * v, vy: Math.sin(a) * v * 0.75, vh: rnd(20, 32), life: DECAL.stay * rnd(0.7, 1), stick: true, size, C, back });
    }
    // 两只眼睛往上轻轻一跳、往两边落（落地不弹）
    for (const d of [-1, 1]) bit({ img: EYE, x: e.x + d * Math.max(1, r * 0.3), y: e.y - r * 0.1, vx: d * rnd(8, 13) * (1 + 0.04 * (k - 1)), vy: rnd(-4, 4), vh: rnd(26, 34) * (e.crush ? 1.1 : 1), drag: 3, life: DECAL.stay, eye: true, back });
    // 蜗牛：壳崩成几片，落地停着
    const SC = SHELL[e.kind];
    if (SC) for (let i = 0; i < 5 * (e.boss ? 2 : 1); i++) {
      const a = rnd(0, Math.PI * 2), v = sp * rnd(0.5, 0.9);
      bit({ img: shard('shell', i % SHARD.shell.length, [SC[2], SC[1], SC[0]]), x: e.x, y: e.y - r * 0.3, vx: Math.cos(a) * v, vy: Math.sin(a) * v * 0.75, vh: rnd(24, 36), drag: 3, life: DECAL.stay * 0.9, blink: true, ground: true });
    }
    // 地上一滩：先溅开（一下长到满），停一会儿，一档一档缩没；鼻涕虫的拖得长；要复活的往回收
    const pr = r * (0.85 + 0.04 * Math.min(k - 1, 4)) * (e.boss ? 2.5 : 1), slug = e.kind === 'slug' ? 1.45 : 1;
    decals.push({ x: e.x, y: e.y + r * 0.4, rx: pr * slug, ry: pr * 0.36, C, v: Math.floor(Math.random() * 4), t: 0, life: DECAL.stay, gather: back });
    if (decals.length > 24) decals.shift();
    if (onBurst) onBurst(e, rec.k);
  }
  // 溅一圈（大个的裂两只、boss 吐一只……）：只溅黏液，不留眼睛
  function splash(e) {
    const C = e.cols, n = e.n || 5;
    for (let i = 0; i < n; i++) {
      const a = (i / n) * Math.PI * 2 + rnd(-0.3, 0.3), v = rnd(25, 45);
      bit({ img: blob(i % 2, C), x: e.x, y: e.y, vx: Math.cos(a) * v, vy: Math.sin(a) * v * 0.75, vh: rnd(14, 26), life: rnd(1, 1.6), stick: true, size: i % 2, C });
    }
  }
  // 珠子碎：玻璃片 / 骨头渣 / 黑石块（带几颗火星），往外迸、顺着坡滑、停住、闪两下没了
  function shatter(e) {
    const kind = SHARD[e.kind] ? e.kind : e.kind === 'taw' || e.kind === 'iron' || e.kind === 'bowl' ? 'steel' : 'glass';
    const C = e.cols, shapes = SHARD[kind];
    mark('shatter', e.x, e.y);
    const n = kind === 'glass' ? 6 : 5;
    for (let i = 0; i < n; i++) {
      const a = (i / n) * Math.PI * 2 + rnd(-0.4, 0.4), v = rnd(35, 65);
      bit({ img: shard(kind, i % shapes.length, C), x: e.x, y: e.y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 10, vh: rnd(10, 22), drag: 2.6, grav: 40, life: rnd(1.1, 1.5), layer: 'o', blink: true });
    }
    if (kind === 'lava') for (let i = 0; i < 3; i++) bit({ img: EMBER, x: e.x, y: e.y, vx: rnd(-30, 30), vy: rnd(-40, -10), vh: rnd(20, 32), drag: 2, life: 0.5, layer: 'o' });
    else for (let i = 0; i < 3; i++) { const a = rnd(0, Math.PI * 2); bit({ img: SPARK, x: e.x, y: e.y, vx: Math.cos(a) * 60, vy: Math.sin(a) * 60, drag: 8, life: 0.18, layer: 'o' }); }
  }
  // 珠子裂一道：崩下一两粒碎渣
  function crack(e) {
    for (let i = 0; i < 2; i++) bit({ img: shard('glass', 3, e.cols), x: e.x, y: e.y, vx: rnd(-35, 35), vy: rnd(-35, 5), vh: rnd(10, 18), drag: 3, grav: 40, life: 0.7, layer: 'o', blink: true });
  }
  // 挡板裂了：掉两块漆皮；断了：前头那截转着掉下去，再掉几块漆皮
  function flipCrack(e) { for (let i = 0; i < 2; i++) bit({ img: CHIP, x: e.x + rnd(-4, 4), y: e.y + rnd(-2, 2), vx: rnd(-20, 20), vy: rnd(-20, 0), vh: rnd(10, 20), drag: 1.5, grav: 80, life: 0.9, layer: 'o' }); }
  function flipBreak(e) {
    const dir = e.side === 'L' ? 1 : -1;
    mark('flipBreak', e.x, e.y);
    bit({ img: PIECE, spin: dir * 9, x: e.tx != null ? (e.x + e.tx) / 2 : e.x + dir * 6, y: e.ty != null ? (e.y + e.ty) / 2 : e.y, vx: dir * rnd(10, 20), vy: -25, drag: 0.5, grav: 160, life: 1.2, layer: 'o' });
    for (let i = 0; i < 4; i++) bit({ img: CHIP, x: e.x + dir * rnd(2, 10), y: e.y + rnd(-2, 2), vx: rnd(-30, 30), vy: rnd(-40, -5), vh: rnd(10, 20), drag: 1.5, grav: 120, life: 1, layer: 'o' });
  }
  // ---------- 骨刺 ----------
  // 崩出来："咔"一下白星，掉两三粒骨头渣（跟珠子一层）
  function spikeOut(e) {
    mark('spikes', e.x, e.y);
    push(stamps, { img: [STAR[1]], x: e.x, y: e.y, t: 0, dur: 0.08, layer: 'o' });
    for (let i = 0; i < 2; i++) bit({ img: shard('bone', i % 3, BONE_D), x: e.x, y: e.y, vx: rnd(-30, 30), vy: rnd(-35, 0), vh: rnd(10, 20), drag: 3, grav: 40, life: 0.6, layer: 'o', blink: true });
  }
  // 扎进史莱姆（没扎死）：骨刺插在身上一下。a 是骨刺朝哪
  function spikeStick(e) { push(stamps, { img: [spikeImg(octOf(e.a))], x: e.x, y: e.y, t: 0, dur: 0.22 }); }
  // 飞着的骨刺：尖朝前，身后两个点的残影（跟珠子一层，台面格）
  function drawSpikes(g, shards) {
    for (const q of shards || []) {
      if (q.dead) continue;
      const v = Math.hypot(q.vx, q.vy) || 1, ux = q.vx / v, uy = q.vy / v;
      MK.px(g, Math.round(q.x - ux * 5), Math.round(q.y - uy * 5), BONE[2]);
      const im = spikeImg(octOf(Math.atan2(q.vy, q.vx)));
      MK.spr(g, im, Math.round(q.x - im.width / 2), Math.round(q.y - im.height / 2));
    }
  }
  // ---------- 火 ----------
  // 点着："呼"地蹿起一团火，三颗火星往上飘（x, y 是头顶）
  function ignite(e) {
    mark('burn', e.x, e.y);
    push(stamps, { img: FLARE, x: e.x, y: e.y - 3, t: 0, dur: 0.3 });
    for (let i = 0; i < 3; i++) bit({ img: EMBER, x: e.x + rnd(-3, 3), y: e.y, vx: rnd(-10, 10), vy: rnd(-25, -12), drag: 1.5, life: rnd(0.35, 0.55) });
  }
  // 烧一下：头顶火苗跳一下，身子黑一档（最多三档）
  function burnTick(e) {
    mark('burnTick', e.x, e.y);
    chars.set(e.id, Math.min(3, (chars.get(e.id) || 0) + 1));
    push(stamps, { img: [FLARE[0], FLARE[2]], x: e.x, y: e.y + 1, t: 0, dur: 0.18 });
    bit({ img: EMBER, x: e.x + rnd(-2, 2), y: e.y - 2, vx: rnd(-8, 8), vy: -22, drag: 1.5, life: 0.4 });
  }
  // 火传过去：一颗火星划一道弧，落到那一只身上蹿一下火
  function spread(e) {
    mark('spread', e.x1, e.y1);
    const d = Math.hypot(e.x1 - e.x0, e.y1 - e.y0);
    bit({ img: EMBER, x: e.x0, y: e.y0, path: { x0: e.x0, y0: e.y0, x1: e.x1, y1: e.y1, arc: 4 + d * 0.15 }, life: 0.3, trail: true,
      onEnd: () => push(stamps, { img: FLARE, x: e.x1, y: e.y1 - 3, t: 0, dur: 0.24 }) });
  }
  // ---------- 复活 ----------
  // 这一只要复活（碎的同一下就知道）：溅出去的、地上那一滩，dur 秒里全往回收
  function revive(e) { const rec = kills.get(e.id); mark('revive', rec ? rec.e.x : 0, rec ? rec.e.y : 0); if (rec) rec.revive = { two: !!e.two, dur: e.dur, t0: now }; }
  // 聚好了"啵"一下站起来：还没炸开的就不炸了；收回来的都收走
  function revived(e) {
    mark('revived', e.x, e.y);
    for (const rec of pending) if (rec.revive && Math.abs(rec.e.x - e.x) < 0.5 && Math.abs(rec.e.y - e.y) < 0.5) rec.done = true;
    for (const b of bits) if (b.back && Math.abs(b.back.x - e.x) < 0.5 && Math.abs(b.back.y - e.y) < 0.5) b.dead = true;
    // 一圈白点从身子边上往外崩（不压在脸上）
    const r = e.r || 6;
    for (let i = 0; i < 6; i++) { const a = (i / 6) * Math.PI * 2; bit({ img: SPARK, x: e.x + Math.cos(a) * r, y: e.y + Math.sin(a) * r * 0.7, vx: Math.cos(a) * 60, vy: Math.sin(a) * 42, drag: 9, life: 0.18 }); }
    for (let i = 0; i < 2; i++) { const a = -Math.PI / 2 + rnd(-1.2, 1.2); bit({ img: blob(0, e.cols), x: e.x, y: e.y, vx: Math.cos(a) * 22, vy: Math.sin(a) * 14, vh: rnd(12, 20), life: 0.45 }); }
  }
  // ---------- 珠子回珠袋、打空了 ----------
  // 回收：珠子划一道弧飞回珠袋最前那一格（tx, ty 是那一格的中心），落进去"啵"一下；0.3 秒飞到，赶在下一颗上膛（隔 0.35 秒）之前
  function flyBack(e) {
    mark('recycle', e.x, e.y);
    const ok = bit({ img: e.img, x: e.x, y: e.y, path: { x0: e.x, y0: e.y, x1: e.tx, y1: e.ty, arc: 14 }, life: 0.3, layer: 'o',
      onEnd: () => { backN = Math.max(0, backN - 1); push(stamps, { img: [PUFF[0]], x: e.tx, y: e.ty, t: 0, dur: 0.1, layer: 'o' }); } });
    if (ok) backN++;
  }
  // 打空了（没买回收）：珠子"噗"一下没了
  function poof(e) {
    mark('usedUp', e.x, e.y);
    push(stamps, { img: PUFF, x: e.x, y: e.y, t: 0, dur: 0.2, layer: 'o' });
    for (let i = 0; i < 3; i++) { const a = rnd(0, Math.PI * 2); bit({ img: SPARK, x: e.x, y: e.y, vx: Math.cos(a) * 50, vy: Math.sin(a) * 50, drag: 8, life: 0.2, layer: 'o' }); }
  }
  // ---------- boss、金星 ----------
  // boss 落地：脚底一圈土团往两边扬开，几块土坷垃蹦出去（w 是 boss 多宽）
  function dust(e) {
    mark('dust', e.x, e.y);
    const w = e.w || 8;
    for (let i = 0; i < 10; i++) { const d = i % 2 ? 1 : -1, x = e.x + d * rnd(0.5, 1.1) * w; bit({ img: DUST, frames: true, x, y: e.y + rnd(-1, 2), vx: d * rnd(40, 70), vy: rnd(-10, -2), drag: 4, life: rnd(0.4, 0.55) }); }
    for (let i = 0; i < 4; i++) { const d = i % 2 ? 1 : -1; bit({ img: shard('lava', i % 3, [CLOD[2], CLOD[1], CLOD[0]]), x: e.x + d * w * 0.6, y: e.y, vx: d * rnd(25, 45), vy: rnd(-10, 0), vh: rnd(20, 30), drag: 2.5, life: 0.9, blink: true, ground: true }); }
  }
  // 金星：往外迸一圈（layer 'o' 跟珠子一层）
  function sparkle(e) {
    mark('sparkle', e.x, e.y);
    const n = e.n || 8;
    for (let i = 0; i < n; i++) { const a = (i / n) * Math.PI * 2 + rnd(-0.2, 0.2), v = rnd(40, 80) * (n > 10 ? 1.5 : 1); bit({ img: GSTAR, x: e.x, y: e.y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, vh: rnd(5, 15), drag: 3, life: rnd(0.5, 0.8), layer: e.layer || 'w', blink: true }); }
  }
  // 拉杆装上那一下：发射道底下冒一小团灰烟往两边散，崩两三颗白火花（跟珠子一层）
  function clunk(e) {
    mark('clunk', e.x, e.y);
    for (let i = 0; i < 6; i++) { const d = i % 2 ? 1 : -1; bit({ img: SMOKE, frames: true, x: e.x + d * rnd(1, 4), y: e.y, vx: d * rnd(18, 34), vy: rnd(-12, -3), drag: 4, life: rnd(0.3, 0.45), layer: 'o' }); }
    for (let i = 0; i < 3; i++) { const a = -Math.PI / 2 + rnd(-1, 1); bit({ img: SPARK, x: e.x, y: e.y - 2, vx: Math.cos(a) * 55, vy: Math.sin(a) * 55, drag: 6, grav: 80, life: 0.25, layer: 'o' }); }
  }
  // 碾过去：记下离这一点最近的那颗珠子，画它 0.25 秒的残影
  function crushed(x, y, balls) {
    let best = null, bd = Infinity;
    for (const b of balls || []) if (b.state === 'play') { const d = Math.hypot(b.x - x, b.y - y); if (d < bd) { bd = d; best = b; } }
    if (best) crushT.set(best, now);
  }

  // ---------- 每帧 ----------
  function update(dt, balls, flippers) {
    now += dt; frameKills = 0;
    // 碎了的：等够了炸开；炸完再留一会儿（look 还要用），0.5 秒后收走
    for (const rec of pending) {
      rec.t += dt;
      if (!rec.done && rec.t >= (rec.crush || rec.e.boss ? 0 : POP_T)) { rec.done = true; burst(rec); }
    }
    for (let i = pending.length - 1; i >= 0; i--) if (pending[i].t > 0.5) { const rec = pending[i]; pending.splice(i, 1); if (kills.get(rec.e.id) === rec) kills.delete(rec.e.id); }
    for (const s of stamps) s.t += dt;
    stamps = stamps.filter(s => s.t < s.dur);
    for (const b of bits) {
      b.t += dt;
      if (b.t < 0) continue;
      if (b.path) {
        const u = clamp(b.t / b.life, 0, 1), Q = b.path;
        b.x = Q.x0 + (Q.x1 - Q.x0) * u; b.y = Q.y0 + (Q.y1 - Q.y0) * u; b.h = Q.arc * Math.sin(Math.PI * u);
        if (u >= 1 && !b.arrived) { b.arrived = true; b.dead = true; if (b.onEnd) b.onEnd(b); }
        continue;
      }
      if (b.back) {
        const B = b.back, u = (now - B.t0) / Math.max(0.01, B.end - B.t0);
        if (u >= 1) { b.dead = true; continue; }
        if (u > 0.3) { const kk = Math.min(1, dt * 16); b.x += (B.x - b.x) * kk; b.y += (B.y - b.y) * kk; b.h *= 1 - kk; b.vh = 0; continue; }
      }
      const f = Math.exp(-b.drag * dt);
      if (b.h > 0 || b.vh > 0 || !b.stick) {
        b.vx *= f; b.vy = b.vy * f + b.grav * dt;
        b.x += b.vx * dt; b.y += b.vy * dt;
      }
      if (b.vh !== 0 || b.h > 0) {
        b.h += b.vh * dt; b.vh -= 320 * dt;
        if (b.h <= 0) { b.h = 0; b.vh = b.bounce && -b.vh > 25 ? -b.vh * b.bounce : 0; if (!b.vh) b.landed = true; }
      }
    }
    bits = bits.filter(b => !b.dead && b.t < b.life + (b.stick ? DECAL.step * 3 : 0));
    for (const d of decals) d.t += dt;
    decals = decals.filter(d => (d.gather ? now < d.gather.end : d.t < d.life + DECAL.step * 3));
    // 珠子走过的地方（残影用）、挡板尖走过的地方（拍的残影用）
    for (const b of balls || []) { let h = ballHist.get(b); if (!h) ballHist.set(b, (h = [])); h.unshift([b.x, b.y]); if (h.length > 5) h.pop(); }
    const P = window.MainLine;
    for (const fp of flippers || []) { const h = flipHist[fp.side] || (flipHist[fp.side] = []); h.unshift(fp.broken ? null : P.tipOf(fp)); if (h.length > 3) h.pop(); }
  }
  // 史莱姆这一帧画成什么样：等着炸的白闪着，炸之前压扁一下，炸了就不画
  function look(o, p) {
    if (o.burn > 0 && chars.has(o.id)) p.char = chars.get(o.id);
    const rec = kills.get(o.id);
    if (!rec || o.boss) return p;
    if (rec.t < 0) { p.state = 'live'; p.flash = 0.05; p.squash = 0; }
    else if (!rec.crush && rec.t < POP_T) { p.state = 'pop'; p.t = (rec.t / POP_T) * 0.25 * 0.7; }
    else p.state = 'wait';
    return p;
  }

  // ---------- 画 ----------
  // 缩档：停够了以后一档一档变小（黏液块 2 → 1 → 0 → 没；一滩照比例缩）
  function shrinkStep(t, life) { return t < life ? 0 : Math.floor((t - life) / DECAL.step) + 1; }
  function drawGround(g, toW) {
    for (const d of decals) {
      const s = shrinkStep(d.t, d.life), grow = Math.min(1, 0.5 + d.t / 0.08);
      let k = s ? 1 - s * 0.3 : grow;
      if (d.gather) k = grow * (1 - 0.85 * clamp((now - d.gather.t0) / Math.max(0.01, d.gather.end - d.gather.t0), 0, 1));
      if (k <= 0) continue;
      const im = puddle(d.rx * k, d.ry * k, d.C, d.v), p = toW(d.x, d.y);
      MK.spr(g, im, Math.round(p.x - im.width / 2), Math.round(p.y - im.height / 2));
    }
    for (const b of bits) if (b.layer === 'w' && onGround(b)) drawBit(g, b, toW);
  }
  const onGround = b => b.h <= 0 && !b.path && (b.stick || b.eye || b.ground);
  function drawStamp(g, s, toW) { const fr = s.img[Math.min(s.img.length - 1, Math.floor(s.t / s.dur * s.img.length))], p = toW(s.x, s.y); MK.spr(g, fr, Math.round(p.x - fr.width / 2), Math.round(p.y - fr.height / 2)); }
  function drawWorld(g, toW) {
    for (const b of bits) if (b.layer === 'w' && !onGround(b)) drawBit(g, b, toW);
    for (const s of stamps) if (s.layer !== 'o') drawStamp(g, s, toW);
  }
  const ID = (x, y) => ({ x, y });
  function drawOver(g) {
    for (const b of bits) if (b.layer === 'o') drawBit(g, b, ID);
    for (const s of stamps) if (s.layer === 'o') drawStamp(g, s, ID);
  }
  function drawBit(g, b, toW) {
    if (b.t < 0) return;
    let im = b.img;
    if (b.frames) im = b.img[Math.min(b.img.length - 1, Math.floor(b.t / b.life * b.img.length))];
    // 火星的尾巴：弧上往回两个点
    if (b.trail && b.path) {
      const Q = b.path, u = clamp(b.t / b.life, 0, 1);
      for (const du of [0.12, 0.24]) { const v = u - du; if (v <= 0) continue; const p = toW(Q.x0 + (Q.x1 - Q.x0) * v, Q.y0 + (Q.y1 - Q.y0) * v - Q.arc * Math.sin(Math.PI * v)); MK.px(g, Math.round(p.x), Math.round(p.y), du < 0.2 ? FIRE.y : FIRE.o); }
    }
    if (b.stick && b.t > b.life) { const s = shrinkStep(b.t, b.life), n = b.size - s; if (n < 0) return; im = blob(n, b.C); }
    if (b.blink && b.t > b.life - 0.3 && Math.floor(b.t * 16) % 2) return;
    if (b.eye && b.t > b.life) return;
    if (Array.isArray(im)) im = im[Math.floor(Math.abs(b.t * (b.spin || 0))) % im.length];
    const p = toW(b.x, b.y - b.h);
    MK.spr(g, im, Math.round(p.x - im.width / 2), Math.round(p.y - im.height / 2));
  }
  // 碾过去的残影：珠子身后三个一个比一个小的圆
  function drawTrails(g, balls) {
    for (const b of balls || []) {
      const t0 = crushT.get(b); if (t0 == null || now - t0 > 0.25 || b.state !== 'play') continue;
      const h = ballHist.get(b); if (!h) continue;
      const C = (window.MainArt.BALL_C[b.kind] || A.MARB.glass)[2];
      [2.5, 2, 1.5].forEach((r, i) => { const q = h[i + 1]; if (!q) return; const im = disc(r, C); MK.spr(g, im, Math.round(q[0] - im.width / 2), Math.round(q[1] - im.height / 2)); });
    }
  }
  // 挡板拍上去的残影：转轴到前两帧挡板尖，各描一道浅色的点
  function drawFlipTrails(g, flippers) {
    for (const fp of flippers || []) {
      const h = flipHist[fp.side]; if (!h || !h[0] || !h[1]) continue;
      if (Math.hypot(h[0][0] - h[1][0], h[0][1] - h[1][1]) < 1.5) continue;
      for (let i = 1; i < h.length; i++) if (h[i]) MK.dots(g, fp.px, fp.py, h[i][0], h[i][1], i === 1 ? FLIP.h : '#ffd8d0', 2);
    }
  }
  function clear() { bits = []; stamps = []; decals = []; kills.clear(); pending.length = 0; combo = 0; chars.clear(); backN = 0; }

  return {
    COMBO, STAGGER, POP_T, DECAL,
    hit, ding, kill, splash, shatter, crack, flipCrack, flipBreak, crushed,
    spikeOut, spikeStick, ignite, burnTick, spread, revive, revived, flyBack, poof, dust, sparkle, clunk,
    update, look, drawGround, drawWorld, drawOver, drawTrails, drawFlipTrails, drawSpikes, clear,
    flyingBack: () => backN, events: () => evs,
    combo: () => (now - lastKill > COMBO.gap ? 0 : combo),
    lastEv: () => ev,
    setOnBurst: f => { onBurst = f; },
    count: () => ({ bits: bits.length, stamps: stamps.length, decals: decals.length, pending: pending.filter(r => !r.done).length, seen }),
  };
})();
