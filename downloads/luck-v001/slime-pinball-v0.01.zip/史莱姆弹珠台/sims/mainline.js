/*
 * 主线大台（史莱姆主线）。从 sims/pinwide.js（沼泽那张大台）改来：坐标、发射道、导轨、弹弓、顶上两条通道都一样。
 * 跟沼泽不一样的：
 *   挡板按"盖住口子几成"连续变长（树上一级一级加长：4 成起，每级多盖 5%，最长 8 成半）。没有挡板时，台底正中是一道 48 格宽的口子（x 66..114）。
 *   挡板会断：f.broken 了就不碰，台子只画一截断茬。
 *   撞史莱姆先问台子（s.onHit(m, b, impact, nx, ny)），它回：
 *     'pass' 很重的珠子（保龄球）这一下打死了：穿过去，不弹、不减速（史莱姆那边自己把 solid 关掉）
 *     'plow' 很重的珠子打着了没死：推着它擦过去，只弹一点点（平常的三成，不加 kick）
 *     'ding' 打不动（珠子比它软）：照常弹开，弹得硬一点
 *     'hit' / 'soft' 打着了（打死了也算，基础珠子要弹一下）/ 太轻没算：照常弹开
 *   珠子大小可以不一样（b.r），以后的重珠子也走这里。
 *   台上的零件按树上买的装（s.parts）：sling 两边的弹力绳（弹弓三角）、lanes 顶上两个能穿过去的小孔（通道）。
 *     没买的时候台面是空的：只有墙、顶、发射道、底下两条导轨和挡板转轴的螺栓。setParts 换零件，碰撞体整个重建。
 * 固定步长 1/480 秒。
 */
(function (root, factory) {
  const Sim = typeof module === 'object' && module.exports ? require('../sim.js') : root.Sim;
  const api = factory(Sim);
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.MainLine = api;
}(typeof self !== 'undefined' ? self : globalThis, function (Sim) {
  'use strict';
  const DT = 1 / 480;
  const DX = 64;
  const X0 = 14, X1 = 178, Y0 = 20, YB = 154, CH = 20;
  const LANE_X = Sim.LANE_X + DX, LANE_TOP = Sim.LANE_TOP, LANE_CX = Sim.LANE_CX + DX, HEAD_Y = Sim.HEAD_Y, REST_Y = Sim.REST_Y;
  const BALL_R = 3.5, GRAVITY = 170, VMAX = 255;
  const LAUNCH = Object.assign({}, Sim.DEFAULTS, { gravity: GRAVITY });
  const CXF = 90;   // 台底口子的正中
  const FLIP = { L: { px: CXF - 24, py: 131 }, R: { px: CXF + 24, py: 131 }, rp: 3.6, rt: 2.1, rest: 28 * Math.PI / 180, w: 18 };
  // 挡板护住口子（48 格）的几成 → 一片多长；一片护一半：len·cos(28°) + 尖上的圆 = 24 × 几成
  const flipLen = c => (c > 0 ? (24 * c - FLIP.rt) / Math.cos(FLIP.rest) : 0);
  const PIT = { x0: CXF - 24, x1: CXF + 24, y: 134 };   // 台底的口子
  const DRAIN_Y = 152;                                   // 掉到这一行就算没了
  const GATE = { x0: LANE_X, y0: LANE_TOP, x1: X1, y1: LANE_TOP - 10 };
  { const l = Math.hypot(GATE.x1 - GATE.x0, GATE.y1 - GATE.y0); GATE.nx = (GATE.y1 - GATE.y0) / l; GATE.ny = -(GATE.x1 - GATE.x0) / l; }
  // 导轨：墙 → 挡板转轴。导轨贴着转轴的圆顶收尾（切点），珠子顺着滚上挡板，不会卡在导轨头和转轴中间的夹缝里。
  // 弹弓三角：A 顶、B 底（贴着导轨）、C 斜边下头，斜边 A→C 是橡皮筋；cap 是墙接到 A 的斜板
  function tangentEnd(ax, ay, cx, cy, r, side) {
    const dx = cx - ax, dy = cy - ay, d = Math.hypot(dx, dy), th = Math.asin(r / d) * (side === 'L' ? -1 : 1);
    const ux = dx / d, uy = dy / d, c = Math.cos(th), s_ = Math.sin(th), L = Math.sqrt(d * d - r * r);
    return [ax + L * (ux * c - uy * s_), ay + L * (ux * s_ + uy * c)];
  }
  const GUIDE = { L: [[X0, 84], tangentEnd(X0, 84, FLIP.L.px, FLIP.L.py, FLIP.rp, 'L')], R: [[LANE_X, 84], tangentEnd(LANE_X, 84, FLIP.R.px, FLIP.R.py, FLIP.rp, 'R')] };
  const SLING = { L: { A: [34, 86], B: [34, 99], C: [48, 112], cap: [X0, 70] }, R: { A: [146, 86], B: [146, 99], C: [132, 112], cap: [LANE_X, 70] } };
  // 顶上两条通道：一根柱子隔出来；球往下滚过 sy 那一行发 lane 事件
  const LANES = { L: { x: 30, y0: 50, y1: 64, sx0: X0, sx1: 30, sy: 58 }, R: { x: 150, y0: 54, y1: 66, sx0: 150, sx1: LANE_X, sy: 60 } };
  // 史莱姆待的地方
  const ZONE = { x0: 44, x1: 136, y0: 34, y1: 84 };

  function build(s) {
    const parts = s.parts || {};
    Sim.addSeg(s, X0, Y0 + CH, X0, 84, 'wall', 0.4, 0.02, 60, 90);
    Sim.addSeg(s, X1, Y0 + CH, X1, YB, 'wall', 0.4, 0.02, 60, 90);
    Sim.addSeg(s, X0, Y0 + CH, X0 + CH, Y0, 'roof', 0.2, 0.01, 60, 90);
    Sim.addSeg(s, X0 + CH, Y0, X1 - CH, Y0, 'roof', 0.2, 0.01, 60, 90);
    Sim.addSeg(s, X1 - CH, Y0, X1, Y0 + CH, 'roof', 0.2, 0.01, 60, 90);
    Sim.addWall(s, LANE_X, LANE_TOP, LANE_X, YB, 'lane', 0.3, 0.02);
    Sim.addSeg(s, LANE_X, HEAD_Y, X1, HEAD_Y, 'head', 0.1, 0.2, LANE_CX, 100);
    Sim.addSeg(s, LANE_X, LANE_TOP, LANE_X - 6, LANE_TOP + 4, 'guard', 0.3, 0.02, LANE_X - 8, LANE_TOP - 4);
    for (const k of ['L', 'R']) {
      const [a, b] = GUIDE[k];
      Sim.addWall(s, a[0], a[1], b[0], b[1], 'guide', 0.35, 0.02);
      if (parts.sling) {
        const S = SLING[k];
        Sim.addWall(s, S.cap[0], S.cap[1], S.A[0], S.A[1], 'wall', 0.4, 0.02);
        Sim.addWall(s, S.A[0], S.A[1], S.B[0], S.B[1], 'post', 0.4, 0.02);
        Sim.addWall(s, S.B[0], S.B[1], S.C[0], S.C[1], 'post', 0.4, 0.02);
        Sim.addWall(s, S.A[0], S.A[1], S.C[0], S.C[1], 'sling', 0.55, 0.02);
        for (const p of [S.A, S.B, S.C]) Sim.addCircle(s, p[0], p[1], 2, 'post', 0.4, 0.02);
      }
      if (parts.lanes) {
        const Ln = LANES[k];
        Sim.addWall(s, Ln.x, Ln.y0, Ln.x, Ln.y1, 'post', 0.4, 0.02);
        Sim.addCircle(s, Ln.x, Ln.y0, 2, 'post', 0.4, 0.02);
        Sim.addCircle(s, Ln.x, Ln.y1, 2, 'post', 0.4, 0.02);
      }
    }
    // 转轴的螺栓：挡板断了、还没买挡板，导轨头上也有这一颗圆顶托着，珠子从它上面滚进口子
    for (const k of ['L', 'R']) Sim.addCircle(s, FLIP[k].px, FLIP[k].py, FLIP.rp, 'post', 0.3, 0.02);
  }

  // cover：盖住口子几成（0 就是没有挡板）
  function makeFlippers(cover) {
    if (!(cover > 0)) return [];
    const len = flipLen(cover);
    return [
      { side: 'L', px: FLIP.L.px, py: FLIP.L.py, len, rp: FLIP.rp, rt: FLIP.rt, rest: FLIP.rest, up: -FLIP.rest, ang: FLIP.rest, angVel: 0, on: false, broken: false },
      { side: 'R', px: FLIP.R.px, py: FLIP.R.py, len, rp: FLIP.rp, rt: FLIP.rt, rest: Math.PI - FLIP.rest, up: Math.PI + FLIP.rest, ang: Math.PI - FLIP.rest, angVel: 0, on: false, broken: false },
    ];
  }
  function create(opts) {
    opts = opts || {};
    const s = {
      colliders: [], cells: null, stamp: 0, quiet: false, events: [],
      cfg: { frictionMin: 8.3, hitMin: 12.5 }, parts: Object.assign({ sling: false, lanes: false }, opts.parts),
      flippers: makeFlippers(opts.cover || 0), cover: opts.cover || 0, balls: [], slimes: [], time: 0, seq: 0, onHit: null,
    };
    build(s);
    Sim.buildGrid(s);
    return s;
  }
  // 换零件（买了弹力绳、小孔）：碰撞体整个重建
  function setParts(s, parts) {
    const want = Object.assign({}, s.parts, parts);
    if (want.sling === s.parts.sling && want.lanes === s.parts.lanes) return false;
    s.parts = want;
    s.colliders = [];
    build(s);
    Sim.buildGrid(s);
    return true;
  }
  // 换一副挡板（加长了）：新装上去的两片，按着的照样按着；断了的照样断着
  function setCover(s, cover) {
    const old = s.flippers;
    s.flippers = makeFlippers(cover);
    s.cover = cover;
    for (const f of s.flippers) { const o = old.find(q => q.side === f.side); if (o) { f.on = o.on; f.broken = o.broken; } }
  }
  const emit = (s, e) => { if (!s.quiet) s.events.push(e); };
  const inLane = s => s.balls.find(b => b.state === 'lane');

  // 装一颗球在推头上（推头上已经有一颗就不装，返回 null）
  function load(s, extra) {
    if (inLane(s)) return null;
    const b = Object.assign({ id: ++s.seq, x: LANE_CX, y: REST_Y, vx: 0, vy: 0, r: BALL_R, state: 'lane', age: 0, slow: 0 }, extra || {});
    b.y = HEAD_Y - b.r;
    s.balls.push(b);
    return b;
  }
  function launch(s, p) {
    const b = inLane(s);
    if (!b) return null;
    b.x = LANE_CX; b.y = HEAD_Y - b.r; b.vx = 0;
    b.vy = -Sim.launchSpeed(LAUNCH, Math.max(0, Math.min(1, p)));
    b.state = 'play'; b.slow = 0; b.age = 0;
    emit(s, { type: 'launch', p, b });
    return b;
  }
  const tipOf = f => [f.px + Math.cos(f.ang) * f.len, f.py + Math.sin(f.ang) * f.len];

  function bounce(s, b, h) {
    const col = h.col;
    b.x += h.nx * h.depth; b.y += h.ny * h.depth;
    const vn = b.vx * h.nx + b.vy * h.ny;
    if (vn >= 0) return;
    const impact = -vn, tx = -h.ny, ty = h.nx;
    let vt = b.vx * tx + b.vy * ty, out = impact * col.e;
    if (col.kind === 'sling' && impact > 25) out += 105;
    const dvt = impact > 8.3 ? Math.min(Math.abs(vt), col.f * (impact + out)) : 0;
    vt -= Math.sign(vt) * dvt;
    b.vx = h.nx * out + tx * vt; b.vy = h.ny * out + ty * vt;
    if (impact > 12.5) emit(s, { type: 'hit', kind: col.kind, id: col.id, x: h.px, y: h.py, impact, b });
  }
  function flipperHit(s, f, b) {
    const [tx, ty] = tipOf(f), vx = tx - f.px, vy = ty - f.py, L2 = vx * vx + vy * vy;
    let t = ((b.x - f.px) * vx + (b.y - f.py) * vy) / L2;
    t = t < 0 ? 0 : t > 1 ? 1 : t;
    const qx = f.px + vx * t, qy = f.py + vy * t, rq = f.rp + (f.rt - f.rp) * t;
    const dx = b.x - qx, dy = b.y - qy;
    let d = Math.hypot(dx, dy);
    const rr = rq + b.r;
    if (d >= rr) return;
    let nx, ny;
    if (d > 1e-6) { nx = dx / d; ny = dy / d; } else { nx = Math.sin(f.ang); ny = -Math.cos(f.ang); if (ny > 0) { nx = -nx; ny = -ny; } d = 0; }
    b.x += nx * (rr - d); b.y += ny * (rr - d);
    const cx = qx + nx * rq, cy = qy + ny * rq;
    const ux = -f.angVel * (cy - f.py), uy = f.angVel * (cx - f.px);
    const rvx = b.vx - ux, rvy = b.vy - uy, vn = rvx * nx + rvy * ny;
    if (vn < 0) {
      b.vx -= 1.45 * vn * nx; b.vy -= 1.45 * vn * ny;
      if (-vn > 20) emit(s, { type: 'flip', side: f.side, impact: -vn, x: cx, y: cy, moving: Math.abs(f.angVel) > 1, b });
    }
  }
  function slimeHit(s, m, b) {
    const dx = b.x - m.x, dy = b.y - m.y, rr = m.r + b.r, d2 = dx * dx + dy * dy;
    if (d2 >= rr * rr) return;
    const d = Math.sqrt(d2) || 1e-6, nx = dx / d, ny = dy / d;
    const vn = b.vx * nx + b.vy * ny;
    if (vn >= 0) { b.x = m.x + nx * rr; b.y = m.y + ny * rr; return; }
    const impact = -vn;
    const res = s.onHit ? s.onHit(m, b, impact, nx, ny) : 'hit';
    const e = { type: 'slime', m, b, impact, nx, ny, x: m.x + nx * m.r, y: m.y + ny * m.r, res };
    if (res === 'pass') { emit(s, e); return; }   // 打死了：穿过去
    b.x = m.x + nx * rr; b.y = m.y + ny * rr;
    // 史莱姆是软的：碰一下至少弹出 kick 那么快；很重的珠子推着它走，只弹回三成
    const out = res === 'plow' ? impact * 0.3 : Math.max(impact * (m.e || 0.55), m.kick || 75) * (res === 'ding' ? 1.15 : 1);
    b.vx += (impact + out) * nx; b.vy += (impact + out) * ny;
    emit(s, e);
  }
  // 球和球：一样重，正面那一份交换（打一点折扣）
  function ballBall(s, a, b) {
    const dx = b.x - a.x, dy = b.y - a.y, rr = a.r + b.r, d2 = dx * dx + dy * dy;
    if (d2 >= rr * rr || d2 < 1e-9) return;
    const d = Math.sqrt(d2), nx = dx / d, ny = dy / d, push = (rr - d) / 2;
    a.x -= nx * push; a.y -= ny * push; b.x += nx * push; b.y += ny * push;
    const rv = (b.vx - a.vx) * nx + (b.vy - a.vy) * ny;
    if (rv >= 0) return;
    const j = -rv * 0.95;
    a.vx -= j * nx; a.vy -= j * ny; b.vx += j * nx; b.vy += j * ny;
    if (-rv > 25) emit(s, { type: 'clack', impact: -rv, x: a.x + nx * a.r, y: a.y + ny * a.r });
  }

  function stepBall(s, b) {
    // 被粘住、冻住：原地不动，数完了接着走
    if (b.hold > 0) { b.hold -= DT; return; }
    b.age += DT;
    b.vy += GRAVITY * DT;
    const px = b.x, py = b.y;
    b.x += b.vx * DT; b.y += b.vy * DT;
    for (let k = 0; k < 4; k++) { const h = Sim.deepest(s, b); if (!h) break; bounce(s, b, h); }
    // 发射道口的单向门：往上打出去畅通，从上面落回来就被挡回台面
    if (b.vy > 0 && b.x > LANE_X - b.r && b.x < X1) {
      const sd = (b.x - GATE.x0) * GATE.nx + (b.y - GATE.y0) * GATE.ny;
      if (sd > -1 && sd < b.r) {
        b.x += (b.r - sd) * GATE.nx; b.y += (b.r - sd) * GATE.ny;
        const vn = b.vx * GATE.nx + b.vy * GATE.ny;
        if (vn < 0) { b.vx -= 1.4 * vn * GATE.nx; b.vy -= 1.4 * vn * GATE.ny; }
      }
    }
    for (const f of s.flippers) if (!f.broken) flipperHit(s, f, b);
    for (const m of s.slimes) { if (m.solid) slimeHit(s, m, b); if (b.state !== 'play') return; }
    const sp = Math.hypot(b.vx, b.vy);
    if (sp > VMAX) { b.vx *= VMAX / sp; b.vy *= VMAX / sp; }
    if (s.parts.lanes) for (const k of ['L', 'R']) {
      const Ln = LANES[k];
      if (py < Ln.sy && b.y >= Ln.sy && b.x > Ln.sx0 && b.x < Ln.sx1) emit(s, { type: 'lane', side: k, b, x: (Ln.sx0 + Ln.sx1) / 2, y: Ln.sy });
    }
    // 掉回发射道：停在推头上，再打一下就行（不算一颗新珠子）
    if (b.x > LANE_X && b.y >= HEAD_Y - b.r - 0.6 && Math.abs(b.vy) < 30 && b.age > 0.3) {
      const busy = s.balls.some(o => o !== b && o.state === 'lane');
      b.x = LANE_CX; b.y = HEAD_Y - b.r; b.vx = b.vy = 0;
      b.state = busy ? 'queue' : 'lane';
      emit(s, { type: 'back', b }); return;
    }
    // 从台底口子掉下去
    if (b.y > DRAIN_Y && b.x < LANE_X) { b.state = 'gone'; emit(s, { type: 'drain', b, age: b.age }); return; }
    // 卡住了（几乎不动）：台子自己抖一下。按着挡板托住珠子不算卡，托太久（5 秒）也抖
    const held = s.flippers.some(f => f.on);
    if (sp < 6) { b.slow += DT; if (b.slow > (held ? 5 : 1.5)) { b.slow = 0; b.vy = -110; b.vx = (b.x < CXF ? 1 : -1) * 40; emit(s, { type: 'nudge', b }); } } else b.slow = 0;
  }
  function step(s) {
    s.time += DT;
    for (const f of s.flippers) {
      const target = f.on && !f.broken ? f.up : f.rest, d = target - f.ang, mx = FLIP.w * DT;
      if (Math.abs(d) <= mx) { f.angVel = d / DT; f.ang = target; } else { f.angVel = Math.sign(d) * FLIP.w; f.ang += f.angVel * DT; }
    }
    const live = s.balls.filter(b => b.state === 'play');
    for (const b of live) if (b.state === 'play') stepBall(s, b);
    const now = s.balls.filter(b => b.state === 'play');
    for (let i = 0; i < now.length; i++) for (let j = i + 1; j < now.length; j++) ballBall(s, now[i], now[j]);
    s.balls = s.balls.filter(b => b.state !== 'gone');
  }

  return { DT, DX, X0, X1, Y0, YB, CH, LANE_X, LANE_TOP, LANE_CX, HEAD_Y, REST_Y, GRAVITY, VMAX, BALL_R, CXF, FLIP, flipLen, PIT, DRAIN_Y, GATE, GUIDE, SLING, LANES, ZONE,
    create, setCover, setParts, load, launch, step, tipOf, inLane };
}));
