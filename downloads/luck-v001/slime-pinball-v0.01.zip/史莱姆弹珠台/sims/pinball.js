/*
 * 打怪那一类的弹球台（草地史莱姆、蘑菇洞共用）。坐标跟基础机一样：台面 x 14..114、y 20..154，卡面一格 = 这里两格。
 *   右边 x 103..114 是发射道，推头在底下，按住拉、松手打（力度换算同基础机，sim.js 的 launchSpeed）。
 *   底下两片挡板，左边转轴 (34,131)、右边 (82,131)，长 20；平时垂着（斜 28°），按下去拍上来（转 56°）。
 *   两片挡板中间 x 50..66 是出球口：球从这里掉下去，这一球就完了。两边的导轨从墙斜着接到挡板，没有外侧漏球道。
 *   挡板上面两个弹弓（三角，斜边是橡皮筋，撞上去多弹一下）。
 *   史莱姆是软的圆：撞上去弹开（至少弹出 75 的速度，不会停在它头上），每撞一下发一个 slime 事件，扣血由台子自己算。
 *   蘑菇（蘑菇洞）是弹柱：撞上去按法线弹出去（至少 150）。
 * 固定步长 1/480 秒，跟基础机一样。
 */
(function (root, factory) {
  const Sim = typeof module === 'object' && module.exports ? require('../sim.js') : root.Sim;
  const api = factory(Sim);
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.Pinball = api;
}(typeof self !== 'undefined' ? self : globalThis, function (Sim) {
  'use strict';
  const DT = 1 / 480;
  const { X0, X1, Y0, YB, CH, LANE_X, LANE_TOP, LANE_CX, HEAD_Y, REST_Y } = Sim;
  const BALL_R = 3.5;
  const GRAVITY = 170;
  const VMAX = 255;                    // 球最快多快（不然挡板尖上一拍会飞出天去）
  const LAUNCH = Object.assign({}, Sim.DEFAULTS, { gravity: GRAVITY });
  const FLIP = { L: { px: 34, py: 131 }, R: { px: 82, py: 131 }, len: 20, rp: 3.6, rt: 2.1, rest: 28 * Math.PI / 180, w: 18 };
  const DRAIN = { x0: 50, x1: 66, y: 146 };
  const GATE = { x0: LANE_X, y0: LANE_TOP, x1: X1, y1: LANE_TOP - 10 };
  { const l = Math.hypot(GATE.x1 - GATE.x0, GATE.y1 - GATE.y0); GATE.nx = (GATE.y1 - GATE.y0) / l; GATE.ny = -(GATE.x1 - GATE.x0) / l; }
  // 两边导轨、弹弓（三角：A 顶、B 底、C 斜边下头；斜边 A→C 是橡皮筋）；右边那套按 x=58 对称（右弹弓背往里挪 1 格，跟发射道墙留的缝比珠子小）
  const GUIDE = { L: [[14, 110], [30, 127]], R: [[LANE_X, 110], [86, 127]] };
  const SLING = { L: { A: [20, 90], B: [20, 112], C: [29, 121], cap: [14, 84] }, R: { A: [96, 90], B: [96, 112], C: [87, 121], cap: [LANE_X, 83] } };

  function addWall(s, x0, y0, x1, y1, kind, e, f) { Sim.addWall(s, x0, y0, x1, y1, kind, e, f); }
  function build(s, opts) {
    const e = 0.4, f = 0.02;
    Sim.addSeg(s, X0, Y0 + CH, X0, 112, 'wall', e, f, 60, 90);
    Sim.addSeg(s, X1, Y0 + CH, X1, YB, 'wall', e, f, 60, 90);
    Sim.addSeg(s, X0, Y0 + CH, X0 + CH, Y0, 'roof', 0.2, 0.01, 60, 90);
    Sim.addSeg(s, X0 + CH, Y0, X1 - CH, Y0, 'roof', 0.2, 0.01, 60, 90);
    Sim.addSeg(s, X1 - CH, Y0, X1, Y0 + CH, 'roof', 0.2, 0.01, 60, 90);
    addWall(s, LANE_X, LANE_TOP, LANE_X, YB, 'lane', 0.3, 0.02);
    Sim.addSeg(s, LANE_X, HEAD_Y, X1, HEAD_Y, 'head', 0.1, 0.2, LANE_CX, 100);
    Sim.addSeg(s, LANE_X, LANE_TOP, LANE_X - 6, LANE_TOP + 4, 'guard', 0.3, 0.02, LANE_X - 8, LANE_TOP - 4);
    for (const k of ['L', 'R']) {
      const [a, b] = GUIDE[k];
      addWall(s, a[0], a[1], b[0], b[1], 'guide', 0.35, 0.02);
      const S = SLING[k];
      addWall(s, S.cap[0], S.cap[1], S.A[0], S.A[1], 'wall', 0.4, 0.02);
      addWall(s, S.A[0], S.A[1], S.B[0], S.B[1], 'post', 0.4, 0.02);
      addWall(s, S.B[0], S.B[1], S.C[0], S.C[1], 'post', 0.4, 0.02);
      addWall(s, S.A[0], S.A[1], S.C[0], S.C[1], 'sling', 0.55, 0.02);
      for (const p of [S.A, S.B, S.C]) Sim.addCircle(s, p[0], p[1], 2, 'post', 0.4, 0.02);
    }
    for (const [x, y, r] of opts.bumpers || []) Sim.addCircle(s, x, y, r, 'shroom', 0.6, 0);
    // 出球口两边的小墙（挡板转轴底下），球只能从中间掉
    addWall(s, 30, 127, 34, 134, 'guide', 0.3, 0.02);
    addWall(s, 86, 127, 82, 134, 'guide', 0.3, 0.02);
  }

  function create(opts) {
    opts = opts || {};
    const s = {
      colliders: [], cells: null, stamp: 0, quiet: false, events: [],
      cfg: { frictionMin: 8.3, hitMin: 12.5 },
      flippers: [], ball: null, slimes: [], time: 0, bumpers: opts.bumpers || [],
    };
    build(s, opts);
    Sim.buildGrid(s);
    const len = FLIP.len + (opts.flipLen || 0);
    s.flippers = [
      { side: 'L', px: FLIP.L.px, py: FLIP.L.py, len, rp: FLIP.rp, rt: FLIP.rt, rest: FLIP.rest, up: -FLIP.rest, ang: FLIP.rest, angVel: 0, on: false },
      { side: 'R', px: FLIP.R.px, py: FLIP.R.py, len, rp: FLIP.rp, rt: FLIP.rt, rest: Math.PI - FLIP.rest, up: Math.PI + FLIP.rest, ang: Math.PI - FLIP.rest, angVel: 0, on: false },
    ];
    return s;
  }
  function setFlipLen(s, extra) { for (const f of s.flippers) f.len = FLIP.len + extra; }
  const emit = (s, e) => { if (!s.quiet) s.events.push(e); };

  // 装一颗新球在推头上
  function load(s) { s.ball = { x: LANE_CX, y: REST_Y, vx: 0, vy: 0, r: BALL_R, state: 'lane', age: 0, slow: 0 }; return s.ball; }
  function launch(s, p) {
    const b = s.ball;
    if (!b || b.state !== 'lane') return false;
    b.x = LANE_CX; b.y = REST_Y; b.vx = 0;
    b.vy = -Sim.launchSpeed(LAUNCH, Math.max(0, Math.min(1, p)));
    b.state = 'play'; b.slow = 0;
    emit(s, { type: 'launch', p });
    return true;
  }
  const tipOf = f => [f.px + Math.cos(f.ang) * f.len, f.py + Math.sin(f.ang) * f.len];

  function bounce(s, b, h) {
    const col = h.col;
    b.x += h.nx * h.depth; b.y += h.ny * h.depth;
    const vn = b.vx * h.nx + b.vy * h.ny;
    if (vn >= 0) return;
    const impact = -vn, tx = -h.ny, ty = h.nx;
    let vt = b.vx * tx + b.vy * ty, out = impact * col.e;
    if (col.kind === 'sling' && impact > 25) out += 105;          // 橡皮筋多弹一下
    if (col.kind === 'shroom') out = Math.max(out + 60, 150);     // 蘑菇弹柱
    const dvt = impact > 8.3 ? Math.min(Math.abs(vt), col.f * (impact + out)) : 0;
    vt -= Math.sign(vt) * dvt;
    b.vx = h.nx * out + tx * vt; b.vy = h.ny * out + ty * vt;
    if (impact > 12.5) emit(s, { type: 'hit', kind: col.kind, id: col.id, x: h.px, y: h.py, impact });
  }
  function flipperHit(s, f, b) {
    const [tx, ty] = tipOf(f), vx = tx - f.px, vy = ty - f.py, L2 = vx * vx + vy * vy;
    let t = ((b.x - f.px) * vx + (b.y - f.py) * vy) / L2;
    t = t < 0 ? 0 : t > 1 ? 1 : t;
    const qx = f.px + vx * t, qy = f.py + vy * t, rq = f.rp + (f.rt - f.rp) * t;
    let dx = b.x - qx, dy = b.y - qy, d = Math.hypot(dx, dy);
    const rr = rq + b.r;
    if (d >= rr) return;
    let nx, ny;
    if (d > 1e-6) { nx = dx / d; ny = dy / d; } else { nx = Math.sin(f.ang); ny = -Math.cos(f.ang); if (ny > 0) { nx = -nx; ny = -ny; } d = 0; }
    b.x += nx * (rr - d); b.y += ny * (rr - d);
    const cx = qx + nx * rq, cy = qy + ny * rq;
    const ux = -f.angVel * (cy - f.py), uy = f.angVel * (cx - f.px);
    const rvx = b.vx - ux, rvy = b.vy - uy, vn = rvx * nx + rvy * ny;
    if (vn < 0) {
      b.vx -= 1.45 * vn * nx; b.vy -= 1.45 * vn * ny;
      // 顺着挡板的那一份留着，球会顺着板子滚
      if (-vn > 20) emit(s, { type: 'flip', side: f.side, impact: -vn, x: cx, y: cy, moving: Math.abs(f.angVel) > 1 });
    }
  }
  function slimeHit(s, m, b) {
    const dx = b.x - m.x, dy = b.y - m.y, rr = m.r + b.r, d2 = dx * dx + dy * dy;
    if (d2 >= rr * rr) return;
    const d = Math.sqrt(d2) || 1e-6, nx = dx / d, ny = dy / d;
    b.x = m.x + nx * rr; b.y = m.y + ny * rr;
    const vn = b.vx * nx + b.vy * ny;
    if (vn >= 0) return;
    const impact = -vn, out = Math.max(impact * 0.55, 75);
    b.vx += (impact + out) * nx; b.vy += (impact + out) * ny;
    emit(s, { type: 'slime', m, impact, nx, ny, x: m.x + nx * m.r, y: m.y + ny * m.r });
  }

  function step(s) {
    s.time += DT;
    for (const f of s.flippers) {
      const target = f.on ? f.up : f.rest, d = target - f.ang, mx = FLIP.w * DT;
      if (Math.abs(d) <= mx) { f.angVel = d / DT; f.ang = target; } else { f.angVel = Math.sign(d) * FLIP.w; f.ang += f.angVel * DT; }
    }
    const b = s.ball;
    if (!b || b.state !== 'play') return;
    b.age += DT;
    b.vy += GRAVITY * DT;
    b.x += b.vx * DT; b.y += b.vy * DT;
    for (let k = 0; k < 4; k++) { const h = Sim.deepest(s, b); if (!h) break; bounce(s, b, h); }
    // 发射道口的单向门：往上打出去畅通，从上面落回来就被挡回台面
    if (b.vy > 0 && b.x > LANE_X - b.r && b.x < X1) {
      const sd = (b.x - GATE.x0) * GATE.nx + (b.y - GATE.y0) * GATE.ny;
      if (sd > -1 && sd < b.r) {
        b.x += (b.r - sd) * GATE.nx; b.y += (b.r - sd) * GATE.ny;
        const vn = b.vx * GATE.nx + b.vy * GATE.ny;
        if (vn < 0) { b.vx -= 1.4 * vn * GATE.nx; b.vy -= 1.4 * vn * GATE.ny; }
      }
    }
    for (const f of s.flippers) flipperHit(s, f, b);
    for (const m of s.slimes) if (m.solid) slimeHit(s, m, b);
    const sp = Math.hypot(b.vx, b.vy);
    if (sp > VMAX) { b.vx *= VMAX / sp; b.vy *= VMAX / sp; }
    // 掉回发射道：停在推头上，再打一下就行（不算一颗新珠子）
    if (b.x > LANE_X && b.y >= REST_Y - 0.6 && Math.abs(b.vy) < 30 && b.age > 0.3) {
      b.state = 'lane'; b.x = LANE_CX; b.y = REST_Y; b.vx = b.vy = 0;
      emit(s, { type: 'lane' }); return;
    }
    // 从两片挡板中间掉下去
    if (b.y > DRAIN.y + 6 && b.x < LANE_X) { b.state = 'gone'; emit(s, { type: 'drain', age: b.age }); return; }
    // 卡住了（没按挡板、又几乎不动）：台子自己抖一下
    const held = s.flippers.some(f => f.on);
    if (sp < 6 && !held) { b.slow += DT; if (b.slow > 1.5) { b.slow = 0; b.vy = -110; b.vx = (b.x < 58 ? 1 : -1) * 40; emit(s, { type: 'nudge' }); } } else b.slow = 0;
  }
  // 推 dt 秒（按定步长）
  function advance(s, dt, acc) {
    acc.t += dt;
    let n = 0;
    while (acc.t >= DT && n < 400) { step(s); acc.t -= DT; n++; }
  }

  return { DT, GRAVITY, VMAX, BALL_R, FLIP, DRAIN, GUIDE, SLING, GATE, create, setFlipLen, load, launch, step, advance, tipOf };
}));
