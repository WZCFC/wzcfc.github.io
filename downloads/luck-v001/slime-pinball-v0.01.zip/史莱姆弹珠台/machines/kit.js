/*
 * 机台公用件：每台机拿起来以后怎么打，写在 machines/<id>.js 里，用 Machines.def(id, env => 台子) 注册。
 * 台子要给的：
 *   fine(f)            不动的那一层（钉子、导轨、挡板座……），拿起来时画一次；f 见 art.js renderMachineCard
 *   update(dt) / draw(ctx)
 *   down(p) / move(p) / up(p)   p = { x, y（原生）, sx, sy（台面格）, btn, id, inCard }，返回 true = 这一下台子用了
 *   key(code, down)    返回 true = 台子用了
 *   inPlay()           有珠子还在台上没算完（破产判断要等它）
 *   hint()             底下那行提示：现在该干什么
 *   info()             左边那几行：这台现在的数（每行 [字, 颜色]）
 *   onUpgrade(k)       刚买了一档升级
 * env（game.js 给）：g、R、A、sfx、spend()、refund()、award(base, { at, mult, label })、find(k)、jackpot()、kill(n)、toast(s)、val(k)、lv(skill)、luck(p)、save()
 */
window.Machines = (function () {
  'use strict';
  const defs = {};
  return {
    def(id, make) { defs[id] = make; },
    has: id => !!defs[id],
    make: (id, env) => (defs[id] ? defs[id](env) : null),
  };
})();

window.MK = (function () {
  'use strict';
  const A = Art, INK = A.INK, FX = A.FX, FY = A.FY;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const ease = t => 1 - Math.pow(1 - clamp(t, 0, 1), 3);
  // 台面格坐标 → 2 倍贴图
  function spr(ctx, im, sx, sy) { ctx.drawImage(im, Math.round(FX(sx)), Math.round(FY(sy)), im.width * 2, im.height * 2); }
  function sprC(ctx, im, sx, sy) { spr(ctx, im, Math.round(sx - im.width / 2), Math.round(sy - im.height / 2)); }
  function px(ctx, sx, sy, c) { ctx.fillStyle = c; ctx.fillRect(FX(Math.floor(sx)), FY(Math.floor(sy)), 2, 2); }
  function rect(ctx, sx, sy, w, h, c) { ctx.fillStyle = c; ctx.fillRect(FX(sx), FY(sy), w * 2, h * 2); }
  // 虚线（瞄准线）：每 gap 格一个点
  function dots(ctx, x0, y0, x1, y1, c, gap, phase) {
    const d = Math.hypot(x1 - x0, y1 - y0), n = Math.floor(d / (gap || 3));
    for (let i = 0; i <= n; i++) { const t = n ? (i + (phase || 0) % 1) / n : 0; if (t > 1) continue; px(ctx, x0 + (x1 - x0) * t, y0 + (y1 - y0) * t, c); }
  }
  function ring(ctx, cx, cy, r, c, step) { const n = Math.max(12, Math.round(r * 2 * Math.PI / (step || 2.5))); for (let i = 0; i < n; i++) { const a = i / n * Math.PI * 2; px(ctx, cx + Math.cos(a) * r, cy + Math.sin(a) * r, c); } }

  // ---------- 小图 ----------
  const S = {};
  const PEG4 = ['.kk.', 'khwk', 'kwsk', '.kk.'];
  const PEG_C = { k: INK, h: '#fff6c0', w: '#ffd23a', s: '#e0a010' }, PEG_HIT = { k: INK, h: '#ffffff', w: '#ffffff', s: '#fff6c0' };
  const LAMP_ON = ['#fff6c0', '#ffd84a', '#ffd84a', '#e0a010'], LAMP_OFF = ['#a8283a', '#8c1f2e', '#8c1f2e', '#6a1622'];
  const ALU = A.ALU;
  function sprites() {
    if (S.ready) return S;
    S.peg = A.sprite(PEG4, PEG_C); S.pegHit = A.sprite(PEG4, PEG_HIT);
    S.lampOff = A.sprite(['abbb', 'bbbb', 'bbbb', 'bbbc'], { a: LAMP_OFF[0], b: LAMP_OFF[1], c: LAMP_OFF[3] });
    S.lampOn = A.sprite(['abbb', 'bbbb', 'bbbb', 'bbbc'], { a: LAMP_ON[0], b: LAMP_ON[1], c: LAMP_ON[3] });
    S.head = A.sprite(['abbbbbbbbc', 'dddddddddd'], { a: '#ffffff', b: ALU[1], c: ALU[2], d: ALU[3] });
    S.spark = A.sprite(['.w.', 'wyw', '.w.'], { w: '#ffffff', y: '#ffd23a' });
    S.ledDigits = A.digitSprites('#fe4c40');
    S.popDigits = A.digitSprites(A.GOLD[0], INK);
    S.ready = true;
    return S;
  }
  const MB7 = ['..kkk..', '.khhwk.', 'khhwwwk', 'kwwwwsk', 'kwwwssk', '.kwssk.', '..kkk..'];
  const ballCache = new Map();
  // 7×7 的珠子（半径 3.5 格），C = [暗, 中, 亮]
  function ball7(C) { const k = C.join(); if (!ballCache.has(k)) ballCache.set(k, A.sprite(MB7, { k: INK, s: C[0], w: C[1], h: C[2] })); return ballCache.get(k); }

  // ---------- 侧视台：发射道、发力灯、钉子、洞 ----------
  const Sim = window.Sim;
  // dx：大台（冰窟这种 96 宽的）发射道整个往右挪 64 格
  function fineLane(f, guard, dx = 0) {
    const top = Sim.LANE_TOP, X = 103 + dx;
    for (let y = top; y <= 153; y++) { f.px(X, y, y === top ? '#ffffff' : ALU[1]); f.px(X + 1, y, ALU[3]); }
    const [gw, gh] = guard || [6, 6];
    for (let i = 0; i <= gw; i++) { const y = top + Math.round(i * gh / gw); f.px(X - i, y, ALU[1]); f.px(X - i, y + 1, ALU[3]); }
  }
  function finePegs(f, list) {
    for (const [x, y, r] of list) {
      if (r === Sim.PEG_R) { PEG4.forEach((row, j) => { for (let i = 0; i < 4; i++) { const c = PEG_C[row[i]]; if (c) f.px(x - 2 + i, y - 2 + j, c); } }); continue; }
      const L = f.layer(12, 12), ox = Math.floor(x) - 5, oy = Math.floor(y) - 5;
      for (let j = 0; j < 12; j++) for (let i = 0; i < 12; i++) {
        const X = ox + i, Y = oy + j;
        if (X < Sim.X0 || X > 102) continue;
        if (Math.hypot(X + 0.5 - x, Y + 0.5 - y) <= r + 0.2) f.lset(L, i, j, Y + 0.5 < y - 0.8 ? ALU[0] : Y + 0.5 < y + 0.8 ? ALU[1] : ALU[2]);
      }
      f.loutline(L, INK);
      for (let j = 0; j < 12; j++) for (let i = 0; i < 12; i++) { const c = f.lget(L, i, j), X = ox + i; if (c && X >= Sim.X0 && X <= 102) f.px(X, oy + j, c); }
    }
  }
  // n 个洞（小台 9 个，冰窟 15 个）：洞和洞之间一根 2 格的隔条
  function fineHoles(f, n = 9) { for (let k = 0; k < n - 1; k++) for (let y = 146; y <= 153; y++) for (const dx of [0, 1]) f.px(22 + k * 10 + dx, y, y === 146 ? '#e3eaea' : '#9aa8ac'); }
  // 弹簧、推头、推头上等着的珠子
  function lane(ctx, pull, loadedIm, dx = 0) {
    sprites();
    const top = Sim.HEAD_Y + 2 + pull, bot = 153, n = 4;
    for (let k = 0; k < n; k++) { const y = Math.round(top + (bot - top) * k / (n - 1)); ctx.fillStyle = k % 2 ? '#93a1a8' : '#c8d0d4'; ctx.fillRect(FX(105 + dx), FY(y), 14, 2); }
    ctx.fillStyle = '#5f6f76'; ctx.fillRect(FX(105 + dx), FY(top), 2, (bot - top + 1) * 2); ctx.fillRect(FX(111 + dx), FY(top), 2, (bot - top + 1) * 2);
    spr(ctx, S.head, 104 + dx, Sim.HEAD_Y + pull);
    if (loadedIm) spr(ctx, loadedIm, Sim.LANE_CX + dx - 3.5, Sim.REST_Y - 3.5 + pull);
  }
  // 按住拉弹簧：HOLD_FILL 秒拉满，拉满以后手抖（同基础机）
  function plunger(sfx) {
    return {
      on: false, t: 0, by: null, tick: -1, last: 0,
      start(by) { this.on = true; this.t = 0; this.by = by; this.tick = -1; },
      cancel() { this.on = false; this.t = 0; },
      power() { return this.on ? Sim.holdPower(this.t) : this.last; },
      pull() { return this.on ? Math.round(Sim.PULL * Sim.holdPower(this.t)) : 0; },
      update(dt) {
        if (!this.on) return;
        this.t += dt;
        const k = Math.floor(this.t / 0.1);
        if (k > this.tick && this.t < Sim.HOLD_FILL) { this.tick = k; sfx.ratchet(Sim.holdPower(this.t)); }
      },
      release() { const p = Sim.holdPower(this.t); this.last = p; this.on = false; return p; },
    };
  }
  // 力度刻度（技能树"力度刻度"）：outcomes[i] = 力度 i/100 落在哪；good(o) 返回颜色或 null
  function gaugeTicks(ctx, outcomes, good, dx = 0) {
    const M = A.METER;
    for (let i = 0; i <= 100; i++) {
      const c = good(outcomes[i]);
      if (!c) continue;
      const y = M.y + M.h - 2 - Math.round(i / 100 * 108);
      ctx.fillStyle = c; ctx.fillRect(FX(M.x - 2 + dx), FY(y), 3, 2);
    }
  }
  // 数码管（卡面 4 倍那一格）
  function led(ctx, n, blink, t) {
    sprites();
    if (blink && Math.sin(t * 8) > 0) return;
    const s = String(Math.max(0, Math.min(99, n))).padStart(2, '0');
    [...s].forEach((ch, k) => ctx.drawImage(S.ledDigits[ch], A.CX0 + (4 + k * 4) * A.S4, A.CY0 + 4 * A.S4, 3 * A.S4, 5 * A.S4));
  }
  // 台面上的一行小字（例如"第 3 层"）：描深边，画在原生那一层
  function label(ctx, s, sx, sy, color, align) { Txt.draw(ctx, s, FX(sx), FY(sy), { color: color || '#fff3d8', align: align || 'left' }); }

  // 侧视台上好几颗珠子一起走（鸡窝的蛋、马戏团的球）：s 是 Sim.createMachine 搭好的场地，珠子之间不互相撞（同火山弹）。
  //   珠子：{ x, y, vx, vy, r, t, alive, lane（从推头打出去的那颗：掉回推头算退回） }
  //   onCol(b, col, impact, h)：碰上场地里哪样东西（已经弹开了）。返回这一步的 land / fallback
  //   停在什么顶上不动：过一会儿往离中线远的那边拨一下
  function sideStep(s, balls, onCol) {
    const out = [], DT = Sim.DT;
    for (const b of balls) {
      if (!b.alive) continue;
      b.t += DT; b.vy += s.cfg.gravity * DT; b.x += b.vx * DT; b.y += b.vy * DT;
      for (let k = 0; k < 4; k++) {
        const h = Sim.deepest(s, b);
        if (!h) break;
        const impact = -(b.vx * h.nx + b.vy * h.ny);
        Sim.resolve(s, b, h);
        if (onCol && impact > 0) onCol(b, h.col, impact, h);
      }
      b.slow = Math.hypot(b.vx, b.vy) < 6 && b.y < Sim.STRIP - 8 ? (b.slow || 0) + DT : 0;
      if (b.slow > 0.4) { b.vx = (b.x < 64 ? -1 : 1) * 40; b.vy = -12; b.slow = 0; }
      if (b.lane && b.x > Sim.LANE_X && b.y >= Sim.REST_Y - 0.5 && b.vy >= 0 && b.t > 0.05) { b.alive = false; out.push({ type: 'fallback', b }); continue; }
      if (b.x < Sim.LANE_X && b.y >= Sim.STRIP - b.r) { b.alive = false; out.push({ type: 'land', b, hole: Sim.holeAt(b.x), x: b.x, y: b.y }); continue; }
      if (b.t > 12) { b.alive = false; out.push(b.lane && b.x > Sim.LANE_X ? { type: 'fallback', b, stuck: true } : { type: 'land', b, hole: Sim.holeAt(Math.min(b.x, Sim.LANE_X - 1)), x: b.x, y: b.y }); }
    }
    return out;
  }
  // 洞口那排灯：lit 里的亮黄，别的暗红（鸡窝、马戏团）
  function holeLamps(ctx, lit, blink) {
    sprites();
    for (let i = 0; i < 9; i++) spr(ctx, lit.includes(i) && !(blink && blink(i)) ? S.lampOn : S.lampOff, 16 + 10 * i, 149);
  }

  // ---------- 俯视台：往后拉着打 ----------
  // 拉的手势：按在球上（或附近）开始，拖开，松手。返回 { vx, vy, p } 或 null
  function dragShot(st, len, vmax) {
    if (!st) return null;
    return window.TopDown.shotFromDrag(st.cx - st.bx, st.cy - st.by, len, vmax);
  }
  return { clamp, ease, spr, sprC, px, rect, dots, ring, sprites, ball7, fineLane, finePegs, fineHoles, lane, plunger, gaugeTicks, led, label, dragShot, sideStep, holeLamps, LAMP_ON, LAMP_OFF, PEG4 };
})();
