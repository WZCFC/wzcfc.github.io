/*
 * 像素样图 13：一大堆机台预览卡（全局界面里的小图，每张 64×84 原生）
 *   前三排 24 张是侧视（珠子往下掉）：同一个卡壳（卡框、直顶斜角台面、导轨、底下一排洞灯、左上数码管、右上徽章）+ 一张题材皮。
 *     题材照"被关着的弹珠"来找：冻在冰块里、黏在蜂巢里、鸡窝孵着、扭蛋机装着……一眼看出这台机要救的珠子在哪。
 *   第四排 8 张是俯视（球在台面上滚）：台面换成圆角长方形的场地（球场、球桌、冰场），没有斜角和洞灯，场上的球门、袋口就是目标。
 *   预览图先不画钉子（钉子怎么摆还没定），也不画拉杆。
 *   ?zoom=K&cx=..&cy=..：放大看局部。
 */
(() => {
  'use strict';
  const q = new URLSearchParams(location.search);
  const W = 640, H = 480;
  const K = PixelKit(W, H);
  const { P, sprite, disc, layer, lset, lget, loutline, fl, rd } = K;
  const INK = '#1b2628', SLATE = '#2f3a3c', DEEP = '#0e1719';
  const PW = 64, PH = 84, CX = 32;   // 台面左右对称轴在 x=32.0（像素 31 和 32 之间）
  const SIDE = { x0: 7, x1: 56, y0: 10, y1: 76, ch: 10, hole: 73 };
  const TOP = { x0: 7, x1: 56, y0: 14, y1: 76, r: 3 };
  let MODE = 'side', OX = 0, OY = 0;
  const inSide = (x, y) => x >= SIDE.x0 && x <= SIDE.x1 && y >= SIDE.y0 && y <= SIDE.y1 && (x - SIDE.x0) + (y - SIDE.y0) >= SIDE.ch && (SIDE.x1 - x) + (y - SIDE.y0) >= SIDE.ch;
  const inTop = (x, y) => {
    if (x < TOP.x0 || x > TOP.x1 || y < TOP.y0 || y > TOP.y1) return false;
    const r = TOP.r, cx = x < TOP.x0 + r ? TOP.x0 + r : x > TOP.x1 - r ? TOP.x1 - r : x, cy = y < TOP.y0 + r ? TOP.y0 + r : y > TOP.y1 - r ? TOP.y1 - r : y;
    return Math.hypot(x - cx, y - cy) <= r + 0.3;
  };
  const inB = (x, y) => (MODE === 'side' ? inSide(x, y) : inTop(x, y));
  const inArt = (x, y) => inB(x, y) && (MODE !== 'side' || y < SIDE.hole);
  const hash = (x, y) => { let h = (x * 374761393 + y * 668265263) | 0; h = Math.imul(h ^ (h >>> 13), 1274126177); return ((h ^ (h >>> 16)) >>> 0) / 4294967296; };

  // ---------- 颜色 ----------
  const RED = ['#ff8a7a', '#fe4c40', '#b8322a'], YEL = ['#fff3a0', '#ffd23a', '#e0a010'], BLU = ['#7ac0ff', '#2f86ea', '#1a5fb0'];
  const GRN = ['#9af06a', '#36b24a', '#22803a'], ORG = ['#ffc070', '#ff9700', '#c86a10'], PUR = ['#c8a0ff', '#9a5ad8', '#6a3aa0'];
  const WHT = ['#ffffff', '#dfe7f2', '#9aa6ba'], BLK = ['#5f7378', '#2f3a3c', '#1b2628'], STEEL = ['#e3eaea', '#9aa8ac', '#5f6f76'];
  const WOOD = ['#e8a85a', '#c07a36', '#8a5226'], SNOW = ['#ffffff', '#e6f2fb', '#b4c8dc'], BONE = ['#fff6e0', '#f0e2c0', '#c8b48c'];
  const SAND = ['#ffe0a0', '#f0c060', '#c89038'];
  const CLOUD = { base: '#ffffff', shade: '#c6dbf7' }, SMOKE = { light: '#f1e9f8', base: '#cdbfe0', shade: '#9c8cb8' };
  const MW = ['#9aa6ba', '#dfe7f2', '#ffffff'];               // 玻璃珠：暗、中、亮
  const mramp = c => [c[2], c[1], c[0]];                       // [亮,中,暗] → 珠子用的 [暗,中,亮]

  // ---------- 画图小工具（都画进 64×84 的图层） ----------
  function rrect(x, y, w, h, r, fn) {
    for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) {
      const cx = i < r ? r : i > w - 1 - r ? w - 1 - r : i, cy = j < r ? r : j > h - 1 - r ? h - 1 - r : j;
      const d = Math.hypot(i - cx, j - cy);
      if (d > r + 0.3) continue;
      const inCorner = (i < r || i > w - 1 - r) && (j < r || j > h - 1 - r);
      const de = inCorner ? r - d : Math.min(i, j, w - 1 - i, h - 1 - j);
      const c = fn(i, j, de);
      if (c) P(x + i, y + j, c);
    }
  }
  const tone = (u, v, c) => (u + v < -0.7 ? c[0] : u + v > 0.5 ? c[2] : c[1]);
  function E(L, cx, cy, rx, ry, col, test) {
    for (let y = fl(cy - ry - 1); y <= Math.ceil(cy + ry); y++) for (let x = fl(cx - rx - 1); x <= Math.ceil(cx + rx); x++) {
      const u = (x + 0.5 - cx) / rx, v = (y + 0.5 - cy) / ry;
      if (u * u + v * v > 1 || (test && !test(x, y, u, v))) continue;
      const c = typeof col === 'string' ? col : Array.isArray(col) ? tone(u, v, col) : col(x, y, u, v);
      if (c) lset(L, x, y, c);
    }
  }
  function R(L, x0, y0, w, h, col) {
    for (let y = y0; y < y0 + h; y++) for (let x = x0; x < x0 + w; x++) {
      let c;
      if (Array.isArray(col)) c = y === y0 || x === x0 ? col[0] : y === y0 + h - 1 || x === x0 + w - 1 ? col[2] : col[1];
      else c = typeof col === 'string' ? col : col(x, y);
      if (c) lset(L, x, y, c);
    }
  }
  function PG(L, pts, col) {
    let y0 = Infinity, y1 = -Infinity;
    for (const [, y] of pts) { y0 = Math.min(y0, y); y1 = Math.max(y1, y); }
    for (let y = fl(y0); y <= Math.ceil(y1); y++) {
      const yc = y + 0.5, xs = [];
      for (let i = 0; i < pts.length; i++) {
        const [ax, ay] = pts[i], [bx, by] = pts[(i + 1) % pts.length];
        if ((ay <= yc && by > yc) || (by <= yc && ay > yc)) xs.push(ax + (yc - ay) * (bx - ax) / (by - ay));
      }
      xs.sort((a, b) => a - b);
      for (let k = 0; k + 1 < xs.length; k += 2) for (let x = Math.ceil(xs[k] - 0.5); x <= fl(xs[k + 1] - 0.5); x++) {
        const c = typeof col === 'string' ? col : col(x, y);
        if (c) lset(L, x, y, c);
      }
    }
  }
  function LN(L, x0, y0, x1, y1, c) { const n = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0)) || 1; for (let s = 0; s <= n; s++) lset(L, rd(x0 + (x1 - x0) * s / n), rd(y0 + (y1 - y0) * s / n), c); }
  function SP(L, rows, map, x, y) { rows.forEach((r, j) => { for (let i = 0; i < r.length; i++) { const c = map[r[i]]; if (c) lset(L, x + i, y + j, c); } }); }
  const MARBLE = ['.kkk.', 'khwwk', 'kwwwk', 'kwwsk', '.kkk.'];
  const MARBLE7 = ['..kkk..', '.khhwk.', 'khhwwwk', 'kwwwwsk', 'kwwwssk', '.kwssk.', '..kkk..'];
  function MB(L, x, y, m = MW) { SP(L, MARBLE, { k: INK, s: m[0], w: m[1], h: m[2] }, x - 2, y - 2); }
  function MB7(L, x, y, m = MW) { SP(L, MARBLE7, { k: INK, s: m[0], w: m[1], h: m[2] }, x - 3, y - 3); }
  function puffInto(L, lobes, col, flatBottom) {   // 几个椭圆并成一整团：底下压一道影，不画成一个个球
    const m = new Set();
    for (const [cx, cy, rx, ry] of lobes) for (let y = fl(cy - ry - 1); y <= Math.ceil(cy + ry); y++) for (let x = fl(cx - rx - 1); x <= Math.ceil(cx + rx); x++) {
      if (Math.hypot((x + 0.5 - cx) / rx, (y + 0.5 - cy) / ry) > 1 || (flatBottom != null && y > flatBottom)) continue;
      m.add(y * 4096 + x);
    }
    const has = (x, y) => m.has(y * 4096 + x);
    for (const key of m) {
      const x = key % 4096, y = fl(key / 4096);
      let c = col.base;
      if (!has(x, y + 1) || !has(x + 1, y + 1)) c = col.shade;
      else if (col.light && (!has(x, y - 1) || !has(x - 1, y - 1))) c = col.light;
      lset(L, x, y, c);
    }
  }
  function gem(L, x, y, c) { SP(L, ['.kkk.', 'khcck', '.kck.', '..k..'], { k: INK, h: c[0], c: c[1] }, x - 2, y - 2); }
  function bubble(L, x, y) { SP(L, ['.b.', 'b.b', '.b.'], { b: '#bfe8f4' }, x - 1, y - 1); }
  function bee(L, cx, cy) {
    E(L, cx - 0.5, cy - 3, 1.8, 1.5, '#ffffff'); E(L, cx + 2, cy - 3, 1.8, 1.5, '#dfe7f2');
    E(L, cx + 0.5, cy, 3.4, 2.3, x => (x === cx || x === cx + 2 ? SLATE : '#ffd23a'));
    lset(L, cx - 2, cy - 1, INK);
  }
  function gear(L, cx, cy, r, teeth, ramp) {
    const R2 = r + 2.4;
    for (let y = fl(cy - R2 - 1); y <= cy + R2 + 1; y++) for (let x = fl(cx - R2 - 1); x <= cx + R2 + 1; x++) {
      const dx = x + 0.5 - cx, dy = y + 0.5 - cy, d = Math.hypot(dx, dy), a = Math.atan2(dy, dx) / (2 * Math.PI);
      const t = (((a * teeth) % 1) + 1) % 1;
      if (d > R2 || (d > r && (t < 0.3 || t > 0.7))) continue;
      let c = tone(dx / R2, dy / R2, ramp);
      if (d < r * 0.42) c = d < r * 0.22 ? INK : ramp[0];
      else if (r >= 8 && d > r * 0.52 && d < r * 0.78 && ((((a * 4) % 1) + 1) % 1) < 0.28) c = SLATE;
      lset(L, x, y, c);
    }
  }
  function ring(L, cx, cy, front) {   // 土星环：后半圈先画，前半圈压在星球上
    for (let y = cy - 6; y <= cy + 6; y++) for (let x = cx - 19; x <= cx + 19; x++) {
      const u = x + 0.5 - cx, v = y + 0.5 - cy;
      if ((u / 17.5) ** 2 + (v / 4.6) ** 2 > 1 || (u / 13.5) ** 2 + (v / 2.8) ** 2 < 1) continue;
      if (front ? v <= 0 : v > 0) continue;
      lset(L, x, y, v > 0 ? '#e0b040' : '#fee787');
    }
  }
  const popcorn = (x, y) => { const h = hash(x >> 1, y >> 1); return h < 0.15 ? '#ffd23a' : h < 0.45 ? '#f0d890' : '#fff6d0'; };

  // 画进当前这张卡：bg 直接铺台面底，obj 画一个物件（图层 → 描深边 → 只贴在台面里）
  function bg(fn) { for (let y = 0; y < PH; y++) for (let x = 0; x < PW; x++) if (inArt(x, y)) { const c = fn(x, y); if (c) P(OX + x, OY + y, c); } }
  function outl(L) {   // 描深边，但不在已经是深边的像素外面再描一圈（珠子、宝石自带一圈深边）
    const add = [];
    for (let y = 0; y < L.h; y++) for (let x = 0; x < L.w; x++) {
      if (lget(L, x, y)) continue;
      if ([lget(L, x - 1, y), lget(L, x + 1, y), lget(L, x, y - 1), lget(L, x, y + 1)].some(c => c && c !== INK)) add.push([x, y]);
    }
    for (const [x, y] of add) lset(L, x, y, INK);
  }
  function obj(draw, outline = true) {
    const L = layer(PW, PH);
    draw(L);
    if (outline) outl(L);
    for (let y = 0; y < PH; y++) for (let x = 0; x < PW; x++) { const c = lget(L, x, y); if (c && inArt(x, y)) P(OX + x, OY + y, c); }
  }

  const DOGM = ['.kk......kk.', 'kook....kook', 'kookkkkkkook', 'koowwwwwwook', 'koowkwwkwook', 'kowwwwwwwwok', '.kwwwkkwwwk.', '.kwwwttwwwk.', '..kbbbbbbk..', '...kkkkkk...'];
  const D35 = {
    0: ['xxx', 'x.x', 'x.x', 'x.x', 'xxx'], 1: ['.x.', 'xx.', '.x.', '.x.', 'xxx'], 2: ['xxx', '..x', 'xxx', 'x..', 'xxx'],
    3: ['xxx', '..x', '.xx', '..x', 'xxx'], 4: ['x.x', 'x.x', 'xxx', '..x', '..x'], 5: ['xxx', 'x..', 'xxx', '..x', 'xxx'],
    6: ['xxx', 'x..', 'xxx', 'x.x', 'xxx'], 7: ['xxx', '..x', '.x.', '.x.', '.x.'], 8: ['xxx', 'x.x', 'xxx', 'x.x', 'xxx'], 9: ['xxx', 'x.x', 'xxx', '..x', 'xxx'],
  };

  // ====================== 侧视 24 张 ======================
  function pDog() {
    bg((x, y) => (x % 6 === 3 && y % 6 === 1 ? '#3169e4' : '#2a62dc'));
    obj(L => { puffInto(L, [[13, 31, 4, 2.6], [17, 29, 4.2, 3.2], [21, 31, 3.6, 2.6]], CLOUD, 32); puffInto(L, [[44, 27, 3.4, 2.2], [48, 25.5, 3.6, 2.8], [51.5, 27, 3, 2.2]], CLOUD, 28); });
    obj(L => {
      const sag = x => 14 + rd(2 * Math.sin(Math.PI * (x + 0.5 - 17) / 30));
      for (let x = 17; x <= 46; x++) lset(L, x, sag(x), INK);
      [[21, '#fe4c40'], [28, '#ffd23a'], [35, '#ffffff'], [42, '#36b24a']].forEach(([x, c]) => { const y = sag(x) + 1; lset(L, x - 1, y, c); lset(L, x, y, c); lset(L, x + 1, y, c); lset(L, x, y + 1, c); });
    }, false);
    obj(L => { for (let x = 7; x <= 56; x++) { if (x > 15 && x < 48) continue; for (let y = 68; y <= 72; y++) lset(L, x, y, y === 68 ? '#8ae063' : '#36b24a'); } });
    obj(L => {
      for (let x = 11; x <= 52; x++) { const yo = 38 + Math.abs(x + 0.5 - CX) * 0.8; for (let y = fl(yo); y <= yo + 3.6; y++) lset(L, x, y, y < yo + 1 ? '#ff8a7a' : '#fe4c40'); }
      for (let x = 16; x <= 47; x++) for (let y = Math.ceil(41.6 + Math.abs(x + 0.5 - CX) * 0.8); y <= 72; y++) lset(L, x, y, x === 16 || x === 47 ? '#d47028' : (y - 40) % 4 === 0 ? '#b5561c' : (y - 40) % 4 === 1 ? '#ffad5e' : '#ef8a34');
      for (let y = 54; y <= 72; y++) for (let x = 23; x <= 40; x++) {
        const d = (y + 0.5 >= 63 ? Math.abs(x + 0.5 - CX) : Math.hypot(x + 0.5 - CX, y + 0.5 - 63)) - 6.5;
        if (d <= 0) lset(L, x, y, SLATE); else if (d <= 1.3) lset(L, x, y, '#fff4d6');
      }
      SP(L, DOGM, { k: '#311508', o: '#cf8343', w: '#f9eed7', t: '#f8898f', b: '#4977b9' }, 26, 63);
      E(L, CX, 50.5, 4.6, 2.7, '#5aa8ff');
      for (let x = 29; x <= 34; x++) lset(L, x, 50, '#ffffff');
      for (const x of [29, 34]) { lset(L, x, 49, '#ffffff'); lset(L, x, 51, '#ffffff'); }
    });
  }
  function pVolc() {
    bg((x, y) => (y < 40 && x % 6 === 3 && y % 6 === 1 ? '#5c2c88' : '#4a1d70'));
    for (const [x, y, c] of [[13, 24, '#fee787'], [50, 30, '#ffffff'], [21, 17, '#c9a0e8'], [44, 15, '#fee787'], [53, 42, '#c9a0e8'], [10, 38, '#ffffff']]) P(OX + x, OY + y, c);
    obj(L => { puffInto(L, [[32, 33, 6, 4], [36, 31, 4, 3.4], [28, 32, 3.4, 3]], SMOKE); puffInto(L, [[37, 22, 4.4, 2.8], [40, 21, 2.6, 2]], SMOKE); });
    obj(L => {
      for (let y = 39; y <= 72; y++) { const h = 5 + 23 * Math.sqrt((y - 39) / 33); for (let x = fl(CX - h); x <= Math.ceil(CX + h); x++) { const u = (x + 0.5 - CX) / h; if (Math.abs(u) <= 1) lset(L, x, y, u < -0.55 ? '#c96a48' : u > 0.5 ? '#7a3230' : '#a24a36'); } }
      for (let x = 28; x <= 35; x++) lset(L, x, 39, '#ff9700');
      for (const [x, c] of [[30, '#fee787'], [31, '#fee787'], [32, '#ff9700'], [33, '#ff9700']]) lset(L, x, 38, c);
      for (const [x, y] of [[28, 40], [27, 41], [26, 42], [26, 43], [25, 44], [35, 40], [36, 41], [37, 42], [37, 43]]) lset(L, x, y, '#ff9700');
      for (const [x, y] of [[28, 49], [28, 50], [35, 49], [35, 50], [30, 53], [31, 54], [32, 54], [33, 53]]) lset(L, x, y, INK);
      lset(L, 26, 52, '#ff7a6a'); lset(L, 37, 52, '#ff7a6a');
      for (const [cx, cy, full] of [[17, 58, 0], [44, 51, 1], [32, 64, 0]]) {
        E(L, cx, cy, 5.2, 2.6, INK);
        E(L, cx, cy, 4.2, 1.7, (x, y, u, v) => (v < 0.1 ? '#2a0f22' : '#ff9700'));
        if (full) for (const [dx, dy, c] of [[-2, -1, '#ffffff'], [0, -1, '#ffffff'], [1, -1, '#dfe7f2'], [-1, -2, '#ffffff'], [2, -1, '#dfe7f2']]) lset(L, cx + dx, cy + dy, c);
      }
    });
    obj(L => { for (let x = 7; x <= 56; x++) { lset(L, x, 70, INK); lset(L, x, 71, x % 5 < 2 ? '#fee787' : '#ff9700'); lset(L, x, 72, '#e8501a'); } }, false);
  }
  function pMine() {
    bg((x, y) => (hash(x >> 2, y >> 2) < 0.22 ? '#4a4160' : hash((x + 2) >> 2, (y + 1) >> 2) < 0.1 ? '#332c44' : '#3d3550'));
    obj(L => { gem(L, 15, 33, RED); gem(L, 49, 45, BLU); gem(L, 16, 55, GRN); MB(L, 47, 29); MB(L, 14, 44); });
    obj(L => {
      R(L, 8, 16, 3, 57, WOOD); R(L, 53, 16, 3, 57, WOOD); R(L, 8, 15, 48, 3, WOOD);
      lset(L, 32, 18, '#9aa8ac'); lset(L, 32, 19, '#9aa8ac');
      R(L, 30, 20, 5, 1, INK); R(L, 30, 21, 5, 4, YEL); R(L, 30, 25, 5, 1, INK); lset(L, 32, 22, '#ffffff');
    });
    obj(L => { for (let x = 7; x <= 56; x++) { lset(L, x, 69, '#c9d2d6'); lset(L, x, 70, '#66767e'); if (x % 6 < 2) { lset(L, x, 71, '#8a5226'); lset(L, x, 72, '#6a3e1e'); } } });
    obj(L => {
      MB(L, 25, 47); MB(L, 38, 47); MB(L, 31, 45);
      gem(L, 20, 48, YEL); gem(L, 44, 48, GRN); gem(L, 34, 49, RED);
      PG(L, [[16, 50], [48, 50], [45, 65], [19, 65]], (x, y) => (y <= 51 ? '#dfe7ea' : y === 57 ? '#66767e' : x < 22 ? '#b4bec4' : x > 41 ? '#5f6f76' : '#8a979e'));
      for (const x of [21, 42]) { lset(L, x, 54, INK); lset(L, x, 61, INK); }
      E(L, 24, 66.5, 3, 3, INK); E(L, 40, 66.5, 3, 3, INK); lset(L, 23, 66, '#9aa8ac'); lset(L, 39, 66, '#9aa8ac');
    });
  }
  function pRes() {
    bg((x, y) => {
      if (y < 36) return '#7cc8ff';
      if (y === 36) return x % 6 < 3 ? '#e6f6ff' : '#5aa8f0';
      if (y >= 67) return hash(x, y) < 0.15 ? '#c8a050' : '#e8c070';
      if ((y === 46 || y === 57) && (x + y) % 7 < 3) return '#3a86e4';
      return '#1f6fd0';
    });
    obj(L => puffInto(L, [[16, 22, 3.6, 2.4], [20, 20, 4, 3], [24, 22, 3.2, 2.2]], CLOUD, 23));
    obj(L => { MB(L, 15, 65); MB(L, 22, 66); MB(L, 36, 65); MB(L, 47, 66); });
    obj(L => { bubble(L, 23, 57); bubble(L, 25, 51); bubble(L, 22, 45); }, false);
    obj(L => E(L, 16, 37, 7, 2.1, GRN, (x, y) => !(x >= 16 && x <= 17 && y <= 37)));
    obj(L => {
      E(L, 45, 37.5, 8.5, 2.3, GRN);
      E(L, 45, 32.5, 6.2, 4.2, ['#9af06a', '#4cc83a', '#2a8a2a']);
      E(L, 42, 28.6, 2.5, 2.4, '#4cc83a'); E(L, 48, 28.6, 2.5, 2.4, '#4cc83a');
      for (const ex of [41, 47]) { lset(L, ex, 28, '#ffffff'); lset(L, ex + 1, 28, '#ffffff'); lset(L, ex, 29, '#ffffff'); lset(L, ex + 1, 29, INK); }
      for (const [x, y] of [[43, 33], [44, 34], [45, 34], [46, 34], [47, 33]]) lset(L, x, y, INK);
      lset(L, 40, 32, '#ff9aa8'); lset(L, 50, 32, '#ff9aa8');
    });
  }
  function pFactory() {
    bg((x, y) => (y % 12 === 4 ? '#a85222' : y % 12 === 6 && x % 6 === 3 ? '#e8844a' : '#c8642a'));
    obj(L => gear(L, 20, 29, 9, 8, STEEL));
    obj(L => gear(L, 31, 42, 5, 6, YEL));
    obj(L => { R(L, 44, 10, 4, 30, STEEL); R(L, 39, 40, 14, 4, YEL); for (let x = 40; x <= 51; x += 3) lset(L, x, 41, SLATE); });
    obj(L => {
      R(L, 10, 56, 44, 5, (x, y) => (y === 56 ? '#4f6367' : y === 60 ? INK : (x + (y % 2) * 2) % 4 === 0 ? '#3b5055' : SLATE));
      E(L, 11, 58.5, 3, 3, STEEL); E(L, 53, 58.5, 3, 3, STEEL);
      MB(L, 19, 53); MB(L, 28, 53); MB(L, 45, 53);
    });
    obj(L => { for (let y = 66; y <= 72; y++) for (let x = 7; x <= 56; x++) lset(L, x, y, (x + y) % 8 < 4 ? '#ffc83a' : SLATE); });
  }
  function pIce() {
    bg((x, y) => {
      const a1 = 21 + 2.5 * Math.sin(x / 5), a2 = 27 + 2 * Math.sin(x / 6 + 2);
      if (Math.abs(y + 0.5 - a1) < 1.5) return '#2fd0a0';
      if (Math.abs(y + 0.5 - a2) < 1) return '#7a7aff';
      if (y < 46 && hash(x, y) < 0.025) return '#ffffff';
      return '#1d3f8c';
    });
    obj(L => { for (const [x, len] of [[19, 6], [24, 4], [29, 8], [35, 5], [40, 7], [45, 4]]) PG(L, [[x - 2, 9], [x + 3, 9], [x + 0.5, 10 + len]], xx => (xx < x + 0.5 ? '#e6fbff' : '#9fd8f0')); });
    obj(L => E(L, CX, 75, 30, 9, SNOW));
    obj(L => {
      for (const [x0, y0] of [[9, 52], [23, 52], [16, 38]]) {
        R(L, x0, y0, 13, 13, (x, y) => (y === y0 || x === x0 ? '#e6fbff' : y === y0 + 12 || x === x0 + 12 ? '#5ab8e0' : '#9fe6ff'));
        MB(L, x0 + 6, y0 + 6, ['#7fbfdc', '#d2f2ff', '#ffffff']);
        lset(L, x0 + 9, y0 + 2, '#ffffff'); lset(L, x0 + 10, y0 + 3, '#ffffff'); lset(L, x0 + 10, y0 + 4, '#ffffff');
      }
    });
    obj(L => {
      E(L, 39.5, 59, 1.7, 4, BLK); E(L, 52.5, 59, 1.7, 4, BLK);
      E(L, 46, 57, 6.5, 9.5, BLK);
      E(L, 46, 60, 4.3, 6.3, ['#ffffff', '#f0f4f8', '#c8d4e0']);
      for (const ex of [43, 48]) { lset(L, ex, 51, '#ffffff'); lset(L, ex, 52, INK); }
      lset(L, 45, 53, '#ff9700'); lset(L, 46, 53, '#ff9700'); lset(L, 45, 54, '#e07800'); lset(L, 46, 54, '#e07800');
      for (let x = 39; x <= 53; x++) for (let y = 55; y <= 56; y++) if (lget(L, x, y)) lset(L, x, y, y === 55 ? '#ff8a7a' : '#fe4c40');
      R(L, 48, 57, 2, 5, '#fe4c40');
      for (const x of [42, 43, 48, 49]) lset(L, x, 67, '#ff9700');
    });
  }
  function pHoney() {
    bg((x, y) => ((x % 8 === 4 && y % 8 === 2) || (x % 8 === 0 && y % 8 === 6) ? '#8a5ac8' : '#6a3aa8'));
    obj(L => { R(L, 7, 14, 50, 3, WOOD); E(L, 18, 18, 2.8, 1.5, GRN); E(L, 45, 12.6, 2.6, 1.4, GRN); });   // 蜂巢挂在一根树枝上
    obj(L => { for (let x = 8; x <= 55; x += 3) { for (let y = 66; y <= 72; y++) lset(L, x, y, '#3a8a4a'); for (let y = 61; y <= 65; y++) lset(L, x + (y % 2), y, y % 2 ? '#c8a8ff' : '#a07ae0'); } }, false);
    obj(L => {
      for (let y = 17; y <= 61; y++) for (let x = 12; x <= 52; x++) {
        const u = (x + 0.5 - CX) / 19.5, v = (y + 0.5 - 39) / 21.5;
        if (u * u + v * v > 1) continue;
        const row = fl((y - 17) / 5), off = (row % 2) * 3, cxl = (((x - 12 + off) % 6) + 6) % 6, cyl = (y - 17) % 5;
        let c = '#ffc83a';
        if (cyl === 0 || cxl === 0) c = '#c87a10';
        else if (cyl === 1 && cxl === 1) c = '#ffe08a';
        else if (cyl === 4 || cxl === 5) c = '#f0a81a';
        if (c !== '#c87a10' && hash(fl((x - 12 + off) / 6), row) < 0.18) c = '#ffe6a0';
        lset(L, x, y, c);
      }
      for (const [col, row] of [[2, 2], [4, 4], [1, 6], [3, 7], [5, 5]]) MB(L, 12 + col * 6 - (row % 2) * 3 + 3, 17 + row * 5 + 2);
      R(L, 25, 59, 2, 6, '#ffb21a'); lset(L, 25, 65, '#ffb21a'); R(L, 38, 60, 2, 4, '#ffb21a');
    });
    obj(L => { bee(L, 11, 24); bee(L, 51, 58); });
  }
  function pHen() {
    bg((x, y) => (y === 22 || y === 23 ? '#a83424' : x % 6 === 0 ? '#a83424' : '#c8402e'));
    obj(L => { for (let x = 7; x <= 56; x++) { const t = 63 + (x % 3 === 0 ? 0 : 1); for (let y = t; y <= 72; y++) lset(L, x, y, (x + y) % 4 === 0 ? '#c89820' : y === t ? '#ffe070' : '#f0c040'); } });
    obj(L => {
      const STRAW = ['#ffe070', '#f0c040', '#c89820'], HEN = ['#ffffff', '#f0ece4', '#c8c0b4'];
      E(L, CX, 58, 18, 5.5, STRAW);
      PG(L, [[42, 45], [49, 34], [52, 39], [47, 49]], x => (x > 49 ? HEN[2] : HEN[1]));
      E(L, 35, 47, 12, 9, HEN);
      E(L, 23, 37, 5.2, 5, HEN);
      E(L, 20.5, 31.8, 1.6, 1.6, '#fe4c40'); E(L, 23, 31.2, 1.7, 1.7, '#fe4c40'); E(L, 25.5, 32, 1.4, 1.4, '#fe4c40');
      PG(L, [[18.5, 36], [15, 37.5], [18.5, 39]], '#ff9700');
      E(L, 18.6, 41, 1.2, 1.7, '#fe4c40');
      lset(L, 21, 36, INK);
      for (let x = 31; x <= 42; x++) lset(L, x, 47 + rd(2 * Math.sin(((x - 31) / 11) * Math.PI)), HEN[2]);
      MB(L, 21, 58); MB(L, 28, 59); MB(L, 36, 59); MB(L, 43, 58);
      E(L, CX, 62, 19, 4.2, STRAW, (x, y) => y >= 60);
      for (let x = 15; x <= 49; x += 4) lset(L, x, 62, '#c89820');
    });
  }
  function pBalloon() {
    bg((x, y) => (x % 8 === 4 && y % 8 === 4 ? '#a896f6' : '#9a84f0'));
    obj(L => { puffInto(L, [[12, 69, 6, 4], [20, 67, 6, 5], [29, 70, 5, 3.5]], CLOUD); puffInto(L, [[38, 70, 5, 3.5], [46, 67, 6, 5], [54, 69, 6, 4]], CLOUD); });
    obj(L => { for (const [x, y0, y1] of [[19, 37, 49], [32, 32, 45], [45, 37, 49]]) for (let y = y0; y <= y1; y++) lset(L, x + rd(Math.sin(y / 2.2) * 0.7), y, '#3b5055'); }, false);
    obj(L => { MB(L, 19, 52); MB(L, 32, 48); MB(L, 45, 52); });
    for (const [cx, cy, c] of [[32, 22, YEL], [19, 27, RED], [45, 27, BLU]]) obj(L => {
      E(L, cx, cy, 7, 8.4, c);
      lset(L, cx - 4, cy - 4, '#ffffff'); lset(L, cx - 4, cy - 3, '#ffffff'); lset(L, cx - 3, cy - 5, '#ffffff');
      for (const [dx, dy] of [[-1, 8], [0, 8], [-1, 9], [0, 9]]) lset(L, cx + dx, cy + dy, c[2]);
    });
  }
  function pGum() {
    bg((x, y) => ((x + y) % 8 < 4 ? '#ff8ab8' : '#ff9cc4'));
    obj(L => {
      E(L, CX, 29, 14, 14, '#dff3ff');
      const cols = [RED, YEL, BLU, GRN, WHT, ORG];
      let k = 0;
      for (let row = 0; row < 6; row++) for (let i = -3; i <= 3; i++) {
        const gx = CX + i * 5 + (row % 2) * 2.5, gy = 40.5 - row * 4.4;
        if (gy < 19 || Math.hypot(gx - CX, gy - 29) > 11.4) continue;
        E(L, gx, gy, 2.5, 2.5, cols[(k++ * 5 + row * 2) % 6]);
      }
      for (let a = 3.6; a <= 4.4; a += 0.04) lset(L, fl(CX + Math.cos(a) * 11.6), fl(29 + Math.sin(a) * 11.6), '#ffffff');
      E(L, CX, 15.5, 5.5, 2.4, RED); E(L, CX, 13, 1.6, 1.4, RED);
    });
    obj(L => {
      PG(L, [[20, 43], [44, 43], [47, 70], [17, 70]], (x, y) => (y === 43 ? '#ff8a7a' : x < 22 ? '#ff6a5a' : x > 41 ? '#b8322a' : '#fe4c40'));
      E(L, CX, 52, 4.2, 4.2, WHT);
      for (let x = 30; x <= 33; x++) lset(L, x, 52, SLATE);
      R(L, 27, 60, 10, 6, SLATE);
      MB(L, 32, 63, mramp(YEL));
      R(L, 17, 70, 30, 2, '#8a2420');
    });
  }
  function pClam() {
    bg((x, y) => { if (y >= 66) return hash(x, y) < 0.15 ? '#c8a050' : '#e8c070'; if (y % 9 === 4 && (x + fl(y / 9) * 3) % 7 < 4) return '#167a92'; return '#0f6a80'; });
    obj(L => { for (const [bx, top] of [[11, 33], [51, 40]]) for (let y = top; y <= 67; y++) { const x = bx + rd(Math.sin(y / 3) * 1.4); lset(L, x, y, '#36b24a'); lset(L, x + 1, y, '#22803a'); } });
    obj(L => { E(L, 16, 26, 4.2, 2.6, YEL); PG(L, [[19.5, 26], [23.5, 23], [23.5, 29]], '#e0a010'); lset(L, 14, 25, INK); });
    obj(L => { bubble(L, 44, 37); bubble(L, 46, 30); bubble(L, 43, 23); }, false);
    obj(L => {
      const SH = ['#ffb8c8', '#ff8aa8', '#d05a7a'];
      E(L, CX, 61, 16, 6, SH, (x, y, u, v) => v >= -0.1);
      E(L, CX, 58.5, 13, 3.3, '#ffe6ee');
      E(L, CX, 54, 16, 12, (x, y, u, v) => { if (v > 0.02) return SH[2]; const a = Math.atan2(y + 0.5 - 60, x + 0.5 - CX); return fl(a * 10 / Math.PI) % 2 === 0 ? '#ff8aa8' : '#ffa8c0'; }, (x, y, u, v) => v <= 0.12);
      MB7(L, 31, 57);
    });
  }
  function pJelly() {
    // 蓝格子桌布上一整块带竖棱的红果冻，珠子悬在果冻里；顶上一坨奶油一颗樱桃，两边几道晃动线
    bg((x, y) => { const a = (x >> 2) % 2, b = (y >> 2) % 2; return a && b ? '#6aa4e8' : a || b ? '#9cc6f4' : '#d4e8ff'; });
    obj(L => {
      for (const [x, y] of [[12, 45], [11, 46], [11, 47], [11, 48], [12, 49], [9, 46], [8, 47], [9, 48]]) { lset(L, x, y, '#3b5055'); lset(L, 63 - x, y, '#3b5055'); }
    }, false);
    obj(L => E(L, CX, 67, 22, 4.6, WHT));
    obj(L => {
      const JR = ['#ffc0c8', '#ff7a88', '#f04a5a', '#c42e40', '#8a1a2c'];
      const hw = y => 12 + (y - 38) * 0.23;   // 半宽：上窄下宽
      for (let y = 38; y <= 64; y++) for (let x = 7; x <= 56; x++) {
        const u = (x + 0.5 - CX) / hw(y);
        if (Math.abs(u) > 1) continue;
        const s = (u + 1) * 4, t = s - fl(s);   // 8 道竖棱，往上收窄
        let i = 2;
        if (t < 0.3) i--; else if (t > 0.7) i++;
        if (u < -0.5) i--; else if (u > 0.5) i++;
        lset(L, x, y, JR[Math.max(0, Math.min(4, i))]);
      }
      E(L, CX, 38, 12, 3.5, (x, y, u, v) => (u + v < -0.8 ? JR[0] : JR[1]));   // 顶面
      for (let y = 43; y <= 55; y++) lset(L, rd(CX - 0.62 * hw(y) - 0.5), y, '#ffffff');   // 一道高光
      lset(L, rd(CX - 0.62 * hw(58) - 0.5), 58, '#ffffff');
      const JM = { k: JR[4], s: '#d8606e', w: '#ffb8c2', h: '#ffffff' };
      for (const [x, y] of [[25, 50], [37, 46], [30, 58], [40, 57]]) SP(L, MARBLE, JM, x - 2, y - 2);
      puffInto(L, [[CX, 35, 6.5, 3.2], [27.5, 34.5, 3.6, 2.6], [36.5, 34.5, 3.6, 2.6], [CX, 31.5, 4, 2.6], [CX, 29, 2.2, 1.8]], { base: '#ffffff', shade: '#f0d6cc' });
      E(L, CX, 26, 2.4, 2.4, ['#ff8a7a', '#e8202a', '#a01820']);
      LN(L, 32, 23, 34, 20, '#22803a');
    });
  }
  function pSquirrel() {
    bg((x, y) => (hash(fl(x / 3), fl(y / 3)) < 0.3 ? '#e05a46' : hash(fl((x + 1) / 3), fl((y + 2) / 3)) < 0.12 ? '#f08a4a' : '#d8483a'));
    obj(L => { for (let x = 7; x <= 56; x++) for (let y = 69; y <= 72; y++) lset(L, x, y, y === 69 ? '#8ae063' : '#36b24a'); });
    obj(L => {
      const BARK = ['#b07a50', '#8a5a3a', '#6a4028'];
      PG(L, [[21, 9], [43, 9], [46, 73], [18, 73]], (x, y) => ((x + (y >> 3)) % 5 === 1 ? BARK[2] : x < 23 ? BARK[0] : x > 41 ? BARK[2] : BARK[1]));
      R(L, 44, 27, 13, 4, BARK);
      E(L, CX, 47, 7.6, 9.6, BARK[2]); E(L, CX, 47.6, 6.3, 8.3, SLATE);
      MB(L, 29, 51); MB(L, 35, 52); MB(L, 31, 54);
      E(L, 34, 43.6, 2.2, 2.6, ['#e8b870', '#c8904a', '#9a6a30']); R(L, 32, 41, 5, 2, BARK[2]);
    });
    obj(L => {
      const FUR = ['#ffc070', '#ff9a3a', '#c86a1a'];
      E(L, 53, 20, 3.6, 6.2, FUR);
      E(L, 49, 23.5, 3.6, 3.6, FUR);
      E(L, 46, 19.6, 2.8, 2.6, FUR);
      lset(L, 45, 16, FUR[1]); lset(L, 45, 17, FUR[1]);
      lset(L, 45, 19, INK);
      lset(L, 48, 24, '#fff0c8'); lset(L, 48, 25, '#fff0c8');
      MB(L, 44, 25);
    });
  }
  function pPinata() {
    bg((x, y) => ((x - y + 64) % 8 < 4 ? '#ffb42a' : '#ffc04a'));
    obj(L => {
      for (let x = 11; x <= 52; x++) lset(L, x, 16, INK);
      [[12, '#ff6aa8'], [19, '#2f86ea'], [26, '#36b24a'], [33, '#9a5ad8'], [40, '#ff6aa8'], [47, '#2f86ea']].forEach(([x0, c]) => {
        for (let y = 17; y <= 22; y++) for (let x = x0; x < x0 + 5; x++) { if ((y === 22 && (x - x0) % 2 === 1) || (y === 19 && x === x0 + 2)) continue; lset(L, x, y, c); }
      });
    }, false);
    obj(L => { for (let y = 17; y <= 33; y++) lset(L, 36, y, '#3b5055'); }, false);
    obj(L => {
      const STR = ['#ff6aa8', '#ffd23a', '#2f86ea', '#36b24a', '#9a5ad8', '#ff9700'];
      const fill = (x, y) => STR[((fl(y / 2) % 6) + 6) % 6];
      PG(L, [[45, 37], [51, 34], [50, 41]], fill);
      R(L, 27, 45, 3, 9, fill); R(L, 32, 46, 3, 8, fill); R(L, 38, 46, 3, 8, fill); R(L, 43, 45, 3, 9, fill);
      E(L, 36, 40, 11.5, 7, fill);
      PG(L, [[22, 36], [27, 32], [30, 41], [25, 44]], fill);
      E(L, 21, 31, 5, 4.2, fill);
      PG(L, [[18, 28], [19, 21], [21.5, 27]], fill); PG(L, [[22.5, 27], [24.5, 21], [25.5, 28]], fill);
      lset(L, 19, 30, INK); lset(L, 16, 32, INK);
      for (const [x, y] of [[32, 46], [33, 47], [34, 46], [35, 47], [36, 46], [37, 47]]) lset(L, x, y, INK);
    });
    obj(L => { MB(L, 33, 57); MB(L, 38, 63); MB(L, 29, 67); });
  }
  function pFossil() {
    const BANDS = ['#c8783a', '#b0602a', '#d08a44', '#9a522a', '#c0703a', '#a85a2a'];
    bg((x, y) => {
      if (y < 16) return '#7cc8ff';
      if (y < 18) return y === 16 ? '#8ae063' : '#36b24a';
      if (hash(x, y) < 0.03) return '#e0a870';
      const b = fl((y - 18 + 2 * Math.sin(x / 7)) / 9);
      return BANDS[((b % 6) + 6) % 6];
    });
    obj(L => {
      E(L, 38, 40, 10.5, 8.5, BONE);
      PG(L, [[17, 37], [31, 33], [33, 47], [18, 47]], (x, y) => (y < 38 ? BONE[0] : y > 45 ? BONE[2] : BONE[1]));
      for (let x = 18; x <= 34; x++) { lset(L, x, 48, x % 3 === 2 ? BONE[0] : SLATE); lset(L, x, 49, x % 3 === 0 ? BONE[0] : SLATE); }
      PG(L, [[19, 50], [35, 50], [38, 55], [23, 55]], (x, y) => (y > 53 ? BONE[2] : BONE[1]));
      E(L, 40, 38, 3, 3, SLATE); E(L, 31, 41.5, 2, 2.6, SLATE); lset(L, 20, 39, SLATE);
    });
    obj(L => { MB(L, 13, 62); MB(L, 47, 64); MB(L, 50, 27); MB(L, 12, 29); MB(L, 30, 64, ['#c86a10', '#ffb030', '#fff0a0']); });
  }
  function pSpace() {
    bg((x, y) => {
      if (hash(x, y) < 0.03) return hash(y, x) < 0.5 ? '#ffffff' : '#fee787';
      const t = Math.max(0, 1 - Math.hypot(x - 18, y - 46) / 20) * 0.7 + Math.max(0, 1 - Math.hypot(x - 46, y - 16) / 14) * 0.5;
      return K.dith(x, y, t) ? '#2f3f86' : '#1b2a5a';
    });
    obj(L => ring(L, 36, 33, false));
    obj(L => E(L, 36, 32, 10, 10, (x, y, u, v) => (Math.abs(v + 0.32) < 0.1 || Math.abs(v - 0.36) < 0.1 ? '#e07020' : tone(u, v, ['#ffb060', '#ff8a2a', '#c85a1a']))));
    obj(L => { ring(L, 36, 33, true); MB(L, 20, 34); MB(L, 52, 33); });
    obj(L => {
      PG(L, [[12, 62], [12, 54], [15, 48], [18, 54], [18, 62]], (x, y) => (y < 52 ? '#fe4c40' : x < 14 ? '#ffffff' : x > 16 ? '#9aa6ba' : '#dfe7f2'));
      lset(L, 14, 55, '#2f86ea'); lset(L, 15, 55, '#2f86ea'); lset(L, 14, 56, '#2f86ea'); lset(L, 15, 56, '#1a5fb0');
      PG(L, [[12, 57], [9, 63], [12, 62]], '#fe4c40'); PG(L, [[18, 57], [21, 63], [18, 62]], '#fe4c40');
      PG(L, [[13, 63], [17, 63], [15, 69]], (x, y) => (y < 66 ? '#fee787' : '#ff9700'));
    });
    obj(L => { E(L, 45, 61, 6.5, 5, ['#b4bcc8', '#8a94a4', '#5f6878']); E(L, 42, 59, 1.6, 1.2, '#5f6878'); E(L, 48, 64, 1.4, 1, '#5f6878'); MB(L, 46, 61); });
  }
  function pPanda() {
    bg((x, y) => {
      if (y >= 68) return '#2f9060';
      if ([[9, 3], [20, 2], [42, 3]].some(([a, w]) => x >= a && x < a + w)) return y % 9 === 0 ? '#2f9060' : '#4cbc80';
      return '#3aa870';
    });
    obj(L => {
      R(L, 50, 10, 4, 63, (x, y) => (y % 10 === 4 ? '#3a7a1a' : x === 50 ? '#b8f070' : x === 53 ? '#4a8a22' : '#7ac843'));
      PG(L, [[49, 24], [41, 20], [47, 26.5]], '#7ac843'); PG(L, [[49, 40], [42, 44], [48, 42.5]], '#5ab830');
    });
    obj(L => {
      const WH = ['#ffffff', '#e6eef0', '#b4c2bf'];
      E(L, 24, 66, 5.5, 4.5, BLK); E(L, 40, 66, 5.5, 4.5, BLK);
      E(L, CX, 57, 12.5, 11, WH);
      E(L, 24, 31, 3.3, 3.3, BLK); E(L, 40, 31, 3.3, 3.3, BLK);
      E(L, CX, 39, 10, 8.6, WH);
      E(L, 28, 39.5, 2.4, 3.2, BLK); E(L, 36, 39.5, 2.4, 3.2, BLK);
      lset(L, 28, 38, '#ffffff'); lset(L, 35, 38, '#ffffff');
      lset(L, 31, 43, INK); lset(L, 32, 43, INK);
      lset(L, 30, 45, INK); lset(L, 31, 46, INK); lset(L, 32, 46, INK); lset(L, 33, 45, INK);
      MB(L, 27, 51, mramp(RED)); MB(L, 36, 51, mramp(BLU)); MB(L, 31, 50, mramp(YEL));   // 抱着一篮彩色珠子（白珠子会糊进白肚皮）
      PG(L, [[22, 53], [42, 53], [40, 64], [24, 64]], (x, y) => (y === 53 ? '#f0c070' : y === 54 || y === 63 ? '#8a5a26' : ((x >> 1) + (y >> 1)) % 2 ? '#d8a050' : '#b07a38'));
      E(L, 22, 58, 3.6, 5, BLK); E(L, 42, 58, 3.6, 5, BLK);
    });
  }
  function pPumpkin() {
    bg((x, y) => {
      if (y >= 66) return y === 66 && x % 3 === 0 ? '#3a8a4a' : '#2a6a3a';
      if (y < 50 && hash(x, y) < 0.02) return '#fee787';
      return '#1d4a44';
    });
    obj(L => E(L, 46, 22, 7, 7, ['#fff6c0', '#fee787', '#e8c860']));
    obj(L => { for (const [x, y] of [[14, 22], [22, 16], [33, 19]]) SP(L, ['k...k', '.kkk.', '..k..'], { k: SLATE }, x - 2, y - 1); }, false);
    obj(L => {
      E(L, 30, 51, 16, 12.5, (x, y, u, v) => { const au = Math.abs(u); if (Math.abs(au - 0.36) < 0.06 || Math.abs(au - 0.72) < 0.06) return '#d0680c'; return tone(u, v, ['#ffb050', '#ff8a1a', '#c05a08']); });
      R(L, 28, 36, 4, 4, ['#7ac85a', '#4a9a3a', '#2a6a22']);
      PG(L, [[20.5, 50], [27.5, 50], [24, 44]], SLATE); PG(L, [[32.5, 50], [39.5, 50], [36, 44]], SLATE);
      PG(L, [[28, 54], [32, 54], [30, 51]], SLATE);
      PG(L, [[18.5, 56], [41.5, 56], [38, 62], [22, 62]], SLATE);
      MB(L, 25, 58); MB(L, 30, 59); MB(L, 35, 58);
      R(L, 27, 56, 2, 1, '#ff8a1a'); R(L, 32, 61, 2, 1, '#ff8a1a');
    });
    obj(L => { E(L, 50, 65, 5.5, 4.2, ['#ffb050', '#ff8a1a', '#c05a08']); R(L, 49, 59, 2, 3, '#4a9a3a'); });
  }
  function pCircus() {
    bg((x, y) => (x % 8 < 4 ? '#b8282e' : '#c83238'));
    for (const [x, y, c] of [[12, 30, '#ffd23a'], [52, 26, '#ffd23a'], [15, 44, '#7ac0ff'], [49, 40, '#9af06a'], [11, 52, '#ffffff'], [53, 50, '#ffffff']]) P(OX + x, OY + y, c);
    obj(L => {
      for (let x = 7; x <= 56; x++) {
        const k = fl((x - 8) / 6), cxs = 8 + k * 6 + 3, bottom = 16 + Math.sqrt(Math.max(0, 9 - (x + 0.5 - cxs) ** 2)) * 0.9;
        for (let y = 9; y <= bottom; y++) lset(L, x, y, k % 2 ? '#fff0d0' : '#fe4c40');
      }
    });
    obj(L => {
      E(L, CX, 68, 13, 3.4, '#1a5fb0');
      R(L, 19, 58, 26, 10, (x, y) => (y === 62 + (x % 4 < 2 ? 0 : 1) ? '#ffd23a' : x === 19 ? '#7ac0ff' : x === 44 ? '#1a5fb0' : '#2f86ea'));
      E(L, CX, 58, 13, 3.4, YEL);
    });
    obj(L => {
      const SEAL = ['#9ab8d4', '#6a8aa8', '#4a6a88'];
      PG(L, [[42, 53], [49, 58], [41, 57]], SEAL[2]);
      E(L, 36, 46, 8.5, 9.5, SEAL);
      PG(L, [[29, 37], [37, 38], [37, 45], [29, 42]], SEAL[1]);
      E(L, 30, 34.5, 5.2, 4.6, SEAL);
      E(L, 25.5, 33, 2.6, 2, SEAL[2]);
      lset(L, 23, 32, INK); lset(L, 29, 33, INK);
      E(L, 28, 50, 2.2, 4, SEAL);
    });
    obj(L => MB7(L, 24, 25));
  }
  function pPirate() {
    bg((x, y) => {
      if (y < 40) { if (Math.hypot(x + 0.5 - 45, y + 0.5 - 40) < 8) return '#fee787'; return y < 25 ? '#ff8a3a' : '#ffa04a'; }
      if ((y === 45 || y === 53 || y === 61) && (x + y) % 7 < 3) return '#3a82e0';
      return '#1f6ad0';
    });
    obj(L => E(L, 30, 73, 24, 9.5, SAND));
    obj(L => { for (let t = 0; t <= 1; t += 0.02) { const x = 43 + 5 * t * t, y = 66 - 34 * t; for (let k = -1; k <= 1; k++) lset(L, rd(x + k), rd(y), rd(y) % 4 === 0 ? '#7a4a22' : k < 0 ? '#c88a4a' : '#a86a3a'); } });
    obj(L => {
      for (const [tx, ty] of [[36, 31], [57, 32], [40, 22], [55, 23]]) for (let t = 0; t <= 1; t += 0.04) {
        const x = 48 + (tx - 48) * t, y = 31 + (ty - 31) * t - Math.sin(t * Math.PI) * 2.2;
        lset(L, rd(x), rd(y), '#36b24a'); lset(L, rd(x), rd(y) + 1, '#22803a');
      }
      E(L, 47, 33, 1.6, 1.6, '#8a5226'); E(L, 49.5, 33.5, 1.6, 1.6, '#6a3e1e');
    });
    obj(L => {
      PG(L, [[13, 55], [33, 55], [31, 46], [15, 46]], (x, y) => (y < 48 ? '#c88a4a' : '#8a5226'));
      MB(L, 18, 52); MB(L, 24, 51); MB(L, 29, 53);
      E(L, 15.5, 54, 1.7, 1.2, YEL); E(L, 26.5, 54, 1.7, 1.2, YEL); E(L, 21, 49.5, 1.7, 1.2, YEL);
      R(L, 12, 55, 22, 10, (x, y) => (y === 55 || x <= 13 || x >= 32 ? '#ffc83a' : y === 64 ? '#6a3a1a' : (y - 55) % 3 === 0 ? '#8a5226' : '#a0602a'));
      R(L, 21, 57, 4, 4, '#ffc83a'); lset(L, 22, 58, SLATE); lset(L, 23, 58, SLATE); lset(L, 22, 59, SLATE);
    });
  }
  function pFerris() {
    bg((x, y) => (hash(x, y) < 0.02 ? '#fee787' : x % 6 === 3 && y % 6 === 3 ? '#8a3a7a' : '#7a2a6a'));
    obj(L => {
      for (const ex of [19, 45]) for (let t = 0; t <= 1; t += 0.02) { const x = CX + (ex - CX) * t, y = 36 + 32 * t; lset(L, fl(x - 0.5), rd(y), '#e6eef0'); lset(L, fl(x + 0.5), rd(y), '#b4c2bf'); }
      R(L, 10, 68, 44, 5, ['#6a7a80', SLATE, INK]);
    });
    obj(L => { for (let k = 0; k < 8; k++) { const a = k * Math.PI / 4 + Math.PI / 8; LN(L, 31.5, 35.5, 31.5 + Math.cos(a) * 14.5, 35.5 + Math.sin(a) * 14.5, '#fff6c0'); } }, false);
    obj(L => {
      for (let y = 17; y <= 55; y++) for (let x = 13; x <= 51; x++) { const d = Math.hypot(x + 0.5 - CX, y + 0.5 - 36); if (d >= 14.6 && d <= 16.6) lset(L, x, y, d > 15.6 ? '#e0b040' : '#fee787'); }
      E(L, CX, 36, 2.6, 2.6, RED);
    });
    obj(L => {
      const COLS = [RED, YEL, BLU, GRN];
      for (let k = 0; k < 8; k++) {
        const a = k * Math.PI / 4 + Math.PI / 8, gx = CX + Math.cos(a) * 15.6, gy = 36 + Math.sin(a) * 15.6;
        R(L, rd(gx - 3.5), rd(gy + 3), 7, 3, COLS[k % 4]);
        MB(L, rd(gx - 0.5), rd(gy + 2));
      }
    });
  }
  function pPopcorn() {
    bg((x, y) => (x % 8 < 4 ? '#1f8a8a' : '#239696'));
    obj(L => {
      PG(L, [[11, 23], [53, 23], [47, 14], [17, 14]], (x, y) => (y < 16 ? '#ff8a7a' : '#fe4c40'));
      for (let x = 11; x <= 52; x++) { lset(L, x, 23, '#ffd23a'); if (x % 4 < 2) lset(L, x, 24, '#ffd23a'); }
      R(L, 13, 25, 3, 28, BLK); R(L, 48, 25, 3, 28, BLK);
      for (let y = 25; y <= 52; y++) for (let x = 16; x <= 47; x++) lset(L, x, y, y < 36 + (hash(x >> 1, 7) < 0.5 ? 0 : 1) ? '#d8f2ff' : popcorn(x, y));
      for (let y = 26; y <= 34; y++) lset(L, 17, y, '#ffffff');
      E(L, CX, 29, 6, 3.6, STEEL); R(L, 31, 25, 2, 2, SLATE);
      for (const [x, y] of [[25, 27], [26, 26], [38, 27], [37, 26], [27, 32], [36, 33]]) lset(L, x, y, '#fff6d0');
      R(L, 12, 53, 40, 14, (x, y) => (y === 53 || y === 54 ? '#ffd23a' : x === 12 ? '#ff8a7a' : x === 51 ? '#b8322a' : '#fe4c40'));
      SP(L, ['..x..', '.xxx.', 'xxxxx', '.x.x.'], { x: '#ffd23a' }, 30, 58);
      E(L, 20, 68.5, 3, 3, BLK); E(L, 44, 68.5, 3, 3, BLK);
    });
    obj(L => { MB(L, 22, 44); MB(L, 33, 40); MB(L, 41, 47); MB(L, 27, 49); });
  }
  function pDesert() {
    const d1 = x => 50 + 5 * Math.sin((x + 4) / 9), d2 = x => 59 + 4 * Math.sin((x - 10) / 7);
    bg((x, y) => (y >= d1(x) ? (y < d1(x) + 1 ? '#ffe8b0' : '#f0b850') : y < 30 ? '#ffb43a' : '#ffc04a'));
    obj(L => E(L, 18, 25, 6.5, 6.5, ['#fff6c0', '#fee787', '#f0c040']));
    obj(L => {
      const C = GRN;
      R(L, 38, 31, 6, 34, (x, y) => (x === 38 ? C[0] : x === 43 ? C[2] : x === 40 && y % 3 === 0 ? C[2] : C[1]));
      E(L, 41, 31.5, 3, 2.6, C);
      R(L, 33, 45, 6, 3, C); R(L, 33, 37, 3, 9, C); E(L, 34.5, 37.5, 1.5, 1.6, C);
      R(L, 44, 41, 4, 3, C); R(L, 45, 33, 3, 9, C); E(L, 46.5, 33.5, 1.5, 1.6, C);
      for (const [x, y] of [[37, 35], [44, 38], [37, 50], [44, 54], [32, 41], [48, 37]]) lset(L, x, y, '#fee787');
      R(L, 12, 52, 4, 12, (x, y) => (x === 12 ? C[0] : x === 15 ? C[2] : C[1])); E(L, 14, 52.5, 2, 1.8, C);
    });
    obj(L => { for (let x = 7; x <= 56; x++) for (let y = Math.ceil(d2(x)); y <= 72; y++) lset(L, x, y, y < d2(x) + 1 ? '#ffe0a0' : hash(x, y) < 0.08 ? '#c88030' : '#e8a040'); }, false);
    obj(L => {   // 珠子半埋在前面的沙丘里：先描边，再把沙面以下那半截擦掉，补一道沙边
      const ms = [[21, MW], [31, mramp(BLU)], [51, MW]].map(([x, m]) => [x, rd(d2(x)) + 1, m]);
      for (const [x, cy, m] of ms) MB7(L, x, cy, m);
      for (const [x, cy] of ms) {
        for (let y = cy + 1; y <= cy + 4; y++) for (let xx = x - 3; xx <= x + 3; xx++) lset(L, xx, y, null);
        for (let xx = x - 3; xx <= x + 3; xx++) lset(L, xx, cy + 1, '#ffe0a0');
      }
    }, false);
  }
  function pSnow() {
    bg((x, y) => (hash(x, y) < 0.05 ? '#ffffff' : hash(x + 7, y * 3) < 0.03 ? '#8fb0e8' : '#2a4a9a'));
    obj(L => E(L, CX, 79, 34, 13, SNOW));
    obj(L => { LN(L, 22, 43, 13, 35, '#8a5a3a'); LN(L, 15, 37, 13, 33, '#8a5a3a'); LN(L, 41, 43, 50, 35, '#8a5a3a'); LN(L, 48, 37, 50, 33, '#8a5a3a'); }, false);
    obj(L => {
      E(L, CX, 58, 12.5, 10, SNOW);
      E(L, CX, 42, 9.5, 8, SNOW);
      E(L, CX, 28.5, 7.5, 7, SNOW);
      for (let x = 24; x <= 39; x++) for (let y = 34; y <= 35; y++) if (lget(L, x, y)) lset(L, x, y, y === 34 ? '#ff8a7a' : '#fe4c40');
      R(L, 36, 36, 3, 7, '#fe4c40');
      R(L, 27, 12, 10, 9, ['#6a7a80', SLATE, INK]); R(L, 27, 18, 10, 2, '#fe4c40'); R(L, 24, 21, 16, 2, ['#6a7a80', SLATE, INK]);
      PG(L, [[31.5, 30], [31.5, 32], [37.5, 31.2]], '#ff9700');
      MB(L, 28, 27); MB(L, 35, 27); MB(L, 31, 41); MB(L, 31, 47); MB(L, 31, 56);
    });
  }

  // ====================== 俯视 8 张 ======================
  function tSoccer() {
    bg((x, y) => (fl((y - 14) / 6) % 2 ? '#3cb452' : '#36a84a'));
    obj(L => { for (let y = 14; y <= 19; y++) for (let x = 22; x <= 41; x++) lset(L, x, y, (x + y) % 3 === 0 ? '#9aa8ac' : '#e6eef0'); });
    obj(L => {
      const Wc = '#f4fff4', hl = (x0, x1, y) => { for (let x = x0; x <= x1; x++) lset(L, x, y, Wc); }, vl = (x, y0, y1) => { for (let y = y0; y <= y1; y++) lset(L, x, y, Wc); };
      hl(9, 54, 20); vl(9, 20, 74); vl(54, 20, 74); hl(9, 54, 68);
      hl(17, 46, 35); vl(17, 20, 35); vl(46, 20, 35);
      hl(25, 38, 25); vl(25, 20, 25); vl(38, 20, 25);
      lset(L, 31, 30, Wc); lset(L, 32, 30, Wc);
      for (let a = 0; a < Math.PI; a += 0.05) { const y = 30 + Math.sin(a) * 8; if (y > 35.5) lset(L, fl(CX + Math.cos(a) * 8), fl(y), Wc); }
      for (let a = Math.PI; a < 2 * Math.PI; a += 0.04) lset(L, fl(CX + Math.cos(a) * 8), fl(68.5 + Math.sin(a) * 8), Wc);
      vl(22, 14, 20); vl(41, 14, 20);
    }, false);
    obj(L => { MB(L, 27, 17); MB(L, 33, 16); MB(L, 37, 17); });
    obj(L => { for (const [x, y, c] of [[25, 41, RED], [32, 40, RED], [39, 41, RED], [32, 23, YEL]]) { E(L, x, y, 3.4, 2.1, c); E(L, x, y - 0.6, 1.6, 1.6, '#f0c090'); lset(L, fl(x - 0.5), fl(y - 1.2), '#3b2a1e'); } });
    obj(L => SP(L, ['.kkkk.', 'kwwwwk', 'kwkkwk', 'kwkkwk', 'kwwwsk', '.kkkk.'], { k: INK, w: '#ffffff', s: '#c9d2de' }, 29, 49));
  }
  function tPool() {
    bg((x, y) => ((x * 3 + y) % 7 === 0 ? '#239452' : '#1f8a4a'));
    obj(L => { for (let x = 7; x <= 56; x++) for (let y = 14; y <= 76; y++) { const e = Math.min(x - 7, 56 - x, y - 14, 76 - y); if (e < 2) lset(L, x, y, e < 1 ? '#145a30' : '#18773e'); } }, false);
    obj(L => { for (let x = 10; x <= 53; x += 2) lset(L, x, 58, '#2a9a5a'); }, false);
    obj(L => { for (const [x, y] of [[9.5, 16.5], [54.5, 16.5], [8.5, 45.5], [55.5, 45.5], [9.5, 74.5], [54.5, 74.5]]) E(L, x, y, 3.2, 3.2, SLATE); });
    obj(L => {
      const BALLS = [YEL, BLU, RED, PUR, ORG, GRN, ['#d07070', '#a8323a', '#6a1a22']];
      let k = 0;
      for (let row = 0; row < 5; row++) for (let i = 0; i <= row; i++) {
        const bx = CX + (i - row / 2) * 5, by = 37 - row * 4.4;
        E(L, bx, by, 2.4, 2.4, row === 2 && i === 1 ? BLK : BALLS[k++ % 7]);
        if ((row + i) % 2) lset(L, fl(bx), fl(by - 0.5), '#ffffff');
      }
    });
    obj(L => E(L, CX, 62, 2.4, 2.4, WHT));
    obj(L => { LN(L, 34, 66, 46, 78, '#e8c088'); LN(L, 35, 66, 47, 78, '#a8703a'); lset(L, 34, 66, '#2f86ea'); lset(L, 35, 66, '#2f86ea'); });
  }
  function tHockey() {
    bg((x, y) => (hash(x, y * 7) < 0.08 ? '#d8ecfa' : '#eef8ff'));
    obj(L => {
      for (let x = 7; x <= 56; x++) { lset(L, x, 21, '#e8443a'); lset(L, x, 39, '#2f6ae8'); lset(L, x, 40, '#2f6ae8'); lset(L, x, 62, '#e8443a'); lset(L, x, 63, '#e8443a'); }
      for (let y = 22; y <= 27; y++) for (let x = 26; x <= 37; x++) if (Math.hypot(x + 0.5 - CX, y + 0.5 - 21) <= 5.6) lset(L, x, y, '#a8d8ff');
      for (let a = 0; a < 2 * Math.PI; a += 0.04) lset(L, fl(CX + Math.cos(a) * 7), fl(63 + Math.sin(a) * 7), '#2f6ae8');
      for (const [fx, fy] of [[16, 30], [47, 30]]) { for (let a = 0; a < 2 * Math.PI; a += 0.08) lset(L, fl(fx + 0.5 + Math.cos(a) * 4.5), fl(fy + 0.5 + Math.sin(a) * 4.5), '#e8443a'); lset(L, fx, fy, '#e8443a'); }
    }, false);
    obj(L => { for (let y = 15; y <= 20; y++) for (let x = 27; x <= 36; x++) lset(L, x, y, x === 27 || x === 36 || y === 15 ? '#e8443a' : (x + y) % 2 ? '#dfe7f2' : '#b4c2cc'); });
    obj(L => { for (const [x, y] of [[32, 45], [24, 48], [40, 48], [28, 55], [36, 55], [30, 61]]) { E(L, x, y, 2.4, 2.4, BLK); lset(L, fl(x - 1), fl(y - 1), '#6a7a80'); } });   // 冰饼之间留出冰面，不糊成一团
    obj(L => { LN(L, 46, 77, 39, 64, '#d8a868'); LN(L, 47, 77, 40, 64, '#a8703a'); R(L, 34, 62, 6, 2, SLATE); });
  }
  function tMarbles() {
    bg((x, y) => { const h = hash(x, y); return h < 0.06 ? '#a8723e' : h < 0.1 ? '#e0b07a' : '#c8925a'; });
    obj(L => { for (let y = 20; y <= 70; y++) for (let x = 8; x <= 56; x++) { const d = Math.hypot(x + 0.5 - CX, y + 0.5 - 43); if (Math.abs(d - 19.5) < 0.75) lset(L, x, y, '#fff8ec'); } }, false);
    obj(L => {
      const CAT = [RED, BLU, GRN, YEL, PUR, ORG].map(mramp);
      [[32, 43], [32, 37], [32, 49], [26, 43], [38, 43], [32, 31], [32, 55], [20, 43], [44, 43]].forEach(([x, y], k) => MB(L, x, y, CAT[k % 6]));
    });
    obj(L => MB7(L, 31, 69, mramp(BLU)));
  }
  function tCrok() {
    bg(() => SLATE);
    obj(L => E(L, CX, 45.5, 24.2, 24.2, (x, y) => {
      const d = Math.hypot(x + 0.5 - CX, y + 0.5 - 45.5);
      if (d < 2.4) return INK;
      if (Math.abs(d - 16) < 0.6 || Math.abs(d - 8.5) < 0.55 || Math.abs(d - 22.5) < 0.5) return '#8a5226';
      if (d > 16 && d < 22.5 && (Math.abs(x + 0.5 - CX) < 0.6 || Math.abs(y + 0.5 - 45.5) < 0.6)) return '#8a5226';
      return fl(d * 0.7) % 2 ? '#e8c088' : '#e0b478';
    }));
    obj(L => { for (let k = 0; k < 8; k++) { const a = k * Math.PI / 4 + Math.PI / 8; E(L, CX + Math.cos(a) * 16, 45.5 + Math.sin(a) * 16, 1.3, 1.3, '#e0b040'); } });
    obj(L => { for (const [x, y, c] of [[24, 34, RED], [41, 53, RED], [36, 40, BONE], [21, 56, BONE], [32, 66, RED]]) E(L, x, y, 2.6, 2.6, c); });
  }
  function tBowling() {
    bg((x, y) => (x < 12 || x > 51 ? (x === 11 || x === 52 ? INK : SLATE) : fl((x - 12) / 4) % 2 ? '#e8b870' : '#dca860'));
    obj(L => { for (const x of [17, 24, 32, 39, 46]) SP(L, ['.x.', 'xxx'], { x: '#a86a3a' }, x - 1, 52); for (const x of [20, 28, 35, 43]) lset(L, x, 60, '#a86a3a'); }, false);
    obj(L => {
      for (const [px, py] of [[21.5, 19], [28.5, 19], [35.5, 19], [42.5, 19], [25, 25], [32, 25], [39, 25], [28.5, 31], [35.5, 31], [32, 37]]) {
        E(L, px, py, 2.4, 2.4, (x, y, u, v) => { const d = u * u + v * v; return d < 0.2 ? '#ffffff' : d < 0.5 ? '#fe4c40' : u + v < 0 ? '#ffffff' : '#dfe7f2'; });
      }
    });
    obj(L => { E(L, CX, 66, 4.6, 4.6, ['#a87aff', '#6a3ad8', '#3a1a8a']); lset(L, 30, 64, SLATE); lset(L, 33, 64, SLATE); lset(L, 31, 67, SLATE); });
  }
  function tCurling() {
    bg((x, y) => (hash(x * 3, y) < 0.06 ? '#e2eef8' : '#f2f9ff'));
    obj(L => {
      for (let x = 7; x <= 56; x++) lset(L, x, 56, '#e8443a');
      for (let y = 14; y <= 76; y++) lset(L, 31, y, '#c8d4e0');
      E(L, CX, 30, 14.5, 14.5, (x, y) => { const d = Math.hypot(x + 0.5 - CX, y + 0.5 - 30); return d > 10.5 ? '#2f86ea' : d > 7 ? '#f2f9ff' : d > 3.6 ? '#e8443a' : '#f2f9ff'; });
      for (let x = 7; x <= 56; x++) if (Math.abs(x + 0.5 - CX) > 14.5) lset(L, x, 30, '#a8b8cc');
    }, false);
    obj(L => {
      for (const [x, y, h] of [[27, 26, RED], [37, 33, YEL], [24, 38, RED], [41, 21, YEL], [32, 66, YEL]]) {
        E(L, x + 0.5, y + 0.5, 3.3, 3.3, ['#c8d0dc', '#8a94a4', '#5f6878']);
        R(L, x - 1, y, 3, 1, h[1]); lset(L, x - 1, y - 1, h[0]);
      }
    });
    obj(L => { LN(L, 47, 77, 41, 64, '#e8c088'); R(L, 37, 60, 9, 3, '#fe4c40'); for (let x = 37; x <= 45; x += 2) lset(L, x, 59, '#ffd23a'); });
  }
  function tGolf() {
    bg((x, y) => (((x >> 1) + (y >> 1)) % 2 ? '#3cba52' : '#36b04a'));
    obj(L => E(L, 44, 26, 7, 4.5, SAND));
    obj(L => E(L, 19, 60, 8, 5, BLU));
    obj(L => R(L, 7, 42, 31, 3, WOOD));
    obj(L => E(L, 17, 25, 2.4, 2.4, SLATE));
    obj(L => { for (let y = 15; y <= 24; y++) lset(L, 17, y, '#e6eef0'); PG(L, [[18, 15], [24, 17.5], [18, 20]], '#fe4c40'); });
    obj(L => { R(L, 39, 45, 15, 3, x => (x < 46 ? '#fe4c40' : '#ffffff')); R(L, 45, 39, 3, 15, (x, y) => (y < 46 ? '#ffffff' : '#fe4c40')); E(L, 46.5, 46.5, 1.8, 1.8, SLATE); });
    obj(L => { R(L, 39, 65, 11, 8, '#2a9a4a'); MB(L, 44, 69); });
  }

  // ---------- 卡框花纹（只在卡框那一圈露出来） ----------
  const isSide = (i, j) => j > 11 && j < PH - 6 && (i < 6 || i > PW - 7);
  const FP = {
    dots: c => (i, j) => (i % 5 === 2 && j % 5 === 2 ? c : null),
    rivets: (c, s = 8) => (i, j) => (((i === 3 || i === PW - 4) && j % s === 4) || ((j === 5 || j === PH - 4) && i % s === 4) ? c : null),
    bands: (c, s = 14) => (i, j) => ((isSide(i, j) ? j % s : i % s) < 2 ? c : null),
    vstripes: c => (i, j) => ((isSide(i, j) ? j % 6 : i % 6) < 3 ? c : null),
    zig: c => (i, j) => ((isSide(i, j) ? (j + (i % 2) * 2) % 4 : (i + (j % 2) * 2) % 4) === 0 ? c : null),
    bulbs: c => (i, j) => (((i === 3 || i === PW - 4) && j % 5 === 2) || ((j === 5 || j === PH - 4) && i % 5 === 2) ? c : null),
    knit: c => (i, j) => ((j + (i % 2)) % 3 === 0 ? c : null),
    hex: c => (i, j) => (j % 3 === 1 && (i + (fl(j / 3) % 2) * 2) % 4 === 0 ? c : null),
    bricks: c => (i, j) => (j % 4 === 0 || (i + (fl(j / 4) % 2) * 4) % 8 === 0 ? c : null),
    speck: c => (i, j) => (hash(i * 3, j * 5) < 0.25 ? c : null),
    nodes: c => (i, j) => ((isSide(i, j) ? j % 10 : i % 10) === 0 ? c : null),
  };

  // ---------- 32 张：f = 卡框 [亮,中,暗]，rail = 导轨色，em = 徽章芯 ----------
  const THEMES = [
    { paint: pDog, f: ['#ffe066', '#ffbe1a', '#e8860c'], fp: FP.dots('#f5a810'), rail: '#fe4c40', em: '#7fc2ff' },
    { paint: pVolc, f: ['#ff8a4a', '#e8452a', '#a82a1a'], fp: FP.bricks('#c2361e'), rail: '#ff7a2a', em: '#3d1a5a' },
    { paint: pMine, f: ['#e09a52', '#b8742e', '#7a4a1e'], fp: FP.rivets('#5a3a1a'), rail: '#9aa8ac', em: '#3d3550' },
    { paint: pRes, f: ['#6fe0cc', '#1fa89a', '#137266'], fp: FP.bands('#ffc83a'), rail: '#ffc83a', em: '#7cc8ff' },
    { paint: pFactory, f: ['#c8d8e4', '#8aa2b4', '#56707f'], fp: FP.rivets('#3b5055'), rail: '#ffc83a', em: '#c8642a' },
    { paint: pIce, f: ['#e6fbff', '#9fe6ff', '#4fb0d8'], fp: FP.speck('#c8f4ff'), rail: '#ffffff', em: '#1d3f8c' },
    { paint: pHoney, f: ['#ffc860', '#f0901a', '#b05a08'], fp: FP.hex('#ffb040'), rail: '#7a3a10', em: '#ffc83a' },
    { paint: pHen, f: ['#ffffff', '#ece6d8', '#b8ae9a'], fp: FP.vstripes('#ddd4c0'), rail: '#fe4c40', em: '#f0c040' },
    { paint: pBalloon, f: ['#ffb0d0', '#ff6aa8', '#c83a7a'], fp: FP.dots('#ff90c0'), rail: '#ffffff', em: '#9a84f0' },
    { paint: pGum, f: ['#8af0c8', '#3ccf9a', '#1f8a64'], fp: FP.dots('#6ae4b4'), rail: '#fe4c40', em: '#ff8ab8' },
    { paint: pClam, f: ['#ffb89a', '#ff8a6a', '#c85a40'], fp: FP.dots('#ffa080'), rail: '#fee787', em: '#0f6a80' },
    { paint: pJelly, f: ['#fff8e0', '#ffe8a8', '#d8b86a'], fp: FP.dots('#ffd890'), rail: '#fe4c40', em: '#f04a5a' },
    { paint: pSquirrel, f: ['#7ac85a', '#4a9a3a', '#2a6a22'], fp: FP.dots('#5aaa48'), rail: '#ff9a3a', em: '#d8483a' },
    { paint: pPinata, f: ['#ff8ac0', '#e83a8a', '#a8205a'], fp: FP.zig('#ff5aa0'), rail: '#36b24a', em: '#ffb42a' },
    { paint: pFossil, f: ['#ffe8b0', '#e8c070', '#b08a40'], fp: FP.dots('#d8b060'), rail: '#9a5a2a', em: '#f0e2c0' },
    { paint: pSpace, f: ['#ffffff', '#cdd6e0', '#8a98aa'], fp: FP.rivets('#9aa8b8'), rail: '#2f86ea', em: '#1b2a5a' },
    { paint: pPanda, f: ['#b8f070', '#7ac843', '#4a8a22'], fp: FP.nodes('#5aa030'), rail: '#ffffff', em: '#3aa870' },
    { paint: pPumpkin, f: ['#a87ae0', '#7a4ab8', '#4f2a80'], fp: FP.dots('#9a6ad8'), rail: '#ff8a1a', em: '#1d4a44' },
    { paint: pCircus, f: ['#7a9aff', '#2a4ad8', '#1a2a90'], fp: FP.dots('#ffd23a'), rail: '#ffd23a', em: '#fe4c40' },
    { paint: pPirate, f: ['#d89a5a', '#a86a3a', '#6a3e1e'], fp: FP.rivets('#ffc83a'), rail: '#ffc83a', em: '#1f6ad0' },
    { paint: pFerris, f: ['#d8b8ff', '#ab84f0', '#7a5ad0'], fp: FP.bulbs('#fee787'), rail: '#fee787', em: '#7a2a6a' },
    { paint: pPopcorn, f: ['#ff8a7a', '#e8343a', '#a82228'], fp: FP.vstripes('#fff4ec'), rail: '#ffd23a', em: '#1f8a8a' },
    { paint: pDesert, f: ['#f0905a', '#d06a3a', '#9a4422'], fp: FP.zig('#e88050'), rail: '#36b24a', em: '#ffc04a' },
    { paint: pSnow, f: ['#7ad08a', '#3a9a5a', '#22703a'], fp: FP.knit('#4aaa6a'), rail: '#fe4c40', em: '#2a4a9a' },
    { mode: 'top', paint: tSoccer, f: ['#7aa8ff', '#2f6ae8', '#1a3fa8'], fp: FP.vstripes('#e6eef8'), rail: '#ffffff', em: '#36a84a' },
    { mode: 'top', paint: tPool, f: ['#c8704a', '#8a3a22', '#5a2416'], fp: FP.rivets('#ffd23a'), rail: '#ffd23a', em: '#1f8a4a' },
    { mode: 'top', paint: tHockey, f: ['#ff8a7a', '#e8443a', '#a82a22'], fp: FP.bands('#ffffff', 10), rail: '#ffffff', em: '#2f6ae8' },
    { mode: 'top', paint: tMarbles, f: ['#e8b880', '#c8925a', '#8a5a2a'], fp: FP.dots('#f0d8b0'), rail: '#fff8ec', em: '#2f86ea' },
    { mode: 'top', paint: tCrok, f: ['#6f8388', '#3b5055', '#26343a'], fp: FP.rivets('#e0b040'), rail: '#e0b040', em: '#e8c088' },
    { mode: 'top', paint: tBowling, f: ['#6ae0d8', '#2fb8b0', '#1f8078'], fp: FP.dots('#fee787'), rail: '#ffffff', em: '#6a3ad8' },
    { mode: 'top', paint: tCurling, f: ['#c0c8d4', '#8a96a4', '#5f6878'], fp: FP.speck('#a8b4c0'), rail: '#e8443a', em: '#2f86ea' },
    { mode: 'top', paint: tGolf, f: ['#ffc070', '#ff9a2a', '#c86a10'], fp: FP.dots('#ffd8a0'), rail: '#ffffff', em: '#36b04a' },
  ];
  const LEDS = ['05', '08', '10', '12', '15', '16', '18', '20', '24', '25', '28', '30', '32', '35', '36', '40', '42', '45', '48', '50', '55', '60', '64', '72', '06', '09', '14', '22', '26', '33', '44', '66'];

  // ---------- 卡壳 ----------
  function shell(T) {
    const F = T.f;
    rrect(OX + 2, OY + 3, PW, PH, 6, () => DEEP);
    rrect(OX, OY, PW, PH, 6, (i, j, de) => {
      if (de < 1) return INK;
      if (de < 2) return i + j < (PW + PH) / 2 ? F[0] : F[2];
      return (T.fp && T.fp(i, j)) || F[1];
    });
    const b = MODE === 'side' ? SIDE : TOP;
    for (let y = b.y0 - 2; y <= b.y1 + 2; y++) for (let x = b.x0 - 2; x <= b.x1 + 2; x++) {
      if (inB(x, y)) continue;
      if (inB(x + 1, y) || inB(x - 1, y) || inB(x, y + 1) || inB(x, y - 1)) P(OX + x, OY + y, INK);
      else if (inB(x + 2, y) || inB(x - 2, y) || inB(x, y + 2) || inB(x, y - 2)) P(OX + x, OY + y, T.rail);
    }
  }
  function finish(T, k) {
    if (MODE === 'side') {
      for (let y = SIDE.hole; y <= SIDE.y1; y++) for (let x = SIDE.x0; x <= SIDE.x1; x++) P(OX + x, OY + y, y === SIDE.hole ? INK : SLATE);
      const lit = [k % 8, (k * 3 + 2) % 8, (k * 5 + 5) % 8];
      for (let i = 0; i < 8; i++) {
        const x = OX + SIDE.x0 + 3 + i * 6, y = OY + SIDE.hole + 1, on = lit.includes(i);
        P(x, y, on ? '#fff6c0' : '#a8283a'); P(x + 1, y, on ? '#ffd84a' : '#8c1f2e'); P(x, y + 1, on ? '#ffd84a' : '#8c1f2e'); P(x + 1, y + 1, on ? '#e0a010' : '#6a1622');
      }
    }
    rrect(OX + 2, OY + 2, 12, 9, 1, (i, j, de) => (de < 1 ? INK : DEEP));
    [...LEDS[k]].forEach((ch, n) => sprite(D35[ch], { x: '#fe4c40' }, OX + 4 + n * 4, OY + 4));
    disc(OX + PW - 7.5, OY + 7, 4.6, INK); disc(OX + PW - 7.5, OY + 7, 3.6, T.rail); disc(OX + PW - 7.5, OY + 7, 2.4, T.em);
  }

  // ---------- 背景 + 排版：8 列 4 排，第 4 排是俯视 ----------
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) P(x, y, K.dith(x, y, Math.max(0, 1 - Math.hypot(x - W / 2, y - H / 2) / 420) * 0.5) ? '#1f2d30' : '#1b2628');
  for (let x = 22; x < W - 22; x++) if (x % 4 < 2) P(x, 357, '#2f3f42');
  THEMES.forEach((T, k) => {
    MODE = T.mode || 'side';
    OX = 22 + (k % 8) * 76;
    OY = 33 + fl(k / 8) * 110 + (k >= 24 ? 4 : 0);
    shell(T);
    T.paint();
    finish(T, k);
    const s = String(k + 1), w = s.length * 4 - 1;
    [...s].forEach((ch, n) => sprite(D35[ch], { x: '#4f6367' }, OX + 32 - fl(w / 2) + n * 4, OY + PH + 6));
  });

  // ---------- 输出 ----------
  const cv = document.getElementById('c');
  K.flush(cv);
  function fit() {
    if (q.has('zoom')) {
      const z = Number(q.get('zoom')), cx = Number(q.get('cx') || W / 2), cy = Number(q.get('cy') || H / 2);
      Object.assign(cv.style, { position: 'absolute', width: W * z + 'px', height: H * z + 'px', left: (window.innerWidth / 2 - cx * z) + 'px', top: (window.innerHeight / 2 - cy * z) + 'px' });
      return;
    }
    const z = Math.max(1, fl(Math.min(window.innerWidth / W, window.innerHeight / H)));
    cv.style.width = W * z + 'px';
    cv.style.height = H * z + 'px';
  }
  fit();
  window.addEventListener('resize', fit);
  window.__done = true;
})();
