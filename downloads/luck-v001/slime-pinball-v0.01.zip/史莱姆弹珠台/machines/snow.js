/*
 * 越滚越大（雪球场；俯视，小台 64 宽，11-11 粗做）。冰面上散着雪球，顶上一块推雪板，冰面下边是台沿，推下去的归你。
 *   在卡上按住往后拉，松手从下面弹一个小雪球上去（只能往前弹）。弹出去的同时，顶上落进【签】个小雪球，推雪板往前推一趟再退回来。
 *   一样大的两个雪球碰上，粘成大一号（四号最大）。推下台沿的吐【价】×（1、3、8、20）张券，越大越值。推板只跟着你弹的那一下走。
 *   冰晶雪球（碰运气）：落进来的 1% 是冰晶的（×5，粘大了还是）。雪人帽（手上功夫 = 大奖）：推下一个四号雪球。雪铲（打得深）：推下 200 个。
 */
Machines.def('snow', env => {
  'use strict';
  const { A, sfx } = env;
  const T = window.TopDown, INK = A.INK;
  const BOX = { x0: 14, x1: 114 }, EDGE = 150, LAUNCH = { x: 64, y: 160 };
  const PUSH = { rest: 66, out: 92, tOut: 1.1, tBack: 0.6 };
  const RAD = [0, 3.5, 5, 6.5, 8], WORTH = [0, 1, 3, 8, 20], MASS = [0, 1, 2, 4, 8];
  const VMAX = 230, PULL = 44, CAP = 30;
  const s = T.create();
  const st = { state: 'aim', drag: null, quiet: 0, acc: { t: 0 }, time: 0, py: PUSH.rest, pv: 0, cycle: null, fell: 0, falling: [], pops: [], auto: null, shotN: 0 };
  const m = () => env.m();
  const SNOW = ['#b4c8dc', '#e6f2fb', '#ffffff'], ICE = ['#4fb0d8', '#a8e8ff', '#ffffff'];
  const ims = {};
  const imOf = b => { const k = b.size + (b.ice ? 'i' : ''); return ims[k] || (ims[k] = A.ballSprite(RAD[b.size], b.ice ? ICE : SNOW, b.ice ? (kk, c) => { kk.P(Math.floor(c), Math.floor(c - 1), '#ffffff'); kk.P(Math.floor(c - 1), Math.floor(c), '#ffffff'); kk.P(Math.floor(c + 1), Math.floor(c), '#ffffff'); kk.P(Math.floor(c), Math.floor(c + 1), '#ffffff'); } : null)); };
  const balls = () => s.bodies.filter(b => b.alive);
  const mk = (x, y, size, o) => T.add(s, Object.assign({ kind: 'snow', x, y, size, r: RAD[size], m: MASS[size], mu: 80, drag: 1.2, e: 0.2, we: 0.3, box: BOX }, o));
  function placeOne(y0, y1, size, blink) {
    for (let k = 0; k < 40; k++) {
      const r = RAD[size], x = BOX.x0 + r + 2 + Math.random() * (BOX.x1 - BOX.x0 - 2 * r - 4), y = y0 + Math.random() * (y1 - y0);
      if (s.bodies.some(b => b.alive && Math.hypot(b.x - x, b.y - y) < b.r + r + 0.5)) continue;
      return mk(x, y, size, { ice: env.luck(0.01), born: blink ? 0.01 : 1 });
    }
    return null;
  }
  for (let i = 0; i < 18; i++) placeOne(PUSH.rest + 6, EDGE - 4, i < 3 ? 2 : 1, false);

  // ---------- 弹 ----------
  function startDrag(p) { if (st.state !== 'aim') return false; st.drag = { x0: p.sx, y0: p.sy, x: p.sx, y: p.sy, by: p.id }; st.state = 'drag'; return true; }
  function pullVec() {
    const d = st.drag; let dx = d.x - d.x0, dy = d.y - d.y0; const l = Math.hypot(dx, dy);
    if (l > PULL) { dx *= PULL / l; dy *= PULL / l; }
    if (l > 0.01 && dy / Math.hypot(dx, dy) < 0.5) { const ll = Math.min(l, PULL), sx = Math.sign(dx) || 1; dy = 0.5 * ll; dx = sx * Math.sqrt(ll * ll - dy * dy); }
    return { dx, dy, l: Math.min(l, PULL) };
  }
  function release() {
    if (st.state !== 'drag') return;
    const { dx, dy, l } = pullVec();
    st.drag = null;
    if (l < 3) { st.state = 'aim'; return; }
    if (!env.spend()) { st.state = 'aim'; return; }
    const v = T.shotFromDrag(dx, dy, PULL, VMAX);
    const b = mk(LAUNCH.x, LAUNCH.y, 1, { fresh: true });
    b.vx = v.vx; b.vy = v.vy;
    let n = 0;
    for (let i = 0; i < env.val('n') && balls().length < CAP; i++) if (placeOne(PUSH.rest + 4, PUSH.rest + 22, 1, true)) n++;
    if (n) sfx.hop(3);
    st.cycle = { t: 0 }; st.fell = 0; st.quiet = 0; st.shotN += 1; st.state = 'roll';
    sfx.launch(v.p * 0.5);
  }
  function pusher(dt) {
    const c = st.cycle;
    if (!c) { st.py = PUSH.rest; st.pv = 0; return; }
    c.t += dt;
    const { rest, out, tOut, tBack } = PUSH;
    if (c.t < tOut) { const u = c.t / tOut; st.py = rest + (out - rest) * (0.5 - 0.5 * Math.cos(Math.PI * u)); st.pv = (out - rest) * Math.PI / 2 / tOut * Math.sin(Math.PI * u); }
    else if (c.t < tOut + tBack) { const u = (c.t - tOut) / tBack; st.py = out - (out - rest) * u; st.pv = 0; }
    else { st.py = rest; st.pv = 0; st.cycle = null; }
  }
  // 推板往前走的时候，一枚顶一枚：挨着的两枚，把靠台沿那一枚整个挪开（推力一路传下去，不像碰撞那样一枚分一半）
  function shove() {
    if (!(st.pv > 0)) return;
    const B = s.bodies.filter(b => b.alive).sort((a, b) => a.y - b.y);
    for (let it = 0; it < 2; it++) for (let i = 0; i < B.length; i++) for (let j = i + 1; j < B.length; j++) {
      const a = B[i], b = B[j], dx = b.x - a.x, dy = b.y - a.y, rr = a.r + b.r;
      if (dy <= 0 || dy >= rr || Math.abs(dx) >= rr) continue;
      const d2 = dx * dx + dy * dy;
      if (d2 >= rr * rr) continue;
      const d = Math.sqrt(d2) || 1e-6, pen = rr - d;
      b.x += dx / d * pen; b.y += dy / d * pen;
      const v = st.pv * dy / d; if (b.vy < v) b.vy = v;
    }
  }
  function push() {
    for (const b of s.bodies) {
      if (!b.alive) continue;
      if (b.y - b.r < st.py) { b.y = st.py + b.r; if (b.vy < st.pv) b.vy = st.pv; }
      if (b.fresh && b.y < EDGE - 6) b.fresh = false;
      if (!b.fresh && b.y > EDGE) drop(b);
    }
  }
  // 一样大的碰上：粘成大一号，落在两个中间，速度按质量平均
  function merge(a, b) {
    if (!a.alive || !b.alive || a.size !== b.size || a.size >= 4) return;
    const M = a.m + b.m, size = a.size + 1;
    a.x = (a.x * a.m + b.x * b.m) / M; a.y = (a.y * a.m + b.y * b.m) / M;
    a.vx = (a.vx * a.m + b.vx * b.m) / M; a.vy = (a.vy * a.m + b.vy * b.m) / M;
    a.size = size; a.r = RAD[size]; a.m = MASS[size]; a.ice = a.ice || b.ice; a.fresh = false;
    b.alive = false;
    st.pops.push({ x: a.x, y: a.y, r: a.r, t: 0 });
    sfx.pop();
  }
  function drop(b) {
    b.alive = false;
    st.fell += 1;
    const base = env.val('v') * WORTH[b.size] * (b.ice ? 5 : 1);
    env.award(base, { at: [b.x, EDGE - 2], n: Math.min(6, base) });
    st.falling.push({ x: b.x, y: b.y, im: imOf(b), t: 0 });
    m().kills = (m().kills || 0) + 1;
    if (b.size >= 4) env.jackpot();
    if (b.ice) { env.toast('冰晶雪球！×5', A.GOLD[0]); env.find('luck'); }
    if (m().kills >= 200) env.find('deep');
    sfx.settle(Math.min(5, b.size + 1));
  }
  function settle() {
    for (const b of s.bodies) if (b.fresh) b.fresh = false;
    push();
    s.bodies = s.bodies.filter(b => b.alive);
    st.state = 'aim';
    env.save();
  }

  // ---------- 自动弹：往一样大的两颗中间弹，没有就往最靠台沿的那一列 ----------
  function auto(dt) {
    const A_ = st.auto || (st.auto = { t: 0 });
    if (st.state !== 'aim' || env.marbles() <= 0) return;
    A_.t += dt; if (A_.t < 0.5) return; A_.t = 0;
    const bs = balls(), ones = bs.filter(b => b.size === 1);
    const tgt = ones.length ? ones[Math.floor(Math.random() * ones.length)] : bs.length ? bs.reduce((a, b) => (b.y > a.y ? b : a)) : { x: 64, y: 90 };
    const vx = tgt.x - LAUNCH.x, vy = Math.min(-40, tgt.y - LAUNCH.y), vl = Math.hypot(vx, vy), p = Math.min(1, 0.4 + (LAUNCH.y - tgt.y) / 160);
    st.drag = { x0: 0, y0: 0, x: -vx / vl * PULL * p, y: -vy / vl * PULL * p, by: 'auto' };
    st.state = 'drag';
    release();
  }

  return {
    s,
    fine(f) {
      for (let x = 14; x <= 113; x++) { f.px(x, EDGE + 1, '#9ab0c8'); for (let y = EDGE + 2; y <= 153; y++) f.px(x, y, '#1d2a44'); }
      for (let x = LAUNCH.x - 6; x <= LAUNCH.x + 6; x++) f.px(x, EDGE + 1, '#4a72b0');
    },
    update(dt) {
      st.time += dt;
      for (const b of s.bodies) if (b.born > 0 && b.born < 1) b.born = Math.min(1, b.born + dt / 0.25);
      if (st.state === 'roll') {
        T.advance(s, dt, st.acc, null, () => { pusher(T.DT); shove(); push(); for (const e of s.events) if (e.type === 'hit') merge(e.a, e.b); s.events.length = 0; });
        if (!st.cycle && !T.moving(s, 2)) { st.quiet += dt; if (st.quiet > 0.25) { for (const b of s.bodies) b.vx = b.vy = 0; settle(); } } else st.quiet = 0;
      } else s.events.length = 0;
      st.falling = st.falling.filter(q => (q.t += dt) < 0.4);
      st.pops = st.pops.filter(q => (q.t += dt) < 0.2);
    },
    draw(ctx) {
      for (const b of balls()) {
        if (b.born > 0 && b.born < 1 && Math.sin(b.born * 20) > 0) continue;
        const im = imOf(b);
        MK.spr(ctx, im, Math.round(b.x - im.width / 2), Math.round(b.y - im.height / 2));
      }
      for (const q of st.pops) MK.ring(ctx, q.x, q.y, q.r + 2 + q.t * 10, '#ffffff', 3);
      for (const q of st.falling) { const y = q.y + q.t * 30; if (Math.floor(q.t * 20) % 2 === 0) MK.spr(ctx, q.im, Math.round(q.x - q.im.width / 2), Math.round(y - q.im.height / 2)); }
      // 推雪板：红板子，一排黄铆钉，前沿亮边
      const py = Math.round(st.py);
      MK.rect(ctx, 14, 28, 100, py - 28, '#fe4c40');
      for (let x = 20; x < 114; x += 12) MK.rect(ctx, x, Math.max(29, py - 6), 2, 2, '#ffd23a');
      MK.rect(ctx, 14, py - 2, 100, 1, '#ff8a7a'); MK.rect(ctx, 14, py - 1, 100, 1, INK);
      if ((st.state === 'aim' || st.state === 'drag') && env.marbles() > 0) { const im = imOf({ size: 1 }); MK.spr(ctx, im, LAUNCH.x - im.width / 2, LAUNCH.y - im.height / 2); }
      if (st.state === 'drag') {
        const { dx, dy, l } = pullVec();
        if (l >= 3) { const ux = -dx / l, uy = -dy / l; MK.dots(ctx, LAUNCH.x + ux * 7, LAUNCH.y + uy * 7, LAUNCH.x + ux * (14 + 50 * l / PULL), LAUNCH.y + uy * (14 + 50 * l / PULL), l >= PULL * 0.98 ? A.GOLD[0] : '#4a72b0', 3, st.time * 3); }
      }
      if (st.state === 'aim' && env.marbles() > 0 && st.shotN < 3 && Math.sin(st.time * 5) > 0) MK.label(ctx, '按住往后拉', 64, 132, '#4a72b0', 'center');
      if (st.state === 'roll' && st.fell > 0) MK.label(ctx, '推下 ' + st.fell, 64, py + 4, A.GOLD[0], 'center');
      MK.led(ctx, env.marbles(), env.marbles() <= 0, st.time);
    },
    down(p) {
      if (p.btn !== 0) return false;
      if (st.state === 'aim') { if (env.marbles() <= 0) { env.deny('marbles'); return true; } return startDrag(p); }
      return true;
    },
    move(p) { if (st.state === 'drag' && st.drag.by !== 'auto') { st.drag.x = p.sx; st.drag.y = p.sy; } },
    up(p) { if (st.state === 'drag' && st.drag.by === p.id) release(); },
    key() { return false; },
    cancel() { if (st.state === 'drag') { st.drag = null; st.state = 'aim'; } },
    leave() { if (st.state === 'drag') { st.drag = null; st.state = 'aim'; } },
    auto,
    inPlay: () => st.state === 'roll' || st.state === 'drag',
    busy: () => st.state === 'drag',
    hint() {
      if (st.state === 'drag') return '松手弹出去（拉回原处不弹）';
      if (st.state !== 'aim' || env.marbles() <= 0) return '';
      return st.shotN < 3 ? '在卡上按住往后拉，弹一个雪球上去；一样大的碰上粘成大的，推下台沿的归你' : '';
    },
    info() {
      return [
        ['台上 ' + balls().length + ' 个 · 一弹落进 ' + env.val('n') + ' 个（最多 ' + CAP + '）', null],
        ['推下去吐 ' + env.val('v') + '×1 / ×3 / ×8 / ×20（看大小）', null],
        ['推下一个最大号 = 大奖', null],
      ];
    },
    onUpgrade() {},
    debug: () => ({ state: st.state, onTable: balls().length, sizes: balls().map(b => b.size).join(''), shots: st.shotN, marbles: env.marbles(), fell: m().kills || 0 }),
  };
});
