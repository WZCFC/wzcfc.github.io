/*
 * 赌场 v2 的钱和全局系统（浏览器 <script> 引入、Node require，同一份）。照 2026-11-10_十八台和全局系统_策划案_v1.md。
 *   十八台：三排、一排六台，进洞（hole）、打怪（fight）、俯视（top）轮着开，开台顺序就是编号。
 *   每台吐自己的筹码、只吃自己那种珠子，珠子用这台的筹码买。门槛盒和升级用上一台的筹码付（基础机用自己的）。
 *   打满 = 这台的升级全买满 → 底座上多一个助手，自己打（统计模型，不跑物理）。
 *   陈列柜（第 3 台出现）、摆件（第 4 台招财猫、第 6 台闹钟……）、转灯（第一排开完）、大奖灯（第二排开头）。
 *   转生 = 会员卡盖章：开一台一个章、打满一个章、打怪每深 10 层一个章；第一排铜章 1 颗星，第二排银章 5 颗，第三排金章 25 颗。
 *   星买技能树（四枝）；转生三次以后挑战开张。
 *   发钱都走 award：小数攒着不丢，所以 +10% 这种加成在一个筹码一个筹码的台上也算数。
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.Rules = api;
}(typeof self !== 'undefined' ? self : globalThis, function () {
  'use strict';

  const range = (a, b) => { const o = []; for (let i = a; i <= b; i++) o.push(i); return o; };
  const STAR = { 1: 1, 2: 5, 3: 25 };   // 铜章、银章、金章各换几颗星

  // ---------- 十八台 ----------
  // ups：{ k, tag, name, unit, vals, costs }，costs[i] 是从 i 档升到 i+1 档的价钱（用 pay 那种筹码付）
  // items：陈列柜三样（luck 碰运气、skill 手上功夫 = 这台的大奖、deep 打得深）
  // bot：助手的统计模型。sec 几秒打一颗珠子，ev 一颗珠子平均吐几个筹码（打满时，乘加成之前）；用 test/botcal.js 拿物理跑出来的
  const MACHINES = [
    { id: 'dog', n: 1, kind: 'hole', name: '基础机', where: '狗屋', chip: 'bone', chipName: '骨头筹码', marble: 'glass', marbleName: '玻璃珠', price: 1,
      short: '点卡抽骨头，按住拉弹簧、松手打。落进有骨头的洞就中。',
      how: '点卡抽骨头，按住拉弹簧、松手打。落进有骨头的洞，小狗叼走骨头，吐骨头筹码。',
      ups: [
        { k: 'n', tag: '签', name: '每发抽几根骨头', unit: '根', vals: range(1, 9), costs: [10, 15, 22, 30, 42, 56, 74, 95] },
        { k: 'v', tag: '价', name: '一根骨头吐几个', unit: '个', vals: [4, 5, 6, 8, 10, 13, 16, 20, 26], costs: [8, 12, 18, 26, 36, 50, 68, 120], cap: 1 },
      ],
      items: [{ k: 'luck', name: '金骨头', how: '抽骨头时抽到金骨头（中了 ×5）' }, { k: 'skill', name: '骨头奖杯', how: '亲手连着三发落进同一个洞' }, { k: 'deep', name: '狗项圈', how: '这一局中满 150 发' }],
      bot: { sec: 8, ev: 20 } },
    { id: 'slime', n: 2, kind: 'fight', name: '草地史莱姆', where: '草地', chip: 'slime', chipName: '史莱姆筹码', marble: 'steel', marbleName: '钢珠', price: 5,
      box: { n: 3, price: 150 },
      short: '拍挡板把钢珠留在台上，撞史莱姆：一下掉一块，碎了吐筹码。',
      how: '拉弹簧把钢珠打上去。左键、右键拍挡板（键盘 Z、M）。撞史莱姆一下掉一块，撞碎了吐筹码。每碎 10 只往下一层：越深越硬，也越值钱。球从两片挡板中间掉下去，这一球就完了。',
      ups: [
        { k: 'n', tag: '签', name: '草地上几只史莱姆', unit: '只', vals: [3, 4, 5, 6], costs: [60, 120, 240] },
        { k: 'h', tag: '速', name: '几下撞碎一只', unit: '下', vals: [3, 2, 1], costs: [150, 450] },
        { k: 'v', tag: '价', name: '一只掉几个筹码', unit: '个', vals: [1, 2, 3, 4, 6, 8], costs: [30, 60, 120, 240, 480] },
      ],
      items: [{ k: 'luck', name: '金史莱姆', how: '撞碎一只金史莱姆（少见，×5）' }, { k: 'skill', name: '绿宝石', how: '亲手一球撞碎 10 只' }, { k: 'deep', name: '草帽', how: '打到第 20 层' }],
      bot: { sec: 22, ev: 70 } },
    { id: 'ring', n: 3, kind: 'top', name: '弹珠出圈', where: '泥地', chip: 'swirl', chipName: '彩珠筹码', marble: 'taw', marbleName: '大母珠', price: 2,
      box: { n: 10, price: 300 },
      short: '在母珠上按住往后拉，松手弹出去。撞出圈的归你。',
      how: '在母珠上按住往后拉，定方向和力度，松手弹出去。撞出圈的弹珠归你。撞出了、母珠又停在圈里，下一杆不花珠子。',
      ups: [
        { k: 'n', tag: '签', name: '每杆补进几颗', unit: '颗', vals: [2, 3, 4, 5], costs: [80, 200, 480] },
        { k: 'v', tag: '价', name: '一颗弹珠值几个', unit: '个', vals: [1, 2, 3, 5, 8], costs: [60, 160, 360, 800] },
        { k: 'a', tag: '准', name: '瞄准线多长', unit: '档', vals: [1, 2, 3], costs: [120, 400] },
      ],
      items: [{ k: 'luck', name: '猫眼珠', how: '补进来一颗猫眼珠，撞出圈（×5）' }, { k: 'skill', name: '冠军珠', how: '亲手一杆撞出 5 颗' }, { k: 'deep', name: '弹珠罐', how: '这一局撞出 300 颗' }],
      bot: { sec: 8, ev: 58 } },
    { id: 'volcano', n: 4, kind: 'hole', name: '火山坑', where: '火山', chip: 'lava', chipName: '岩浆筹码', marble: 'ice', marbleName: '冰珠', price: 1,
      box: { n: 10, price: 900 },
      short: '冰珠填坑，三个坑满了火山喷发。亮着的洞是中奖洞。',
      how: '冰珠掉进岩浆坑，凝成石头。三个坑都填满，火山喷发，一把火山弹撒下来，落进亮洞一颗吐 3 倍。底下亮着的洞是中奖洞，每发自己挑：填坑，还是直接打洞。',
      ups: [
        { k: 'n', tag: '签', name: '底下亮几个洞', unit: '个', vals: [3, 4, 5, 6, 7], costs: [150, 300, 600, 1200] },
        { k: 'v', tag: '价', name: '中一个洞吐几个', unit: '个', vals: [3, 4, 6, 8, 12, 16, 22], costs: [100, 200, 450, 900, 1800, 3200], cap: 1 },
        { k: 's', tag: '速', name: '几颗填满一个坑', unit: '颗', vals: [3, 2, 1], costs: [350, 1000] },
      ],
      items: [{ k: 'luck', name: '金火山弹', how: '喷发时喷出一颗金火山弹，落进亮洞（×5）' }, { k: 'skill', name: '黑曜石', how: '亲手打出的一次喷发，火山弹全落进亮洞' }, { k: 'deep', name: '火山石', how: '这一局喷发 20 次' }],
      bot: { sec: 8, ev: 19 } },
    { id: 'shroom', n: 5, kind: 'fight', name: '蘑菇洞', where: '山洞', chip: 'shroom', chipName: '蘑菇筹码', marble: 'steel', marbleName: '钢珠', price: 5,
      box: { n: 3, price: 400 },
      short: '大史莱姆一碎裂成两只小的，小的吐筹码。接着碎有倍率。',
      how: '蓝史莱姆撞碎了裂成两只小的，小的碎了吐筹码。蘑菇是弹柱，碰一下把球弹开。1.5 秒里接着碎有倍率，每碎 10 只往下一层。',
      ups: [
        { k: 'n', tag: '签', name: '洞里几只大的', unit: '只', vals: [2, 3, 4, 5], costs: [60, 140, 300] },
        { k: 'h', tag: '速', name: '大的几下裂开', unit: '下', vals: [3, 2, 1], costs: [150, 450] },
        { k: 'v', tag: '价', name: '一只小的掉几个', unit: '个', vals: [1, 2, 3, 4, 6], costs: [40, 90, 200, 420] },
        { k: 'x', tag: '倍', name: '连碎每只多加几倍', unit: '倍', vals: [0, 0.5, 1, 1.5], costs: [80, 200, 450] },
      ],
      items: [{ k: 'luck', name: '金蘑菇', how: '撞碎一只金史莱姆（少见，×5）' }, { k: 'skill', name: '蓝宝石', how: '亲手连碎 5 只' }, { k: 'deep', name: '矿工灯', how: '打到第 20 层' }],
      bot: { sec: 24, ev: 192 } },
    { id: 'bowl', n: 6, kind: 'top', name: '保龄球', where: '球道', chip: 'pin', chipName: '球瓶筹码', marble: 'bowl', marbleName: '保龄球', price: 3,
      box: { n: 6, price: 450 },
      short: '在球上按住往后拉，松手滚出去。瓶子滚进后面的坑才算钱。',
      how: '在球上按住往后拉，松手滚出去。一局两球，倒下的瓶留在道上。瓶子滚进后面的坑才算钱，掉沟里不算。全中下一局 ×2，补中 ×1.5。',
      ups: [
        { k: 'g', tag: '签', name: '每局几个金瓶（×3）', unit: '个', vals: [0, 1, 2, 3], costs: [180, 450, 1000] },
        { k: 'v', tag: '价', name: '一个瓶值几个', unit: '个', vals: [1, 2, 3, 4, 6], costs: [120, 300, 650, 1350] },
        { k: 'a', tag: '准', name: '瞄准线多长', unit: '档', vals: [1, 2, 3], costs: [180, 600] },
        { k: 'r', tag: '救', name: '一局里几球有护栏', unit: '球', vals: [0, 1, 2], costs: [360, 1100] },
      ],
      items: [{ k: 'luck', name: '彩虹瓶', how: '一局里冒出彩虹瓶，滚进坑（×10）' }, { k: 'skill', name: '金球', how: '亲手连着三局全中' }, { k: 'deep', name: '球鞋', how: '这一局 300 个瓶进坑' }],
      bot: { sec: 10, ev: 66 } },
    // ---- 第二排、第三排：先挂名字和价签，还没做的盖着布（ready: false）----
    // ---- 第二排：大台（卡面 96 宽）----
    { id: 'ice', n: 7, kind: 'hole', name: '冰窟', where: '冰洞', chip: 'ice', chipName: '冰块筹码', marble: 'iron', marbleName: '铁珠', price: 1,
      box: { n: 10, price: 24000 },   // 第一排的墙：保龄球打满以后手打加助手一分钟一千五左右，要攒十几分钟；转生一次带着技能再来就快
      short: '铁珠砸冰块，碎了放出冻住的珠子。底下碎了，上面的砸下来。',
      how: '按住拉弹簧、松手打铁珠。铁珠撞冰块一下掉一格，格子掉光就碎，冻在里面的珠子蹦出来。铁珠和珠子落进亮着的洞吐筹码。一列底下那块碎了，上面的砸下来，落地自己裂一格。',
      ups: [
        { k: 'n', tag: '签', name: '底下亮几个洞', s: '亮几个洞', unit: '个', vals: [4, 5, 6, 7, 8], costs: [320, 640, 1100, 1800] },
        { k: 'v', tag: '价', name: '中一个洞吐几个', s: '一洞吐几个', unit: '个', vals: [3, 4, 6, 8, 12, 16, 22], costs: [240, 480, 800, 1300, 2000, 4000], cap: 1 },
        { k: 'h', tag: '速', name: '几下砸碎一块冰', s: '几下砸碎', unit: '下', vals: [3, 2, 1], costs: [800, 1900] },
        { k: 'k', tag: '救', name: '一块冰最多冻几颗', s: '每块冻几颗', unit: '颗', vals: [1, 2, 3, 4], costs: [480, 1100, 2100] },
      ],
      items: [{ k: 'luck', name: '金冰珠', how: '冰块里冻着一颗金珠，碎出来落进亮洞（×5）' }, { k: 'skill', name: '冰镐', how: '亲手一发把一整堆（6 块）砸塌' }, { k: 'deep', name: '冰灯', how: '这一局砸碎 100 块冰' }],
      bot: { sec: 8, ev: 54 } },   // 满档手打 240 秒 4609 个（一分钟约 1150），助手取三成五
    { id: 'swamp', n: 8, kind: 'fight', name: '沼泽', where: '沼泽', chip: 'amber', chipName: '琥珀筹码', marble: 'steel', marbleName: '钢珠', price: 40,
      box: { n: 3, price: 1500 },
      short: '琥珀史莱姆把钢珠粘住，粘满三颗撑破，三颗一起放出来。',
      how: '拉弹簧把钢珠打上去，左键、右键拍挡板（键盘 Z、M）。泥史莱姆撞一下掉一块，碎了吐筹码，每碎 10 只往下一层。橙色的琥珀史莱姆把球粘住：台上没球了，发射道马上补一颗，不花珠子；粘满三颗它撑破，三颗一起放出来，台上好几颗球。上面左右两条通道，滚过去救球重新亮。',
      ups: [
        { k: 'n', tag: '签', name: '沼泽里几只泥史莱姆', s: '几只史莱姆', unit: '只', vals: [4, 5, 6, 7], costs: [500, 1000, 1750] },
        { k: 'h', tag: '速', name: '几下撞碎一只', s: '几下撞碎', unit: '下', vals: [3, 2, 1], costs: [900, 2100] },
        { k: 'v', tag: '价', name: '一只掉几个筹码', s: '一只掉几个', unit: '个', vals: [6, 8, 12, 16, 24, 32], costs: [180, 350, 620, 950, 1400] },
        { k: 'x', tag: '倍', name: '多球时每多一颗球多几倍', s: '多球倍数', unit: '倍', vals: [0, 0.5, 1, 1.5], costs: [450, 880, 1600] },
        { k: 's', tag: '救', name: '开球、过通道后几秒里掉了退回', s: '救球几秒', unit: '秒', vals: [2, 3, 4, 6], costs: [350, 700, 1250] },
      ],
      items: [{ k: 'luck', name: '金泥鳅', how: '撞碎一只金史莱姆（少见，×5）' }, { k: 'skill', name: '琥珀里的虫', how: '亲手一次多球碎 10 只' }, { k: 'deep', name: '雨靴', how: '打到第 20 层' }],
      bot: { sec: 20, ev: 750 } },   // 满档手打 240 秒 25626 个（一分钟约 6400；多球、救球都在里面），助手取三成五
    { id: 'coin', n: 9, kind: 'top', name: '推币机', chip: 'coin', chipName: '铜钱筹码', marble: 'coin', marbleName: '硬币', price: 10, box: { n: 20, price: 1800 }, ready: false },
    { id: 'hen', n: 10, kind: 'hole', name: '鸡窝', chip: 'egg', chipName: '鸡蛋筹码', marble: 'sponge', marbleName: '海绵珠', price: 10, box: { n: 10, price: 2400 }, ready: false },
    { id: 'garden', n: 11, kind: 'fight', name: '雨后菜园', chip: 'snail', chipName: '蜗牛筹码', marble: 'steel', marbleName: '钢珠', price: 40, box: { n: 3, price: 3000 }, ready: false },
    { id: 'snow', n: 12, kind: 'top', name: '雪球场', chip: 'snow', chipName: '雪球筹码', marble: 'snowball', marbleName: '雪球', price: 10, box: { n: 20, price: 3600 }, ready: false },
    { id: 'circus', n: 13, kind: 'hole', name: '马戏团', chip: 'circus', chipName: '马戏筹码', marble: 'rubber', marbleName: '橡胶珠', price: 100, box: { n: 10, price: 90000 }, ready: false },
    { id: 'sea', n: 14, kind: 'fight', name: '海底', chip: 'fish', chipName: '海星筹码', marble: 'steel', marbleName: '钢珠', price: 400, box: { n: 3, price: 30000 }, ready: false },
    { id: 'soccer', n: 15, kind: 'top', name: '足球', chip: 'ball', chipName: '足球筹码', marble: 'football', marbleName: '足球', price: 100, box: { n: 10, price: 40000 }, ready: false },
    { id: 'fish', n: 16, kind: 'hole', name: '钓鱼塘', chip: 'hook', chipName: '鱼钩筹码', marble: 'bait', marbleName: '饵团', price: 100, box: { n: 10, price: 50000 }, ready: false },
    { id: 'king', n: 17, kind: 'fight', name: '史莱姆王城', chip: 'crown', chipName: '王冠筹码', marble: 'steel', marbleName: '钢珠', price: 400, box: { n: 3, price: 60000 }, ready: false },
    { id: 'pool', n: 18, kind: 'top', name: '台球', chip: 'eight', chipName: '八号球筹码', marble: 'cue', marbleName: '母球', price: 100, box: { n: 10, price: 80000 }, ready: false },
  ];
  // 后几台（主线 11-11 粗做）的陈列柜三样：碰运气、手上功夫（= 这台的大奖）、打得深
  const LATE_ITEMS = {
    hen: [['luck', '金蛋', '母鸡飞起来，滚出一个金蛋落进亮洞（×5）'], ['skill', '鸡毛掸子', '惹飞一次，4 个蛋落进亮洞'], ['deep', '草编篮', '这一局收满 150 个蛋']],
    fish: [['luck', '金鱼', '钓上一条金鱼（×5）'], ['skill', '老钓竿', '连着钓上 3 条，一条没跑'], ['deep', '鱼篓', '这一局钓满 100 条']],
    circus: [['luck', '金球', '海豹抛出一个金球落进亮洞（×5）'], ['skill', '小丑鼻子', '一发让海豹顶 5 下'], ['deep', '门票本', '这一局谢幕 20 次']],
    snow: [['luck', '冰晶雪球', '补进来一个冰晶雪球推下台边（×5）'], ['skill', '雪人帽', '推下一个最大号的雪球'], ['deep', '雪铲', '这一局推下 200 个']],
    coin: [['luck', '古钱', '滚进来一枚古钱推下台边（×10）'], ['skill', '存钱猪', '一推掉下 8 枚'], ['deep', '钱袋', '这一局掉下 500 枚']],
    soccer: [['luck', '金足球', '滚进来一个金足球进了亮洞（×5）'], ['skill', '帽子戏法', '一脚进 3 个'], ['deep', '奖杯', '这一局进 150 个']],
    pool: [['luck', '八号球', '八号球进袋（×5）'], ['skill', '巧克', '一杆进 4 颗'], ['deep', '球杆架', '这一局进袋 300 颗']],
  };
  for (const M of MACHINES) {
    if (LATE_ITEMS[M.id]) M.items = LATE_ITEMS[M.id].map(([k, name, how]) => ({ k, name, how }));
    M.row = Math.ceil(M.n / 6);
    M.col = (M.n - 1) % 6;
    M.ups = M.ups || [];
    M.items = M.items || [{ k: 'luck', name: '？', how: '还没做' }, { k: 'skill', name: '？', how: '还没做' }, { k: 'deep', name: '？', how: '还没做' }];
    if (M.ready === undefined) M.ready = true;
  }
  const BY = Object.fromEntries(MACHINES.map(M => [M.id, M]));
  const prevOf = id => { const M = BY[id]; return M.n > 1 ? MACHINES[M.n - 2] : null; };
  const payChip = id => (prevOf(id) ? prevOf(id).chip : BY[id].chip);   // 升级、门槛盒用哪种筹码付
  const CHIPS = [...new Set(MACHINES.map(M => M.chip))];

  // ---------- 摆件：兑奖柜下层买，摆在柜台上，转生清空 ----------
  // pay：两种筹码（老台的 + 新台的），costs[i] = [老, 新]
  const TRINKETS = [
    { k: 'cat', name: '招财猫', at: 'volcano', pay: ['bone', 'lava'], max: 5, costs: [[300, 30], [600, 60], [1200, 120], [2400, 240], [4800, 480]], fx: '全场所有筹码 +10%（一级加一次）' },
    { k: 'clock', name: '闹钟', at: 'bowl', pay: ['slime', 'pin'], max: 3, costs: [[300, 40], [800, 100], [2000, 250]], fx: '助手打得快：8 秒一发 → 7 → 6 → 5' },
    { k: 'egg', name: '蛋钟', at: 'ice', pay: ['swirl', 'ice'], max: 3, costs: [[2000, 100], [5000, 300], [12000, 900]], fx: '拧一圈，30 秒里全场筹码 ×2；拧完等 5 分钟' },
    { k: 'glove', name: '手套', at: 'hen', pay: ['lava', 'egg'], max: 4, costs: [[3000, 200], [8000, 500], [20000, 1200], [50000, 3000]], fx: '你亲手打的筹码 +25%（一级加一次）' },
    { k: 'auto', name: '自动换珠机', at: 'snow', pay: ['shroom', 'snow'], max: 1, costs: [[5000, 400]], fx: '你在打的那台珠子打光了，自己用这台的筹码补上' },
    { k: 'piggy', name: '存钱罐', at: 'circus', pay: ['pin', 'circus'], max: 4, costs: [[20000, 500], [50000, 1500], [120000, 4000], [300000, 10000]], fx: '关掉游戏以后助手接着打：最多算 1 → 2 → 4 → 8 小时' },
  ];
  const TBY = Object.fromEntries(TRINKETS.map(t => [t.k, t]));

  // ---------- 技能树：四枝，用星买，转生不清 ----------
  // s：技能树格子上的短名（六个字以内）；name：底下说明条里的全文
  const SKILLS = [
    { k: 'chips', b: 'all', s: '筹码 +25%', name: '全场所有筹码 +25%，一级加一次', max: 4, costs: [1, 3, 6, 12] },
    { k: 'boxOff', b: 'all', s: '门槛盒便宜', name: '门槛盒便宜 20%，一级加一次', max: 2, costs: [4, 10] },
    { k: 'botAim', b: 'all', s: '助手准一点', name: '助手吐的筹码 +15%，一级加一次', max: 2, costs: [3, 8] },
    { k: 'botFast', b: 'all', s: '助手快一点', name: '助手每级快 1 秒一发（本来 8 秒一发）', max: 2, costs: [4, 10] },
    { k: 'catStart', b: 'all', s: '自带招财猫', name: '每局开局柜台上就有一级招财猫', max: 1, costs: [6] },
    { k: 'spin', b: 'all', s: '转灯', name: '转灯：一级亮得勤 → 二级多转 15 秒 → 三级 ×3 变 ×4', max: 3, costs: [3, 6, 12] },
    { k: 'luck', b: 'all', s: '运气 ×2', name: '陈列柜里「碰运气」那样（金骨头、金史莱姆……）冒出来的几率 ×2', max: 1, costs: [5] },
    { k: 'head', b: 'all', s: '起跑', name: '起跑：每局开局第一排六台都开好', max: 1, costs: [40] },
    { k: 'chal', b: 'all', s: '挑战', name: '会员卡机上开「挑战」页（转生三次以后能买）', max: 1, costs: [8], need: 3 },
    { k: 'bones', b: 'hole', s: '开局骨头', name: '基础机开局多抽一根骨头（【签】先送一级）', max: 3, costs: [1, 2, 4] },
    { k: 'marbles', b: 'hole', s: '开局珠子', name: '基础机开局多 3 颗玻璃珠', max: 3, costs: [1, 2, 3] },
    { k: 'pity', b: 'hole', s: '保底', name: '保底：基础机连空 3 发（二级 2 发），下一发多抽一根骨头', max: 2, costs: [2, 3] },
    { k: 'cap', b: 'hole', s: '价上限', name: '进洞的台【价】上限加一档', max: 1, costs: [6] },
    { k: 'gauge', b: 'hole', s: '力度刻度', name: '力度灯上标出每个洞要多大力', max: 1, costs: [4] },
    { k: 'flip', b: 'fight', s: '长挡板', name: '挡板长一格', max: 1, costs: [4] },
    { k: 'save', b: 'fight', s: '救球', name: '救球：开球后 2 秒里掉下去的，钢珠退回来', max: 1, costs: [3] },
    { k: 'extra', b: 'fight', s: '多一只', name: '打怪的台上多一只史莱姆（【签】多一级）', max: 1, costs: [4] },
    { k: 'layer', b: 'fight', s: '层数起步', name: '打怪的台开台从上局最深那层的一半开始', max: 1, costs: [8] },
    { k: 'aim', b: 'top', s: '瞄准线', name: '瞄准线也画出被撞的那颗往哪走', max: 1, costs: [4] },
    { k: 'more', b: 'top', s: '多两颗', name: '弹珠出圈开台时圈里多两颗弹珠', max: 1, costs: [3] },
    { k: 'rail', b: 'top', s: '护栏', name: '保龄球【救】开台就有一级：第一球有护栏', max: 1, costs: [4] },
  ];
  const SBY = Object.fromEntries(SKILLS.map(s => [s.k, s]));
  const BUST_GIFTS = ['bones', 'marbles', 'pity'];

  // ---------- 挑战：转生三次、买了"挑战"以后，在会员卡机上挑一条开一局 ----------
  const CHALLENGES = [
    { k: 'nobot', name: '不准用助手', rule: '这一局助手不上岗', goal: 'shroom', stars: 15 },
    { k: 'three', name: '开局只有 3 颗', rule: '基础机开局只有 3 颗珠子、1 根骨头，技能树里进洞那枝不算', goal: 'volcano', stars: 10 },
    { k: 'half', name: '筹码减半', rule: '这一局所有筹码 ×0.5', goal: 'bowl', stars: 20 },
  ];

  // =========================================================================
  // 存档
  // =========================================================================
  function newMeta() {
    return { stars: 0, skills: {}, cab: {}, medals: {}, tiers: 1, deepest: {}, busts: 0, rebirths: 0, runs: 1, free: 0, seen: {}, chal: null, totalStars: 0 };
  }
  function blankMachine() { return { marbles: 0, ups: {}, frac: 0, shots: 0, hits: 0, kills: 0, layer: 1, lk: 0, deep: 0, streak: [], misses: 0, botT: 0, potHit: 0 }; }
  function newRun(meta) {
    const chips = {}; for (const c of CHIPS) chips[c] = 0;
    const m = {}; for (const M of MACHINES) m[M.id] = blankMachine();
    const run = { chips, m, open: { dog: true }, maxed: {}, trinkets: {}, pot: 0, jackShots: 0, potWon: 0, spin: { id: null, t: 0, next: 150 }, egg: { t: 0, cool: 0 }, time: 0, earned: 0, chal: meta.chal || null };
    for (const t of TRINKETS) run.trinkets[t.k] = 0;
    if (lv(meta, 'catStart')) run.trinkets.cat = 1;
    const three = run.chal === 'three';
    run.m.dog.marbles = three ? 3 : 5 + 3 * (three ? 0 : lv(meta, 'marbles'));
    run.m.dog.ups.n = three ? 0 : Math.min(8, lv(meta, 'bones'));
    if (lv(meta, 'head')) for (const M of MACHINES.slice(1, 6)) openMachine({ meta, run }, M.id, true);
    return run;
  }
  function newGame() { const meta = newMeta(); return { v: 2, meta, run: newRun(meta) }; }
  const lv = (meta, k) => meta.skills[k] || 0;

  // =========================================================================
  // 升级
  // =========================================================================
  const upDef = (id, k) => BY[id].ups.find(u => u.k === k);
  const upLvl = (g, id, k) => g.run.m[id].ups[k] || 0;
  // 这一档最多能买到几级：cap 那几档要技能树"【价】上限加一档"才开
  function upMax(g, id, k) { const u = upDef(id, k); return u.vals.length - 1 - (u.cap && !(BY[id].kind === 'hole' && lv(g.meta, 'cap')) ? u.cap : 0); }
  function val(g, id, k) {
    const u = upDef(id, k); let v = u.vals[Math.min(upLvl(g, id, k), u.vals.length - 1)];
    if (k === 'n' && BY[id].kind === 'fight' && lv(g.meta, 'extra')) v += 1;          // 开台时多一只
    if (k === 'r' && id === 'bowl' && lv(g.meta, 'rail')) v = Math.max(v, 1);          // 护栏开台一级
    return v;
  }
  const nextVal = (g, id, k) => (upLvl(g, id, k) >= upMax(g, id, k) ? null : upDef(id, k).vals[upLvl(g, id, k) + 1]);
  const upCost = (g, id, k) => (upLvl(g, id, k) >= upMax(g, id, k) ? null : upDef(id, k).costs[upLvl(g, id, k)]);
  function buyUp(g, id, k) {
    const c = upCost(g, id, k), pay = payChip(id);
    if (c == null || !g.run.open[id] || g.run.chips[pay] < c) return false;
    g.run.chips[pay] -= c;
    g.run.m[id].ups[k] = upLvl(g, id, k) + 1;
    checkMaxed(g, id);
    return true;
  }
  // 打满：这台的升级全买满（cap 那档不算）
  function allMaxed(g, id) { return BY[id].ups.every(u => upLvl(g, id, u.k) >= u.vals.length - 1 - (u.cap || 0)); }
  function checkMaxed(g, id) {
    if (!g.run.maxed[id] && allMaxed(g, id)) { g.run.maxed[id] = true; g.run.m[id].botT = 0; return true; }
    return false;
  }

  // =========================================================================
  // 开台、珠子
  // =========================================================================
  const marblePrice = (g, id) => BY[id].price;
  function boxPrice(g, id) { const M = BY[id]; return M.box ? Math.round(M.box.price * (1 - 0.2 * lv(g.meta, 'boxOff'))) : null; }
  // 补一盒：开了台以后珠子打光、这台的筹码又不够买，用上一台的筹码补一盒。门槛价的三成（门槛贵，补一盒不能跟着变成坑）
  function refillPrice(g, id) { const p = boxPrice(g, id); return p == null ? null : Math.max(10, Math.round(p * 0.3 / 10) * 10); }
  const canOpen = (g, id) => { const p = prevOf(id); return !!(p && g.run.open[p.id] && !g.run.open[id] && BY[id].ready); };
  function openMachine(g, id, free) {
    const M = BY[id];
    g.run.open[id] = true;
    g.run.m[id].marbles += M.box ? M.box.n : 0;
    if (M.kind === 'fight' && lv(g.meta, 'layer')) g.run.m[id].layer = Math.max(1, Math.floor((g.meta.deepest[id] || 0) / 2));
    // 陈列柜一层齐了：这一类六台开台时【签】直接一级
    if (shelfFull(g, M.kind) && M.ups[0] && !g.run.m[id].ups[M.ups[0].k]) g.run.m[id].ups[M.ups[0].k] = 1;
    if (M.row > g.meta.tiers) g.meta.tiers = M.row;   // 装修：多出一层台阶，转生也不拆
    checkMaxed(g, id);
    if (!free && g.run.chal && CHALLENGES.find(c => c.k === g.run.chal).goal === id) finishChallenge(g);
    return true;
  }
  // 门槛盒：没开的台 = 开台；开了的台 = 再买一盒（打光了，用上一台的筹码先养着）
  function buyBox(g, id) {
    const M = BY[id], open = !!g.run.open[id], p = open ? refillPrice(g, id) : boxPrice(g, id), pay = payChip(id);
    if (p == null || g.run.chips[pay] < p) return false;
    if (!open) { if (!canOpen(g, id)) return false; g.run.chips[pay] -= p; return openMachine(g, id); }
    g.run.chips[pay] -= p; g.run.m[id].marbles += M.box.n;
    return true;
  }
  function buyMarbles(g, id, n) {
    const c = n * marblePrice(g, id), M = BY[id];
    if (n <= 0 || !g.run.open[id] || g.run.chips[M.chip] < c) return false;
    g.run.chips[M.chip] -= c; g.run.m[id].marbles += n;
    return true;
  }
  // 打一发：扣一颗珠子
  function spend(g, id) { const m = g.run.m[id]; if (m.marbles <= 0) return false; m.marbles -= 1; m.shots += 1; jackTick(g, 1); return true; }
  function refund(g, id) { const m = g.run.m[id]; m.marbles += 1; m.shots -= 1; g.run.jackShots = Math.max(0, g.run.jackShots - 1); }

  // =========================================================================
  // 发钱
  // =========================================================================
  const itemsOf = (g, id) => ['luck', 'skill', 'deep'].filter(k => g.meta.cab[id + '.' + k]).length;
  const shelfFull = (g, kind) => MACHINES.filter(M => M.kind === kind).every(M => itemsOf(g, M.id) === 3);
  const spinMult = g => (lv(g.meta, 'spin') >= 3 ? 4 : 3);
  function mult(g, id, hand) {
    let x = (1 + 0.25 * lv(g.meta, 'chips')) * (1 + 0.1 * (g.run.trinkets.cat || 0)) * (1 + 0.05 * itemsOf(g, id)) * (itemsOf(g, id) === 3 ? 1.1 : 1);
    if (hand) { x *= 1 + 0.25 * (g.run.trinkets.glove || 0); if (g.run.spin.id === id && g.run.spin.t > 0) x *= spinMult(g); }
    if (g.run.egg.t > 0) x *= 2;
    if (g.run.chal === 'half') x *= 0.5;
    return x;
  }
  // 发 base 个筹码（乘全场加成），小数攒着下次补上。返回这次实际到手几个
  function award(g, id, base, hand) {
    const m = g.run.m[id], raw = base * mult(g, id, hand) + m.frac, n = Math.floor(raw + 1e-9);
    m.frac = raw - n;
    g.run.chips[BY[id].chip] += n;
    g.run.earned += n;
    return n;
  }

  // =========================================================================
  // 陈列柜、大奖
  // =========================================================================
  // 找到一样：返回 true 表示第一次找到（要放烟花、进柜子）
  function find(g, id, k) {
    const key = id + '.' + k;
    if (g.meta.cab[key]) return false;
    g.meta.cab[key] = 1;
    return true;
  }
  const luckP = (g, p) => p * (lv(g.meta, 'luck') ? 2 : 1);   // 碰运气那样的几率
  // 大奖：亲手打出这台"手上功夫"那一下。第一次进陈列柜；有大奖灯以后每次都赢走锅里的星
  function jackpot(g, id) {
    const first = find(g, id, 'skill');
    let won = 0;
    if (g.meta.tiers >= 2 && g.run.pot > 0) { won = g.run.pot; g.run.potWon += won; g.run.pot = 0; }
    g.run.m[id].potHit += 1;
    return { first, won };
  }
  // 大奖灯：全场每打一发都往上跳，每攒满 100 发多 1 颗星（第二排装修以后才挂起来）
  function jackTick(g, n) {
    if (g.meta.tiers < 2) return;
    g.run.jackShots += n;
    while (g.run.jackShots >= 100) { g.run.jackShots -= 100; g.run.pot += 1; }
  }
  // 打怪的层数：每碎 10 只升一层；每深 10 层盖一个章
  function onKill(g, id, n) {
    const m = g.run.m[id];
    m.kills += n; m.lk += n;
    let up = 0;
    while (m.lk >= 10) { m.lk -= 10; m.layer += 1; up += 1; }
    m.deep = Math.max(m.deep, m.layer);
    if (m.layer > (g.meta.deepest[id] || 0)) g.meta.deepest[id] = m.layer;
    return up;
  }
  // 第 L 层：史莱姆多几下才碎（每 4 层多一下）、一只值几倍（每层 +20%）
  const layerHp = L => Math.floor((L - 1) / 4);
  const layerMult = L => 1 + 0.2 * (L - 1);

  // =========================================================================
  // 盖章、转生
  // =========================================================================
  // 这一局的会员卡：每台 [开台, 打满, 层数章几个]
  function stamps(g) {
    const out = [];
    for (const M of MACHINES) {
      const open = !!g.run.open[M.id] && M.n > 1, maxed = !!g.run.maxed[M.id];
      const deep = M.kind === 'fight' ? Math.floor((g.run.m[M.id].deep || 0) / 10) : 0;
      out.push({ id: M.id, row: M.row, open, maxed, deep, stars: (open + maxed + deep) * STAR[M.row] });
    }
    return out;
  }
  const runStars = g => stamps(g).reduce((a, s) => a + s.stars, 0) + g.run.potWon;
  function endRun(g, bust) {
    const stars = runStars(g);
    let gift = null;
    g.meta.stars += stars; g.meta.totalStars += stars;
    if (bust) {
      g.meta.busts += 1;
      const k = g.meta.busts <= BUST_GIFTS.length ? BUST_GIFTS.find(x => !lv(g.meta, x)) : null;
      if (k) { g.meta.skills[k] = 1; gift = k; }
    }
    g.meta.rebirths += 1;
    if (g.meta.rebirths === 1) g.meta.free += 1;
    g.meta.chal = null;
    g.run = null;
    return { stars, gift, bust: !!bust };
  }
  function startRun(g) { g.meta.runs += 1; g.run = newRun(g.meta); return g.run; }
  // 第一次转生白送一样：价钱 6 颗星以内的随便挑一样
  function skillCost(g, k) { const s = SBY[k]; if (lv(g.meta, k) >= s.max) return null; const c = s.costs[lv(g.meta, k)]; return g.meta.free > 0 && c <= 6 ? 0 : c; }
  const skillLocked = (g, k) => !!(SBY[k].need && g.meta.rebirths < SBY[k].need);
  function buySkill(g, k) {
    const c = skillCost(g, k);
    if (c == null || skillLocked(g, k) || g.meta.stars < c) return false;
    if (c === 0 && g.meta.free > 0) g.meta.free -= 1; else g.meta.stars -= c;
    g.meta.skills[k] = lv(g.meta, k) + 1;
    return true;
  }
  function startChallenge(g, k) { if (!lv(g.meta, 'chal')) return false; g.meta.chal = k; return true; }
  function finishChallenge(g) {
    const C = CHALLENGES.find(c => c.k === g.run.chal);
    if (!C) return null;
    const first = !g.meta.medals[C.k];
    g.meta.medals[C.k] = 1;
    if (first) { g.meta.stars += C.stars; g.meta.totalStars += C.stars; }
    g.run.chal = null; g.meta.chal = null;
    g.run.chalDone = { k: C.k, first, stars: first ? C.stars : 0 };
    return g.run.chalDone;
  }

  // =========================================================================
  // 摆件
  // =========================================================================
  const trinketShown = (g, k) => !!g.run.open[TBY[k].at];
  function trinketCost(g, k) { const t = TBY[k], l = g.run.trinkets[k]; return l >= t.max ? null : t.costs[l]; }
  function buyTrinket(g, k) {
    const t = TBY[k], c = trinketCost(g, k);
    if (!c || !trinketShown(g, k) || g.run.chips[t.pay[0]] < c[0] || g.run.chips[t.pay[1]] < c[1]) return false;
    g.run.chips[t.pay[0]] -= c[0]; g.run.chips[t.pay[1]] -= c[1];
    g.run.trinkets[k] += 1;
    return true;
  }
  function windEgg(g) { if (!g.run.trinkets.egg || g.run.egg.cool > 0) return false; g.run.egg.t = 30 + 10 * (g.run.trinkets.egg - 1); g.run.egg.cool = 300 - 60 * (g.run.trinkets.egg - 1); return true; }

  // =========================================================================
  // 每秒走一下：助手、转灯、蛋钟。lifted = 你手上拿着的那台（它的助手停手）
  // 返回 [{ type: 'bot', id, n }, { type: 'spin', id }, ...] 给画面放动画
  // =========================================================================
  const spinUnlocked = g => MACHINES.slice(0, 6).every(M => g.run.open[M.id]);
  const botSec = g => Math.max(3, 8 - (g.run.trinkets.clock || 0) - lv(g.meta, 'botFast'));
  function botEv(g, id) {
    const M = BY[id];
    if (id === 'dog') return val(g, 'dog', 'v');
    return M.bot.ev;
  }
  function tick(g, dt, lifted, rnd) {
    const run = g.run, ev = [];
    rnd = rnd || Math.random;
    run.time += dt;
    // 助手
    if (run.chal !== 'nobot') for (const M of MACHINES) {
      if (!run.maxed[M.id] || M.id === lifted || !M.bot) continue;
      const m = run.m[M.id], sec = M.bot.sec * botSec(g) / 8;
      m.botT += dt;
      while (m.botT >= sec) {
        m.botT -= sec;
        if (m.marbles <= 0) { if (run.chips[M.chip] >= M.price) { run.chips[M.chip] -= M.price; m.marbles += 1; } else break; }
        m.marbles -= 1; m.shots += 1; jackTick(g, 1);
        const base = botEv(g, M.id) * (0.6 + 0.8 * rnd()) * (1 + 0.15 * lv(g.meta, 'botAim'));
        const n = award(g, M.id, base, false);
        if (rnd() < luckP(g, 0.004) && find(g, M.id, 'luck')) ev.push({ type: 'find', id: M.id, k: 'luck' });
        ev.push({ type: 'bot', id: M.id, n });
      }
    }
    // 转灯
    if (spinUnlocked(g)) {
      const S = run.spin;
      if (S.t > 0) { S.t -= dt; if (S.t <= 0) { S.t = 0; S.id = null; ev.push({ type: 'spinEnd' }); } }
      else {
        S.next -= dt * (lv(g.meta, 'spin') >= 1 ? 1.5 : 1);
        if (S.next <= 0) {
          const opened = MACHINES.filter(M => run.open[M.id] && M.ready);
          S.id = opened[Math.floor(rnd() * opened.length)].id;
          S.t = 30 + (lv(g.meta, 'spin') >= 2 ? 15 : 0);
          S.next = 120 + 60 * rnd();
          ev.push({ type: 'spin', id: S.id });
        }
      }
    }
    if (run.egg.t > 0) run.egg.t = Math.max(0, run.egg.t - dt);
    if (run.egg.cool > 0) run.egg.cool = Math.max(0, run.egg.cool - dt);
    return ev;
  }
  // 离线：存钱罐，最多算几个小时
  function offline(g, sec) {
    const hrs = [0, 1, 2, 4, 8][g.run.trinkets.piggy || 0];
    const t = Math.min(sec, hrs * 3600);
    if (t <= 0) return 0;
    let got = 0;
    for (let s = 0; s < t; s += 4) for (const e of tick(g, Math.min(4, t - s), null)) if (e.type === 'bot') got += e.n;
    return got;
  }

  // =========================================================================
  // 破产：没有助手在打，开了的台都打不了（没珠子、买不起珠子、也买不起一盒）
  // =========================================================================
  function canPlay(g, id) {
    const M = BY[id], m = g.run.m[id];
    if (!g.run.open[id]) return false;
    if (m.marbles > 0) return true;
    if (g.run.chips[M.chip] >= M.price) return true;
    const p = refillPrice(g, id);
    return p != null && g.run.chips[payChip(id)] >= p;
  }
  function isBust(g) {
    if (Object.keys(g.run.maxed).length && g.run.chal !== 'nobot') return false;
    return !MACHINES.some(M => canPlay(g, M.id));
  }

  // ---------- 读档 ----------
  function load(raw) {
    try {
      const d = typeof raw === 'string' ? JSON.parse(raw) : raw;
      if (!d || d.v !== 2 || !d.meta) return null;
      const g = newGame();
      Object.assign(g.meta, d.meta);
      for (const k of ['skills', 'cab', 'medals', 'deepest', 'seen']) g.meta[k] = Object.assign({}, d.meta[k] || {});
      if (d.run) {
        const r = newRun(g.meta);
        for (const k of ['open', 'maxed', 'trinkets', 'spin', 'egg']) r[k] = Object.assign(r[k] || {}, d.run[k] || {});
        Object.assign(r.chips, d.run.chips || {});
        for (const M of MACHINES) r.m[M.id] = Object.assign(blankMachine(), (d.run.m || {})[M.id] || {});
        for (const k of ['pot', 'jackShots', 'potWon', 'time', 'earned', 'chal']) if (d.run[k] !== undefined) r[k] = d.run[k];
        g.run = r;
      } else g.run = null;
      return g;
    } catch (e) { return null; }
  }

  return {
    MACHINES, BY, CHIPS, TRINKETS, TBY, SKILLS, SBY, CHALLENGES, STAR, BUST_GIFTS,
    prevOf, payChip, newMeta, newRun, newGame, lv,
    upDef, upLvl, upMax, val, nextVal, upCost, buyUp, allMaxed, checkMaxed,
    marblePrice, boxPrice, refillPrice, canOpen, openMachine, buyBox, buyMarbles, spend, refund,
    itemsOf, shelfFull, mult, award, find, luckP, jackpot, jackTick, onKill, layerHp, layerMult, spinMult,
    stamps, runStars, endRun, startRun, skillCost, skillLocked, buySkill, startChallenge, finishChallenge,
    trinketShown, trinketCost, buyTrinket, windEgg, spinUnlocked, botSec, botEv, tick, offline, canPlay, isBust, load,
  };
}));
