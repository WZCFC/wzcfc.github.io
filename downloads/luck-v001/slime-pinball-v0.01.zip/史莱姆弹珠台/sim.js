/*
 * 赌场版 · 基础机的规则和物理（浏览器用 <script> 引入，Node 用 require，同一份代码）
 * 坐标就是机台界面里"珠子钉子那一层"的格子（卡面一格 = 这层两格），和画面一一对应：
 *   台面 x 14..114、y 20..154。直顶 y=20，左上、右上各一个 45° 斜角（20 格）。
 *   右边 x 103..114 是发射道，推头和弹簧在发射道底下。
 *   底下一排 9 个洞：洞 i 占 x 14+10i .. 24+10i，洞口在 y=146。珠子碰到洞口那一行就算进了哪个洞。
 * 一发：按徽章抽骨头（k 根骨头落在 k 个不同的洞上）→ 按住拉弹簧、松手发射 → 珠子落洞。落进有骨头的洞就中。
 * 固定步长 1/480 秒。结构固定：同一个力度永远落同一个洞，随机只来自抽骨头和人手。
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.Sim = api;
}(typeof self !== 'undefined' ? self : globalThis, function () {
  'use strict';

  const DT = 1 / 480;
  const X0 = 14, X1 = 114, Y0 = 20, STRIP = 146, YB = 154, CH = 20;
  const LANE_X = 103, LANE_TOP = 50, LANE_CX = 108.75;
  const BALL_R = 3.5, PEG_R = 2;
  const HOLES = 9, HOLE_W = 10;
  const HEAD_Y = 142;                  // 推头顶面（不拉的时候）
  const REST_Y = HEAD_Y - BALL_R;      // 珠子停在推头上
  const PULL = 8;                      // 拉满时推头往下走几格
  const CAPTURE_Y = STRIP - BALL_R;    // 珠子下沿碰到洞口
  const CELL = 12, GW = 11, GH = 14;

  const DEFAULTS = {
    gravity: 208,
    reach: 99,          // 推头到右上斜角的高度（算发射速度用）
    pDead: 0.05,        // 力度低于它冲不上去，珠子退回推头
    vOver: 72,          // 刚好翻过发射道的那一下，撞到斜角时的速度
    vMax: 177,          // 力度 1 时，撞到斜角那一刻的速度
    // 钉阵：5 排三角格，横距 15、排距 16（test/tune.js 随机搜出来的，手抖测试和灰盒差不多）
    pegRows: 5, pegDX: 15, pegDY: 16, pegY0: 56, pegXe: 20, pegXo: 28,
    bumpR: 2.5,         // 墙上的小凸包：这一排最外的钉子离墙远，就在墙上补一个，不让珠子贴墙一路滑下去
    guard: [6, 6],      // 发射道顶上往左下的小斜板（宽、高）
    pegE: 0.26, pegF: 0.1, wallE: 0.4, wallF: 0.02, roofE: 0.15, roofF: 0.01, laneE: 0.3,
    door: { cx: 64, cy: 126, r: 14 },   // 狗屋门洞：这一块不钉钉子
    frictionMin: 8.3, hitMin: 12.5,
    shotTimeLimit: 12,
    rewards: [4, 5, 6, 8, 10, 13, 16, 20],          // 一根骨头吐几个筹码（8 档）
    boneCosts: [10, 15, 22, 30, 42, 56, 74, 95],    // 骨头 1→2 …… 8→9 的价钱
    rewardCosts: [8, 12, 18, 26, 36, 50, 68],       // 奖励 0→1 …… 6→7 档的价钱
  };

  function rng(seed) {
    let a = seed >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      let t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  // ---------- 场地 ----------
  function addSeg(s, x0, y0, x1, y1, kind, e, f, inX, inY) {
    const dx = x1 - x0, dy = y1 - y0, len = Math.hypot(dx, dy);
    let nx = -dy / len, ny = dx / len;
    if (nx * (inX - x0) + ny * (inY - y0) < 0) { nx = -nx; ny = -ny; }
    s.colliders.push({ id: s.colliders.length, type: 'seg', kind, x0, y0, x1, y1, dx, dy, len2: len * len, nx, ny, e, f, mark: 0, twoSided: false });
  }
  function addWall(s, x0, y0, x1, y1, kind, e, f) {   // 两面都挡的薄板（发射道内墙）
    addSeg(s, x0, y0, x1, y1, kind, e, f, x0 - 1, y0);
    s.colliders[s.colliders.length - 1].twoSided = true;
  }
  function addCircle(s, x, y, r, kind, e, f) {
    s.colliders.push({ id: s.colliders.length, type: 'circle', kind, x, y, r, e, f, mark: 0 });
  }

  // 钉阵：三角格，单双排错开半格；门洞里不钉；离墙太近、会把珠子夹住的不钉
  // 返回 [x, y, r]：r = PEG_R 是钉子，r = bumpR 是墙上的凸包
  function pegPositions(cfg) {
    const c = Object.assign({}, DEFAULTS, cfg || {}), out = [];
    const pass = 2 * BALL_R + 1;             // 珠子要过得去的缝
    for (let r = 0; r < c.pegRows; r++) {
      const y = c.pegY0 + r * c.pegDY, x0 = r % 2 ? c.pegXo : c.pegXe;
      const row = [];
      for (let x = x0; x <= LANE_X; x += c.pegDX) {
        if (x - PEG_R - X0 < pass || LANE_X - x - PEG_R < pass) continue;
        if (c.door) {
          const d = y >= c.door.cy ? Math.abs(x - c.door.cx) : Math.hypot(x - c.door.cx, y - c.door.cy);
          if (d < c.door.r) continue;
        }
        row.push(x);
      }
      for (const x of row) out.push([x, y, PEG_R]);
      if (c.bumpR && row.length) {
        if (row[0] - PEG_R - X0 - c.bumpR > pass + 2) out.push([X0, y, c.bumpR]);
        if (LANE_X - row[row.length - 1] - PEG_R - c.bumpR > pass + 2 && y > LANE_TOP + 8) out.push([LANE_X - 2, y, c.bumpR]);   // 往左挪 2 格，不伸进发射道
      }
    }
    return out;
  }

  function build(s) {
    const c = s.cfg;
    addSeg(s, X0, Y0 + CH, X0, YB, 'wall', c.wallE, c.wallF, 60, 90);
    addSeg(s, X1, Y0 + CH, X1, YB, 'wall', c.wallE, c.wallF, 60, 90);
    addSeg(s, X0, Y0 + CH, X0 + CH, Y0, 'roof', c.roofE, c.roofF, 60, 90);
    addSeg(s, X0 + CH, Y0, X1 - CH, Y0, 'roof', c.roofE, c.roofF, 60, 90);
    addSeg(s, X1 - CH, Y0, X1, Y0 + CH, 'roof', c.roofE, c.roofF, 60, 90);
    addWall(s, LANE_X, LANE_TOP, LANE_X, YB, 'lane', c.laneE, 0.02);
    addSeg(s, LANE_X, HEAD_Y, X1, HEAD_Y, 'head', 0.1, 0.2, LANE_CX, 100);
    if (c.guard) addSeg(s, LANE_X, LANE_TOP, LANE_X - c.guard[0], LANE_TOP + c.guard[1], 'guard', 0.3, 0.02, LANE_X - 8, LANE_TOP - 4);
    for (const [x, y, r] of pegPositions(c)) addCircle(s, x, y, r, r === PEG_R ? 'peg' : 'bump', c.pegE, c.pegF);
  }

  function bounds(c) {
    if (c.type === 'circle') return [c.x - c.r, c.y - c.r, c.x + c.r, c.y + c.r];
    return [Math.min(c.x0, c.x1) - 1, Math.min(c.y0, c.y1) - 1, Math.max(c.x0, c.x1) + 1, Math.max(c.y0, c.y1) + 1];
  }
  const cellX = v => Math.max(0, Math.min(GW - 1, Math.floor(v / CELL)));
  const cellY = v => Math.max(0, Math.min(GH - 1, Math.floor(v / CELL)));
  function buildGrid(s) {
    const cells = Array.from({ length: GW * GH }, () => []);
    s.colliders.forEach((c, i) => {
      const [x0, y0, x1, y1] = bounds(c);
      for (let cy = cellY(y0 - BALL_R); cy <= cellY(y1 + BALL_R); cy++) for (let cx = cellX(x0 - BALL_R); cx <= cellX(x1 + BALL_R); cx++) cells[cy * GW + cx].push(i);
    });
    s.cells = cells;
  }

  // ---------- 碰撞 ----------
  function contact(c, b) {
    const r = b.r;
    if (c.type === 'circle') {
      const dx = b.x - c.x, dy = b.y - c.y, rr = r + c.r, d2 = dx * dx + dy * dy;
      if (d2 >= rr * rr) return null;
      const d = Math.sqrt(d2) || 1e-6;
      return { col: c, depth: rr - d, nx: dx / d, ny: dy / d, px: c.x + dx / d * c.r, py: c.y + dy / d * c.r };
    }
    let t = ((b.x - c.x0) * c.dx + (b.y - c.y0) * c.dy) / c.len2;
    t = t < 0 ? 0 : t > 1 ? 1 : t;
    const qx = c.x0 + c.dx * t, qy = c.y0 + c.dy * t;
    const dx = b.x - qx, dy = b.y - qy, d2 = dx * dx + dy * dy;
    if (d2 >= r * r) return null;
    const d = Math.sqrt(d2);
    if (c.twoSided) {
      if (d < 1e-6) return { col: c, depth: r, nx: c.nx, ny: c.ny, px: qx, py: qy };
      return { col: c, depth: r - d, nx: dx / d, ny: dy / d, px: qx, py: qy };
    }
    // 单面墙：从里面那一面推回去
    const side = dx * c.nx + dy * c.ny;
    if (side < 0) return { col: c, depth: r + (-side), nx: c.nx, ny: c.ny, px: qx, py: qy };
    if (d < 1e-6) return { col: c, depth: r, nx: c.nx, ny: c.ny, px: qx, py: qy };
    return { col: c, depth: r - d, nx: dx / d, ny: dy / d, px: qx, py: qy };
  }
  function deepest(s, b) {
    const stamp = ++s.stamp;
    let best = null;
    for (let cy = cellY(b.y - b.r); cy <= cellY(b.y + b.r); cy++) for (let cx = cellX(b.x - b.r); cx <= cellX(b.x + b.r); cx++) {
      const list = s.cells[cy * GW + cx];
      for (let k = 0; k < list.length; k++) {
        const c = s.colliders[list[k]];
        if (c.mark === stamp) continue;
        c.mark = stamp;
        const h = contact(c, b);
        if (h && (!best || h.depth > best.depth)) best = h;
      }
    }
    return best;
  }
  function emit(s, e) { if (!s.quiet) s.events.push(e); }
  function resolve(s, b, h) {
    const col = h.col;
    b.x += h.nx * h.depth;
    b.y += h.ny * h.depth;
    const vn = b.vx * h.nx + b.vy * h.ny;
    if (vn >= 0) return;
    const impact = -vn, tx = -h.ny, ty = h.nx;
    let vt = b.vx * tx + b.vy * ty;
    const vnOut = impact * col.e;
    // 只有真撞上才有摩擦；轻轻贴着不给，珠子就不会稳稳停在钉子尖上
    const dvt = impact > s.cfg.frictionMin ? Math.min(Math.abs(vt), col.f * (impact + vnOut)) : 0;
    vt -= Math.sign(vt) * dvt;
    b.vx = h.nx * vnOut + tx * vt;
    b.vy = h.ny * vnOut + ty * vt;
    if (impact > s.cfg.hitMin) emit(s, { type: 'hit', kind: col.kind, id: col.id, x: h.px, y: h.py, impact });
  }

  // ---------- 一发 ----------
  // 力度 → 发射速度：让"撞到右上斜角那一刻的速度"和力度成直线，各个洞在力度上分得匀一些
  // 力度 < pDead：冲不过发射道顶，退回推头；pDead 以上从"刚好翻过去"线性涨到 vMax
  function launchSpeed(cfg, p) {
    const base = Math.sqrt(2 * cfg.gravity * cfg.reach);
    const vc = p < cfg.pDead ? cfg.vOver * 0.5 * p / cfg.pDead
      : cfg.vOver + (cfg.vMax - cfg.vOver) * (p - cfg.pDead) / (1 - cfg.pDead);
    return Math.sqrt(vc * vc + base * base);
  }

  function createMachine(seed, overrides) {
    const cfg = Object.assign({}, DEFAULTS, overrides || {});
    const s = {
      seed, cfg, colliders: [], cells: null, stamp: 0, quiet: false, events: [],
      lotRng: rng(seed), phase: 'idle', bones: [], ball: null, power: 0, shotTime: 0, time: 0,
      shots: 0, hits: 0, fallbacks: 0, history: [],
    };
    build(s);
    buildGrid(s);
    placeBall(s);
    return s;
  }
  function placeBall(s) { s.ball = { x: LANE_CX, y: REST_Y, vx: 0, vy: 0, r: BALL_R }; }

  // 抽骨头：k 根骨头落在 k 个不同的洞上（每发抽一次，抽完必须打掉这一发）
  function drawBones(s, k, forced) {
    if (s.phase !== 'idle') return null;
    const idx = [];
    for (let i = 0; i < HOLES; i++) idx.push(i);
    const n = Math.max(1, Math.min(HOLES, k));
    for (let i = 0; i < n; i++) {
      const j = i + Math.floor(s.lotRng() * (HOLES - i));
      const t = idx[i]; idx[i] = idx[j]; idx[j] = t;
    }
    s.bones = (forced || idx.slice(0, n)).slice().sort((a, b) => a - b);
    s.phase = 'ready';
    emit(s, { type: 'drawn', bones: s.bones.slice() });
    return s.bones;
  }

  function launch(s, power) {
    if (s.phase !== 'ready') return false;
    const p = Math.max(0, Math.min(1, power));
    placeBall(s);
    s.power = p;
    s.ball.vy = -launchSpeed(s.cfg, p);
    s.phase = 'flying';
    s.shotTime = 0;
    s.shots += 1;
    emit(s, { type: 'launch', power: p });
    return true;
  }

  function land(s, hole) {
    const hit = s.bones.indexOf(hole) >= 0;
    if (hit) s.hits += 1;
    s.history.push({ hole, hit, power: s.power, time: s.shotTime });
    s.phase = 'landed';
    emit(s, { type: 'land', hole, hit, x: s.ball.x, y: s.ball.y });
  }

  // 没冲上去（或卡住超时）：珠子退回推头，不算这一发，骨头不变
  function fallback(s, stuck) {
    s.shots -= 1;
    s.fallbacks += 1;
    placeBall(s);
    s.phase = 'ready';
    emit(s, { type: 'fallback', stuck: !!stuck });
  }

  function step(s) {
    if (s.phase !== 'flying') return;
    const b = s.ball;
    b.vy += s.cfg.gravity * DT;
    b.x += b.vx * DT;
    b.y += b.vy * DT;
    for (let k = 0; k < 4; k++) {
      const h = deepest(s, b);
      if (!h) break;
      resolve(s, b, h);
    }
    s.shotTime += DT;
    s.time += DT;
    if (b.x > LANE_X && b.y >= REST_Y - 0.5 && b.vy >= 0 && s.shotTime > 0.05) { fallback(s); return; }
    if (b.x < LANE_X && b.y >= CAPTURE_Y) { land(s, holeAt(b.x)); return; }
    if (s.shotTime > s.cfg.shotTimeLimit) fallback(s, true);
  }
  const holeAt = x => Math.max(0, Math.min(HOLES - 1, Math.floor((x - X0) / HOLE_W)));
  const holeCx = i => X0 + HOLE_W * i + 4;   // 洞口中间（洞 8 格宽，后 2 格是隔条）

  function next(s) { if (s.phase === 'landed') { s.phase = 'idle'; s.bones = []; placeBall(s); } }

  // 一口气打完一发（无头测试用）。落洞返回这一发的记录；退回推头返回 null
  function runShot(s, power) {
    if (s.phase === 'idle') drawBones(s, 1);
    if (!launch(s, power)) return null;
    while (s.phase === 'flying') step(s);
    const r = s.phase === 'landed' ? s.history[s.history.length - 1] : null;
    next(s);
    return r;
  }

  // 按住 t 秒时弹簧拉到的力度：HOLD_FILL 秒拉满；拉满以后手会抖，在 0.96–1 之间晃，
  // 所以"一直按着不放"不是一个能精确复现的力度
  const HOLD_FILL = 1.1;
  function holdPower(t) {
    if (t < HOLD_FILL) return Math.max(0, t / HOLD_FILL);
    const u = t - HOLD_FILL;
    const ph = 2 * Math.PI * 3.1 * u + 1.7 * Math.sin(2 * Math.PI * 1.3 * u);
    return 1 - 0.04 * (0.5 - 0.5 * Math.cos(ph));
  }

  return {
    DT, X0, X1, Y0, STRIP, YB, CH, LANE_X, LANE_TOP, LANE_CX, BALL_R, PEG_R, HOLES, HOLE_W, HEAD_Y, REST_Y, PULL, CAPTURE_Y, DEFAULTS,
    rng, pegPositions, launchSpeed, createMachine, drawBones, launch, step, next, runShot, holeAt, holeCx, HOLD_FILL, holdPower,
    // 给火山坑、弹球台搭场地用（v2 加的，基础机自己的打法没变）
    addSeg, addWall, addCircle, buildGrid, contact, deepest, resolve, emit,
  };
}));
