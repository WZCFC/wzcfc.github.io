/*
 * 赌场 v2 的画法：桌面照样图 17（参考资料/早期原型/小孩机/像素样图/scene17.js）改成按数据重画。
 *   全局赌桌一格 = 1 像素（640×360）。三层台阶：前排 6 个小台，中排 6 个大台，顶排 6 个横台；没装修的那层不画。
 *   桌上放小预览，拿起来才是整张卡（卡面 64×84，从 art/scene13.js 的样图 13 读回来，史莱姆台和蘑菇洞是新画的）。
 *   机台界面：卡 4 倍虚化，台面上的东西 2 倍清楚（机台自己画），桌子压暗放大当底，左下是这台的底座、珠子盘、筹码。
 *   字交给 text.js，画在原生那一层。
 */
window.Art = (function () {
  'use strict';
  const W = 640, H = 360;
  let K = PixelKit(W, H), P = K.P;
  const { fl, rd, layer, lset, lget } = K;
  const INK = '#1b2628', DEEP = '#0e1719', SLATE = '#2f3a3c';

  // ---------- 颜色 ----------
  const RED = ['#ff8a7a', '#fe4c40', '#b8322a'], YEL = ['#fff3a0', '#ffd23a', '#e0a010'], BLU = ['#7ac0ff', '#2f86ea', '#1a5fb0'];
  const GRN = ['#9af06a', '#36b24a', '#22803a'], ORG = ['#ffc070', '#ff9700', '#c86a10'], PUR = ['#c8a0ff', '#9a5ad8', '#6a3aa0'];
  const BRN = ['#c89060', '#8a5226', '#5a3418'], BONE = ['#fff6e0', '#f0e2c0', '#c8b48c'];
  const ALU = ['#f2f6f6', '#c8d0d4', '#93a1a8', '#5f6f76'], GOLD = ['#fff3a0', '#e8c048', '#a87a20'];
  const WOOD = ['#e8a85a', '#c07a36', '#8a5226'], SNOW = ['#ffffff', '#e6f2fb', '#b4c8dc'];
  const BLK = ['#5f7378', '#2f3a3c', '#1b2628'];
  const CLOUD = { base: '#ffffff', shade: '#c6dbf7' }, SMOKE = { light: '#f1e9f8', base: '#cdbfe0', shade: '#9c8cb8' };
  const TREE = { light: '#6ad85a', base: '#2f9a3a', shade: '#1f6a2a' };
  const MINT = ['#c8ffd8', '#6ce89a', '#2fae68'];
  const BLUE_SLIME = ['#c8e8ff', '#5aa8f8', '#2a64c0'];
  const AMBER = ['#ffc888', '#f08a20', '#a85a10'];   // 琥珀：跟琥珀筹码一个橙，跟金史莱姆的黄分开
  const toRGB = h => { const n = parseInt(h.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
  const toHex = (r, g, b) => '#' + ((1 << 24) | (r << 16) | (g << 8) | b).toString(16).slice(1);
  const mix = (a, b, t) => { const A = toRGB(a), B = toRGB(b); return toHex(...A.map((v, k) => rd(v + (B[k] - v) * t))); };
  const memo = f => { const m = new Map(); return c => { let v = m.get(c); if (v === undefined) { v = f(c); m.set(c, v); } return v; }; };
  const hash = (x, y) => { let h = (x * 374761393 + y * 668265263) | 0; h = Math.imul(h ^ (h >>> 13), 1274126177); return ((h ^ (h >>> 16)) >>> 0) / 4294967296; };
  const mramp = c => [c[2], c[1], c[0]];

  // ---------- 画图小工具 ----------
  function api(set) {
    const put = (x, y, c, a, b) => { const cc = typeof c === 'function' ? c(x, y, a, b) : c; if (cc) set(x, y, cc); };
    return {
      px(x, y, c) { if (c) set(fl(x), fl(y), c); },
      r(x, y, w, h, c) { for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) put(x + i, y + j, c, i, j); },
      e(cx, cy, rx, ry, c) {
        for (let y = fl(cy - ry - 1); y <= Math.ceil(cy + ry); y++) for (let x = fl(cx - rx - 1); x <= Math.ceil(cx + rx); x++) {
          const u = (x + 0.5 - cx) / rx, v = (y + 0.5 - cy) / ry;
          if (u * u + v * v <= 1) put(x, y, c, u, v);
        }
      },
      p(pts, c) {
        let y0 = Infinity, y1 = -Infinity;
        for (const [, y] of pts) { y0 = Math.min(y0, y); y1 = Math.max(y1, y); }
        for (let y = fl(y0); y <= Math.ceil(y1); y++) {
          const yc = y + 0.5, xs = [];
          for (let i = 0; i < pts.length; i++) {
            const [ax, ay] = pts[i], [bx, by] = pts[(i + 1) % pts.length];
            if ((ay <= yc && by > yc) || (by <= yc && ay > yc)) xs.push(ax + (yc - ay) * (bx - ax) / (by - ay));
          }
          xs.sort((a, b) => a - b);
          for (let k = 0; k + 1 < xs.length; k += 2) for (let x = Math.ceil(xs[k] - 0.5); x <= fl(xs[k + 1] - 0.5); x++) put(x, y, c);
        }
      },
      l(x0, y0, x1, y1, c) {
        x0 = rd(x0); y0 = rd(y0); x1 = rd(x1); y1 = rd(y1);
        const dx = Math.abs(x1 - x0), dy = -Math.abs(y1 - y0), sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1;
        let err = dx + dy;
        for (;;) {
          put(x0, y0, c);
          if (x0 === x1 && y0 === y1) break;
          const e2 = 2 * err;
          if (e2 >= dy) { err += dy; x0 += sx; }
          if (e2 <= dx) { err += dx; y0 += sy; }
        }
      },
      s(rows, map, x, y) { rows.forEach((r, j) => { for (let i = 0; i < r.length; i++) { const cc = map[r[i]]; if (cc) set(x + i, y + j, cc); } }); },
    };
  }
  let D = api(P);
  function useKit(kit) { K = kit; P = kit.P; D = api(P); }
  function obj(bx, by, bw, bh, draw, outline, filter) {
    const L = layer(bw + 4, bh + 4), ox = bx - 2, oy = by - 2;
    draw(api((x, y, c) => lset(L, x - ox, y - oy, filter ? filter(c) : c)));
    if (outline !== null) K.loutline(L, outline || INK);
    K.blit(L, ox, oy);
  }
  function rr(x, y, w, h, r, fn) {
    for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) {
      const cx = i < r ? r : i > w - 1 - r ? w - 1 - r : i, cy = j < r ? r : j > h - 1 - r ? h - 1 - r : j;
      const d = Math.hypot(i - cx, j - cy);
      if (d > r + 0.3) continue;
      const inCorner = (i < r || i > w - 1 - r) && (j < r || j > h - 1 - r);
      const de = inCorner ? r - d : Math.min(i, j, w - 1 - i, h - 1 - j);
      const c = fn(i, j, de);
      if (c) P(x + i, y + j, c);
    }
  }
  const toCanvas = kit => { const c = document.createElement('canvas'); kit.flush(c); return c; };
  const grab = kit => toCanvas(kit).getContext('2d').getImageData(0, 0, kit.W, kit.H).data;

  // ---------- 图层上的画法（小预览、卡面用） ----------
  const tone = (u, v, c) => (u + v < -0.7 ? c[0] : u + v > 0.5 ? c[2] : c[1]);
  function lE(L, cx, cy, rx, ry, col, test) {
    for (let y = fl(cy - ry - 1); y <= Math.ceil(cy + ry); y++) for (let x = fl(cx - rx - 1); x <= Math.ceil(cx + rx); x++) {
      const u = (x + 0.5 - cx) / rx, v = (y + 0.5 - cy) / ry;
      if (u * u + v * v > 1 || (test && !test(x, y, u, v))) continue;
      const c = typeof col === 'string' ? col : Array.isArray(col) ? tone(u, v, col) : col(x, y, u, v);
      if (c) lset(L, x, y, c);
    }
  }
  function lR(L, x0, y0, w, h, col) {
    for (let y = y0; y < y0 + h; y++) for (let x = x0; x < x0 + w; x++) {
      let c;
      if (Array.isArray(col)) c = y === y0 || x === x0 ? col[0] : y === y0 + h - 1 || x === x0 + w - 1 ? col[2] : col[1];
      else c = typeof col === 'string' ? col : col(x, y);
      if (c) lset(L, x, y, c);
    }
  }
  function lP(L, pts, col) {
    let y0 = Infinity, y1 = -Infinity;
    for (const [, y] of pts) { y0 = Math.min(y0, y); y1 = Math.max(y1, y); }
    for (let y = fl(y0); y <= Math.ceil(y1); y++) {
      const yc = y + 0.5, xs = [];
      for (let i = 0; i < pts.length; i++) {
        const [ax, ay] = pts[i], [bx, by] = pts[(i + 1) % pts.length];
        if ((ay <= yc && by > yc) || (by <= yc && ay > yc)) xs.push(ax + (yc - ay) * (bx - ax) / (by - ay));
      }
      xs.sort((a, b) => a - b);
      for (let k = 0; k + 1 < xs.length; k += 2) for (let x = Math.ceil(xs[k] - 0.5); x <= fl(xs[k + 1] - 0.5); x++) {
        const c = typeof col === 'string' ? col : col(x, y);
        if (c) lset(L, x, y, c);
      }
    }
  }
  function lL(L, x0, y0, x1, y1, c) { const n = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0)) || 1; for (let s = 0; s <= n; s++) lset(L, rd(x0 + (x1 - x0) * s / n), rd(y0 + (y1 - y0) * s / n), c); }
  function lS(L, rows, map, x, y) { rows.forEach((r, j) => { for (let i = 0; i < r.length; i++) { const c = map[r[i]]; if (c) lset(L, x + i, y + j, c); } }); }
  function lPuff(L, lobes, col, flatBottom) {
    const m = new Set();
    for (const [cx, cy, rx, ry] of lobes) for (let y = fl(cy - ry - 1); y <= Math.ceil(cy + ry); y++) for (let x = fl(cx - rx - 1); x <= Math.ceil(cx + rx); x++) {
      if (Math.hypot((x + 0.5 - cx) / rx, (y + 0.5 - cy) / ry) > 1 || (flatBottom != null && y > flatBottom)) continue;
      m.add(y * 4096 + x + 2048);
    }
    const has = (x, y) => m.has(y * 4096 + x + 2048);
    for (const key of m) {
      const y = fl(key / 4096), x = key - y * 4096 - 2048;
      let c = col.base;
      if (!has(x, y + 1) || !has(x + 1, y + 1)) c = col.shade;
      else if (col.light && (!has(x, y - 1) || !has(x - 1, y - 1))) c = col.light;
      lset(L, x, y, c);
    }
  }
  function outl(L) {
    const add = [];
    for (let y = 0; y < L.h; y++) for (let x = 0; x < L.w; x++) {
      if (lget(L, x, y)) continue;
      if ([lget(L, x - 1, y), lget(L, x + 1, y), lget(L, x, y - 1), lget(L, x, y + 1)].some(c => c && c !== INK)) add.push([x, y]);
    }
    for (const [x, y] of add) lset(L, x, y, INK);
  }
  const MARBLE5 = ['.kkk.', 'khwwk', 'kwwwk', 'kwwsk', '.kkk.'];
  const MARBLE7 = ['..kkk..', '.khhwk.', 'khhwwwk', 'kwwwwsk', 'kwwwssk', '.kwssk.', '..kkk..'];
  const MW = ['#9aa6ba', '#dfe7f2', '#ffffff'];
  const STEELM = ['#5f6f76', '#a3b0b5', '#ffffff'];
  function MB5(L, x, y, m = MW) { lS(L, MARBLE5, { k: INK, s: m[0], w: m[1], h: m[2] }, x - 2, y - 2); }
  function MB7(L, x, y, m = MW) { lS(L, MARBLE7, { k: INK, s: m[0], w: m[1], h: m[2] }, x - 3, y - 3); }
  // 史莱姆：底下平一点的一团，大小当血；C = [亮, 身子, 暗]
  function slimeBlob(L, cx, cy, rx, ry, C, face = true) {
    const bot = cy + ry * 0.62;
    lE(L, cx, cy, rx, ry, (x, y, u, v) => (u + v < -0.9 ? C[0] : u + v > 0.55 || v > 0.4 ? C[2] : C[1]), (x, y) => y + 0.5 <= bot + 0.4);
    const hx = fl(cx - rx * 0.52), hy = fl(cy - ry * 0.55);
    lset(L, hx, hy, '#ffffff'); if (rx >= 6) { lset(L, hx + 1, hy - 1, '#ffffff'); lset(L, hx - 1, hy + 1, C[0]); }
    if (!face) return;
    const dx = Math.max(1.5, rx * 0.34), ey = fl(cy - ry * 0.02);
    for (const ex of [fl(cx - dx), fl(cx + dx - 1)]) { lset(L, ex, ey, INK); if (ry >= 4.5) lset(L, ex, ey + 1, INK); }
    if (rx >= 6) { const my = ey + (ry >= 6 ? 3 : 2); lset(L, fl(cx) - 1, my, INK); lset(L, fl(cx), my, INK); }
  }

  // ---------- 数字、价签、筹码 ----------
  const D35 = {
    0: ['xxx', 'x.x', 'x.x', 'x.x', 'xxx'], 1: ['.x.', 'xx.', '.x.', '.x.', 'xxx'], 2: ['xxx', '..x', 'xxx', 'x..', 'xxx'],
    3: ['xxx', '..x', '.xx', '..x', 'xxx'], 4: ['x.x', 'x.x', 'xxx', '..x', '..x'], 5: ['xxx', 'x..', 'xxx', '..x', 'xxx'],
    6: ['xxx', 'x..', 'xxx', 'x.x', 'xxx'], 7: ['xxx', '..x', '.x.', '.x.', '.x.'], 8: ['xxx', 'x.x', 'xxx', 'x.x', 'xxx'], 9: ['xxx', 'x.x', 'xxx', '..x', 'xxx'],
    '+': ['...', '.x.', 'xxx', '.x.', '...'], '-': ['...', '...', 'xxx', '...', '...'], '>': ['x..', '.x.', '..x', '.x.', 'x..'],
    'x': ['...', 'x.x', '.x.', 'x.x', '...'], 'k': ['x..', 'x.x', 'xx.', 'x.x', 'x.x'], 'm': ['...', 'xxx', 'xxx', 'x.x', 'x.x'], '.': ['...', '...', '...', '...', '.x.'],
  };
  const num35 = (g, s, x, y, c) => [...String(s)].forEach((ch, n) => g.s(D35[ch] || D35['-'], { x: c }, x + n * 4, y));
  const numW35 = s => String(s).length * 4 - 1;
  // 大数缩写：12345 → 12k，1234567 → 1.2m（数码管位数有限）
  const short = n => (n < 10000 ? String(Math.floor(n)) : n < 1e6 ? Math.floor(n / 1000) + 'k' : n < 1e7 ? (Math.floor(n / 1e5) / 10) + 'm' : Math.floor(n / 1e6) + 'm');
  const TIX = {
    bone: { face: '#ffe680', icon: '#a8600c', chip: YEL },
    slime: { face: '#c8ffd8', icon: '#1f8a44', chip: ['#b8ffc8', '#3ccf6a', '#1f8a44'] },
    swirl: { face: '#ecd0ff', icon: '#6a2aa8', chip: ['#e0b0ff', '#a050e8', '#6a2aa8'] },
    lava: { face: '#ffb894', icon: '#a82a1a', chip: ['#ff9a7a', '#e8452a', '#a82a1a'] },
    shroom: { face: '#c8f6f8', icon: '#16808c', chip: ['#9af0f0', '#2ab8c8', '#16808c'] },
    pin: { face: '#fff0d4', icon: '#a87830', chip: ['#ffe0a8', '#e8b060', '#a87830'] },
    ice: { face: '#d4f6ff', icon: '#1a5fb0', chip: ['#d4f6ff', '#6ac8ec', '#2f86b0'] },
    amber: { face: '#ffe0b0', icon: '#a85a10', chip: ['#ffd090', '#f08a20', '#a85a10'] },
    coin: { face: '#f8d8c0', icon: '#8a4a2a', chip: ['#f0b890', '#c87a4a', '#8a4a2a'] },
    egg: { face: '#fffaf0', icon: '#d88a10', chip: ['#ffffff', '#e6dfd0', '#b0a690'] },
    snail: { face: '#ffd4e6', icon: '#a82a6a', chip: ['#ffc0d8', '#e85a9a', '#a82a6a'] },
    snow: { face: '#eef6ff', icon: '#4a7ab0', chip: ['#ffffff', '#c8e4f8', '#7aa8d0'] },
    circus: { face: '#c0ceff', icon: '#e8343a', chip: ['#8aa6ff', '#2a4ad8', '#1a2a90'] },
    fish: { face: '#c8f6ee', icon: '#107068', chip: ['#8af0e0', '#20b0a0', '#107068'] },
    ball: { face: '#f2f6f6', icon: INK, chip: ['#ffffff', '#c8d0d4', '#5f6f76'] },
    hook: { face: '#d0e8ff', icon: '#1a5aa8', chip: ['#a8d8ff', '#3a8ae8', '#1a5aa8'] },
    crown: { face: '#ffd0ec', icon: '#8a1a60', chip: ['#ffa8d8', '#d83a9a', '#8a1a60'] },
    eight: { face: '#c8f0cc', icon: '#145a28', chip: ['#9ae0a0', '#2a9a4a', '#145a28'] },
    star: { face: '#fff3a0', icon: '#a87a20', chip: GOLD },
  };
  const TAG_ICON = {
    bone: ['x...x', '.xxx.', 'x...x'], slime: ['.xxx.', 'xxxxx', 'xxxxx'], swirl: ['.xxx.', 'xx..x', '.xxx.'], lava: ['..x..', '.xxx.', 'xxxxx'],
    shroom: ['.xxx.', 'xxxxx', '..x..'], pin: ['x.x.x', '.x.x.', '..x..'], ice: ['x.x.x', '.xxx.', 'x.x.x'], amber: ['..x..', '.xxx.', '.xxx.'],
    coin: ['.xxx.', 'x.x.x', '.xxx.'], egg: ['.xx.', 'xxxx', '.xx.'], snail: ['.xx..', 'x.xx.', 'xxxxx'], snow: ['.x...', 'xxx.x', '.x.xx'],
    circus: ['..x..', 'xxxxx', '.x.x.'], fish: ['.xx.x', 'xxxxx', '.xx.x'], ball: ['.xxx.', 'xx.xx', '.xxx.'], hook: ['..x..', 'x.x..', '.x...'],
    crown: ['x.x.x', 'xxxxx', 'xxxxx'], eight: ['.xxx.', 'xxxxx', '.xxx.'], star: ['..x..', 'xxxxx', '.x.x.'],
  };
  function priceTag(x, y, t, price, poor) {
    const T = TIX[t], ic = TAG_ICON[t], iw = ic[0].length, s = short(price), w = 2 + iw + 1 + numW35(s) + 2;
    obj(x, y, w, 7, g => { g.r(x, y, w, 7, T.face); g.s(ic, { x: T.icon }, x + 2, y + 2); num35(g, s, x + 3 + iw, y + 1, poor ? RED[1] : INK); });
    return w;
  }
  const tagW = (t, price) => 2 + TAG_ICON[t][0].length + 1 + numW35(short(price)) + 2;
  function chipStack(cx, by, n, Cc) {
    const ty = by - 2 * n - 3;
    obj(cx - 5, ty, 11, by - ty + 1, g => {
      for (let i = 0; i < n; i++) {
        const y = by - 2 * (i + 1);
        g.r(cx - 4, y, 9, 1, X => ((X - cx + 4) % 3 === 1 ? '#ffffff' : Cc[1]));
        g.r(cx - 4, y + 1, 9, 1, Cc[2]);
      }
      g.r(cx - 3, ty, 7, 1, Cc[0]); g.r(cx - 4, ty + 1, 9, 2, Cc[0]); g.r(cx - 1, ty + 1, 3, 1, Cc[1]);
    });
  }
  // 每台的珠子：[暗, 中, 亮]
  const MARB = {
    glass: ['#9aa6ba', '#dfe7f2', '#ffffff'], steel: ['#5f6f76', '#a3b0b5', '#ffffff'], taw: ['#1a5fb0', '#2f86ea', '#7ac0ff'],
    ice: ['#4fb0d8', '#a8e8ff', '#ffffff'], bowl: ['#3a1a8a', '#6a3ad8', '#a87aff'], iron: ['#3b4448', '#6f7c80', '#c8d0d4'],
    coin: ['#a87a20', '#e8c048', '#fff3a0'], sponge: ['#e0a010', '#ffd23a', '#fff3a0'], snowball: ['#b4c8dc', '#e6f2fb', '#ffffff'],
    rubber: ['#b8322a', '#fe4c40', '#ff8a7a'], football: ['#5f6f76', '#ffffff', '#ffffff'], bait: ['#8a5226', '#c89060', '#f0d0a0'], cue: ['#c8c0b4', '#f6f2ea', '#ffffff'],
  };
  const SPOTS = [[-9, -4], [-3, -4], [3, -4], [-6, -8], [0, -8]];

  // =========================================================================
  // 排布（同样图 17）
  // =========================================================================
  const CEIL = 25, WALL0 = CEIL + 6;
  const SX0 = 24, PITCH = 66, SX1 = SX0 + PITCH * 6 - 1;
  const ROW = [null, { pw: 48, ph: 64 }, { pw: 54, ph: 47 }, { pw: 61, ph: 35 }];
  const PLH = 11, LAMP_Y = 62;
  const B = [];
  B[3] = LAMP_Y + 4 + ROW[3].ph + PLH;
  B[2] = B[3] + 5 + ROW[2].ph + PLH;
  B[1] = B[2] + 5 + ROW[1].ph + PLH;
  const TOP0 = 190, EDGE = 306;
  const slotX = (r, i) => Math.round(SX0 + PITCH * i + PITCH / 2 - ROW[r].pw / 2);
  const prevY = r => B[r] - PLH - ROW[r].ph;
  const slotRect = n => { const r = Math.ceil(n / 6), i = (n - 1) % 6; return { x: slotX(r, i), y: prevY(r), w: ROW[r].pw, h: ROW[r].ph, r, i }; };

  // =========================================================================
  // 赌场
  // =========================================================================
  const Cz = {
    ceil: '#2a0c16', ceilLine: '#3a1420', wall: '#5a1626', trellis: '#6a1e30', soft: '#240810',
    felt: '#1f7a42', feltD: '#17603a', riser: '#165a36', riserD: '#114a2c',
    leather: ['#7a4e3e', '#5a3628', '#3e2218'], apron: ['#4a2a1c', '#38200f', '#26150a'],
    drape: ['#d04458', '#a01c34', '#6a0e22'], velvet: ['#c03048', '#9a1830', '#6e1024'],
    black: ['#4a4a58', '#2c2c36', '#1a1a22'],
  };
  const VELV = Cz.velvet;
  const wallF = memo(c => mix(c, Cz.wall, 0.5));
  const nearF = memo(c => mix(c, Cz.wall, 0.15));
  const WHI = '#7a2638', WLO = '#3c0c18', WGOLD = mix(GOLD[1], Cz.wall, 0.5);
  function chandelier(cx) {
    D.r(cx, 0, 1, 4, GOLD[2]);
    obj(cx - 22, 3, 45, 20, g => {
      g.r(cx - 1, 3, 3, 4, GOLD[1]);
      g.l(cx, 7, cx - 18, 15, GOLD[2]); g.l(cx + 1, 7, cx + 19, 15, GOLD[2]);
      g.e(cx + 0.5, 16, 20, 2.6, GOLD[1]);
      g.e(cx + 0.5, 15.7, 17, 1.4, GOLD[2]);
      for (const dx of [-18, -9, 0, 9, 18]) { g.r(cx + dx, 10, 2, 5, '#fff6e0'); g.r(cx + dx, 8, 2, 2, YEL[1]); }
      for (let dx = -16; dx <= 17; dx += 4) g.r(cx + dx, 19, 1, Math.abs(dx) % 8 === 0 ? 3 : 2, '#c8e8ff');
    }, Cz.soft, nearF);
  }
  function drape(x, right) {
    const y0 = WALL0, y1 = TOP0;
    obj(x, y0, 22, y1 - y0, g => {
      for (let Y = y0; Y < y1; Y++) {
        const pinch = Y > 96 && Y < 160 ? Math.round(7 * Math.sin(Math.PI * (Y - 96) / 64)) : 0;
        for (let i = 0; i < 22 - pinch; i++) {
          const X = right ? x + 21 - i : x + i, k = i % 6;
          g.px(X, Y, k === 0 ? Cz.drape[0] : k >= 4 ? Cz.drape[2] : Cz.drape[1]);
        }
      }
      g.r(x, y0, 22, 8, Cz.drape[1]); g.r(x, y0 + 7, 22, 1, Cz.drape[2]);
      for (let X = x; X < x + 22; X += 2) g.r(X, y0 + 8, 1, 2, GOLD[1]);
      const ty = 126; g.r(right ? x + 7 : x, ty, 15, 3, GOLD[1]); g.r(right ? x + 7 : x, ty, 15, 1, GOLD[0]);
    }, Cz.soft, nearF);
  }
  function wallBays(y1) {
    for (let k = 0; k < 6; k++) {
      const x0 = SX0 + PITCH * k + 8, x1 = SX0 + PITCH * (k + 1) - 8, y0 = WALL0 + 8, w = x1 - x0 + 1, h = y1 - y0 + 1;
      D.r(x0, y0, w, 1, WHI); D.r(x0, y0, 1, h, WHI); D.r(x0, y1, w, 1, WLO); D.r(x1, y0, 1, h, WLO);
      D.r(x0 + 2, y0 + 2, w - 4, 1, WLO); D.r(x0 + 2, y0 + 2, 1, h - 4, WLO); D.r(x0 + 2, y1 - 2, w - 4, 1, WHI); D.r(x1 - 2, y0 + 2, 1, h - 4, WHI);
    }
    for (let k = 0; k <= 6; k++) {
      const cx = SX0 + PITCH * k, x = cx - 3;
      D.r(x, WALL0, 7, TOP0 - WALL0, '#4c1222'); D.r(x, WALL0, 1, TOP0 - WALL0, WHI); D.r(x + 6, WALL0, 1, TOP0 - WALL0, WLO);
      D.r(x, WALL0 + 2, 7, 2, WGOLD); D.r(x, TOP0 - 6, 7, 2, WGOLD);
      if (k === 0 || k === 6) continue;
      const sy = 116;
      obj(cx - 5, sy - 3, 11, 15, g => {
        g.r(cx - 1, sy + 2, 3, 9, GOLD[1]); g.r(cx - 1, sy + 2, 1, 9, GOLD[0]); g.r(cx + 1, sy + 3, 1, 8, GOLD[2]);
        g.r(cx - 4, sy + 7, 9, 1, GOLD[2]);
        g.r(cx - 5, sy + 5, 3, 2, GOLD[1]); g.r(cx + 3, sy + 5, 3, 2, GOLD[1]);
        g.r(cx - 4, sy, 1, 5, '#fff6e0'); g.r(cx + 4, sy, 1, 5, '#fff6e0');
        g.r(cx - 4, sy - 2, 1, 2, YEL[1]); g.r(cx + 4, sy - 2, 1, 2, YEL[1]);
      }, Cz.soft, nearF);
    }
  }
  const SUITS = {
    spade: ['...x...', '..xxx..', '.xxxxx.', 'xxxxxxx', 'xxxxxxx', '.x.x.x.', '...x...', '..xxx..'],
    heart: ['.xx.xx.', 'xxxxxxx', 'xxxxxxx', 'xxxxxxx', '.xxxxx.', '..xxx..', '...x...'],
    diamond: ['...x...', '..xxx..', '.xxxxx.', 'xxxxxxx', '.xxxxx.', '..xxx..', '...x...'],
    club: ['..xxx..', '..xxx..', 'xx.x.xx', 'xxxxxxx', 'xx.x.xx', '...x...', '..xxx..'],
  };
  function suits(x0, y) {
    [['spade', INK], ['heart', RED[1]], ['diamond', RED[1]], ['club', INK]].forEach(([k, c], n) => {
      const x = x0 + n * 26;
      obj(x, y, 20, 24, g => {
        g.r(x, y, 20, 24, GOLD[1]); g.r(x, y, 20, 1, GOLD[0]); g.r(x, y, 1, 24, GOLD[0]); g.r(x + 19, y + 1, 1, 23, GOLD[2]);
        g.r(x + 3, y + 3, 14, 18, '#f4ecd8');
        g.s(SUITS[k], { x: c }, x + 6, y + 8);
      }, Cz.soft, wallF);
    });
  }
  function casinoBack(vm) {
    D.r(0, 0, W, CEIL, Cz.ceil);
    for (let x = 20; x < W; x += 40) D.r(x, 0, 1, CEIL, Cz.ceilLine);
    const m = CEIL;
    D.r(0, m, W, 1, GOLD[0]); D.r(0, m + 1, W, 3, GOLD[1]); D.r(0, m + 4, W, 1, GOLD[2]); D.r(0, m + 5, W, 1, INK);
    for (let x = 1; x < W; x += 4) D.r(x, m + 2, 2, 1, GOLD[2]);
    D.r(0, WALL0, W, TOP0 - WALL0, (x, y) => ((x + y) % 12 === 0 || (x - y + 1200) % 12 === 0 ? Cz.trellis : Cz.wall));
    wallBays(TOP0 - 14);
    chandelier(vm.tiers >= 2 ? 108 : SX0 + PITCH * 3);
    chandelier(536);
    drape(0, false); drape(W - 22, true);
  }
  function casinoTable() {
    D.r(0, TOP0, W, 1, INK);
    D.r(0, TOP0 + 1, W, EDGE - TOP0 - 1, Cz.felt);
    D.r(0, TOP0 + 1, W, 3, Cz.feltD);
    D.r(0, EDGE, W, 1, INK);
    const L = Cz.leather, R0 = EDGE + 14;
    D.r(0, EDGE + 1, W, 13, (x, y) => { const j = y - EDGE - 1; if (j === 4 && x % 4 === 1) return '#b08870'; return j < 2 ? L[0] : j < 8 ? L[1] : L[2]; });
    D.r(0, R0, W, 1, INK); D.r(0, R0 + 1, W, 1, GOLD[0]); D.r(0, R0 + 2, W, 1, GOLD[2]); D.r(0, R0 + 3, W, 1, INK);
    D.r(0, R0 + 4, W, H - R0 - 4, Cz.apron[1]);
  }
  // 一层台阶：台面绒布（back..Bn+2）、金边（Bn+3..Bn+4）、立面（Bn+5..down）
  function tier(Bn, back, down) {
    const x0 = SX0 - 2, w = SX1 - SX0 + 5;
    D.r(x0, back, w, Bn + 3 - back, (x, y) => (y === back ? Cz.feltD : Cz.felt));
    D.r(x0, Bn + 3, w, 1, GOLD[0]); D.r(x0, Bn + 4, w, 1, GOLD[2]);
    D.r(x0, Bn + 5, w, down - Bn - 4, (x, y) => (y === down ? INK : y === Bn + 5 ? Cz.riserD : y === Bn + 7 ? mix(GOLD[1], Cz.riser, 0.55) : Cz.riser));
    D.r(x0 - 1, back, 1, down - back + 1, INK); D.r(x0 + w, back, 1, down - back + 1, INK);
  }

  // =========================================================================
  // 小预览
  // =========================================================================
  function artMask(aw, ah, mode, x, y) {
    if (x < 0 || y < 0 || x >= aw || y >= ah) return false;
    if (mode === 'side') return x + y >= 3 && (aw - 1 - x) + y >= 3;
    const r = 2, cx = x < r ? r : x > aw - 1 - r ? aw - 1 - r : x, cy = y < r ? r : y > ah - 1 - r ? ah - 1 - r : y;
    return Math.hypot(x - cx, y - cy) <= r + 0.3;
  }
  function paintArt(aw, ah, mode, paint) {
    const art = layer(aw, ah), inA = (x, y) => artMask(aw, ah, mode, x, y);
    const A = {
      w: aw, h: ah,
      bg(fn) { for (let y = 0; y < ah; y++) for (let x = 0; x < aw; x++) if (inA(x, y)) { const c = fn(x, y); if (c) lset(art, x, y, c); } },
      obj(draw, outline = true) {
        const L = layer(aw, ah); draw(L); if (outline) outl(L);
        for (let y = 0; y < ah; y++) for (let x = 0; x < aw; x++) { const c = lget(L, x, y); if (c && inA(x, y)) lset(art, x, y, c); }
      },
      px(x, y, c) { if (inA(x, y)) lset(art, x, y, c); },
    };
    paint(A);
    return { art, inA };
  }
  function preview(M, x, y, w, h) {
    const F = M.f, aw = w - 8, ah = h - 8, { art, inA } = paintArt(aw, ah, M.mode, M.paint);
    rr(x, y, w, h, 3, (i, j, de) => {
      const ai = i - 4, aj = j - 4;
      if (inA(ai, aj)) return lget(art, ai, aj) || '#ff00ff';
      if (inA(ai + 1, aj) || inA(ai - 1, aj) || inA(ai, aj + 1) || inA(ai, aj - 1)) return INK;
      if (de < 1) return INK;
      if (de < 2) return i + j < (w + h) / 2 ? F[0] : F[2];
      return F[1];
    });
    rr(x + 1, y + 1, 11, 9, 1, (i, j, de) => (de < 1 ? INK : DEEP));
    if (M.led != null) String(Math.min(99, M.led)).padStart(2, '0').split('').forEach((ch, n) => D.s(D35[ch], { x: '#fe4c40' }, x + 3 + n * 4, y + 3));
    K.disc(x + w - 5, y + 5, 2.7, INK); K.disc(x + w - 5, y + 5, 1.7, M.em);
  }
  function cloth(x0, y0, w, h, tag) {
    const V = VELV, top = y0 - 2, bot = y0 + h + 1, fl3 = 3, folds = [x0 + w * 0.25, x0 + w * 0.5, x0 + w * 0.75];
    const pts = [[x0 + 3, top], [x0 + w - 3, top], [x0 + w + 1, top + 4], [x0 + w + 1, y0 + h * 0.55]];
    for (let x = x0 + w + fl3, k = 0; x >= x0 - fl3; x -= 4, k++) pts.push([x, bot - (k % 2)]);
    pts.push([x0 - 1, y0 + h * 0.55], [x0 - 1, top + 4]);
    obj(x0 - fl3 - 1, top - 1, w + 2 * fl3 + 3, bot - top + 6, g => {
      g.p(pts, (x, y) => {
        let c = x < x0 + 2 ? V[0] : x >= x0 + w - 3 ? V[2] : V[1];
        if (y > y0 + h * 0.45) {
          const t = (y - y0 - h * 0.45) / (h * 0.55);
          for (const fx of folds) { const d = x + 0.5 - fx; if (Math.abs(d) <= 0.6 + t * 1.6) c = d < 0 ? V[2] : V[0]; }
        }
        return c;
      });
      for (let x = x0 - fl3; x <= x0 + w + fl3 - 1; x++) g.r(x, bot + 1, 1, x % 3 === 0 ? 3 : 2, x % 2 ? GOLD[1] : GOLD[2]);
    });
    if (tag) {
      const tw = tagW(tag.t, tag.price), tx = x0 + w - tw - 2, ty = y0 + Math.min(16, fl(h * 0.32));
      D.l(x0 + w - 6, y0 + 2, tx + tw - 4, ty - 1, GOLD[1]);
      priceTag(tx, ty, tag.t, tag.price, tag.poor);
    }
  }
  // 底座上的小屏（这台的筹码）：屏固定宽，数字每帧另画（plinthWin 给出数字画在哪）
  const PLW = 32;
  const plinthWin = n => { const r = slotRect(n), x0 = r.x - 1, w = r.w + 2; return { x: x0 + fl((w - PLW) / 2) + 9, y: B[r.r] - PLH + 4 }; };
  const ledAt = n => { const r = slotRect(n); return { x: r.x + 3, y: r.y + 3 }; };
  function plinth(x0, w, Bn, M) {
    const y0 = Bn - PLH, Bk = Cz.black;
    obj(x0, y0, w, PLH, g => {
      g.r(x0, y0, w, 1, Bk[0]); g.r(x0, y0 + 1, w, 1, GOLD[1]); g.r(x0, y0 + 2, w, PLH - 2, Bk[2]);
      if (!M || M.covered) return;
      const sw = PLW, sx = x0 + fl((w - sw) / 2), sy = y0 + 2;
      g.r(sx, sy, sw, 9, GOLD[2]); g.r(sx, sy, sw, 1, GOLD[1]);
      g.r(sx + 1, sy + 1, sw - 2, 7, '#120a0e');
      g.s(TAG_ICON[M.t], { x: TIX[M.t].chip[1] }, sx + 2, sy + 3);
      if (M.have != null) num35(g, short(M.have), sx + 9, sy + 2, GOLD[0]);
    });
  }
  function spinLamp(cx, yTop, lit) {
    const x = cx - 2, y = yTop - 4;
    obj(x, y, 5, 4, g => {
      g.r(x, y + 3, 5, 1, GOLD[1]);
      g.r(x + 1, y, 3, 3, lit ? YEL[1] : '#7a1a2a'); g.px(x + 1, y, lit ? '#ffffff' : '#a8283a'); g.px(x + 2, y, lit ? '#fff6c0' : '#8c1f2e');
    });
  }
  const ROBOT = ['...r...', '...a...', '.aaaaa.', '.ayaya.', '.aaaaa.', '..rrr..', '.rrrrr.', '.rrrrr.', '..a.a..'];
  function robot(xr, yb, kind) {
    const x = xr - 7, y = yb - 9;
    obj(x - 4, y - 1, 12, 11, g => {
      g.s(ROBOT, { r: RED[1], a: ALU[1], y: YEL[1] }, x, y);
      g.px(x + 2, y + 2, ALU[0]); g.px(x + 3, y + 2, ALU[0]);
      g.r(x - 1, y + 6, 2, 1, ALU[2]);
      if (kind === 0) { g.px(x - 2, y + 5, ALU[2]); g.px(x - 2, y + 7, ALU[2]); g.px(x - 3, y + 5, ALU[2]); g.px(x - 3, y + 7, ALU[2]); }
      else if (kind === 1) g.r(x - 4, y + 4, 3, 4, WOOD[1]);
      else { g.l(x - 1, y + 6, x - 4, y + 2, WOOD[0]); g.px(x - 4, y + 1, ALU[0]); }
    });
  }

  // ---------- 十八张小预览的画（同样图 17） ----------
  const DOG8 = ['.oo..oo.', 'oowwwwoo', 'owkwwkwo', 'owwwwwwo', '.wwkkww.', '.wwttww.', '..bbbb..'];
  function pvDog(A) {
    A.bg((x, y) => (x % 6 === 3 && y % 6 === 1 ? '#3169e4' : '#2a62dc'));
    A.obj(L => { lPuff(L, [[7, 16, 3.2, 2.2], [10.5, 14.5, 3.6, 2.8], [14, 16, 3, 2.2]], CLOUD, 17); lPuff(L, [[27, 11, 3, 2], [30.5, 9.5, 3.4, 2.6], [34, 11, 2.8, 2]], CLOUD, 12); });
    A.obj(L => {
      const sag = x => 5 + rd(1.5 * Math.sin(Math.PI * (x + 0.5 - 7) / 26));
      for (let x = 7; x <= 32; x++) lset(L, x, sag(x), INK);
      [[11, RED[1]], [17, YEL[1]], [23, '#ffffff'], [29, GRN[1]]].forEach(([x, c]) => { const y = sag(x) + 1; lset(L, x - 1, y, c); lset(L, x, y, c); lset(L, x + 1, y, c); lset(L, x, y + 1, c); });
    }, false);
    A.obj(L => lR(L, 0, 50, 40, 6, (x, y) => (y === 50 ? '#8ae063' : '#36b24a')));
    A.obj(L => {
      const cx = 20;
      for (let x = 3; x <= 36; x++) { const yo = 23 + Math.abs(x + 0.5 - cx) * 0.78; for (let y = fl(yo); y <= yo + 3; y++) lset(L, x, y, y < yo + 1 ? '#ff8a7a' : '#fe4c40'); }
      for (let x = 7; x <= 32; x++) for (let y = Math.ceil(26.6 + Math.abs(x + 0.5 - cx) * 0.78); y <= 52; y++) lset(L, x, y, x === 7 || x === 32 ? '#d47028' : (y - 27) % 4 === 0 ? '#b5561c' : (y - 27) % 4 === 1 ? '#ffad5e' : '#ef8a34');
      for (let y = 36; y <= 52; y++) for (let x = 12; x <= 28; x++) {
        const d = (y + 0.5 >= 44 ? Math.abs(x + 0.5 - cx) : Math.hypot(x + 0.5 - cx, y + 0.5 - 44)) - 5.6;
        if (d <= 0) lset(L, x, y, SLATE); else if (d <= 1.3) lset(L, x, y, '#fff4d6');
      }
      lS(L, DOG8, { o: '#cf8343', w: '#f9eed7', k: '#311508', t: '#f8898f', b: '#4977b9' }, 16, 45);
      lE(L, cx, 33.5, 3.4, 1.9, '#5aa8ff');
      for (let x = 18; x <= 21; x++) lset(L, x, 33, '#ffffff');
      for (const [px, py] of [[17, 32], [17, 34], [22, 32], [22, 34]]) lset(L, px, py, '#ffffff');
    });
  }
  function pvSlime(A) {
    A.bg((x, y) => (y < 9 ? '#a8e0ff' : fl((y - 9) / 5) % 2 ? '#3f9a38' : '#46a63e'));
    for (const [x, y] of [[4, 15], [33, 27], [7, 38], [31, 47], [19, 49]]) { A.px(x, y, '#2f7a2e'); A.px(x + 2, y, '#2f7a2e'); A.px(x + 1, y + 1, '#2f7a2e'); }
    A.obj(L => { lPuff(L, [[2, 7, 5, 4.2], [10, 5.5, 5.2, 4.5], [19.5, 7, 5.5, 4.2], [29, 5.5, 5.2, 4.5], [37.5, 7, 5, 4.2]], TREE); for (const [x, y] of [[7, 5], [23, 4], [33, 7]]) lset(L, x, y, RED[1]); });
    A.obj(L => { slimeBlob(L, 18, 31, 10, 8.5, MINT); slimeBlob(L, 31.5, 19, 4.6, 4, MINT); });
    A.obj(L => {
      lP(L, [[3, 43], [6, 41], [15, 47], [14, 49]], WOOD[1]); lP(L, [[36, 43], [33, 41], [24, 47], [25, 49]], WOOD[1]);
      MB5(L, 26, 39, STEELM);
    });
    A.obj(L => lR(L, 0, 52, 40, 4, (x, y) => (y === 52 ? INK : SLATE)), false);
  }
  function pvRing(A) {
    A.bg((x, y) => (y % 4 === 1 && x % 4 === (fl(y / 4) % 2) * 2 ? '#a8723e' : '#c8925a'));
    A.obj(L => { for (let y = 0; y < 56; y++) for (let x = 0; x < 40; x++) if (Math.abs(Math.hypot(x + 0.5 - 20, y + 0.5 - 24) - 15.5) < 0.75) lset(L, x, y, '#fff8ec'); }, false);
    A.obj(L => { for (let x = 5; x <= 34; x += 3) { lset(L, x, 45, '#fff8ec'); lset(L, x + 1, 45, '#fff8ec'); } }, false);
    A.obj(L => {
      const CAT = [RED, BLU, GRN, YEL, PUR, ORG].map(mramp);
      [[20, 24], [20, 17], [13, 24], [27, 24], [20, 31], [14, 17], [26, 30]].forEach(([x, y], k) => MB5(L, x, y, CAT[k % 6]));
    });
    A.obj(L => MB7(L, 20, 50, mramp(BLU)));
  }
  function pvVolc(A) {
    A.bg((x, y) => (y < 30 && x % 6 === 3 && y % 6 === 1 ? '#5c2c88' : '#4a1d70'));
    for (const [x, y, c] of [[6, 14, '#fee787'], [34, 18, '#ffffff'], [12, 6, '#c9a0e8'], [30, 5, '#fee787'], [36, 30, '#c9a0e8'], [4, 26, '#ffffff']]) A.px(x, y, c);
    A.obj(L => { lPuff(L, [[20, 17, 5, 3.4], [23.5, 15, 3.4, 2.8], [16.5, 16, 3, 2.6]], SMOKE); lPuff(L, [[25, 8, 3.4, 2.3], [27.5, 7, 2.2, 1.8]], SMOKE); });
    A.obj(L => {
      for (let y = 24; y <= 55; y++) { const h = 4 + 17 * Math.sqrt((y - 24) / 31); for (let x = fl(20 - h); x <= Math.ceil(20 + h); x++) { const u = (x + 0.5 - 20) / h; if (Math.abs(u) <= 1) lset(L, x, y, u < -0.55 ? '#c96a48' : u > 0.5 ? '#7a3230' : '#a24a36'); } }
      for (let x = 17; x <= 22; x++) lset(L, x, 24, '#ff9700');
      for (const [x, c] of [[18, '#fee787'], [19, '#fee787'], [20, '#ff9700'], [21, '#ff9700']]) lset(L, x, 23, c);
      for (const [x, y] of [[17, 25], [16, 26], [16, 27], [22, 25], [23, 26], [23, 27], [23, 28]]) lset(L, x, y, '#ff9700');
      for (const [x, y] of [[17, 32], [17, 33], [22, 32], [22, 33], [18, 36], [19, 37], [20, 37], [21, 36]]) lset(L, x, y, INK);
      lset(L, 15, 35, '#ff7a6a'); lset(L, 24, 35, '#ff7a6a');
      for (const [cx, cy, full] of [[9.5, 45, 0], [30, 41, 1], [20, 50, 0]]) {
        lE(L, cx, cy, 3.8, 2, INK);
        lE(L, cx, cy, 2.9, 1.2, (x, y, u, v) => (v < 0.1 ? '#2a0f22' : '#ff9700'));
        if (full) for (const [dx, dy] of [[-1, -1], [0, -1], [1, -1]]) lset(L, fl(cx) + dx, fl(cy) + dy, '#ffffff');
      }
    });
    A.obj(L => { for (let x = 0; x < 40; x++) { lset(L, x, 53, INK); lset(L, x, 54, x % 5 < 2 ? '#fee787' : '#ff9700'); lset(L, x, 55, '#e8501a'); } }, false);
  }
  function mushroom(L, cx, yb, rx, ry, sh) {
    const capY = yb - sh - 1, sw = Math.max(1, rd(rx * 0.32));
    for (let y = capY + 1; y < yb; y++) for (let x = cx - sw; x < cx + sw; x++) lset(L, x, y, x === cx + sw - 1 ? '#c8b48c' : '#f6ecd4');
    lE(L, cx, capY + 0.5, rx, ry, (x, y, u, v) => (u + v < -0.85 ? '#ff8a7a' : u > 0.55 ? '#b8322a' : '#fe4c40'), (x, y) => y <= capY);
    for (let x = fl(cx - rx + 1); x <= Math.ceil(cx + rx - 2); x++) lset(L, x, capY + 1, '#e8d8b8');
    for (const [u, v] of [[-0.5, -0.45], [0.15, -0.75], [0.55, -0.3]]) lset(L, fl(cx + u * rx), fl(capY + v * ry), '#ffffff');
  }
  function pvShroom(A) {
    A.bg((x, y) => { const h = hash(x >> 2, y >> 2); return h < 0.2 ? '#343c5a' : h < 0.3 ? '#222842' : '#2a3150'; });
    for (const [x, y] of [[5, 16], [33, 12], [15, 41], [36, 36], [27, 20]]) A.px(x, y, '#8af0f0');
    A.obj(L => { for (const [x, len] of [[5, 6], [12, 4], [27, 7], [34, 4]]) lP(L, [[x - 2, -1], [x + 3, -1], [x + 0.5, len]], xx => (xx < x + 0.5 ? '#7a7a9a' : '#54546e')); });
    A.obj(L => lR(L, 0, 51, 40, 5, (x, y) => (y === 51 ? '#4a8a5a' : '#2a4a3a')));
    A.obj(L => { mushroom(L, 9, 52, 7, 4.6, 5); mushroom(L, 31, 52, 5.4, 3.6, 4); mushroom(L, 21, 52, 3.2, 2.4, 2); });
    A.obj(L => { slimeBlob(L, 22, 30, 7.4, 6.2, BLUE_SLIME); slimeBlob(L, 10, 22, 3.8, 3.3, BLUE_SLIME); slimeBlob(L, 32, 24, 3.6, 3.1, BLUE_SLIME); });
  }
  function pvBowl(A) {
    A.bg((x, y) => (x < 4 || x > 35 ? (x === 3 || x === 36 ? INK : SLATE) : fl((x - 4) / 4) % 2 ? '#e8b870' : '#dca860'));
    A.obj(L => { for (const x of [9, 14, 20, 26, 31]) lS(L, ['.x.', 'xxx'], { x: '#a86a3a' }, x - 1, 34); for (const x of [11, 17, 23, 29]) lset(L, x, 40, '#a86a3a'); }, false);
    A.obj(L => {
      const pins = [];
      for (let row = 0; row < 4; row++) for (let i = 0; i <= 3 - row; i++) pins.push([20 + (i - (3 - row) / 2) * 6, 7 + row * 5]);
      for (const [px, py] of pins) lE(L, px, py, 2.4, 2.4, (x, y, u, v) => { const d = u * u + v * v; return d < 0.2 ? '#ffffff' : d < 0.55 ? '#fe4c40' : u + v < 0 ? '#ffffff' : '#dfe7f2'; });
    });
    A.obj(L => { lE(L, 20, 47, 4.4, 4.4, ['#a87aff', '#6a3ad8', '#3a1a8a']); lset(L, 18, 45, INK); lset(L, 21, 45, INK); lset(L, 19, 48, INK); });
  }
  function iceCube(L, x0, y0, s) {
    lR(L, x0, y0, s, s, (x, y) => (y === y0 || x === x0 ? '#e6fbff' : y === y0 + s - 1 || x === x0 + s - 1 ? '#5ab8e0' : '#9fe6ff'));
    MB5(L, x0 + fl(s / 2), y0 + fl(s / 2), ['#7fbfdc', '#d2f2ff', '#ffffff']);
    lset(L, x0 + s - 3, y0 + 1, '#ffffff'); lset(L, x0 + s - 2, y0 + 2, '#ffffff');
  }
  function pvIce(A) {
    A.bg((x, y) => {
      const a1 = 9 + 2 * Math.sin(x / 4.5), a2 = 13 + 1.6 * Math.sin(x / 5.5 + 2);
      if (Math.abs(y + 0.5 - a1) < 1.2) return '#2fd0a0';
      if (Math.abs(y + 0.5 - a2) < 0.8) return '#7a7aff';
      return '#1d3f8c';
    });
    A.obj(L => { for (const [x, len] of [[7, 4], [12, 3], [18, 5], [25, 3], [31, 4], [38, 3]]) lP(L, [[x - 1.5, -1], [x + 2.5, -1], [x + 0.5, len]], xx => (xx < x + 0.5 ? '#e6fbff' : '#9fd8f0')); });
    A.obj(L => lE(L, 23, 41, 28, 7, SNOW));
    A.obj(L => { iceCube(L, 1, 26, 9); iceCube(L, 10, 26, 9); iceCube(L, 5, 17, 9); iceCube(L, 30, 26, 9); iceCube(L, 37, 26, 9); iceCube(L, 34, 17, 9); });
    A.obj(L => {
      lE(L, 20.5, 29, 1.2, 2.8, BLK); lE(L, 27.5, 29, 1.2, 2.8, BLK);
      lE(L, 24, 28, 3.8, 5.6, BLK);
      lE(L, 24, 30, 2.4, 3.6, ['#ffffff', '#f0f4f8', '#c8d4e0']);
      lset(L, 22, 25, '#ffffff'); lset(L, 22, 26, INK); lset(L, 25, 25, '#ffffff'); lset(L, 25, 26, INK);
      lset(L, 23, 27, '#ff9700'); lset(L, 24, 27, '#ff9700');
      for (const x of [22, 23, 25, 26]) lset(L, x, 34, '#ff9700');
    });
  }
  function pvSwamp(A) {
    A.bg((x, y) => (y < 26 ? ((y === 7 || y === 14) && (x + y) % 5 < 3 ? '#6e8e66' : '#5a7a58') : y === 26 ? '#7aa87a' : (y + x) % 7 === 0 ? '#3a6a4a' : '#2a4e3a'));
    A.obj(L => {
      for (const [x, top] of [[2, 12], [4, 9], [6, 14], [39, 11], [41, 8], [43, 13]]) { for (let y = top; y <= 27; y++) lset(L, x, y, '#4a8a3a'); lR(L, x, top - 4, 2, 4, (xx, yy) => (yy === top - 4 ? '#a8703a' : '#7a4a22')); }
    });
    A.obj(L => { lE(L, 9, 31, 4.2, 1.4, ['#9af06a', '#4cc83a', '#2a8a2a'], (x, y) => !(x === 9 && y <= 31)); lE(L, 35, 34, 3.6, 1.2, ['#9af06a', '#4cc83a', '#2a8a2a']); });
    A.obj(L => {
      slimeBlob(L, 23, 19, 9.5, 8, AMBER, false);
      lE(L, 23, 19.5, 5.5, 4.4, (x, y, u, v) => (u + v < -0.3 ? '#ffe6a0' : '#ffc860'), (x, y) => y < 22);
      MB5(L, 22, 20, STEELM);
      for (const ex of [19, 26]) { lset(L, ex, 15, INK); lset(L, ex, 16, INK); }
    });
    for (const [x, y] of [[14, 30], [30, 29], [20, 34]]) { A.px(x, y, '#a8d8a8'); A.px(x + 1, y - 1, '#a8d8a8'); }
  }
  function pvCoin(A) {
    A.bg((x, y) => (y < 8 ? '#2a3438' : y > 33 ? DEEP : (x + y * 2) % 9 === 0 ? '#44565e' : '#3a4a52'));
    A.obj(L => lR(L, 3, 1, 40, 7, (x, y) => (y === 1 ? ALU[0] : y === 7 ? ALU[3] : x % 5 === 0 ? ALU[2] : ALU[1])));
    A.obj(L => {
      const coins = [[8, 12], [15, 11], [24, 12], [33, 11], [39, 13], [5, 18], [12, 17], [19, 18], [27, 17], [35, 18], [42, 19], [8, 24], [15, 23], [22, 24], [30, 23], [38, 25], [4, 30], [12, 30], [19, 29], [26, 30], [33, 29], [41, 31]];
      coins.sort((a, b) => a[1] - b[1]).forEach(([cx, cy]) => lE(L, cx, cy, 3.2, 2.2, (x, y, u, v) => (u * u + v * v > 0.6 ? GOLD[2] : u + v < -0.2 ? GOLD[0] : GOLD[1])));
      lS(L, ['.k.', 'kak', '.k.'], { k: INK, a: RED[1] }, 22, 26);
    });
    A.obj(L => { lR(L, 0, 33, 46, 1, GOLD[1]); lE(L, 17, 36.5, 3, 1.4, (x, y, u, v) => (v < 0 ? GOLD[0] : GOLD[2])); lE(L, 30, 37.5, 3, 1.4, (x, y, u, v) => (v < 0 ? GOLD[0] : GOLD[2])); }, false);
  }
  function hen(L, cx, cy, dir) {
    const HEN = ['#ffffff', '#f0ece4', '#c8c0b4'];
    lP(L, [[cx - dir * 4, cy - 1], [cx - dir * 9, cy - 7], [cx - dir * 9, cy - 2], [cx - dir * 6, cy + 2]], HEN[2]);
    lE(L, cx, cy, 6.2, 4.6, HEN);
    lE(L, cx + dir * 4.5, cy - 4.5, 3, 2.8, HEN);
    lE(L, cx + dir * 4, cy - 7.6, 1.2, 1.1, '#fe4c40'); lE(L, cx + dir * 5.6, cy - 7.4, 1.1, 1.1, '#fe4c40');
    lP(L, [[cx + dir * 7, cy - 5.5], [cx + dir * 9.5, cy - 4.6], [cx + dir * 7, cy - 3.6]], '#ff9700');
    lset(L, fl(cx + dir * 6.5), fl(cy - 2.6), '#fe4c40');
    lset(L, fl(cx + dir * 5), fl(cy - 5.2), INK);
  }
  function pvHen(A) {
    A.bg((x, y) => (y === 6 || y === 7 ? '#a83424' : x % 6 === 0 ? '#a83424' : '#c8402e'));
    const STRAW = ['#ffe070', '#f0c040', '#c89820'];
    A.obj(L => lR(L, 0, 33, 46, 6, (x, y) => ((x + y) % 4 === 0 ? '#c89820' : y === 33 ? '#ffe070' : '#f0c040')));
    A.obj(L => {
      for (const [cx, dir] of [[12, -1], [34, 1]]) {
        lE(L, cx, 30, 9, 3, STRAW);
        hen(L, cx, 24, dir);
        for (const dx of [-5, -1, 3]) MB5(L, cx + dx + 1, 29, ['#c8c0b4', '#f6f2ea', '#ffffff']);
        lE(L, cx, 31.5, 9.5, 2, STRAW, (x, y) => y >= 31);
      }
    });
  }
  function pvGarden(A) {
    A.bg((x, y) => (y < 22 ? '#b4dcf4' : (y - 22) % 5 === 0 ? '#8a5226' : '#6a3e1e'));
    A.obj(L => {
      const BANDS = ['#fe4c40', '#ff9700', '#ffd23a', '#36b24a', '#2f86ea'];
      for (let y = 0; y < 22; y++) for (let x = 0; x < 46; x++) { const d = Math.hypot(x + 0.5 - 23, y + 0.5 - 24); const k = fl(18 - d); if (k >= 0 && k < 5) lset(L, x, y, BANDS[k]); }
    }, false);
    A.obj(L => { lPuff(L, [[4, 19, 4, 2.6], [8, 17.5, 3.6, 2.8], [11, 19.5, 3, 2]], CLOUD, 20); lPuff(L, [[35, 19, 3, 2], [38.5, 17.5, 3.8, 2.8], [42, 19, 3.4, 2.4]], CLOUD, 20); });
    A.obj(L => {
      for (const [cx, cy] of [[7, 27], [19, 32], [30, 27], [41, 32], [13, 37], [36, 37]]) {
        lE(L, cx, cy, 3.6, 2.8, ['#b8f070', '#4cc83a', '#2a8a2a']);
        lset(L, cx, fl(cy) - 1, '#d8ffb0'); lset(L, cx - 1, fl(cy), '#2a8a2a'); lset(L, cx + 1, fl(cy), '#2a8a2a');
      }
    });
    A.obj(L => {
      lR(L, 21, 25, 9, 2, '#f6dcb4'); lset(L, 29, 23, '#f6dcb4'); lset(L, 29, 24, '#f6dcb4'); lset(L, 30, 22, INK);
      lE(L, 24, 22.5, 3.4, 3.2, ['#ffc070', '#e88a2a', '#a85a20']);
      for (const [x, y] of [[24, 21], [25, 22], [24, 23], [23, 22]]) lset(L, x, y, '#a85a20');
    });
  }
  function pvSnow(A) {
    A.bg((x, y) => (y > 34 ? DEEP : y % 4 === 2 && x % 6 === (fl(y / 4) % 2) * 3 ? '#d4e6f6' : '#eef6ff'));
    A.obj(L => { lR(L, 2, 1, 42, 5, (x, y) => (y === 1 ? '#ff8a7a' : y === 5 ? '#b8322a' : '#fe4c40')); for (const x of [6, 22, 38]) lset(L, x, 3, YEL[0]); });
    A.obj(L => { for (const [cx, cy, r] of [[8, 13, 2.4], [15, 20, 3.6], [27, 12, 2], [33, 21, 4.6], [22, 28, 2.6], [40, 29, 3], [9, 29, 2.2], [30, 31, 2]]) lE(L, cx, cy, r, r, SNOW); });
    A.obj(L => lR(L, 0, 34, 46, 1, '#9ab0c8'), false);
  }
  function seal(L, cx, yb, dir, ball) {
    const S = ['#9ab8d4', '#6a8aa8', '#4a6a88'];
    lE(L, cx, yb - 4, 3.2, 4.2, S);
    lE(L, cx + dir * 1.2, yb - 9, 2.2, 1.9, S);
    lset(L, fl(cx + dir * 3), fl(yb - 9.5), INK);
    lE(L, cx - dir * 0.5, yb - 2, 1.4, 2, S[2]);
    MB5(L, fl(cx + dir * 1.5), fl(yb - 13), ball);
  }
  function pvCircus(A) {
    A.bg((x, y) => (x % 8 < 4 ? '#b8282e' : '#c83238'));
    A.obj(L => {
      for (let x = 0; x < 53; x++) {
        const k = fl(x / 6), cxs = k * 6 + 3, bottom = 3 + Math.sqrt(Math.max(0, 9 - (x + 0.5 - cxs) ** 2)) * 0.8;
        for (let y = 0; y <= bottom; y++) lset(L, x, y, k % 2 ? '#fff0d0' : '#fe4c40');
      }
    });
    for (let x = 3; x < 53; x += 5) A.px(x, 8 + (x % 2), YEL[1]);
    for (let r = 0; r < 3; r++) for (let i = 0; i < 4 - (r % 2); i++) A.px(19 + i * 5 + (r % 2) * 2.5, 12 + r * 4, YEL[1]);
    A.obj(L => {
      for (const cx of [8, 45]) { lR(L, cx - 5, 21, 10, 5, (x, y) => (y === 23 ? YEL[1] : x === cx - 5 ? '#7ac0ff' : x === cx + 4 ? '#1a5fb0' : '#2f86ea')); lE(L, cx, 21, 5, 1.4, YEL); }
      seal(L, 8, 21, 1, mramp(RED)); seal(L, 45, 21, -1, mramp(YEL));
    });
    A.obj(L => lR(L, 0, 26, 53, 1, '#e8c070'), false);
  }
  // 十八台的画面数据：f 卡框三色、em 徽章芯、mode 侧视/俯视、paint 小预览
  const LOOK = {
    dog: { f: ['#ffe066', '#ffbe1a', '#e8860c'], em: '#7fc2ff', mode: 'side', paint: pvDog },
    slime: { f: ['#c8f080', '#8ad048', '#4a9a2a'], em: '#ff6aa8', mode: 'side', paint: pvSlime },
    ring: { f: ['#e8b880', '#c8925a', '#8a5a2a'], em: '#2f86ea', mode: 'top', paint: pvRing },
    volcano: { f: ['#ff8a4a', '#e8452a', '#a82a1a'], em: '#3d1a5a', mode: 'side', paint: pvVolc },
    shroom: { f: ['#8a8ad8', '#5a5ab0', '#363680'], em: '#8af0f0', mode: 'side', paint: pvShroom },
    bowl: { f: ['#6ae0d8', '#2fb8b0', '#1f8078'], em: '#6a3ad8', mode: 'top', paint: pvBowl },
    ice: { f: ['#e6fbff', '#9fe6ff', '#4fb0d8'], em: '#1d3f8c', mode: 'side', paint: pvIce },
    swamp: { f: ['#c8b070', '#9a8040', '#6a5428'], em: '#ffb030', mode: 'side', paint: pvSwamp },
    coin: { f: ['#ff8a7a', '#e8343a', '#a82228'], em: '#ffd23a', mode: 'top', paint: pvCoin },
    hen: { f: ['#ffffff', '#ece6d8', '#b8ae9a'], em: '#f0c040', mode: 'side', paint: pvHen },
    garden: { f: ['#e09a52', '#b8742e', '#7a4a1e'], em: '#ff6a9a', mode: 'side', paint: pvGarden },
    snow: { f: ['#c8e4ff', '#7aa8e0', '#4a72b0'], em: '#fe4c40', mode: 'top', paint: pvSnow },
    circus: { f: ['#7a9aff', '#2a4ad8', '#1a2a90'], em: '#fe4c40', mode: 'side', paint: pvCircus },
    // 后几台（11-11 粗做）：桌上那张借样图 13，机台里的干净卡新画
    fish: { f: ['#7ae0d0', '#2fa898', '#1f7068'], em: '#ffd23a', mode: 'side', paint: () => {} },
    soccer: { f: ['#ffffff', '#7ac0ff', '#2f86ea'], em: '#36b24a', mode: 'top', paint: () => {} },
    pool: { f: ['#c8864a', '#9a5a2a', '#6a3a1a'], em: '#2f8a4a', mode: 'top', paint: () => {} },
  };

  // =========================================================================
  // 右边：换珠机、兑奖柜、陈列柜；柜台上：铜铃、会员卡机、摆件；台阶上方：大奖灯
  // =========================================================================
  const CHG = { x0: 428, yb: 252 };
  function tubes(x0, y0, y1, kinds) {
    kinds.forEach((m, t) => {
      const tx = x0 + 6 + t * 8, C = MARB[m], lv = [9, 8, 9, 7, 8][t];
      D.r(tx - 1, y0, 9, y1 - y0 + 1, INK);
      D.r(tx, y0 + 1, 7, y1 - y0 - 1, '#cfe0e6');
      for (let k = 0; k < lv; k++) { const yy = y1 - 5 - k * 4; if (yy > y0) D.s(MARBLE5, { k: INK, s: C[0], w: C[1], h: C[2] }, tx + 1, yy); }
    });
  }
  function changer(kinds) {
    const x0 = CHG.x0, w = 51, y = CHG.yb - 95, Bk = Cz.black;
    obj(x0, y, w, 95, g => {
      g.e(x0 + 25.5, y + 20, 25.5, 20, (X, Y, u, v) => (v > 0 ? null : u * u + v * v > 0.74 ? GOLD[1] : '#c8243a'));
      g.r(x0, y + 20, w, 75, Bk[1]); g.r(x0, y + 20, 1, 75, Bk[0]); g.r(x0 + w - 2, y + 20, 2, 75, Bk[2]);
      g.r(x0 + 2, y + 20, w - 4, 1, GOLD[1]);
      g.r(x0, y + 61, w, 1, GOLD[2]);
      for (let t = 0; t < 5; t++) g.r(x0 + 7 + t * 8, y + 64, 5, 2, RED[1]);
      g.r(x0 + 19, y + 69, 13, 5, GOLD[1]); g.r(x0 + 21, y + 71, 9, 1, INK);
      g.r(x0 + 12, y + 77, 27, 8, '#0c0c10'); g.r(x0 + 12, y + 84, 27, 1, GOLD[1]);
      g.r(x0, y + 88, w, 1, GOLD[1]); g.r(x0, y + 89, w, 6, Bk[2]);
    });
    const C = MARB.glass;
    D.s(MARBLE7, { k: INK, s: C[0], w: C[1], h: C[2] }, x0 + 22, y + 6);
    tubes(x0, y + 22, y + 59, kinds);
  }
  function bell(cx, yb) {
    const dome = GOLD, base = [Cz.black[0], Cz.black[1]];
    obj(cx - 11, yb - 15, 23, 16, g => {
      g.e(cx + 0.5, yb - 3, 8.5, 8.5, (x, y, u, v) => (v > 0 ? null : u + v < -0.85 ? dome[0] : u > 0.4 ? dome[2] : dome[1]));
      g.r(cx - 9, yb - 3, 20, 3, base[1]); g.r(cx - 9, yb - 3, 20, 1, base[0]);
      g.r(cx, yb - 13, 2, 2, dome[2]); g.r(cx - 1, yb - 14, 4, 1, dome[1]);
    });
  }
  // 升级的小图标（按增长点的字分）：签 = 一捆、速 = 木槌、价 = 一颗核、准 = 准星、救 = 护栏、倍 = 乘号
  const STAR9 = ['....h....', '...hxx...', '...xxx...', 'hhxxxxxxx', '.xxxxxxx.', '..xxxxx..', '..xx.xx..', '.xx...xx.', '.x.....x.'];
  const STAR5 = ['..x..', '.xxx.', 'xxxxx', '.xxx.', '.x.x.'];
  function upIcon(tag, x, yb, C) {
    C = C || GRN;
    if (tag === '签') obj(x, yb - 16, 18, 16, g => { for (const [dx, dy] of [[2, 6], [8, 6], [5, 1]]) { g.e(x + dx + 3.5, yb - 16 + dy + 4, 3.5, 3.5, (X, Y, u, v) => (u + v < -0.5 ? C[0] : u + v > 0.5 ? C[2] : C[1])); } g.r(x + 1, yb - 3, 14, 2, GOLD[1]); });
    else if (tag === '速') obj(x, yb - 18, 18, 18, g => { g.l(x + 3, yb - 2, x + 10, yb - 11, WOOD[2]); g.l(x + 4, yb - 2, x + 11, yb - 11, WOOD[1]); g.r(x + 8, yb - 17, 9, 6, WOOD[1]); g.r(x + 8, yb - 17, 9, 1, WOOD[0]); g.r(x + 8, yb - 17, 2, 6, RED[1]); g.r(x + 15, yb - 17, 2, 6, RED[1]); });
    else if (tag === '价') obj(x, yb - 16, 16, 16, g => { g.p([[x + 8, yb - 15], [x + 14, yb - 8], [x + 8, yb - 1], [x + 2, yb - 8]], (X, Y) => (X + Y < x + yb - 7 ? C[0] : X > x + 8 ? C[2] : C[1])); g.px(x + 6, yb - 11, '#ffffff'); g.px(x + 7, yb - 12, '#ffffff'); });
    else if (tag === '准') obj(x, yb - 16, 16, 16, g => { g.e(x + 8, yb - 8, 6.5, 6.5, (X, Y, u, v) => (u * u + v * v > 0.55 ? RED[1] : null)); g.r(x + 7, yb - 15, 2, 14, RED[1]); g.r(x + 1, yb - 9, 14, 2, RED[1]); g.r(x + 7, yb - 9, 2, 2, '#ffffff'); });
    else if (tag === '救') obj(x, yb - 14, 18, 14, g => { g.r(x, yb - 5, 18, 3, GOLD[1]); g.r(x, yb - 5, 18, 1, GOLD[0]); for (const dx of [1, 8, 15]) g.r(x + dx, yb - 12, 2, 10, ALU[1]); g.r(x, yb - 12, 18, 2, RED[1]); });
    else if (tag === '倍') obj(x, yb - 14, 14, 14, g => { for (let i = 0; i < 12; i++) { g.r(x + i, yb - 13 + i, 2, 1, YEL[1]); g.r(x + 11 - i, yb - 13 + i, 2, 1, YEL[1]); } });
  }
  // 兑奖柜：上层是最新开的那台的升级（挂真价签），下层是还没买的摆件
  const SC = { x0: 486, x1: 590, yb: 252 };
  function showcase(vm) {
    const F = GOLD, { x0, x1 } = SC, y = SC.yb - 68, w = x1 - x0 + 1, mid = x0 + 52;
    obj(x0, y, w, 68, g => g.r(x0, y, w, 68, VELV[1]));
    const dashed = (bx, by) => { for (let i = 0; i < 16; i++) for (const [px, py] of [[bx + i, by], [bx + i, by + 15], [bx, by + i], [bx + 15, by + i]]) if (i % 2 === 0) P(px, py, VELV[0]); };
    const S = vm.shelf;
    S.ups.forEach((u, k) => { if (u.sold) dashed(x0 + 4 + k * 25, y + 10); else upIcon(u.tag, x0 + 4 + k * 25, y + 29, TIX[S.chip].chip); });
    for (let k = S.ups.length; k < 4; k++) dashed(x0 + 4 + k * 25, y + 10);
    S.trinkets.forEach((t, k) => { if (t) TRINKET_ART[t](x0 + 6 + k * 25, y + 58); else dashed(x0 + 5 + k * 25, y + 41); });
    for (const x of [x0, mid, x1 - 1]) obj(x, y + 5, 2, 55, g => { g.r(x, y + 5, 1, 55, F[0]); g.r(x + 1, y + 5, 1, 55, F[2]); });
    obj(x0, y, w, 5, g => { g.r(x0, y, w, 1, F[0]); g.r(x0, y + 1, w, 1, '#f0e0e4'); g.r(x0, y + 2, w, 1, INK); g.r(x0, y + 3, w, 1, F[0]); g.r(x0, y + 4, w, 1, F[2]); });
    obj(x0, y + 30, w, 8, g => { g.r(x0, y + 30, w, 1, F[0]); g.r(x0, y + 31, w, 6, F[1]); g.r(x0, y + 37, w, 1, F[2]); });
    obj(x0, y + 60, w, 8, g => { g.r(x0, y + 60, w, 1, F[0]); g.r(x0, y + 61, w, 6, F[1]); g.r(x0, y + 67, w, 1, F[2]); });
    S.ups.forEach((u, k) => { if (!u.sold) priceTag(x0 + 3 + k * 25, y + 31, S.pay, u.price, u.poor); });
  }
  // 会员卡机：屏上是现在转能拿几颗星
  const VIP = { x: 598, yb: 300 };
  function vipReader(stars) {
    const x = VIP.x, y = VIP.yb - 30, Bk = Cz.black;
    obj(x + 6, y - 12, 18, 16, g => { g.r(x + 6, y - 12, 18, 16, GOLD[1]); g.r(x + 6, y - 12, 18, 1, GOLD[0]); g.r(x + 9, y - 9, 5, 4, GOLD[2]); g.r(x + 10, y - 8, 3, 2, GOLD[0]); g.r(x + 16, y - 9, 6, 1, GOLD[2]); g.r(x + 16, y - 7, 4, 1, GOLD[2]); });
    obj(x, y, 30, 30, g => {
      g.r(x, y, 30, 30, Bk[1]); g.r(x, y, 30, 2, Bk[0]); g.r(x + 28, y + 2, 2, 28, Bk[2]);
      g.r(x + 4, y, 22, 1, INK);
      g.r(x + 3, y + 6, 24, 9, '#2a0808');
      const s = short(stars), sw = 6 + numW35(s), sx = x + 15 - fl(sw / 2);
      g.s(STAR5, { x: GOLD[1] }, sx, y + 8);
      num35(g, s, sx + 6, y + 8, RED[1]);
      g.e(x + 15, y + 22, 3, 3, RED[1]);
    });
  }
  // 大奖灯：台阶上方墙上一块灯牌。左边金星 + 红数码管 = 锅里攒了几颗星；右边 10 盏灯 = 再打几发多一颗（一盏 10 发）
  const JACK = { cx: SX0 + PITCH * 3, y: 34, w: 176, h: 25 };
  function jackpotSign(stars, prog) {
    const { w, h, y } = JACK, x = fl(JACK.cx - w / 2);
    for (const dx of [30, w - 31]) for (let yy = WALL0; yy < y; yy++) P(x + dx, yy, yy % 2 ? GOLD[2] : GOLD[1]);
    obj(x, y, w, h, g => {
      g.r(x, y, w, h, GOLD[1]); g.r(x, y, w, 1, GOLD[0]); g.r(x, y, 1, h, GOLD[0]); g.r(x, y + h - 1, w, 1, GOLD[2]); g.r(x + w - 1, y, 1, h, GOLD[2]);
      g.r(x + 2, y + 2, w - 4, h - 4, '#4a0c1a');
      let k = 0;
      const bulb = (bx, by) => { g.px(bx, by, k++ % 2 ? '#fff6c0' : '#8c1f2e'); };
      for (let bx = x + 3; bx <= x + w - 4; bx += 3) bulb(bx, y + 3);
      for (let by = y + 6; by <= y + h - 4; by += 3) bulb(x + w - 4, by);
      for (let bx = x + w - 4; bx >= x + 3; bx -= 3) bulb(bx, y + h - 4);
      for (let by = y + h - 7; by >= y + 6; by -= 3) bulb(x + 3, by);
      g.r(x + 5, y + 5, w - 10, h - 10, '#12060a');
    });
    const s = String(stars), dw = s.length * 8 - 2, gx = x + 14, gy = y + 8;
    obj(gx, gy, 9, 9, g => g.s(STAR9, { x: GOLD[1], h: GOLD[0] }, gx, gy));
    [...s].forEach((ch, n) => D35[ch].forEach((row, j) => { for (let i = 0; i < 3; i++) if (row[i] === 'x') D.r(gx + 13 + n * 8 + i * 2, y + 7 + j * 2, 2, 2, '#fe4c40'); }));
    for (let i = 0; i < 10; i++) {
      const lx = gx + 13 + Math.max(dw, 14) + 12 + i * 11, on = i < prog;
      D.r(lx, y + 9, 7, 7, on ? YEL[1] : '#3a0c18');
      D.r(lx + 1, y + 9, 5, 1, on ? '#ffffff' : '#5a1626'); D.r(lx, y + 15, 7, 1, on ? YEL[2] : '#24060c');
    }
  }
  // 陈列柜：三层（一类一层），一层六格（一台一格），一格三样：上面手上功夫（大奖），下面左碰运气、右打得深。下面一排奖章（挑战）
  const CAB = { x: 490, y: 92, w: 92, h: 66 };
  const ITEM = {
    luck: ['.ccc.', 'cwccc', 'ccccc', 'cccdc', '.ccc.'],
    skill: ['ggggg', 'whggg', '.ggg.', '..g..', '.ggg.'],
    deep: ['s.s.s', 'sssss', 'swsss', 'sssss', '.....'],
  };
  const SHELF_ORDER = [[1, 4, 7, 10, 13, 16], [2, 5, 8, 11, 14, 17], [3, 6, 9, 12, 15, 18]];
  function cabinet(vm) {
    const { x, y, w, h } = CAB, WD = ['#8a5a3a', '#5a3420', '#3a2014'], BACK = '#1a1e3a', GHOST = '#0c0e1c';
    obj(x + 30, y - 6, 32, 7, g => { g.p([[x + 30, y], [x + 46, y - 6], [x + 62, y]], (X, Y) => (Y === y ? WD[2] : X < x + 46 ? WD[0] : WD[1])); g.s(STAR5, { x: GOLD[1] }, x + 44, y - 4); });
    obj(x, y, w, h, g => {
      g.r(x, y, w, h, WD[1]); g.r(x, y, w, 1, WD[0]); g.r(x, y, 1, h, WD[0]); g.r(x + w - 1, y, 1, h, WD[2]); g.r(x, y + h - 1, w, 1, WD[2]);
      g.r(x + 3, y + 3, w - 6, h - 6, BACK);
    });
    for (let s = 0; s < 3; s++) {
      const sy = y + 3 + s * 15;
      D.r(x + 3, sy + 13, w - 6, 1, WD[0]); D.r(x + 3, sy + 14, w - 6, 1, WD[2]);
      for (let c = 0; c < 6; c++) {
        const n = SHELF_ORDER[s][c], id = vm.ids[n - 1], cx = x + 3 + c * 14 + 1, col = TIX[vm.chipOf[n - 1]].chip;
        const got = ['luck', 'skill', 'deep'].map(k => !!vm.cab[id + '.' + k]);
        if (c > 0) D.r(cx - 1, sy, 1, 13, WD[2]);
        const put = (rows, ox, oy, k, map) => D.s(rows, got[k] ? map : Object.fromEntries(Object.keys(map).map(key => [key, GHOST])), ox, oy);
        put(ITEM.skill, cx + 4, sy + 1, 1, { g: GOLD[1], h: GOLD[0], w: '#ffffff' });
        put(ITEM.luck, cx + 1, sy + 7, 0, { c: col[1], w: '#ffffff', d: col[2] });
        put(ITEM.deep, cx + 7, sy + 7, 2, { s: ALU[1], w: '#ffffff' });
      }
    }
    const my = y + 3 + 45;
    for (let k = 0; k < 8; k++) {
      const mx = x + 8 + k * 10, got = !!vm.medals[k];
      D.s(['r.b', 'rrb'], { r: got ? RED[1] : GHOST, b: got ? BLU[1] : GHOST }, mx + 1, my + 2);
      D.e(mx + 2.5, my + 8, 2.6, 2.6, got ? GOLD[1] : GHOST);
      if (got) D.px(mx + 1, my + 7, GOLD[0]);
    }
  }
  // ---------- 摆件 ----------
  function luckyCat(x, yb) {
    obj(x, yb - 17, 14, 17, g => {
      g.e(x + 7, yb - 5, 5.5, 5, (X, Y, u, v) => (u + v > 0.6 ? '#e8e0d4' : '#ffffff'));
      g.e(x + 7, yb - 11.5, 5, 4.2, (X, Y, u, v) => (u + v > 0.7 ? '#e8e0d4' : '#ffffff'));
      g.p([[x + 2.5, yb - 13], [x + 3.5, yb - 17], [x + 6, yb - 14.5]], '#ffffff'); g.p([[x + 8, yb - 14.5], [x + 10.5, yb - 17], [x + 11.5, yb - 13]], '#ffffff');
      g.px(x + 4, yb - 15, '#ff9aa8'); g.px(x + 10, yb - 15, '#ff9aa8');
      g.r(x, yb - 15, 2, 6, '#ffffff'); g.r(x, yb - 16, 2, 1, '#ff9aa8');
      g.r(x + 3, yb - 8, 9, 1, RED[1]); g.px(x + 7, yb - 7, GOLD[1]);
      g.px(x + 5, yb - 12, INK); g.px(x + 9, yb - 12, INK); g.px(x + 7, yb - 10, '#ff9aa8');
      g.e(x + 9.5, yb - 4, 1.8, 2.4, (X, Y, u, v) => (u + v < 0 ? GOLD[0] : GOLD[1]));
    });
  }
  function alarmClock(x, yb) {
    obj(x, yb - 15, 14, 15, g => {
      g.e(x + 3, yb - 12, 2.3, 2, (X, Y, u, v) => (v > 0.3 ? null : GOLD[1])); g.e(x + 11, yb - 12, 2.3, 2, (X, Y, u, v) => (v > 0.3 ? null : GOLD[1]));
      g.e(x + 7, yb - 7, 5.5, 5.5, (X, Y, u, v) => (u + v < -0.7 ? RED[0] : u + v > 0.6 ? RED[2] : RED[1]));
      g.e(x + 7, yb - 7, 3.8, 3.8, '#ffffff');
      g.r(x + 7, yb - 10, 1, 3, INK); g.r(x + 7, yb - 7, 3, 1, INK);
      g.px(x + 2, yb - 1, INK); g.px(x + 12, yb - 1, INK);
    });
  }
  function eggTimer(x, yb) {
    obj(x, yb - 13, 10, 13, g => {
      g.e(x + 5, yb - 6.5, 4.2, 6, (X, Y, u, v) => (v < -0.05 ? (u > 0.4 ? '#e8dcc0' : '#fff6e0') : u > 0.4 ? '#e8a020' : '#ffc840'));
      g.r(x + 1, yb - 7, 8, 1, '#a87a20');
      for (const dx of [2, 4, 6, 8]) g.px(x + dx, yb - 9, '#a87a20');
      g.px(x + 5, yb - 6, RED[1]); g.px(x + 4, yb - 5, RED[1]); g.px(x + 6, yb - 5, RED[1]);
    });
  }
  function glove(x, yb) {
    obj(x, yb - 14, 11, 14, g => {
      for (const [dx, top] of [[1, 6], [3, 4], [5, 3], [7, 4]]) g.r(x + dx, yb - 14 + top - 3, 2, 8, '#ffffff');
      g.e(x + 5, yb - 5.5, 4.4, 3.6, '#ffffff');
      g.r(x + 8, yb - 8, 3, 2, '#ffffff');
      g.r(x + 2, yb - 3, 7, 3, RED[1]); g.r(x + 2, yb - 3, 7, 1, RED[0]);
      g.px(x + 3, yb - 9, '#dfe7f2'); g.px(x + 5, yb - 10, '#dfe7f2');
    });
  }
  function autoChanger(x, yb) {
    obj(x, yb - 19, 13, 19, g => {
      g.e(x + 6.5, yb - 13, 5.5, 5.5, (X, Y, u, v) => (u + v < -0.9 ? '#ffffff' : '#d8f0f8'));
      for (const [dx, dy, c] of [[4, -13, RED[1]], [8, -14, BLU[1]], [6, -11, YEL[1]], [9, -11, GRN[1]], [4, -10, PUR[1]]]) g.r(x + dx, yb + dy, 2, 2, c);
      g.p([[x + 2, yb - 8], [x + 11, yb - 8], [x + 12, yb], [x + 1, yb]], (X, Y) => (X < x + 3 ? RED[0] : X > x + 9 ? RED[2] : RED[1]));
      g.r(x + 5, yb - 5, 3, 1, GOLD[1]); g.r(x + 5, yb - 3, 3, 2, INK);
    });
  }
  function piggy(x, yb) {
    obj(x, yb - 16, 17, 16, g => {
      g.e(x + 8, yb - 6, 6.5, 4.6, (X, Y, u, v) => (u + v < -0.7 ? '#ffd0e0' : u + v > 0.6 ? '#e07aa0' : '#ffa8c8'));
      g.p([[x + 4, yb - 9], [x + 5, yb - 13], [x + 7, yb - 10]], '#ff90b8');
      g.e(x + 14.5, yb - 6.5, 1.7, 1.9, '#ff90b8'); g.px(x + 14, yb - 7, '#c85a80'); g.px(x + 15, yb - 6, '#c85a80');
      g.px(x + 11, yb - 8, INK);
      for (const dx of [3, 6, 10, 12]) g.r(x + dx, yb - 2, 2, 2, '#e07aa0');
      g.r(x + 6, yb - 11, 4, 1, INK);
      g.e(x + 8, yb - 14, 2.2, 1.3, (X, Y, u, v) => (v < 0 ? GOLD[0] : GOLD[2]));
      g.px(x + 1, yb - 7, '#e07aa0'); g.px(x, yb - 8, '#e07aa0');
    });
  }
  const TRINKET_ART = { cat: luckyCat, clock: alarmClock, egg: eggTimer, glove, auto: autoChanger, piggy };
  const TRINKET_X = { cat: 467, clock: 489, egg: 511, glove: 529, auto: 548, piggy: 569 };

  // =========================================================================
  // 整张桌子。vm 见 game.js 的 tableVm
  // =========================================================================
  function machineSpot(vm, S, lifted) {
    const R = ROW[S.row], x = slotX(S.row, S.col), y = prevY(S.row);
    plinth(x - 1, R.pw + 2, B[S.row], S);
    if (lifted) return;
    if (S.covered) { cloth(x, y, R.pw, R.ph, S.tag); return; }
    preview(Object.assign({}, LOOK[S.id], S), x, y, R.pw, R.ph);
    if (vm.spinOn) spinLamp(x + fl(R.pw / 2), y, S.lit);
    if (S.bot) robot(x + R.pw + 3, B[S.row] - PLH, ['hole', 'fight', 'top'].indexOf(S.kind));
  }
  function wholeTable(vm, liftedN) {
    casinoBack(vm);
    casinoTable();
    if (vm.jackpot) jackpotSign(vm.jackpot.stars, vm.jackpot.prog);
    if (vm.cabinet) cabinet(vm.cabinet); else suits(498, 88);
    const rowOn = r => vm.tiers >= r;
    if (rowOn(3)) { tier(B[3], B[3], B[2] - 1); vm.slots.filter(S => S.row === 3).forEach(S => machineSpot(vm, S, S.n === liftedN)); }
    if (rowOn(2)) { tier(B[2], rowOn(3) ? B[2] : TOP0 - 70, B[1] - 1); vm.slots.filter(S => S.row === 2).forEach(S => machineSpot(vm, S, S.n === liftedN)); }
    tier(B[1], rowOn(2) ? B[1] : TOP0 - 6, B[1] + 12);
    vm.slots.filter(S => S.row === 1).forEach(S => machineSpot(vm, S, S.n === liftedN));
    changer(vm.tubes);
    showcase(vm);
    bell(446, 296);
    vipReader(vm.vipStars);
    for (const k of Object.keys(TRINKET_X)) if (vm.trinkets[k]) TRINKET_ART[k](TRINKET_X[k], 295);
  }
  function renderTable(vm, liftedN) { useKit(PixelKit(W, H)); wholeTable(vm, liftedN == null ? -1 : liftedN); return toCanvas(K); }

  // 桌上能点的东西（全局界面）。返回 [{ id, x, y, w, h }]，先列的先算
  function tableHot(vm) {
    const out = [{ id: 'sound', ...SOUND }];
    for (const S of vm.slots) {
      if (S.row > vm.tiers) continue;
      const r = slotRect(S.n);
      out.push({ id: 'm:' + S.id, x: r.x - 3, y: r.y - 4, w: r.w + 6, h: r.h + PLH + 5 });
    }
    if (vm.jackpot) out.push({ id: 'jackpot', x: fl(JACK.cx - JACK.w / 2), y: JACK.y, w: JACK.w, h: JACK.h });
    if (vm.cabinet) out.push({ id: 'cabinet', x: CAB.x, y: CAB.y - 6, w: CAB.w, h: CAB.h + 6 });
    for (const k of Object.keys(TRINKET_X)) if (vm.trinkets[k]) out.push({ id: 't:' + k, x: TRINKET_X[k] - 1, y: 276, w: 18, h: 21 });
    out.push({ id: 'changer', x: CHG.x0, y: CHG.yb - 95, w: 51, h: 95 });
    out.push({ id: 'showcase', x: SC.x0, y: SC.yb - 68, w: SC.x1 - SC.x0 + 1, h: 68 });
    out.push({ id: 'bell', x: 434, y: 279, w: 24, h: 19 });
    out.push({ id: 'vip', x: VIP.x - 2, y: VIP.yb - 44, w: 34, h: 46 });
    return out;
  }
  const SOUND = { x: 612, y: 4, w: 22, h: 18 };

  // =========================================================================
  // 卡：基础机、火山坑、弹珠出圈、保龄球从样图 13 读回来；史莱姆台、蘑菇洞是新画的
  // =========================================================================
  const PW = 64, PH = 84;
  // 卡宽：第一排小台 64，第二排大台 96，第三排横台 148（高都是 84，台面格子一样大，台宽了放的东西多）
  const WIDE = { swamp: 96, garden: 96, sea: 148, king: 148 };
  const cwOf = id => WIDE[id] || PW;
  const sideOf = memo(pw => ({ x0: 7, x1: pw - 8, y0: 10, y1: 76, ch: 10, hole: 73 }));
  const topOf = memo(pw => ({ x0: 7, x1: pw - 8, y0: 14, y1: 76, r: 3 }));
  const SIDE = sideOf(PW), TOPF = topOf(PW);
  const inCardW = (pw, i, j) => {
    const r = 6, cx = i < r ? r : i > pw - 1 - r ? pw - 1 - r : i, cy = j < r ? r : j > PH - 1 - r ? PH - 1 - r : j;
    return Math.hypot(i - cx, j - cy) <= r + 0.3;
  };
  const inCard = (i, j) => inCardW(PW, i, j);
  const inSideG = (S, x, y) => x >= S.x0 && x <= S.x1 && y >= S.y0 && y <= S.y1 && (x - S.x0) + (y - S.y0) >= S.ch && (S.x1 - x) + (y - S.y0) >= S.ch;
  const inTopG = (T, x, y) => { if (x < T.x0 || x > T.x1 || y < T.y0 || y > T.y1) return false; const r = T.r, cx = x < T.x0 + r ? T.x0 + r : x > T.x1 - r ? T.x1 - r : x, cy = y < T.y0 + r ? T.y0 + r : y > T.y1 - r ? T.y1 - r : y; return Math.hypot(x - cx, y - cy) <= r + 0.3; };
  const inSide = (x, y) => inSideG(SIDE, x, y), inTop = (x, y) => inTopG(TOPF, x, y);
  // 台面里面（虚化只动这里）
  const inArtOf = (mode, pw = PW) => {
    if (mode === 'top') { const T = topOf(pw); return (x, y) => inTopG(T, x, y); }
    const S = sideOf(pw); return (x, y) => inSideG(S, x, y) && y < S.hole;
  };
  // 样图 13 里借来的那张（桌上 1 倍用；机台里虚化的那张有的另画干净的）
  const SHEET = { dog: 0, volcano: 1, ring: 27, bowl: 29, ice: 5, hen: 7, fish: 3, circus: 18, soccer: 24, pool: 25, coin: 28, snow: 30 };
  let sheet = null;
  const cardCache = new Map();
  function sheetCard(k) {
    if (!sheet) sheet = document.getElementById('c').getContext('2d');
    const OX = 22 + (k % 8) * 76, OY = 33 + fl(k / 8) * 110 + (k >= 24 ? 4 : 0);
    const d = sheet.getImageData(OX, OY, PW, PH).data, A = [];
    for (let j = 0; j < PH; j++) { A.push([]); for (let i = 0; i < PW; i++) { const n = (j * PW + i) * 4; A[j].push(inCard(i, j) ? toHex(d[n], d[n + 1], d[n + 2]) : null); } }
    return A;
  }
  function kitToArt(kit) {
    const px = grab(kit), A = [], pw = kit.W;
    for (let j = 0; j < PH; j++) { A.push([]); for (let i = 0; i < pw; i++) { const n = (j * pw + i) * 4; A[j].push(inCardW(pw, i, j) && px[n + 3] ? toHex(px[n], px[n + 1], px[n + 2]) : null); } }
    return A;
  }
  // 新画的卡：卡壳（同样图 13）+ paint(art) 画台面。mode = side（直顶斜角、底下一排洞）或 top（圆角长方形场地）
  function makeCard(mode, look, rail, bgc, paint, pw = PW) {
    const kit = PixelKit(pw, PH), save = K;
    useKit(kit);
    const S = sideOf(pw), T = topOf(pw);
    const F = look.f, inB = mode === 'top' ? (x, y) => inTopG(T, x, y) : (x, y) => inSideG(S, x, y), b = mode === 'top' ? T : S;
    rr(0, 0, pw, PH, 6, (i, j, de) => (de < 1 ? INK : de < 2 ? (i + j < (pw + PH) / 2 ? F[0] : F[2]) : i % 5 === 2 && j % 5 === 2 ? F[0] : F[1]));
    for (let y = b.y0 - 2; y <= b.y1 + 2; y++) for (let x = b.x0 - 2; x <= b.x1 + 2; x++) {
      if (inB(x, y)) continue;
      if (inB(x + 1, y) || inB(x - 1, y) || inB(x, y + 1) || inB(x, y - 1)) P(x, y, INK);
      else if (inB(x + 2, y) || inB(x - 2, y) || inB(x, y + 2) || inB(x, y - 2)) P(x, y, rail);
    }
    const inA = inArtOf(mode, pw);
    for (let y = 0; y < PH; y++) for (let x = 0; x < pw; x++) if (inA(x, y)) P(x, y, bgc(x, y));
    const art = (draw, outline = true) => { const L = layer(pw, PH); draw(L); if (outline) outl(L); for (let y = 0; y < PH; y++) for (let x = 0; x < pw; x++) { const c = lget(L, x, y); if (c && inA(x, y)) P(x, y, c); } };
    paint(art);
    if (mode === 'side') for (let y = S.hole; y <= S.y1; y++) for (let x = S.x0; x <= S.x1; x++) P(x, y, y === S.hole ? INK : SLATE);
    rr(2, 2, 12, 9, 1, (i, j, de) => (de < 1 ? INK : DEEP));
    K.disc(pw - 7.5, 7, 4.6, INK); K.disc(pw - 7.5, 7, 3.6, rail); K.disc(pw - 7.5, 7, 2.4, look.em);
    useKit(save);
    return kitToArt(kit);
  }
  const sideCard = (look, rail, bgc, paint) => makeCard('side', look, rail, bgc, paint);
  // 弹珠出圈：泥地（一格一格的规整小点），四个角几丛草、几块石子；粉笔圈和弹珠在台面那一层画
  function ringCard() {
    return makeCard('top', LOOK.ring, '#fff8ec', (x, y) => (y % 4 === 1 && x % 4 === (fl(y / 4) % 2) * 2 ? '#a8723e' : '#c8925a'), art => {
      art(L => { for (const [x, y] of [[10, 18], [52, 18], [10, 72], [53, 71]]) { lset(L, x, y, GRN[1]); lset(L, x + 1, y - 1, GRN[0]); lset(L, x + 2, y, GRN[1]); lset(L, x + 1, y, GRN[2]); } }, false);
      art(L => { for (const [x, y] of [[13, 30], [50, 58], [16, 63], [48, 24]]) lR(L, x, y, 2, 2, (X, Y) => (Y === y ? '#e0c8a8' : '#9a7a5a')); });
    });
  }
  // 保龄球：木板球道 + 两边沟，最后面一道黑坑（瓶子滚进去才算钱），瓶位画成小圆点；瓶子和球在台面那一层画
  const PIN_SPOTS = [[43, 38], [57, 38], [71, 38], [85, 38], [50, 50], [64, 50], [78, 50], [57, 62], [71, 62], [64, 74]];
  function bowlCard() {
    return makeCard('top', LOOK.bowl, '#ffffff', (x, y) => (x < 12 || x > 51 ? (x === 11 || x === 52 ? INK : SLATE) : fl((x - 12) / 4) % 2 ? '#e8b870' : '#dca860'), art => {
      art(L => { for (const x of [17, 24, 32, 39, 46]) lS(L, ['.x.', 'xxx'], { x: '#a86a3a' }, x - 1, 52); for (const x of [20, 28, 35, 43]) lset(L, x, 60, '#a86a3a'); }, false);
      art(L => { for (const [sx, sy] of PIN_SPOTS) { lset(L, fl(sx / 2), fl(sy / 2), '#b88848'); } }, false);
      art(L => { for (let x = 7; x <= 56; x++) { lset(L, x, 14, DEEP); lset(L, x, 15, INK); lset(L, x, 16, x % 3 ? SLATE : INK); } }, false);
    });
  }
  function slimeCard() {
    return sideCard(LOOK.slime, '#fff3a0', (x, y) => (y < 17 ? '#a8e0ff' : fl((y - 17) / 6) % 2 ? '#3f9a38' : '#46a63e'), art => {
      art(L => { for (const [x, y] of [[11, 31], [47, 29], [27, 40], [13, 50], [50, 47], [33, 60], [10, 66], [53, 64]]) { lset(L, x, y, '#2f7a2e'); lset(L, x + 2, y, '#2f7a2e'); lset(L, x + 1, y + 1, '#2f7a2e'); } }, false);
      art(L => { for (const [x, y] of [[20, 33], [43, 52]]) { for (const [dx, dy] of [[0, -1], [-1, 0], [1, 0], [0, 1]]) lset(L, x + dx, y + dy, '#ffffff'); lset(L, x, y, YEL[1]); } }, false);
      art(L => { for (let x = 7; x <= 56; x++) for (let y = 22; y <= 24; y++) lset(L, x, y, y === 22 ? '#2f7a2e' : '#36863a'); }, false);
      art(L => {
        lPuff(L, [[6, 15, 6, 5], [14, 13, 6.2, 5.4], [23, 15.5, 6, 5], [32, 13, 6.4, 5.4], [41, 15.5, 6, 5], [50, 13, 6.2, 5.4], [58, 15, 6, 5]], TREE);
        for (const [x, y] of [[11, 12], [27, 15], [36, 11], [47, 15], [54, 12]]) lset(L, x, y, RED[1]);
      });
    });
  }
  // 蘑菇洞：深蓝的洞，顶上垂着钟乳石，地上一排蘑菇（真弹柱在台面那一层画），洞壁上几颗发光的小晶石
  function shroomCard() {
    return sideCard(LOOK.shroom, '#8af0f0', (x, y) => { const h = hash(x >> 2, y >> 2); return h < 0.18 ? '#343c5a' : h < 0.27 ? '#222842' : '#2a3150'; }, art => {
      art(L => { for (const [x, y] of [[12, 30], [50, 26], [22, 46], [46, 52], [30, 36], [16, 60], [52, 62]]) { lset(L, x, y, '#8af0f0'); lset(L, x + 1, y, '#3a8a9a'); } }, false);
      art(L => { for (const [x, len] of [[12, 9], [19, 6], [27, 11], [35, 7], [43, 10], [51, 6]]) lP(L, [[x - 3, 9], [x + 3, 9], [x + 0.5, 9 + len]], xx => (xx < x + 0.5 ? '#7a7a9a' : '#54546e')); });
      art(L => lR(L, 7, 68, 50, 5, (x, y) => (y === 68 ? '#4a8a5a' : '#2a4a3a')));
      art(L => { mushroom(L, 12, 69, 4, 2.6, 3); mushroom(L, 50, 69, 3.4, 2.2, 2); });
    });
  }
  // 冰窟（小台 64 宽）：深蓝的冰洞，上面两道极光、一排冰柱，地上一层雪，左边站一只企鹅。
  // 冰块、冰笋、钉子是会碰的，在台面那一层画
  function iceCard() {
    const pw = 64;
    return makeCard('side', LOOK.ice, '#e6fbff', (x, y) => {
      const a1 = 18 + 2 * Math.sin(x / 6), a2 = 23 + 1.6 * Math.sin(x / 7.5 + 2);
      if (Math.abs(y + 0.5 - a1) < 1.1) return '#2fd0a0';
      if (Math.abs(y + 0.5 - a2) < 0.7) return '#7a7aff';
      if (y >= 67) return y === 67 ? '#e6f2fb' : '#b4c8dc';
      return (x % 6 === 3 && y % 6 === 2) || (x % 6 === 0 && y % 6 === 5) ? '#28509e' : '#1d3f8c';
    }, art => {
      art(L => { for (const [x, len] of [[12, 5], [18, 3], [24, 6], [31, 4], [38, 5], [44, 3], [50, 6]]) lP(L, [[x - 2.5, 9], [x + 2.5, 9], [x + 0.5, 10 + len]], xx => (xx < x + 0.5 ? '#e6fbff' : '#9fd8f0')); });
      art(L => lE(L, 16, 66, 7, 2, SNOW));
      art(L => {
        const ox = -8, oy = 33;
        lE(L, 20.5 + ox, 29 + oy, 1.2, 2.8, BLK); lE(L, 27.5 + ox, 29 + oy, 1.2, 2.8, BLK);
        lE(L, 24 + ox, 28 + oy, 3.8, 5.6, BLK);
        lE(L, 24 + ox, 30 + oy, 2.4, 3.6, ['#ffffff', '#f0f4f8', '#c8d4e0']);
        lset(L, 22 + ox, 25 + oy, '#ffffff'); lset(L, 22 + ox, 26 + oy, INK); lset(L, 25 + ox, 25 + oy, '#ffffff'); lset(L, 25 + ox, 26 + oy, INK);
        lset(L, 23 + ox, 27 + oy, '#ff9700'); lset(L, 24 + ox, 27 + oy, '#ff9700');
        for (const x of [22, 23, 25, 26]) lset(L, x + ox, 34 + oy, '#ff9700');
      });
    }, pw);
  }
  // 沼泽（大台 96 宽，照预览图）：暗绿的夜雾，两道雾带，底下一层泥水；两边芦苇（棕色蒲棒），水上两片荷叶，左边荷叶上一只青蛙，几只萤火虫。
  // 史莱姆、挡板、弹弓是会碰的，在台面那一层画
  function swampCard() {
    const pw = 96;
    return makeCard('side', LOOK.swamp, '#ffd27a', (x, y) => {
      if (y >= 66) return y === 66 ? '#7a8a4a' : (x + 2 * y) % 9 === 0 ? '#5a6a34' : '#46562a';
      const m1 = 19 + 1.5 * Math.sin(x / 7), m2 = 33 + 1.5 * Math.sin(x / 9 + 1);
      if (Math.abs(y + 0.5 - m1) < 1) return '#3e6a5a';
      if (Math.abs(y + 0.5 - m2) < 0.8) return '#365e50';
      return (x % 8 === 4 && y % 8 === 2) ? '#2a4c42' : '#24443a';
    }, art => {
      art(L => { for (const [x, top] of [[9, 46], [12, 52], [15, 48], [80, 50], [83, 45], [86, 53]]) { for (let y = top; y <= 67; y++) lset(L, x, y, '#4a8a3a'); lR(L, x, top - 5, 2, 5, (xx, yy) => (yy === top - 5 ? '#c08040' : '#8a5428')); } });
      art(L => { lE(L, 30, 70, 6, 1.8, ['#9af06a', '#4cc83a', '#2a8a2a'], (x, y) => !(x >= 33 && y <= 70)); lE(L, 66, 72, 5, 1.6, ['#9af06a', '#4cc83a', '#2a8a2a']); });
      art(L => { for (const [x, y] of [[22, 27], [40, 41], [58, 25], [73, 39], [30, 55], [64, 57]]) { lset(L, x, y, '#fff6a0'); lset(L, x + 1, y, '#ffd23a'); } }, false);
      art(L => {
        lE(L, 29.5, 67.5, 3.6, 2.4, ['#9ae86a', '#4cb83a', '#2a7a2a']);
        for (const ex of [27.5, 31.5]) { lE(L, ex, 65, 1.3, 1.3, '#4cb83a'); }
        lset(L, 27, 64, '#ffffff'); lset(L, 28, 65, INK); lset(L, 31, 64, '#ffffff'); lset(L, 32, 65, INK);
      });
    }, pw);
  }
  // 鸡窝：红谷仓板墙、一道横梁，地上一层稻草。窝、母鸡、钉子在台面那一层画
  function henCard() {
    return sideCard(LOOK.hen, '#f0c040', (x, y) => {
      if (y >= 64) return y === 64 ? '#ffe070' : (x + y) % 4 === 0 ? '#c89820' : '#f0c040';
      if (y === 30 || y === 31) return y === 30 ? '#d8583e' : '#8a2a1e';
      return x % 6 === 0 ? '#a83424' : '#c8402e';
    }, art => {
      art(L => { for (const [x, y] of [[13, 22], [43, 22], [13, 46], [43, 46]]) { lset(L, x, y, '#8a2a1e'); lset(L, x + 1, y + 1, '#8a2a1e'); } }, false);
    });
  }
  // 马戏团：红白幕布、顶上一圈花边，几颗金灯。鼓、海豹在台面那一层画
  function circusCard() {
    return sideCard(LOOK.circus, '#ffd23a', (x, y) => (x % 8 < 4 ? '#b8282e' : '#c83238'), art => {
      art(L => {
        for (let x = 7; x < 57; x++) {
          const k = fl((x - 7) / 6), cxs = 7 + k * 6 + 3, bottom = 13 + Math.sqrt(Math.max(0, 9 - (x + 0.5 - cxs) ** 2)) * 0.8;
          for (let y = 9; y <= bottom; y++) lset(L, x, y, k % 2 ? '#fff0d0' : '#fe4c40');
        }
      });
      art(L => { for (let x = 10; x < 56; x += 5) lset(L, x, 19 + (x % 2), YEL[1]); }, false);
    });
  }
  // 雪场：冰面一格一格的浅蓝点。推板、雪球、台边在台面那一层画
  function snowCard() {
    return makeCard('top', LOOK.snow, '#ffffff', (x, y) => (y % 4 === 2 && x % 6 === (fl(y / 4) % 2) * 3 ? '#d4e6f6' : '#eef6ff'), art => {
      art(L => { for (const [x, y] of [[12, 30], [50, 34], [20, 52], [44, 58]]) { lset(L, x, y, '#ffffff'); lset(L, x + 1, y, '#c8dcf0'); } }, false);
    });
  }
  // 推币机：深灰台面，斜纹。推板、硬币、台边在台面那一层画
  function coinCard() {
    return makeCard('top', LOOK.coin, GOLD[1], (x, y) => ((x + y * 2) % 9 === 0 ? '#44565e' : '#3a4a52'), () => {});
  }
  // 足球场：草皮横条，白线（中圈、底下的罚球区）。门、守门员在台面那一层画
  function soccerCard() {
    return makeCard('top', LOOK.soccer, '#ffffff', (x, y) => {
      const c = fl((y - 14) / 5) % 2 ? '#36b24a' : '#3cbf52';
      if (y === 46 && x >= 7 && x <= 56) return '#e8ffe8';
      if (Math.abs(Math.hypot(x + 0.5 - 32, y + 0.5 - 46) - 7) < 0.5) return '#e8ffe8';
      if ((y === 64 && x >= 20 && x <= 43) || ((x === 20 || x === 43) && y >= 64)) return '#e8ffe8';
      return c;
    }, () => {});
  }
  // 台球桌：绿台呢，每 4 格一个暗点；开球线一道虚点。袋口在台面那一层画
  function poolCard() {
    return makeCard('top', LOOK.pool, '#e8c070', (x, y) => {
      if (y === 62 && x % 3 === 0) return '#5ab070';
      return y % 4 === 1 && x % 4 === (fl(y / 4) % 2) * 2 ? '#2a7e44' : '#2f8a4a';
    }, () => {});
  }
  // clean：机台界面用的（俯视两台去掉画在卡上的弹珠、瓶子，台面那一层自己画会动的）
  function cardArt(id, clean = true) {
    const key = id + (clean ? '' : '/sheet');
    if (!cardCache.has(key)) {
      let A;
      if (id === 'slime') A = slimeCard();
      else if (id === 'shroom') A = shroomCard();
      else if (id === 'ice') A = iceCard();
      else if (id === 'swamp') A = swampCard();
      else if (id === 'ring' && clean) A = ringCard();
      else if (id === 'bowl' && clean) A = bowlCard();
      else if (id === 'hen' && clean) A = henCard();
      else if (id === 'circus' && clean) A = circusCard();
      else if (id === 'snow' && clean) A = snowCard();
      else if (id === 'coin' && clean) A = coinCard();
      else if (id === 'soccer' && clean) A = soccerCard();
      else if (id === 'pool' && clean) A = poolCard();
      else A = sheetCard(SHEET[id] != null ? SHEET[id] : 0);
      cardCache.set(key, A);
    }
    return cardCache.get(key).map(r => r.slice());
  }
  const modeOf = id => (LOOK[id] || LOOK.dog).mode;
  // 卡面虚化：台面里的深边换成旁边的颜色，整体往藏青压一点（照样图 14 的 ③）
  function blurred(A, mode) {
    const pw = A[0].length, inA = inArtOf(mode, pw), NAVY = [14, 22, 52], freq = new Map();
    for (let y = 0; y < PH; y++) for (let x = 0; x < pw; x++) if (inA(x, y)) freq.set(A[y][x], (freq.get(A[y][x]) || 0) + 1);
    const out = A.map(r => r.slice());
    for (let y = 0; y < PH; y++) for (let x = 0; x < pw; x++) {
      if (!inA(x, y) || A[y][x] !== INK) continue;
      let best = null;
      for (const ring of [[[1, 0], [-1, 0], [0, 1], [0, -1]], [[1, 1], [-1, 1], [1, -1], [-1, -1]]]) {
        for (const [dx, dy] of ring) { const c = inA(x + dx, y + dy) ? A[y + dy][x + dx] : null; if (c && c !== INK && (!best || freq.get(c) < freq.get(best))) best = c; }
        if (best) break;
      }
      out[y][x] = best ? toHex(...toRGB(best).map(v => rd(v * 0.72))) : INK;
    }
    for (let y = 0; y < PH; y++) for (let x = 0; x < pw; x++) if (inA(x, y)) {
      let [r, g, b] = toRGB(out[y][x]);
      const l = 0.3 * r + 0.59 * g + 0.11 * b;
      [r, g, b] = [r, g, b].map(v => v + (l - v) * 0.1).map((v, k) => rd(v + (NAVY[k] - v) * 0.4));
      out[y][x] = toHex(r, g, b);
    }
    return out;
  }
  const dimC = memo(c => { let [r, g, b] = toRGB(c); const l = 0.3 * r + 0.59 * g + 0.11 * b, T = [20, 8, 12]; [r, g, b] = [r, g, b].map(v => v + (l - v) * 0.3).map((v, k) => rd(v + (T[k] - v) * 0.55)); return toHex(r, g, b); });
  const shade = memo(c => mix(c, '#000000', 0.45));
  // 桌上的小预览（拿起放下的动画用）：直接截桌面上那一块
  function slotCanvas(tableCanvas, n) {
    const r = slotRect(n), c = document.createElement('canvas');
    c.width = r.w; c.height = r.h;
    c.getContext('2d').drawImage(tableCanvas, r.x, r.y, r.w, r.h, 0, 0, r.w, r.h);
    return c;
  }
  // 整张卡（不虚化，拿起放下的动画用）
  function cardCanvas(id) { const A = cardArt(id, false), pw = A[0].length, k = PixelKit(pw, PH); for (let j = 0; j < PH; j++) for (let i = 0; i < pw; i++) if (A[j][i]) k.P(i, j, A[j][i]); return toCanvas(k); }

  // =========================================================================
  // 机台界面：卡 4 倍放在正中，台面上的东西 2 倍（一格 = 卡面半格，坐标跟各台的物理一样）
  // =========================================================================
  const S4 = 4, CY0 = 12;
  // 卡在正中：小台 CX0 = 192，大台 128，横台 24。拿起哪台先 setCard(id)
  let CW = PW, CX0 = 192;
  function setCard(id) { CW = cwOf(id); CX0 = Math.round((W - CW * S4) / 2); return CW; }
  const FX = x => CX0 + x * 2, FY = y => CY0 + y * 2;
  // 镜头拉近 2 倍取桌子的哪一块：横着跟着拿起的那台走，竖着固定在前排那一带
  const camOf = n => { const r = slotRect(n); return { x: Math.max(0, Math.min(W - 320, Math.round(r.x + r.w / 2 - 160))), y: 132 }; };
  // 底：压暗的桌子（拿起的那台空着）+ 卡的影子
  function renderMachineBg(tableCanvas, n, id) {
    const cam = camOf(n), bg = tableCanvas.getContext('2d').getImageData(0, 0, W, H).data;
    const F = PixelKit(W, H);
    const art = cardArt(id), SH = [10, 12], pw = art[0].length;
    const inShadow = (sx, sy) => { const i = fl((sx - CX0 - SH[0]) / S4), j = fl((sy - CY0 - SH[1]) / S4); return i >= 0 && j >= 0 && i < pw && j < PH && !!art[j][i]; };
    for (let y = 0; y < 180; y++) for (let x = 0; x < 320; x++) {
      const k = ((cam.y + y) * W + cam.x + x) * 4;
      let c = dimC(toHex(bg[k], bg[k + 1], bg[k + 2]));
      if (inShadow(x * 2, y * 2)) c = shade(c);
      F.R(x * 2, y * 2, 2, 2, c);
    }
    return toCanvas(F);
  }
  // 卡：4 倍虚化 + fine(K, px) 画不动的那一层（2 倍）
  function renderMachineCard(id, fine) {
    const F = PixelKit(W, H); useKit(F);
    const soft = blurred(cardArt(id), modeOf(id)), pw = soft[0].length, S = sideOf(pw);
    // 侧视卡：底下那条洞只留底色（洞灯、隔条在台面那一层画）
    if (modeOf(id) === 'side') for (let y = S.hole; y <= S.y1; y++) for (let x = S.x0; x <= S.x1; x++) soft[y][x] = y === S.hole ? INK : SLATE;
    for (let j = 0; j < PH; j++) for (let i = 0; i < pw; i++) if (soft[j][i]) F.R(CX0 + i * S4, CY0 + j * S4, S4, S4, soft[j][i]);
    // 数码管那一格清空（数字每帧另画）
    for (let y = 3; y <= 9; y++) for (let x = 3; x <= 12; x++) F.R(CX0 + x * S4, CY0 + y * S4, S4, S4, DEEP);
    const px = (x, y, c) => { if (c) F.R(FX(x), FY(y), 2, 2, c); };
    if (fine) fine({ px, layer, lset, lget, outl, loutline: F.loutline, lE, lR, lP, lL, lS, lPuff, slimeBlob, mushroom, fineMeter: dx => fineMeter({ px }, dx), put: (L, ox, oy) => { for (let j = 0; j < L.h; j++) for (let i = 0; i < L.w; i++) { const c = lget(L, i, j); if (c) px(ox + i, oy + j, c); } } });
    return toCanvas(F);
  }
  // ---------- 底座（这台自己的东西，机台界面左下）：画在 320×180 上再放大 2 倍 ----------
  const DOCK = { x0: 14, CB: 126 };
  function renderDock(id, chip) {
    const save = K, kit = PixelKit(320, 180); useKit(kit);
    const { x0, CB } = DOCK;
    obj(x0 - 2, CB, 68, 13, g => {
      const Bk = Cz.black;
      g.r(x0 - 2, CB, 68, 2, Bk[0]); g.r(x0 - 2, CB + 2, 68, 1, GOLD[1]); g.r(x0 - 2, CB + 3, 68, 10, Bk[2]);
      const Wn = { x: x0 + 32 - 17, y: CB + 4, w: 34, h: 9 };
      g.r(Wn.x, Wn.y, Wn.w, Wn.h, GOLD[2]); g.r(Wn.x, Wn.y, Wn.w, 1, GOLD[1]);
      g.r(Wn.x + 1, Wn.y + 1, Wn.w - 2, Wn.h - 2, '#120a0e');
      g.s(TAG_ICON[chip], { x: TIX[chip].chip[1] }, Wn.x + 3, CB + 7);
    });
    const fy = 145, PRINT = mix(GOLD[1], Cz.felt, 0.4);
    D.r(x0 - 2, fy, 68, 24, Cz.felt);
    for (let i = 2; i < 66; i++) { P(x0 - 2 + i, fy, PRINT); P(x0 - 2 + i, fy + 23, PRINT); }
    for (let j = 2; j < 22; j++) { P(x0 - 2, fy + j, PRINT); P(x0 + 65, fy + j, PRINT); }
    const cx = x0 + 17, cy = 157;
    obj(cx - 14, cy - 3, 30, 9, g => {
      g.r(cx - 14, cy - 3, 30, 9, GOLD[1]); g.r(cx - 14, cy - 3, 30, 1, GOLD[0]); g.r(cx - 14, cy + 5, 30, 1, GOLD[2]);
      g.r(cx - 13, cy - 2, 28, 7, '#141418'); g.r(cx - 12, cy - 1, 26, 5, '#7a1428');
    });
    useKit(save);
    return toCanvas(kit);
  }
  // 底座上会变的：筹码数、珠子盘里几颗、几叠筹码。画进 2 倍的原生画面
  const DOCK_HOT = { tray: { x: (DOCK.x0 + 2) * 2, y: (157 - 13) * 2, w: 62, h: 44 }, plinth: { x: (DOCK.x0 - 2) * 2, y: DOCK.CB * 2, w: 136, h: 26 } };
  const stacksFor = have => { if (have <= 0) return []; const v = have <= 6 ? have : Math.min(24, Math.round(6 + 1.4 * Math.sqrt(have - 6))); const o = []; for (let l = v; l > 0; l -= 8) o.push(Math.min(8, l)); return o; };
  const dockSprites = new Map();
  function dockSprite(key, draw, w, h) {
    if (!dockSprites.has(key)) { const save = K, kit = PixelKit(w, h); useKit(kit); draw(); useKit(save); dockSprites.set(key, toCanvas(kit)); }
    return dockSprites.get(key);
  }
  function drawDock(ctx, dockCanvas, chip, marble, have, marbles) {
    ctx.drawImage(dockCanvas, 0, 0, 640, 360);
    const { x0, CB } = DOCK;
    // 数字（金色、2 倍）
    const s = short(have), dig = dockSprite('d' + s, () => num35(D, s, 0, 0, GOLD[0]), numW35(s), 5);
    ctx.drawImage(dig, (x0 + 32 - 17 + 10) * 2, (CB + 6) * 2, dig.width * 2, 10);
    // 珠子盘里的珠子
    const C = MARB[marble] || MARB.glass, mb = dockSprite('m' + marble, () => D.s(MARBLE7, { k: INK, s: C[0], w: C[1], h: C[2] }, 0, 0), 7, 7);
    const cx = x0 + 17, cy = 157;
    SPOTS.slice(0, Math.min(5, marbles)).sort((a, b) => a[1] - b[1]).forEach(([dx, dy]) => ctx.drawImage(mb, (cx + dx + 3) * 2, (cy + 1 + dy) * 2, 14, 14));
    // 几叠筹码
    stacksFor(have).forEach((n, i) => {
      const st = dockSprite('s' + chip + n, () => chipStack(5, 2 * n + 4, n, TIX[chip].chip), 11, 2 * n + 6);
      ctx.drawImage(st, (x0 + 42 + i * 10 - 5) * 2, (165 - 2 * n - 4) * 2, st.width * 2, st.height * 2);
    });
  }

  // =========================================================================
  // 小图（机台里放大 2 倍用）
  // =========================================================================
  function sprite(rows, map) {
    const w = Math.max(...rows.map(r => r.length)), h = rows.length, k = PixelKit(w, h);
    rows.forEach((r, j) => { for (let i = 0; i < r.length; i++) { const c = map[r[i]]; if (c) k.P(i, j, c); } });
    return toCanvas(k);
  }
  function outlined(rows, map, outline) {
    const w = Math.max(...rows.map(r => r.length)) + 2, h = rows.length + 2, k = PixelKit(w, h), on = (i, j) => j >= 0 && j < rows.length && i >= 0 && i < rows[j].length && map[rows[j][i]];
    for (let j = -1; j <= rows.length; j++) for (let i = -1; i < w - 1; i++) {
      if (on(i, j)) k.P(i + 1, j + 1, map[rows[j][i]]);
      else if (on(i - 1, j) || on(i + 1, j) || on(i, j - 1) || on(i, j + 1)) k.P(i + 1, j + 1, outline);
    }
    return toCanvas(k);
  }
  function disc(r, c) { const n = Math.ceil(r * 2), rows = []; for (let y = 0; y < n; y++) { let s = ''; for (let x = 0; x < n; x++) s += Math.hypot(x + 0.5 - r, y + 0.5 - r) <= r ? 'x' : '.'; rows.push(s); } return sprite(rows, { x: c }); }
  function digitSprites(color, outline) { const o = {}; for (const ch of Object.keys(D35)) o[ch] = outline ? outlined(D35[ch], { x: color }, outline) : sprite(D35[ch], { x: color }); return o; }
  // 一个小圆球（有亮面暗面、深边）：r 半径（细格），C = [暗, 中, 亮]
  function ballSprite(r, C, extra) {
    const n = Math.ceil(r * 2) + 2, k = PixelKit(n, n), c = n / 2;
    for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
      const dx = x + 0.5 - c, dy = y + 0.5 - c, d = Math.hypot(dx, dy);
      if (d > r + 0.5) continue;
      if (d > r - 0.5) { k.P(x, y, INK); continue; }
      const u = dx / r, v = dy / r;
      k.P(x, y, u + v < -0.75 ? C[2] : u + v > 0.55 ? C[0] : C[1]);
    }
    if (extra) extra(k, c);
    return toCanvas(k);
  }
  const CORE = ['#c8ff9a', '#4cc83a', '#22803a'];
  const CORE7 = ['...k...', '..klk..', '.klbbk.', 'klbbbdk', '.kbbdk.', '..kdk..', '...k...'];
  function coreSprite(C) { return sprite(CORE7, { k: INK, l: C[0], b: C[1], d: C[2] }); }
  function chipSprite(chip) { const C = TIX[chip].chip; return sprite(['..kkkk..', '.kyyyyk.', 'kyddddyk', 'kydyydyk', 'kydyydyk', 'kyddddyk', '.kyyyyk.', '..kkkk..'], { k: INK, y: C[1], d: C[2] }); }
  const SPEAKER = ['....x......', '...xx......', 'xxxxx..x...', 'xxxxx...x..', 'xxxxx...x..', 'xxxxx...x..', 'xxxxx..x...', '...xx......', '....x......'];
  const SPEAKER_OFF = ['....x......', '...xx......', 'xxxxx......', 'xxxxx.x.x..', 'xxxxx..x...', 'xxxxx.x.x..', 'xxxxx......', '...xx......', '....x......'];
  const speaker = on => outlined(on ? SPEAKER : SPEAKER_OFF, { x: GOLD[1] }, INK);
  // 大的发力灯槽（卡框上）和亮法：x 117..124、y 38..149，10 格
  const METER = { x: 117, y: 38, w: 8, h: 112, seg: 10 };
  const meterSeg = j => ({ x: METER.x + 1, y: METER.y + METER.h - 2 - (j + 1) * 11 + 2, w: 6, h: 9 });
  // dx：大台的力度灯跟着发射道往右挪（冰窟 64 格）
  function fineMeter(f, dx = 0) {
    for (let y = METER.y; y < METER.y + METER.h; y++) for (let x = METER.x; x < METER.x + METER.w; x++) {
      const edge = x === METER.x || x === METER.x + METER.w - 1 || y === METER.y || y === METER.y + METER.h - 1;
      f.px(x + dx, y, edge ? INK : DEEP);
    }
    for (let j = 0; j < METER.seg; j++) { const s = meterSeg(j); for (let y = 0; y < s.h; y++) for (let x = 0; x < s.w; x++) f.px(s.x + x + dx, s.y + y, '#3a1416'); }
  }
  function drawMeter(ctx, p, live, dx = 0) {
    const rows = Math.round(p * 108);
    for (let j = 0; j < METER.seg; j++) {
      const sg = meterSeg(j), y0 = METER.y + METER.h - 2 - rows;
      for (let r = 0; r < sg.h; r++) {
        const y = sg.y + r;
        if (y < y0) continue;
        ctx.fillStyle = live ? (j === 9 || p >= 0.96 ? (r === 0 ? '#fff6c0' : '#ffd84a') : r === 0 ? '#ff8a7a' : '#fe4c40') : '#6a2a26';
        ctx.fillRect(FX(sg.x + dx), FY(y), sg.w * 2, 2);
      }
    }
  }

  // =========================================================================
  // 面板小件（画在原生 640×360 上，像素 2 倍：外框、货格、按钮；字另写）
  // =========================================================================
  function panelKit() { const k = PixelKit(320, 180); useKit(k); return k; }
  function frame(x, y, w, h, fill) {
    obj(x, y, w, h, g => {
      g.r(x, y, w, h, GOLD[1]); g.r(x, y, w, 1, GOLD[0]); g.r(x, y, 1, h, GOLD[0]); g.r(x, y + h - 1, w, 1, GOLD[2]); g.r(x + w - 1, y, 1, h, GOLD[2]);
      g.r(x + 2, y + 2, w - 4, h - 4, INK);
      g.r(x + 3, y + 3, w - 6, h - 6, fill || '#2c1018');
    });
  }
  function box(x, y, w, h, fill, edge) { obj(x, y, w, h, g => { g.r(x, y, w, h, edge || GOLD[2]); g.r(x, y, w, 1, GOLD[1]); g.r(x + 1, y + 1, w - 2, h - 2, fill); }); }
  function button(x, y, w, h, kind) {
    const C = kind === 'ok' ? GRN : kind === 'red' ? RED : kind === 'off' ? ['#5a4a50', '#3a2a30', '#2a1a20'] : GOLD;
    obj(x, y, w, h, g => { g.r(x, y, w, h, C[1]); g.r(x, y, w, 1, C[0]); g.r(x, y + h - 1, w, 1, C[2]); g.r(x + w - 1, y, 1, h, C[2]); });
  }
  function closeBtn(x, y) {
    obj(x, y, 11, 11, g => {
      g.e(x + 5.5, y + 5.5, 5.5, 5.5, RED[1]);
      for (let i = 0; i < 5; i++) { g.px(x + 3 + i, y + 3 + i, '#ffffff'); g.px(x + 7 - i, y + 3 + i, '#ffffff'); }
    });
    return { x: x * 2, y: y * 2, w: 22, h: 22 };
  }
  // 小图标画在 320×180 的面板格子上
  function chipIcon(x, y, chip) { const C = TIX[chip].chip; D.s(['.kkk.', 'kyyyk', 'kydyk', 'kyyyk', '.kkk.'], { k: INK, y: C[1], d: C[2] }, x, y); }
  function marbleIcon(x, y, m) { const C = MARB[m] || MARB.glass; D.s(MARBLE7, { k: INK, s: C[0], w: C[1], h: C[2] }, x, y); }
  function starIcon(x, y) { obj(x, y, 9, 9, g => g.s(STAR9, { x: GOLD[1], h: GOLD[0] }, x, y)); }
  function stamp(x, y, row, on, kind) {
    const C = row === 1 ? ['#f0b080', '#c8743a', '#8a4a20'] : row === 2 ? ['#ffffff', '#c8d0d4', '#7a8a90'] : GOLD;
    obj(x, y, 7, 7, g => {
      g.e(x + 3.5, y + 3.5, 3.5, 3.5, on ? (X, Y, u, v) => (u + v < -0.5 ? C[0] : u + v > 0.5 ? C[2] : C[1]) : '#3a1a24');
      if (on && kind === 'max') g.s(['x.x', '.x.', 'x.x'], { x: C[2] }, x + 2, y + 2);
      if (on && kind === 'open') g.r(x + 3, y + 2, 1, 3, C[2]);
      if (on && kind === 'deep') g.r(x + 2, y + 3, 3, 1, C[2]);
    }, on ? INK : '#2a0610');
  }
  function trinketIcon(k, x, yb) { TRINKET_ART[k](x, yb); }
  // 小图标做成画布（面板、机台界面里放大 2 倍贴）
  const iconCache = new Map();
  function icon(key, w, h, draw) {
    if (!iconCache.has(key)) { const save = K, kit = PixelKit(w, h); useKit(kit); draw(); useKit(save); iconCache.set(key, toCanvas(kit)); }
    return iconCache.get(key);
  }
  const trinketCanvas = k => icon('t:' + k, 20, 22, () => TRINKET_ART[k](2, 20));
  const upCanvas = (tag, chip) => icon('u:' + tag + chip, 20, 20, () => upIcon(tag, 1, 19, TIX[chip].chip));
  const previewCanvas = (id, w, h) => icon('p:' + id + w + 'x' + h, w, h, () => previewIcon(id, 0, 0, w, h, null));
  const itemCanvas = (k, chip, got) => icon('i:' + k + chip + got, 5, 5, () => itemIcon(k, 0, 0, chip, got));
  const stampCanvas = (row, on, kind) => icon('s:' + row + on + kind, 11, 11, () => stamp(2, 2, row, on, kind));
  const starCanvas = () => icon('star', 13, 13, () => starIcon(2, 2));
  const robotCanvas = kind => icon('r:' + kind, 18, 15, () => robot(13, 13, kind));
  const chipCanvas = chip => icon('c:' + chip, 5, 5, () => chipIcon(0, 0, chip));
  const marbleCanvas = m => icon('m:' + m, 7, 7, () => marbleIcon(0, 0, m));
  const tagIconCanvas = t => icon('g:' + t, 5, 3, () => D.s(TAG_ICON[t], { x: TIX[t].chip[1] }, 0, 0));
  // 图层做成小图：draw(L) 在 w×h 的图层上画，描深边；recolor 把颜色换掉（例如撞到时发白）
  function layerSprite(key, w, h, draw, recolor) {
    if (!iconCache.has(key)) {
      const L = layer(w, h); draw(L); outl(L);
      const k = PixelKit(w, h);
      for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) { let c = lget(L, i, j); if (c && recolor) c = recolor(c); if (c) k.P(i, j, c); }
      iconCache.set(key, toCanvas(k));
    }
    return iconCache.get(key);
  }
  // 史莱姆小图（中心在图的正中）、蘑菇弹柱小图（底边是柄脚）
  const slimeSprite = (rx, ry, C, face, flash) => { const w = Math.ceil(rx) * 2 + 4, h = Math.ceil(ry) * 2 + 4; return layerSprite('sl:' + [rx, ry, C, face, flash].join('|'), w, h, L => slimeBlob(L, w / 2, h / 2, rx, ry, C, face), flash ? (c => (c === INK ? INK : '#ffffff')) : null); };
  const mushroomSprite = (rx, ry, sh, lit) => { const w = Math.ceil(rx) * 2 + 4, h = Math.ceil(ry) + sh + 5; return layerSprite('mu:' + [rx, ry, sh, lit].join('|'), w, h, L => mushroom(L, w / 2, h - 2, rx, ry, sh), lit ? (c => (c === '#fe4c40' ? '#ffffff' : c === '#b8322a' ? '#ff8a7a' : c === '#ff8a7a' ? '#ffffff' : c)) : null); };
  // 小票（跟桌上价签一个样）：深边、票面色、中间那种筹码的记号。界面上 1 倍画，配 12 像素的字
  const tixCanvas = t => { const ic = TAG_ICON[t], w = ic[0].length + 4; return icon('x:' + t, w, 7, () => { D.r(0, 0, w, 7, INK); D.r(1, 1, w - 2, 5, TIX[t].face); D.s(ic, { x: TIX[t].icon }, 2, 2); }); };
  function previewIcon(id, x, y, w, h, led) { const L = LOOK[id]; if (L) preview(Object.assign({}, L, { led: led || 0 }), x, y, w, h); }
  function itemIcon(k, x, y, chip, got) {
    const GHOST = '#3a1a24', col = TIX[chip].chip;
    const map = k === 'skill' ? { g: GOLD[1], h: GOLD[0], w: '#ffffff' } : k === 'luck' ? { c: col[1], w: '#ffffff', d: col[2] } : { s: ALU[1], w: '#ffffff' };
    D.s(ITEM[k], got ? map : Object.fromEntries(Object.keys(map).map(q => [q, GHOST])), x, y);
  }

  // 主线（main/art.js）画关卡底图、节点图标用的小工具
  const kit = {
    makeCard, blurred, inArtOf, sideOf, layer, lset, lget, lE, lR, lP, lL, lS, lPuff, outl, slimeBlob, toCanvas, toHex, toRGB, mix, hash, fl, rd, hen, seal, MB5,
    INK, DEEP, SLATE, RED, YEL, BLU, GRN, ORG, PUR, BRN, BONE, ALU, GOLD, WOOD, SNOW, BLK, CLOUD, SMOKE, TREE, MINT, MARBLE7,
  };
  const ART = {
    kit,
    W, H, INK, DEEP, RED, YEL, BLU, GRN, ORG, PUR, GOLD, ALU, WOOD, MINT, BLUE_SLIME, AMBER, CORE, TIX, TAG_ICON, MARB, LOOK, STAR9,
    ROW, B, PLH, slotRect, camOf, renderTable, tableHot, SOUND, CAB, VIP, JACK, SHELF_ORDER, plinthWin, ledAt, PIN_SPOTS, SIDE, TOPF, D35, ITEM, TRINKET_X, CHG, SC,
    PW, PH, S4, CY0, FX, FY, cwOf, setCard, sideOf, topOf, cardArt, cardCanvas, slotCanvas, blurred, renderMachineBg, renderMachineCard, modeOf,
    renderDock, drawDock, DOCK_HOT, stacksFor, METER, meterSeg, fineMeter, drawMeter,
    sprite, outlined, disc, digitSprites, ballSprite, coreSprite, chipSprite, speaker, short, mix, toCanvas,
    panelKit, frame, box, button, closeBtn, chipIcon, marbleIcon, starIcon, stamp, trinketIcon, previewIcon, itemIcon, upIcon, priceTag, tagW,
    icon, trinketCanvas, upCanvas, previewCanvas, itemCanvas, stampCanvas, starCanvas, robotCanvas, chipCanvas, marbleCanvas, tagIconCanvas, tixCanvas, layerSprite, slimeSprite, mushroomSprite,
    useKit: k => useKit(k), num35: (s, x, y, c) => num35(D, s, x, y, c), numW35,
  };
  // 拿起的那台的卡宽、卡左边：拿起不同宽的台会变，所以是 getter
  Object.defineProperty(ART, 'CX0', { get: () => CX0 });
  Object.defineProperty(ART, 'CW', { get: () => CW });
  return ART;
})();
