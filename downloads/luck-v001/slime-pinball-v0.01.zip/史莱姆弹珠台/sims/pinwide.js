/*
 * 大台的弹球台（第 8 台沼泽用；第 11 台雨后菜园照这个来）。坐标同冰窟：台面 x 14..178，发射道、推头、单向门整个往右挪 64 格。
 *   底下两片挡板跟小台一样大，挪到台面正中：转轴 (66,131)、(114,131)，中间 x 82..98 是出球口。
 *   台宽了：两边各一条斜导轨从墙接到挡板，导轨上坐一个弹弓；弹弓顶上一块斜板接到墙。
 *   上面左右各一条通道（一根柱子隔出来）。从右边发射道打上去的球顺着顶滑到左边，正好掉进左通道；球从通道里往下滚过去，发一个 lane 事件。
 *   好几颗球可以同时在台上（多球），球和球互相撞。球的状态：lane（躺在推头上）、play（在台上）、stuck（粘在史莱姆身上，台子自己挪它）、gone。
 *   史莱姆同小台：软的圆，撞一下发 slime 事件。sticky 的（琥珀）撞得够快就把球粘住，发 stick 事件，粘住以后怎么办台子自己定。
 * 固定步长 1/480 秒，同小台。
 */
(function (root, factory) {
  const Sim = typeof module === 'object' && module.exports ? require('../sim.js') : root.Sim;
  const api = factory(Sim);
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.PinWide = api;
}(typeof self !== 'undefined' ? self : globalThis, function (Sim) {
  'use strict';
  const DT = 1 / 480;
  const DX = 64;
  const X0 = 14, X1 = 178, Y0 = 20, YB = 154, CH = 20;
  const LANE_X = Sim.LANE_X + DX, LANE_TOP = Sim.LANE_TOP, LANE_CX = Sim.LANE_CX + DX, HEAD_Y = Sim.HEAD_Y, REST_Y = Sim.REST_Y;
  const BALL_R = 3.5, GRAVITY = 170, VMAX = 255;
  const LAUNCH = Object.assign({}, Sim.DEFAULTS, { gravity: GRAVITY });
  const CXF = 90;   // 两片挡板的正中
  const FLIP = { L: { px: CXF - 24, py: 131 }, R: { px: CXF + 24, py: 131 }, len: 20, rp: 3.6, rt: 2.1, rest: 28 * Math.PI / 180, w: 18 };
  const DRAIN = { x0: CXF - 8, x1: CXF + 8, y: 146 };
  const GATE = { x0: LANE_X, y0: LANE_TOP, x1: X1, y1: LANE_TOP - 10 };
  { const l = Math.hypot(GATE.x1 - GATE.x0, GATE.y1 - GATE.y0); GATE.nx = (GATE.y1 - GATE.y0) / l; GATE.ny = -(GATE.x1 - GATE.x0) / l; }
  // 导轨：墙 → 挡板转轴旁边。弹弓三角：A 顶、B 底（贴着导轨，缝比珠子小）、C 斜边下头，斜边 A→C 是橡皮筋；cap 是墙接到 A 的斜板
  const GUIDE = { L: [[X0, 84], [CXF - 28, 127]], R: [[LANE_X, 84], [CXF + 28, 127]] };
  const SLING = { L: { A: [34, 86], B: [34, 99], C: [48, 112], cap: [X0, 70] }, R: { A: [146, 86], B: [146, 99], C: [132, 112], cap: [LANE_X, 70] } };
  // 上面两条通道：一根柱子（x，从 y0 到 y1）隔出来；球往下滚过 sy 那一行发 lane 事件
  const LANES = { L: { x: 30, y0: 50, y1: 64, sx0: X0, sx1: 30, sy: 58 }, R: { x: 150, y0: 54, y1: 66, sx0: 150, sx1: LANE_X, sy: 60 } };
  // 史莱姆待的地方
  const ZONE = { x0: 44, x1: 136, y0: 34, y1: 84 };

  function build(s, opts) {
    const e = 0.4, f = 0.02;
    Sim.addSeg(s, X0, Y0 + CH, X0, 84, 'wall', e, f, 60, 90);
    Sim.addSeg(s, X1, Y0 + CH, X1, YB, 'wall', e, f, 60, 90);
    Sim.addSeg(s, X0, Y0 + CH, X0 + CH, Y0, 'roof', 0.2, 0.01, 60, 90);
    Sim.addSeg(s, X0 + CH, Y0, X1 - CH, Y0, 'roof', 0.2, 0.01, 60, 90);
    Sim.addSeg(s, X1 - CH, Y0, X1, Y0 + CH, 'roof', 0.2, 0.01, 60, 90);
    Sim.addWall(s, LANE_X, LANE_TOP, LANE_X, YB, 'lane', 0.3, 0.02);
    Sim.addSeg(s, LANE_X, HEAD_Y, X1, HEAD_Y, 'head', 0.1, 0.2, LANE_CX, 100);
    Sim.addSeg(s, LANE_X, LANE_TOP, LANE_X - 6, LANE_TOP + 4, 'guard', 0.3, 0.02, LANE_X - 8, LANE_TOP - 4);
    for (const k of ['L', 'R']) {
      const [a, b] = GUIDE[k];
      Sim.addWall(s, a[0], a[1], b[0], b[1], 'guide', 0.35, 0.02);
      const S = SLING[k];
      Sim.addWall(s, S.cap[0], S.cap[1], S.A[0], S.A[1], 'wall', 0.4, 0.02);
      Sim.addWall(s, S.A[0], S.A[1], S.B[0], S.B[1], 'post', 0.4, 0.02);
      Sim.addWall(s, S.B[0], S.B[1], S.C[0], S.C[1], 'post', 0.4, 0.02);
      Sim.addWall(s, S.A[0], S.A[1], S.C[0], S.C[1], 'sling', 0.55, 0.02);
      for (const p of [S.A, S.B, S.C]) Sim.addCircle(s, p[0], p[1], 2, 'post', 0.4, 0.02);
      const Ln = LANES[k];
      Sim.addWall(s, Ln.x, Ln.y0, Ln.x, Ln.y1, 'post', 0.4, 0.02);
      Sim.addCircle(s, Ln.x, Ln.y0, 2, 'post', 0.4, 0.02);
      Sim.addCircle(s, Ln.x, Ln.y1, 2, 'post', 0.4, 0.02);
    }
    for (const [x, y, r] of opts.bumpers || []) Sim.addCircle(s, x, y, r, 'shroom', 0.6, 0);
    // 出球口两边的小墙（挡板转轴底下），球只能从中间掉
    Sim.addWall(s, CXF - 28, 127, CXF - 24, 134, 'guide', 0.3, 0.02);
    Sim.addWall(s, CXF + 28, 127, CXF + 24, 134, 'guide', 0.3, 0.02);
  }

  function create(opts) {
    opts = opts || {};
    const s = {
      colliders: [], cells: null, stamp: 0, quiet: false, events: [],
      cfg: { frictionMin: 8.3, hitMin: 12.5 },
      flippers: [], balls: [], slimes: [], time: 0, bumpers: opts.bumpers || [], seq: 0,
    };
    build(s, opts);
    Sim.buildGrid(s);
    const len = FLIP.len + (opts.flipLen || 0);
    s.flippers = [
      { side: 'L', px: FLIP.L.px, py: FLIP.L.py, len, rp: FLIP.rp, rt: FLIP.rt, rest: FLIP.rest, up: -FLIP.rest, ang: FLIP.rest, angVel: 0, on: false },
      { side: 'R', px: FLIP.R.px, py: FLIP.R.py, len, rp: FLIP.rp, rt: FLIP.rt, rest: Math.PI - FLIP.rest, up: Math.PI + FLIP.rest, ang: Math.PI - FLIP.rest, angVel: 0, on: false },
    ];
    return s;
  }
  function setFlipLen(s, extra) { for (const f of s.flippers) f.len = FLIP.len + extra; }
  const emit = (s, e) => { if (!s.quiet) s.events.push(e); };
  const inLane = s => s.balls.find(b => b.state === 'lane');
  const inPlay = s => s.balls.filter(b => b.state === 'play');

  // 装一颗球在推头上（推头上已经有一颗就不装，返回 null）
  function load(s, extra) {
    if (inLane(s)) return null;
    const b = Object.assign({ id: ++s.seq, x: LANE_CX, y: REST_Y, vx: 0, vy: 0, r: BALL_R, state: 'lane', age: 0, slow: 0, lane: { L: 0, R: 0 } }, extra || {});
    s.balls.push(b);
    return b;
  }
  function launch(s, p) {
    const b = inLane(s);
    if (!b) return null;
    b.x = LANE_CX; b.y = REST_Y; b.vx = 0;
    b.vy = -Sim.launchSpeed(LAUNCH, Math.max(0, Math.min(1, p)));
    b.state = 'play'; b.slow = 0; b.age = 0;
    emit(s, { type: 'launch', p, b });
    return b;
  }
  // 粘住的球放出来：从史莱姆身上往外弹
  function release(s, b, vx, vy) { b.state = 'play'; b.vx = vx; b.vy = vy; b.age = 0; b.slow = 0; b.on = null; }
  const tipOf = f => [f.px + Math.cos(f.ang) * f.len, f.py + Math.sin(f.ang) * f.len];

  function bounce(s, b, h) {
    const col = h.col;
    b.x += h.nx * h.depth; b.y += h.ny * h.depth;
    const vn = b.vx * h.nx + b.vy * h.ny;
    if (vn >= 0) return;
    const impact = -vn, tx = -h.ny, ty = h.nx;
    let vt = b.vx * tx + b.vy * ty, out = impact * col.e;
    if (col.kind === 'sling' && impact > 25) out += 105;
    if (col.kind === 'shroom') out = Math.max(out + 60, 150);
    const dvt = impact > 8.3 ? Math.min(Math.abs(vt), col.f * (impact + out)) : 0;
    vt -= Math.sign(vt) * dvt;
    b.vx = h.nx * out + tx * vt; b.vy = h.ny * out + ty * vt;
    if (impact > 12.5) emit(s, { type: 'hit', kind: col.kind, id: col.id, x: h.px, y: h.py, impact, b });
  }
  function flipperHit(s, f, b) {
    const [tx, ty] = tipOf(f), vx = tx - f.px, vy = ty - f.py, L2 = vx * vx + vy * vy;
    let t = ((b.x - f.px) * vx + (b.y - f.py) * vy) / L2;
    t = t < 0 ? 0 : t > 1 ? 1 : t;
    const qx = f.px + vx * t, qy = f.py + vy * t, rq = f.rp + (f.rt - f.rp) * t;
    const dx = b.x - qx, dy = b.y - qy;
    let d = Math.hypot(dx, dy);
    const rr = rq + b.r;
    if (d >= rr) return;
    let nx, ny;
    if (d > 1e-6) { nx = dx / d; ny = dy / d; } else { nx = Math.sin(f.ang); ny = -Math.cos(f.ang); if (ny > 0) { nx = -nx; ny = -ny; } d = 0; }
    b.x += nx * (rr - d); b.y += ny * (rr - d);
    const cx = qx + nx * rq, cy = qy + ny * rq;
    const ux = -f.angVel * (cy - f.py), uy = f.angVel * (cx - f.px);
    const rvx = b.vx - ux, rvy = b.vy - uy, vn = rvx * nx + rvy * ny;
    if (vn < 0) {
      b.vx -= 1.45 * vn * nx; b.vy -= 1.45 * vn * ny;
      if (-vn > 20) emit(s, { type: 'flip', side: f.side, impact: -vn, x: cx, y: cy, moving: Math.abs(f.angVel) > 1 });
    }
  }
  function slimeHit(s, m, b) {
    const dx = b.x - m.x, dy = b.y - m.y, rr = m.r + b.r, d2 = dx * dx + dy * dy;
    if (d2 >= rr * rr) return;
    const d = Math.sqrt(d2) || 1e-6, nx = dx / d, ny = dy / d;
    b.x = m.x + nx * rr; b.y = m.y + ny * rr;
    const vn = b.vx * nx + b.vy * ny;
    if (vn >= 0) return;
    const impact = -vn;
    // 琥珀：撞得够快就粘住（太轻了照样弹开，不然球在它头上滚两下就粘了）
    if (m.sticky && impact > (m.stickMin || 40) && (m.stuck || 0) < (m.cap || 3)) {
      b.state = 'stuck'; b.on = m; b.ox = nx; b.oy = ny; b.vx = b.vy = 0;
      m.stuck = (m.stuck || 0) + 1;
      emit(s, { type: 'stick', m, b, impact, x: m.x + nx * m.r, y: m.y + ny * m.r });
      return;
    }
    const out = Math.max(impact * 0.55, 75);
    b.vx += (impact + out) * nx; b.vy += (impact + out) * ny;
    emit(s, { type: 'slime', m, b, impact, nx, ny, x: m.x + nx * m.r, y: m.y + ny * m.r });
  }
  // 球和球：一样重，正面那一份交换（打一点折扣）
  function ballBall(s, a, b) {
    const dx = b.x - a.x, dy = b.y - a.y, rr = a.r + b.r, d2 = dx * dx + dy * dy;
    if (d2 >= rr * rr || d2 < 1e-9) return;
    const d = Math.sqrt(d2), nx = dx / d, ny = dy / d, push = (rr - d) / 2;
    a.x -= nx * push; a.y -= ny * push; b.x += nx * push; b.y += ny * push;
    const rv = (b.vx - a.vx) * nx + (b.vy - a.vy) * ny;
    if (rv >= 0) return;
    const j = -rv * 0.95;
    a.vx -= j * nx; a.vy -= j * ny; b.vx += j * nx; b.vy += j * ny;
    if (-rv > 25) emit(s, { type: 'clack', impact: -rv, x: a.x + nx * a.r, y: a.y + ny * a.r });
  }

  function stepBall(s, b) {
    b.age += DT;
    b.vy += GRAVITY * DT;
    const px = b.x, py = b.y;
    b.x += b.vx * DT; b.y += b.vy * DT;
    for (let k = 0; k < 4; k++) { const h = Sim.deepest(s, b); if (!h) break; bounce(s, b, h); }
    // 发射道口的单向门：往上打出去畅通，从上面落回来就被挡回台面
    if (b.vy > 0 && b.x > LANE_X - b.r && b.x < X1) {
      const sd = (b.x - GATE.x0) * GATE.nx + (b.y - GATE.y0) * GATE.ny;
      if (sd > -1 && sd < b.r) {
        b.x += (b.r - sd) * GATE.nx; b.y += (b.r - sd) * GATE.ny;
        const vn = b.vx * GATE.nx + b.vy * GATE.ny;
        if (vn < 0) { b.vx -= 1.4 * vn * GATE.nx; b.vy -= 1.4 * vn * GATE.ny; }
      }
    }
    for (const f of s.flippers) flipperHit(s, f, b);
    for (const m of s.slimes) { if (m.solid) slimeHit(s, m, b); if (b.state !== 'play') return; }
    const sp = Math.hypot(b.vx, b.vy);
    if (sp > VMAX) { b.vx *= VMAX / sp; b.vy *= VMAX / sp; }
    // 通道：往下滚过那一行
    for (const k of ['L', 'R']) {
      const Ln = LANES[k];
      if (py < Ln.sy && b.y >= Ln.sy && b.x > Ln.sx0 && b.x < Ln.sx1) emit(s, { type: 'lane', side: k, b, x: (Ln.sx0 + Ln.sx1) / 2, y: Ln.sy });
    }
    // 掉回发射道：停在推头上，再打一下就行（不算一颗新珠子）。推头上已经有一颗了就排队
    if (b.x > LANE_X && b.y >= REST_Y - 0.6 && Math.abs(b.vy) < 30 && b.age > 0.3) {
      const busy = s.balls.some(o => o !== b && o.state === 'lane');
      b.x = LANE_CX; b.y = REST_Y; b.vx = b.vy = 0;
      b.state = busy ? 'queue' : 'lane';
      emit(s, { type: 'back', b }); return;
    }
    // 从两片挡板中间掉下去
    if (b.y > DRAIN.y + 6 && b.x < LANE_X) { b.state = 'gone'; emit(s, { type: 'drain', b, age: b.age }); return; }
    // 卡住了（没按挡板、又几乎不动）：台子自己抖一下
    const held = s.flippers.some(f => f.on);
    if (sp < 6 && !held) { b.slow += DT; if (b.slow > 1.5) { b.slow = 0; b.vy = -110; b.vx = (b.x < CXF ? 1 : -1) * 40; emit(s, { type: 'nudge', b }); } } else b.slow = 0;
  }
  function step(s) {
    s.time += DT;
    for (const f of s.flippers) {
      const target = f.on ? f.up : f.rest, d = target - f.ang, mx = FLIP.w * DT;
      if (Math.abs(d) <= mx) { f.angVel = d / DT; f.ang = target; } else { f.angVel = Math.sign(d) * FLIP.w; f.ang += f.angVel * DT; }
    }
    const live = s.balls.filter(b => b.state === 'play');
    for (const b of live) stepBall(s, b);
    const now = s.balls.filter(b => b.state === 'play');
    for (let i = 0; i < now.length; i++) for (let j = i + 1; j < now.length; j++) ballBall(s, now[i], now[j]);
    // 粘着的球跟着史莱姆走（史莱姆会蹦、会缩）
    for (const b of s.balls) if (b.state === 'stuck' && b.on) { b.x = b.on.x + b.ox * (b.on.r + b.r - 1); b.y = b.on.y + b.oy * (b.on.r + b.r - 1); }
    s.balls = s.balls.filter(b => b.state !== 'gone');
  }
  // 推 dt 秒（按定步长）
  function advance(s, dt, acc) {
    acc.t += dt;
    let n = 0;
    while (acc.t >= DT && n < 400) { step(s); acc.t -= DT; n++; }
  }

  return { DT, DX, X0, X1, Y0, YB, CH, LANE_X, LANE_TOP, LANE_CX, HEAD_Y, REST_Y, GRAVITY, VMAX, BALL_R, CXF, FLIP, DRAIN, GATE, GUIDE, SLING, LANES, ZONE,
    create, setFlipLen, load, launch, release, step, advance, tipOf, inLane, inPlay };
}));
