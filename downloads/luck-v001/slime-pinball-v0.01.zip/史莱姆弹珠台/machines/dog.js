/*
 * 第 1 台 · 基础机（狗屋）。打法同第一版：点卡抽骨头 → 按住拉弹簧、松手发射 → 落进有骨头的洞，小狗叼走骨头，吐骨头筹码。
 * v2 新加：
 *   金骨头（陈列柜·碰运气）：抽骨头时 2% 有一根是金的，落进金骨头的洞 ×5。
 *   骨头奖杯（陈列柜·手上功夫 = 这台的大奖）：亲手连着三发都中、而且落进同一个洞。
 *   狗项圈（陈列柜·打得深）：这一局中满 150 发。
 *   保底（技能树）：连空几发，下一发多抽一根骨头。力度刻度（技能树）：发力灯旁边标出每根骨头对应的力度。
 */
Machines.def('dog', env => {
  'use strict';
  const { A, sfx } = env;
  const S = MK.sprites(), INK = A.INK;
  const FX = A.FX, FY = A.FY;
  const sim = Sim.createMachine((Date.now() ^ (Math.random() * 1e9)) >>> 0);
  const st = { shot: 'idle', chase: null, acc: 0, snap: null, reward: null, trail: [], pegFlash: new Map(), sparks: [], gold: -1, time: 0 };
  const pl = MK.plunger(sfx);
  const GLASS = A.MARB.glass;
  const ballIm = MK.ball7(GLASS), trail1 = A.disc(2, '#a9b8d2'), trail2 = A.disc(1.5, '#7d8db0');
  // 骨头：按【价】的档分大小（一眼看出一根值多少），金骨头另一种颜色
  const BONE = ['#fff6e0', '#f0e2c0', '#c8b48c'], YEL = A.YEL;
  const SHAPES = {
    small: ['xx...xx', '.xxxxx.', 'xx...xx'],
    big: ['xx....xx', 'xxxxxxxx', '.xxxxxx.', 'xxxxxxxx', 'xx....xx'],
    huge: ['xxx....xxx', 'xxxxxxxxxx', '.xxxxxxxx.', 'xxxxxxxxxx', 'xxx....xxx'],
  };
  const boneIm = {};
  for (const k of Object.keys(SHAPES)) for (const gold of [0, 1]) {
    const rows = SHAPES[k], h = rows.length, C = gold ? [YEL[0], YEL[2]] : [BONE[0], k === 'small' ? BONE[1] : BONE[2]];
    boneIm[k + gold] = A.outlined(rows.map((r, j) => r.replace(/x/g, j < h / 2 ? 'a' : 'b')), { a: C[0], b: C[1] }, INK);
  }
  const tierOf = () => { const l = env.lvl('v'); return l >= 6 ? 'huge' : l >= 3 ? 'big' : 'small'; };
  const badge = A.outlined(SHAPES.small, { x: BONE[0] }, INK), badgeHot = A.outlined(SHAPES.small, { x: '#ffffff' }, INK);
  // 小狗：卡面门洞里那只（卡面 x 26..37、y 63..72）。中了醒过来往上蹿，叼走骨头
  const DOG_BOX = { x: 26, y: 63, w: 12, h: 10 }, MOUTH = { x: 64, y: 140 }, DOG_RISE = 3;
  const dog = (() => {
    const raw = A.cardArt('dog', false), soft = A.blurred(A.cardArt('dog'), 'side');
    const { x, y, w, h } = DOG_BOX, den = raw[y - 1][x], denSoft = soft[y - 1][x];
    const a = PixelKit(w, h), b = PixelKit(w, h);
    for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) { b.P(i, j, denSoft); const c = raw[y + j][x + i]; if (c && c !== den) a.P(i, j, c); }
    return { awake: A.toCanvas(a), den: A.toCanvas(b) };
  })();
  // 力度刻度：每个力度落哪个洞（结构固定，算一次就行）
  let gauge = null;
  function calcGauge() {
    if (gauge) return gauge;
    gauge = [];
    for (let i = 0; i <= 100; i++) { const m = Sim.createMachine(1); m.quiet = true; const r = Sim.runShot(m, i / 100); gauge.push(r ? r.hole : null); }
    return gauge;
  }

  const m = () => env.m();
  function drawCount() {
    // 主线里这台第一发必中（env.first：这台一发都还没打过）；赌场那版没有 env.first，照旧
    if (env.first && env.first()) return { k: 9, pityOn: false };
    let k = env.val('n');
    const pity = env.lv('pity'), need = pity === 2 ? 2 : pity === 1 ? 3 : Infinity;
    let pityOn = false;
    if (m().misses >= need) { k += 1; pityOn = true; m().misses = 0; }
    return { k: Math.min(9, k), pityOn };
  }
  function canDraw() { return st.shot === 'idle' && env.marbles() > 0; }
  function draw() {
    if (st.shot !== 'idle') return false;
    if (env.marbles() <= 0) { env.deny('marbles'); return false; }
    const { k, pityOn } = drawCount();
    const bones = Sim.drawBones(sim, k);
    st.gold = env.luck(0.02) ? bones[Math.floor(Math.random() * bones.length)] : -1;
    if (pityOn) { sfx.woof(); env.toast('保底：这一发多一根骨头'); }
    if (bones.length >= 9) { st.shot = 'ready'; sfx.settle(9); return true; }
    const tracks = bones.map((b, j) => {
      const hops = 7 + ((j * 3 + b) % 5), times = [];
      let t = j * 0.05;
      for (let h = 0; h < hops; h++) { t += 0.03 + 0.1 * Math.pow(h / hops, 2); times.push(t); }
      return { target: b, start: (b - hops + 90) % 9, times };
    });
    st.chase = { t: 0, tracks, dur: Math.max(...tracks.map(tr => tr.times[tr.times.length - 1])) + 0.08, hops: 0 };
    st.shot = 'chase';
    return true;
  }
  const chasePos = (tr, t) => { let n = 0; while (n < tr.times.length && tr.times[n] <= t) n++; return { hole: (tr.start + n) % 9, n }; };
  function startCharge(by) { if (st.shot !== 'ready') return false; pl.start(by); st.shot = 'charge'; return true; }
  function release() {
    if (st.shot !== 'charge') return;
    const p = pl.release();
    if (!env.spend()) { st.shot = 'ready'; return; }
    Sim.launch(sim, p);
    st.shot = 'fly'; st.acc = 0; st.trail.length = 0;
    sfx.launch(p);
  }
  function cancel() { if (st.shot === 'charge') { pl.cancel(); st.shot = 'ready'; } }
  // 自动打（自测、对数用）。落点对力度很敏感（差 0.1% 就可能换洞），所以照 test/aim.js 的路子：
  // 0.2% 一格的力度表 + 手抖 σ（5% × window.__autoNoise，最少 2%，一帧就差 1.5%），挑"落进有骨头的洞"几率最大的力度
  const gaussR = () => Math.sqrt(-2 * Math.log(1 - Math.random())) * Math.cos(2 * Math.PI * Math.random());
  let fineTab = null;
  const aimTab = {};
  function aimTable(sig) {
    const key = sig.toFixed(3);
    if (aimTab[key]) return aimTab[key];
    if (!fineTab) { fineTab = []; for (let i = 0; i <= 500; i++) { const mm = Sim.createMachine(1); mm.quiet = true; const r = Sim.runShot(mm, i / 500); fineTab.push(r ? r.hole : -1); } }
    const P = [];   // P[c][h]：瞄 c%，落进 h 号洞的几率
    for (let c = 0; c <= 100; c++) {
      const row = new Array(9).fill(0); let tot = 0;
      for (let i = 0; i <= 500; i++) { const d = (i / 500 - c / 100) / sig, w = Math.exp(-0.5 * d * d); tot += w; if (fineTab[i] >= 0) row[fineTab[i]] += w; }
      P.push(row.map(v => v / tot));
    }
    return (aimTab[key] = P);
  }
  function auto(dt) {
    const A_ = st.auto || (st.auto = { t: 0, target: 0.5 });
    if (st.shot === 'idle') { A_.t += dt; if (A_.t > 0.3 && env.marbles() > 0) { A_.t = 0; draw(); } return; }
    if (st.shot === 'ready') {
      A_.t += dt; if (A_.t < 0.3) return; A_.t = 0;
      const sig = Math.max(0.02, 0.05 * (window.__autoNoise || 0)), P = aimTable(sig);
      let best = 50, bp = -1;
      for (let c = 0; c <= 100; c++) { const pr = sim.bones.reduce((acc, h) => acc + P[c][h], 0); if (pr > bp) { bp = pr; best = c; } }
      A_.target = Math.max(0.02, Math.min(0.99, best / 100 + gaussR() * sig));
      startCharge('auto');
    } else if (st.shot === 'charge' && pl.by === 'auto') {
      const now = Sim.holdPower(pl.t), next = Sim.holdPower(pl.t + dt);
      if (now >= A_.target || next - A_.target > A_.target - now) release();
    }
  }
  function onSim(e) {
    if (e.type === 'hit') {
      if (e.kind === 'peg') { sfx.pin(e.impact, e.id); st.pegFlash.set(e.id, 0.12); if (e.impact > 40) for (let i = 0; i < 3; i++) st.sparks.push({ x: e.x + (i - 1) * 2, y: e.y - 1 - (i % 2) * 2, t: 0.09 + i * 0.02 }); }
      else if (e.kind === 'bump') sfx.bump(e.impact);
      else if (e.kind === 'roof') sfx.rim(e.impact);
      else if (e.kind !== 'head') sfx.wall(e.impact);
    } else if (e.type === 'fallback') { env.refund(); sfx.fallback(); st.shot = 'ready'; st.trail.length = 0; }
    else if (e.type === 'land') { st.snap = { t: 0, x0: e.x, y0: e.y, hole: e.hole, hit: e.hit }; st.shot = 'snap'; st.trail.length = 0; }
  }
  function finishSnap() {
    const { hole, hit } = st.snap, mm = m();
    st.snap = null;
    if (hit) {
      const gold = hole === st.gold, base = env.val('v') * (gold ? 5 : 1);
      mm.hits += 1; mm.misses = 0;
      sfx.win();
      st.reward = { t: 0, hole, gold, base, tier: tierOf() };
      if (gold && env.find('luck')) { /* 第一次：陈列柜放烟花（game.js 管） */ }
      if (gold) env.toast('金骨头！×5');
      // 同一个洞连中三发 = 大奖
      if (mm.streak.length && mm.streak[mm.streak.length - 1] !== hole) mm.streak = [];
      mm.streak.push(hole);
      if (mm.streak.length >= 3) { mm.streak = []; env.jackpot(); }
      if (mm.hits >= 150) env.find('deep');
    } else {
      mm.misses += 1; mm.streak = [];
      sfx.miss();
      st.reward = { t: 0, miss: true, hole };
    }
    st.shot = 'reward';
    env.save();
  }
  function endShot() { Sim.next(sim); st.reward = null; st.shot = 'idle'; st.gold = -1; env.save(); }

  // ---------- 画 ----------
  function drawHoles(ctx) {
    const shown = new Set();
    if (st.shot === 'chase') for (const tr of st.chase.tracks) shown.add(chasePos(tr, st.chase.t).hole);
    else if (['ready', 'charge', 'fly', 'snap'].includes(st.shot)) for (const b of sim.bones) shown.add(b);
    else if (st.shot === 'reward') for (const b of sim.bones) if (st.reward.miss || b !== st.reward.hole || st.reward.t < 0.05) shown.add(b);
    const tier = tierOf();
    const streak = m().streak;
    for (let i = 0; i < 9; i++) {
      if (shown.has(i)) {
        const im = boneIm[tier + (st.shot !== 'chase' && i === st.gold ? 1 : 0)];
        ctx.drawImage(im, FX(14 + 10 * i) + (16 - im.width * 2) / 2, FY(153) - im.height * 2 + 2, im.width * 2, im.height * 2);
      } else MK.spr(ctx, S.lampOff, 16 + 10 * i, 149);
    }
    // 连中记号：上一发中在哪个洞，洞口上面亮几颗金点（三颗 = 大奖）
    if (streak.length && st.shot !== 'reward') {
      const h = streak[streak.length - 1];
      for (let k = 0; k < 3; k++) { ctx.fillStyle = k < streak.length ? A.GOLD[0] : '#5a1626'; ctx.fillRect(FX(15 + 10 * h + k * 3), FY(142), 4, 4); }
    }
  }
  function drawBall(ctx) {
    if (st.shot === 'fly' && sim.ball) {
      const t1 = st.trail[2], t2 = st.trail[4];
      if (t2) MK.spr(ctx, trail2, t2[0] - 1.5, t2[1] - 1.5);
      if (t1) MK.spr(ctx, trail1, t1[0] - 2, t1[1] - 2);
      MK.spr(ctx, ballIm, Math.round(sim.ball.x - 3.5), Math.round(sim.ball.y - 3.5));
    }
    if (st.shot === 'snap') {
      const s = st.snap, t = MK.ease(s.t), x = s.x0 + (Sim.holeCx(s.hole) - s.x0) * t, y = s.y0 + (149 - s.y0) * t;
      MK.spr(ctx, ballIm, Math.round(x - 3.5), Math.round(y - 3.5));
    }
  }
  function drawReward(ctx) {
    const r = st.reward;
    if (!r || r.miss) return;
    const B = DOG_BOX, awake = r.t > 0.05 && r.t < 1.2;
    const up = MK.clamp((r.t - 0.15) / 0.12, 0, 1) * MK.clamp((1.2 - r.t) / 0.15, 0, 1), rise = Math.round(DOG_RISE * up);
    if (awake) {
      const x = A.CX0 + B.x * A.S4, y = A.CY0 + B.y * A.S4, w = B.w * A.S4, h = B.h * A.S4;
      ctx.drawImage(dog.den, x, y, w, h);
      ctx.drawImage(dog.awake, x, y - rise * A.S4, w, h);
    }
    const bone = boneIm[r.tier + (r.gold ? 1 : 0)], fly = MK.clamp(r.t / 0.35, 0, 1), hx = Sim.holeCx(r.hole);
    const tx = MOUTH.x, ty = MOUTH.y - DOG_RISE * 2;
    if (fly < 1) {
      const x = hx + (tx - hx) * MK.ease(fly), y = 150 + (ty - 150) * fly - 26 * Math.sin(Math.PI * fly);
      MK.spr(ctx, bone, x - bone.width / 2, y - bone.height / 2);
    } else if (awake) MK.spr(ctx, bone, MOUTH.x - bone.width / 2, MOUTH.y - rise * 2 - bone.height / 2);
  }

  return {
    sim,
    fine(f) {
      MK.fineHoles(f);
      MK.fineLane(f, Sim.DEFAULTS.guard);
      MK.finePegs(f, Sim.pegPositions());
      f.fineMeter();
    },
    update(dt) {
      st.time += dt;
      for (const [id, t] of st.pegFlash) { if (t - dt <= 0) st.pegFlash.delete(id); else st.pegFlash.set(id, t - dt); }
      st.sparks = st.sparks.filter(s => (s.t -= dt) > 0);
      if (st.shot === 'chase') {
        const c = st.chase; c.t += dt;
        let hops = 0;
        for (const tr of c.tracks) hops += chasePos(tr, c.t).n;
        if (hops > c.hops) { sfx.hop(hops % 12); c.hops = hops; }
        if (c.t >= c.dur) { st.chase = null; st.shot = 'ready'; sfx.settle(sim.bones.length); }
      }
      if (st.shot === 'charge') pl.update(dt);
      if (st.shot === 'fly') {
        st.acc += dt * 1.3;
        let n = 0;
        while (st.acc >= Sim.DT && sim.phase === 'flying' && n < 2000) { Sim.step(sim); st.acc -= Sim.DT; n++; }
        if (sim.ball) { st.trail.unshift([sim.ball.x, sim.ball.y]); if (st.trail.length > 6) st.trail.length = 6; }
        for (const e of sim.events.splice(0)) onSim(e);
      }
      if (st.shot === 'snap') { st.snap.t += dt / 0.12; if (st.snap.t >= 1) finishSnap(); }
      if (st.shot === 'reward') {
        const r = st.reward; r.t += dt;
        if (r.miss) { if (r.t > 0.3) endShot(); }
        else {
          if (r.t > 0.32 && !r.woofed) { r.woofed = true; sfx.woof(); }
          if (r.t > 0.4 && !r.paid) { r.paid = true; env.award(r.base, { at: [MOUTH.x, MOUTH.y - 6], n: Math.min(12, Math.ceil(r.base / 2)) }); }
          if (r.t > 1.25) endShot();
        }
      }
    },
    draw(ctx) {
      drawHoles(ctx);
      MK.lane(ctx, st.shot === 'charge' ? pl.pull() : 0, env.marbles() > 0 && ['idle', 'chase', 'ready', 'charge'].includes(st.shot) ? ballIm : null);
      A.drawMeter(ctx, pl.power(), st.shot === 'charge');
      if (env.lv('gauge') && ['ready', 'charge'].includes(st.shot)) MK.gaugeTicks(ctx, calcGauge(), o => (o != null && sim.bones.includes(o) ? (o === st.gold ? '#ffffff' : A.GOLD[0]) : null));
      // 徽章：能抽的时候一跳一跳
      const idle = canDraw(), bob = idle ? Math.round(Math.sin(st.time * 6) * 0.6) : 0;
      MK.spr(ctx, idle && Math.sin(st.time * 6) > 0.6 ? badgeHot : badge, 109, 12 + bob);
      for (const [id] of st.pegFlash) { const c = sim.colliders[id]; if (c && c.kind === 'peg') MK.spr(ctx, S.pegHit, c.x - 2, c.y - 2); }
      for (const s of st.sparks) MK.spr(ctx, S.spark, s.x - 1, s.y - 1);
      drawBall(ctx);
      drawReward(ctx);
      MK.led(ctx, env.marbles(), env.marbles() <= 0, st.time);
    },
    down(p) {
      if (!p.inCard || p.btn !== 0) return false;
      if (st.shot === 'idle') { draw(); return true; }
      if (st.shot === 'ready') { startCharge(p.id); return true; }
      return st.shot !== 'idle';
    },
    up(p) { if (st.shot === 'charge' && pl.by === p.id) release(); },
    key(code, down) {
      if (code !== 'Space' && code !== 'ArrowDown' && code !== 'Enter') return false;
      if (down) { if (st.shot === 'idle') draw(); else if (st.shot === 'ready') startCharge('key'); }
      else if (st.shot === 'charge' && pl.by === 'key') release();
      return true;
    },
    cancel,
    inPlay: () => ['fly', 'snap', 'reward', 'charge'].includes(st.shot) || (st.shot === 'reward'),
    busy: () => ['charge', 'fly', 'snap'].includes(st.shot),
    debug: () => ({ shot: st.shot, marbles: env.marbles(), shots: m().shots, hits: m().hits }),
    auto,
    hint() {
      if (st.shot === 'idle') return env.marbles() > 0 ? '点一下卡（或按空格）抽骨头' : '';
      if (st.shot === 'chase') return '抽骨头……';
      if (st.shot === 'ready') return '按住拉弹簧（鼠标或空格），松手打。落进有骨头的洞就中';
      if (st.shot === 'charge') return '松手发射';
      return '';
    },
    info() {
      const out = [['每发抽 ' + Math.min(9, env.val('n')) + ' 根骨头，一根吐 ' + env.val('v') + ' 个', null]];
      const s = m().streak;
      if (s.length) out.push(['同一个洞连中 ' + s.length + '/3（三发 = 大奖）', A.GOLD[0]]);
      const pity = env.lv('pity');
      if (pity) out.push(['保底：连空 ' + (pity === 2 ? 2 : 3) + ' 发多一根（已空 ' + m().misses + '）', null]);
      return out;
    },
    onUpgrade() {},
  };
});
