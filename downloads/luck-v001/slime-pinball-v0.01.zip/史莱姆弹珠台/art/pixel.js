/*
 * 像素画小工具：所有东西都直接写进一块 RGBA 缓冲，整数像素、不抗锯齿。
 * 用法：const K = PixelKit(640, 360); …画… ; K.flush(canvas)
 * 中文用 Windows 自带宋体 12px（canvas 里是真点阵）；正式版换开源像素字体。
 */
(function (root) {
  'use strict';
  root.PixelKit = function (W, H) {
    const buf = new Uint8ClampedArray(W * H * 4);
    const fl = Math.floor, rd = Math.round;
    const rgbCache = new Map();
    function rgb(hex) {
      let v = rgbCache.get(hex);
      if (!v) { const n = parseInt(hex.slice(1), 16); v = [(n >> 16) & 255, (n >> 8) & 255, n & 255]; rgbCache.set(hex, v); }
      return v;
    }
    function P(x, y, c) {
      x = fl(x); y = fl(y);
      if (!c || x < 0 || y < 0 || x >= W || y >= H) return;
      const v = rgb(c), i = (y * W + x) * 4;
      buf[i] = v[0]; buf[i + 1] = v[1]; buf[i + 2] = v[2]; buf[i + 3] = 255;
    }
    function R(x, y, w, h, c) { for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) P(x + i, y + j, c); }
    const BAYER = [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5];
    const dith = (x, y, t) => BAYER[((y & 3) << 2) | (x & 3)] + 0.5 < t * 16;
    function line(x0, y0, x1, y1, c) {
      x0 = rd(x0); y0 = rd(y0); x1 = rd(x1); y1 = rd(y1);
      const dx = Math.abs(x1 - x0), dy = -Math.abs(y1 - y0), sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1;
      let err = dx + dy;
      for (;;) {
        P(x0, y0, c);
        if (x0 === x1 && y0 === y1) break;
        const e2 = 2 * err;
        if (e2 >= dy) { err += dy; x0 += sx; }
        if (e2 <= dx) { err += dx; y0 += sy; }
      }
    }
    function sprite(rows, map, x, y) {
      rows.forEach((r, j) => { for (let i = 0; i < r.length; i++) { const c = map[r[i]]; if (c) P(x + i, y + j, c); } });
    }
    function disc(cx, cy, r, c) {
      for (let y = fl(cy - r - 1); y <= Math.ceil(cy + r + 1); y++) for (let x = fl(cx - r - 1); x <= Math.ceil(cx + r + 1); x++) {
        if (Math.hypot(x + 0.5 - cx, y + 0.5 - cy) <= r) P(x, y, c);
      }
    }
    // 有光照的圆球：按法线和左上来的光分四档，外圈描边
    function ball(cx, cy, r, ramp, outline) {
      const L = [-0.55, -0.83];
      for (let y = fl(cy - r - 1); y <= Math.ceil(cy + r + 1); y++) {
        for (let x = fl(cx - r - 1); x <= Math.ceil(cx + r + 1); x++) {
          const dx = x + 0.5 - cx, dy = y + 0.5 - cy, d = Math.hypot(dx, dy);
          if (d > r + 0.5) continue;
          if (d > r - 0.6) { P(x, y, outline); continue; }
          const nz = Math.sqrt(Math.max(0, 1 - (d / r) ** 2));
          const b = (dx / r) * L[0] + (dy / r) * L[1] + nz * 0.45;
          P(x, y, b > 0.9 ? ramp[3] : b > 0.45 ? ramp[2] : b > -0.05 ? ramp[1] : ramp[0]);
        }
      }
    }

    // ---------- 遮罩：文字、数字先变成 0/1 遮罩，再描边/投影/盖章 ----------
    function mk(w, h) { return { w, h, d: new Uint8Array(w * h) }; }
    const on = (m, x, y) => x >= 0 && y >= 0 && x < m.w && y < m.h && m.d[y * m.w + x] === 1;
    function fromRows(rows) {
      const m = mk(rows[0].length, rows.length);
      rows.forEach((r, j) => { for (let i = 0; i < r.length; i++) if (r[i] !== '.') m.d[j * m.w + i] = 1; });
      return m;
    }
    function concat(masks, gap) {
      const w = masks.reduce((a, m) => a + m.w, 0) + gap * Math.max(0, masks.length - 1);
      const h = Math.max(...masks.map(m => m.h));
      const out = mk(w, h);
      let ox = 0;
      for (const m of masks) {
        for (let j = 0; j < m.h; j++) for (let i = 0; i < m.w; i++) if (on(m, i, j)) out.d[j * w + ox + i] = 1;
        ox += m.w + gap;
      }
      return out;
    }
    function scaleMask(m, s) {
      const out = mk(m.w * s, m.h * s);
      for (let j = 0; j < out.h; j++) for (let i = 0; i < out.w; i++) out.d[j * out.w + i] = on(m, fl(i / s), fl(j / s)) ? 1 : 0;
      return out;
    }
    function boldMask(m) {
      const out = mk(m.w + 1, m.h);
      for (let j = 0; j < m.h; j++) for (let i = 0; i < out.w; i++) out.d[j * out.w + i] = on(m, i, j) || on(m, i - 1, j) ? 1 : 0;
      return out;
    }
    function stamp(m, x, y, color, opt) {
      opt = opt || {};
      if (opt.outline) {
        for (let j = -1; j <= m.h; j++) for (let i = -1; i <= m.w; i++) {
          if (on(m, i, j)) continue;
          let near = false;
          for (let dy = -1; dy <= 1 && !near; dy++) for (let dx = -1; dx <= 1; dx++) if (on(m, i + dx, j + dy)) { near = true; break; }
          if (near) P(x + i, y + j, opt.outline);
        }
      }
      if (opt.shadow) for (let j = 0; j < m.h; j++) for (let i = 0; i < m.w; i++) if (on(m, i, j)) P(x + i + 1, y + j + 1, opt.shadow);
      for (let j = 0; j < m.h; j++) for (let i = 0; i < m.w; i++) if (on(m, i, j)) P(x + i, y + j, typeof color === 'function' ? color(i, j, m) : color);
    }
    const tc = document.createElement('canvas');
    tc.width = 640; tc.height = 24;
    const tctx = tc.getContext('2d', { willReadFrequently: true });
    const tcache = new Map();
    function tmask(str) {
      if (tcache.has(str)) return tcache.get(str);
      tctx.clearRect(0, 0, tc.width, tc.height);
      tctx.font = '12px SimSun, "NSimSun", monospace';
      tctx.textBaseline = 'top';
      tctx.fillStyle = '#fff';
      tctx.fillText(str, 0, 0);
      const w = Math.max(1, Math.ceil(tctx.measureText(str).width)), h = 12;
      const img = tctx.getImageData(0, 0, w, h).data;
      const m = mk(w, h);
      for (let i = 0; i < w * h; i++) m.d[i] = img[i * 4 + 3] >= 128 ? 1 : 0;
      tcache.set(str, m);
      return m;
    }
    function text(str, x, y, color, opt) {
      opt = opt || {};
      let m = tmask(str);
      if (opt.bold) m = boldMask(m);
      if (opt.scale > 1) m = scaleMask(m, opt.scale);
      stamp(m, x, y, color, opt);
      return m.w;
    }
    const textW = (str, bold, scale) => (tmask(str).w + (bold ? 1 : 0)) * (scale || 1);

    const D8 = {
      '0': ['.####.', '##..##', '##..##', '##..##', '##..##', '##..##', '##..##', '.####.'],
      '1': ['..##..', '.###..', '..##..', '..##..', '..##..', '..##..', '..##..', '.####.'],
      '2': ['.####.', '##..##', '....##', '...##.', '..##..', '.##...', '##....', '######'],
      '3': ['.####.', '##..##', '....##', '..###.', '....##', '....##', '##..##', '.####.'],
      '4': ['...##.', '..###.', '.####.', '##.##.', '######', '...##.', '...##.', '...##.'],
      '5': ['######', '##....', '##....', '#####.', '....##', '....##', '##..##', '.####.'],
      '6': ['.####.', '##....', '##....', '#####.', '##..##', '##..##', '##..##', '.####.'],
      '7': ['######', '....##', '...##.', '...##.', '..##..', '..##..', '.##...', '.##...'],
      '8': ['.####.', '##..##', '##..##', '.####.', '##..##', '##..##', '##..##', '.####.'],
      '9': ['.####.', '##..##', '##..##', '##..##', '.#####', '....##', '....##', '.####.'],
      '+': ['......', '..##..', '..##..', '######', '######', '..##..', '..##..', '......'],
    };
    const D5 = {
      '1': ['.#.', '##.', '.#.', '.#.', '###'], '2': ['###', '..#', '###', '#..', '###'], '3': ['###', '..#', '.##', '..#', '###'],
      '4': ['#.#', '#.#', '###', '..#', '..#'], '5': ['###', '#..', '###', '..#', '###'], '6': ['###', '#..', '###', '#.#', '###'],
      '7': ['###', '..#', '.#.', '.#.', '.#.'], '8': ['###', '#.#', '###', '#.#', '###'], '9': ['###', '#.#', '###', '..#', '###'],
    };
    const fontCache = new Map();
    function numMask(str, small) {
      const font = small ? D5 : D8;
      return concat(str.split('').map(ch => {
        const key = (small ? '5' : '8') + ch;
        if (!fontCache.has(key)) fontCache.set(key, fromRows(font[ch]));
        return fontCache.get(key);
      }), 1);
    }
    function num(str, x, y, color, opt) {
      opt = opt || {};
      let m = numMask(str, opt.small);
      if (opt.scale > 1) m = scaleMask(m, opt.scale);
      stamp(m, x, y, color, opt);
      return m.w;
    }
    const numW = (str, opt) => numMask(str, opt && opt.small).w * ((opt && opt.scale) || 1);

    // 七段数码管：一位 8×14，笔画 2 像素；灭的笔画也画出来（暗红），像真的 LED
    const SEG = { a: [2, 0, 4, 2], b: [6, 2, 2, 4], c: [6, 8, 2, 4], d: [2, 12, 4, 2], e: [0, 8, 2, 4], f: [0, 2, 2, 4], g: [2, 6, 4, 2] };
    const DIGIT_SEGS = { '0': 'abcdef', '1': 'bc', '2': 'abged', '3': 'abgcd', '4': 'fgbc', '5': 'afgcd', '6': 'afgedc', '7': 'abc', '8': 'abcdefg', '9': 'abcdfg', '-': 'g', ' ': '' };
    function seg7(str, x, y, lit, off, hi) {
      str.split('').forEach((ch, k) => {
        const segs = DIGIT_SEGS[ch] || '';
        for (const s of 'abcdefg') {
          const [sx, sy, w, h] = SEG[s];
          const isOn = segs.includes(s);
          for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) P(x + k * 11 + sx + i, y + sy + j, isOn ? (hi && (j === 0 && (s === 'a' || s === 'g'))) ? hi : lit : off);
        }
      });
      return str.length * 11 - 3;
    }

    function sparkle(x, y, size, core, arm) {
      P(x, y, core);
      for (let k = 1; k <= size; k++) { const c = k === size ? arm : core; P(x - k, y, c); P(x + k, y, c); P(x, y - k, c); P(x, y + k, c); }
    }

    // 图层：先在小画布上拼形状，再统一描外边、贴到主画面
    function layer(w, h) { return { w, h, px: new Array(w * h).fill(null) }; }
    function lset(L, x, y, c) { x = fl(x); y = fl(y); if (x >= 0 && y >= 0 && x < L.w && y < L.h) L.px[y * L.w + x] = c; }
    function lget(L, x, y) { return x >= 0 && y >= 0 && x < L.w && y < L.h ? L.px[y * L.w + x] : null; }
    function lellipse(L, cx, cy, rx, ry, c, test) {
      for (let y = 0; y < L.h; y++) for (let x = 0; x < L.w; x++) {
        const dx = (x + 0.5 - cx) / rx, dy = (y + 0.5 - cy) / ry;
        if (dx * dx + dy * dy <= 1 && (!test || test(x, y, lget(L, x, y)))) L.px[y * L.w + x] = typeof c === 'function' ? c(x, y) : c;
      }
    }
    function loutline(L, c) {
      const add = [];
      for (let y = 0; y < L.h; y++) for (let x = 0; x < L.w; x++) {
        if (lget(L, x, y)) continue;
        if (lget(L, x - 1, y) || lget(L, x + 1, y) || lget(L, x, y - 1) || lget(L, x, y + 1)) add.push([x, y]);
      }
      for (const [x, y] of add) L.px[y * L.w + x] = c;
    }
    function blit(L, x, y) { for (let j = 0; j < L.h; j++) for (let i = 0; i < L.w; i++) { const c = L.px[j * L.w + i]; if (c) P(x + i, y + j, c); } }

    function flush(canvas) {
      canvas.width = W; canvas.height = H;
      canvas.getContext('2d').putImageData(new ImageData(buf, W, H), 0, 0);
    }

    return {
      W, H, fl, rd, P, R, dith, line, sprite, disc, ball, mk, on, fromRows, stamp, scaleMask, boldMask,
      tmask, text, textW, num, numW, seg7, sparkle, layer, lset, lget, lellipse, loutline, blit, flush,
    };
  };
}(window));
