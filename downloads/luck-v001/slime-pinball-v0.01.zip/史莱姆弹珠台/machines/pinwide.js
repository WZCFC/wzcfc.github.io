/*
 * 大台的弹球台公用件（第 8 台沼泽；第 11 台雨后菜园照这个来）。物理在 sims/pinwide.js，跟小台的 machines/pinkit.js 一个路子，多三样：
 *   好几颗球：粘住、救球退回来的球不花珠子；台上两颗以上就是"多球"（st.multi 记这一次多球碎了几只）。
 *   救球：开球、过上面的通道以后【救】秒里掉下去的，退回发射道（技能树"救球"再多 2 秒）。
 *   粘球的史莱姆（sticky）：撞得够快就粘住，台子的 cfg.onStick 决定怎么办（沼泽：粘满三颗撑破，放出来就是多球）。
 * 每台不一样的写在 cfg 里（同 pinkit）：bumpers、colors(o)、target()、spawn(fam)、died(o, t)、info(t)、hint(t)、update(dt, t)、onStick(e, t)、onUpgrade(k, t)、
 *   save()（几秒救球）、multi(n)（台上 n 颗球时一只的倍数）、multiJack（一次多球碎几只算大奖）。
 */
window.PinWideKit = (function () {
  'use strict';
  const A = Art, INK = A.INK, FX = A.FX, FY = A.FY, P = window.PinWide;
  const ALU = A.ALU, RAD = [0, 5, 7, 9], DX = P.DX, CX = P.CXF, ZONE = P.ZONE;
  const FLIP_C = { body: '#fe4c40', hi: '#ff8a7a', lo: '#b8322a' };

  // ---------- 不动的那一层 ----------
  function capsule(f, L, x0, y0, x1, y1, r, col) {
    const vx = x1 - x0, vy = y1 - y0, l2 = vx * vx + vy * vy || 1e-9;
    for (let y = Math.floor(Math.min(y0, y1) - r - 1); y <= Math.ceil(Math.max(y0, y1) + r + 1); y++) for (let x = Math.floor(Math.min(x0, x1) - r - 1); x <= Math.ceil(Math.max(x0, x1) + r + 1); x++) {
      const px = x + 0.5, py = y + 0.5;
      let t = ((px - x0) * vx + (py - y0) * vy) / l2; t = t < 0 ? 0 : t > 1 ? 1 : t;
      const dx = px - (x0 + vx * t), dy = py - (y0 + vy * t), d = Math.hypot(dx, dy);
      if (d <= r) f.lset(L, x, y, typeof col === 'function' ? col(dx, dy, d) : col);
    }
  }
  const metal = (dx, dy) => (dx + dy < -0.6 ? ALU[0] : dx + dy > 0.6 ? ALU[2] : ALU[1]);
  function fineTable(f, bumpers) {
    MK.fineLane(f, [6, 4], DX);
    const L = f.layer(192, 160);
    for (const k of ['L', 'R']) {
      const [a, b] = P.GUIDE[k];
      capsule(f, L, a[0], a[1], b[0], b[1], 1.3, metal);
      const S = P.SLING[k];
      f.lP(L, [S.A, S.B, S.C], (x, y) => ((x + y) % 4 === 0 ? FLIP_C.lo : FLIP_C.body));
      capsule(f, L, S.A[0], S.A[1], S.C[0], S.C[1], 1.2, '#ffffff');
      capsule(f, L, S.cap[0], S.cap[1], S.A[0], S.A[1], 1.1, metal);
      for (const p of [S.A, S.B, S.C]) capsule(f, L, p[0], p[1], p[0], p[1], 2, metal);
      const Ln = P.LANES[k];
      capsule(f, L, Ln.x, Ln.y0, Ln.x, Ln.y1, 1.6, metal);
    }
    capsule(f, L, CX - 28, 127, CX - 24, 134, 1.2, metal);
    capsule(f, L, CX + 28, 127, CX + 24, 134, 1.2, metal);
    f.outl(L);
    f.put(L, 0, 0);
    const G = P.GATE;
    for (let i = 0; i <= 10; i++) { const x = G.x0 + (G.x1 - G.x0) * i / 10, y = G.y0 + (G.y1 - G.y0) * i / 10; f.px(Math.floor(x), Math.floor(y), i % 2 ? ALU[0] : ALU[2]); }
    for (let y = 141; y <= 145; y++) for (let x = P.DRAIN.x0; x <= P.DRAIN.x1; x++) f.px(x, y, y === 141 ? '#5a1626' : INK);
    for (const [x, y, r] of bumpers || []) { const im = A.mushroomSprite(r + 0.5, r * 0.72, Math.round(r), false), L2 = toLayer(f, im); f.put(L2, Math.round(x - im.width / 2), Math.round(y + r - im.height + 2)); }
    f.fineMeter(DX);
  }
  function toLayer(f, im) {
    const L = f.layer(im.width, im.height), d = im.getContext('2d').getImageData(0, 0, im.width, im.height).data;
    for (let j = 0; j < im.height; j++) for (let i = 0; i < im.width; i++) { const k = (j * im.width + i) * 4; if (d[k + 3] > 0) f.lset(L, i, j, '#' + [d[k], d[k + 1], d[k + 2]].map(v => v.toString(16).padStart(2, '0')).join('')); }
    return L;
  }

  // =========================================================================
  function make(env, cfg) {
    const { sfx } = env;
    const s = P.create({ bumpers: cfg.bumpers || [], flipLen: env.lv('flip') ? 2 : 0 });
    const pl = MK.plunger(sfx);
    const ballIm = MK.ball7(A.MARB.steel);
    const st = { acc: { t: 0 }, wait: 0.3, time: 0, parts: [], labels: [], hold: { L: new Set(), R: new Set() }, pending: [], fam: 0, seq: 0, bumpFlash: new Map(), slingFlash: { L: 0, R: 0 }, laneFlash: { L: 0, R: 0 }, saveT: 0, ballKills: 0, multi: null, auto: null, layerFlash: 0 };
    const m = () => env.m();
    const laneBall = () => s.balls.find(b => b.state === 'lane');
    const playing = () => s.balls.filter(b => b.state === 'play');
    const live = () => s.slimes.filter(x => x.state !== 'pop');
    const saveFor = () => (cfg.save ? cfg.save() : 0) + (env.lv('save') ? 2 : 0);

    // ---------- 史莱姆 ----------
    const radOf = def => (def.r || (def.size === 'small' ? 4.5 : RAD[Math.max(1, Math.min(3, def.hp))]));
    function freeSpot(r) {
      for (let k = 0; k < 40; k++) {
        const x = ZONE.x0 + Math.random() * (ZONE.x1 - ZONE.x0), y = ZONE.y0 + Math.random() * (ZONE.y1 - ZONE.y0);
        if (s.slimes.some(o => o.state !== 'pop' && Math.hypot((o.tx ?? o.x) - x, (o.ty ?? o.y) - y) < o.r + r + 6)) continue;
        if ((cfg.bumpers || []).some(([bx, by, br]) => Math.hypot(bx - x, by - y) < br + r + 5)) continue;
        if (playing().some(b => Math.hypot(b.x - x, b.y - y) < r + 10)) continue;
        return [x, y];
      }
      return null;
    }
    function addSlime(def, fam, from) {
      const r = radOf(def);
      const spot = from ? [Math.max(ZONE.x0 - 6, Math.min(ZONE.x1 + 6, from[2])), Math.max(ZONE.y0, Math.min(ZONE.y1 + 6, from[3]))] : freeSpot(r);
      if (!spot) return null;
      const o = Object.assign({
        id: ++st.seq, fam, size: def.size || 'big', gold: !!def.gold, hp: def.hp, maxHp: def.hp, r,
        x: from ? from[0] : spot[0], y: from ? from[1] : 24, tx: spot[0], ty: spot[1],
        state: from ? 'hop' : 'drop', t: 0, dur: from ? 0.35 : 0.45, sx: from ? from[0] : spot[0], sy: from ? from[1] : 24,
        solid: false, cool: 0, flash: 0, squash: 0, hopIn: 2 + Math.random() * 4,
      }, def.extra || {});
      s.slimes.push(o);
      return o;
    }
    function spawnFamily() {
      const fam = ++st.fam, defs = cfg.spawn(fam);
      let ok = 0;
      for (const d of defs) if (addSlime(d, fam)) ok++;
      return ok > 0;
    }
    const famsAlive = () => new Set(live().filter(o => !o.sticky).map(o => o.fam)).size;
    function hop(o) {
      const r = o.r, spot = (() => { for (let k = 0; k < 12; k++) { const x = Math.max(ZONE.x0, Math.min(ZONE.x1, o.x + (Math.random() * 2 - 1) * 16)), y = Math.max(ZONE.y0, Math.min(ZONE.y1, o.y + (Math.random() * 2 - 1) * 12)); if (!s.slimes.some(p => p !== o && p.state !== 'pop' && Math.hypot((p.tx ?? p.x) - x, (p.ty ?? p.y) - y) < p.r + r + 4) && !(cfg.bumpers || []).some(([bx, by, br]) => Math.hypot(bx - x, by - y) < br + r + 4)) return [x, y]; } return null; })();
      if (!spot) return;
      o.state = 'hop'; o.t = 0; o.dur = 0.5; o.sx = o.x; o.sy = o.y; o.tx = spot[0]; o.ty = spot[1];
    }
    function burst(o, n, speed) {
      const C = cfg.colors(o);
      for (let i = 0; i < n; i++) {
        const a = (i / n) * Math.PI * 2 + Math.random() * 0.5, v = speed * (0.6 + Math.random() * 0.6);
        st.parts.push({ x: o.x + Math.cos(a) * o.r * 0.6, y: o.y + Math.sin(a) * o.r * 0.6, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 30, t: 0, dur: 0.45 + Math.random() * 0.2, c: i % 3 ? C[1] : C[0] });
      }
    }
    function damage(o, impact, e) {
      if (o.sticky) { if (impact > 15) { o.squash = Math.max(o.squash, 0.12); sfx.slime(impact * 0.5); } return; }
      if (o.state !== 'live' && o.state !== 'hop') return;
      if (o.cool > 0 || impact < 30) { if (impact > 15) { o.squash = Math.max(o.squash, 0.08); sfx.slime(impact * 0.5); } return; }
      o.hp -= 1; o.cool = 0.15; o.flash = 0.08; o.squash = 0.2;
      sfx.slime(impact);
      const C = cfg.colors(o);
      for (let i = 0; i < 3; i++) st.parts.push({ x: e.x, y: e.y, vx: -e.nx * (40 + i * 25) + (Math.random() - 0.5) * 40, vy: -e.ny * (40 + i * 25) - 20, t: 0, dur: 0.5, c: C[i % 2] });
      if (o.hp <= 0) kill(o);
      else o.r = radOf({ hp: o.hp, size: o.size });
    }
    function kill(o) {
      o.state = 'pop'; o.t = 0; o.solid = false;
      burst(o, 10, 70);
      sfx.pop();
      cfg.died(o, tools);
    }
    // 放出粘在 o 身上的球：往上撒开
    function releaseFrom(o) {
      const stuck = s.balls.filter(b => b.state === 'stuck' && b.on === o);
      stuck.forEach((b, i) => { const a = -Math.PI / 2 + (i - (stuck.length - 1) / 2) * 0.55 + (Math.random() - 0.5) * 0.2; P.release(s, b, Math.cos(a) * 170, Math.sin(a) * 170); b.paid = true; });
      return stuck.length;
    }
    // 多球：台上两颗以上开始，回到一颗结束
    function multiCheck() {
      const n = playing().length;
      if (n >= 2 && !st.multi) st.multi = { kills: 0, jack: false, max: n };
      if (st.multi) { st.multi.max = Math.max(st.multi.max, n); if (n <= 1) { const was = st.multi; st.multi = null; if (cfg.multiEnd) cfg.multiEnd(was, tools); } }
    }
    const tools = {
      env, st, s,
      addSlime, burst, releaseFrom,
      playing: () => playing().length,
      // 补一颗不花珠子的球在推头上（推头上有球就不补）
      loadFree() { const b = P.load(s, { paid: true, free: true }); if (b) sfx.clink(); return !!b; },
      pay(base, o, label) { const n = env.award(base, { at: [o.x, o.y - o.r], n: Math.min(10, Math.max(1, Math.ceil(base / 2))) }); if (label) st.labels.push({ s: label, x: o.x, y: o.y - o.r - 8, t: 0, c: A.GOLD[0] }); return n; },
      killCount(n) {
        const up = env.kill(n);
        if (up) { st.layerFlash = 1.5; for (const o of live()) if (o.state === 'live') o.squash = 0.25; }
        st.ballKills += n;
        if (st.multi) { st.multi.kills += n; if (cfg.multiJack && st.multi.kills >= cfg.multiJack && !st.multi.jack) { st.multi.jack = true; env.jackpot(); } }
        return up;
      },
      mult: () => (cfg.multi ? cfg.multi(playing().length) : 1),
      label(sx, sy, text, c) { st.labels.push({ s: text, x: sx, y: sy, t: 0, c: c || A.GOLD[0] }); },
      layer: () => m().layer,
      layerHp: () => env.R.layerHp(m().layer),
      layerMult: () => env.R.layerMult(m().layer),
    };

    // ---------- 球 ----------
    function loadPaid() { if (env.marbles() <= 0) return false; return !!P.load(s, { paid: false }); }
    function startPlunger(by) { const b = laneBall(); if (!b || pl.on) return false; pl.start(by); return true; }
    function releasePlunger(by) {
      if (!pl.on || (by != null && pl.by !== by)) return;
      const p = pl.release(), b = laneBall();
      if (!b) return;
      if (!b.paid) { if (!env.spend()) return; b.paid = true; if (!playing().length) st.ballKills = 0; }
      P.launch(s, p);
      st.saveT = Math.max(st.saveT, saveFor());
      sfx.launch(p);
    }
    function setFlip(side, id, on) {
      const set = st.hold[side];
      if (on) set.add(id); else set.delete(id);
      const f = s.flippers[side === 'L' ? 0 : 1], was = f.on;
      f.on = set.size > 0;
      if (f.on && !was) sfx.flip();
    }
    function flipAllOff() { for (const side of ['L', 'R']) { st.hold[side].clear(); s.flippers[side === 'L' ? 0 : 1].on = false; } }
    function onEvent(e) {
      if (e.type === 'hit') {
        if (e.kind === 'sling') { sfx.sling(); st.slingFlash[e.x < CX ? 'L' : 'R'] = 0.1; }
        else if (e.kind === 'shroom') { sfx.shroom(); st.bumpFlash.set(e.id, 0.1); }
        else if (e.kind === 'post') sfx.bump(e.impact);
        else if (e.kind === 'roof') sfx.rim(e.impact);
        else if (e.kind !== 'head') sfx.wall(e.impact);
      } else if (e.type === 'slime') damage(e.m, e.impact, e);
      else if (e.type === 'stick') { sfx.stone(); e.m.squash = 0.25; if (cfg.onStick) cfg.onStick(e, tools); }
      else if (e.type === 'flip') { if (e.moving) sfx.clack(e.impact); }
      else if (e.type === 'clack') sfx.clack(e.impact);
      else if (e.type === 'lane') {
        st.laneFlash[e.side] = 1;
        sfx.settle(2);
        const sv = saveFor();
        if (sv > 0) { st.saveT = Math.max(st.saveT, sv); st.labels.push({ s: '救球 ' + sv + ' 秒', x: e.x, y: e.y - 8, t: 0, c: '#9af06a' }); }
        if (cfg.onLane) cfg.onLane(e, tools);
      } else if (e.type === 'drain') {
        if (st.saveT > 0) {
          // 救回来：推头空着就躺回推头，不然排队
          const b = P.load(s, { paid: true, free: true });
          if (!b) s.balls.push({ id: ++s.seq, x: P.LANE_CX, y: P.REST_Y, vx: 0, vy: 0, r: P.BALL_R, state: 'queue', age: 0, slow: 0, paid: true, free: true });
          st.labels.push({ s: '救回来了', x: CX, y: 138, t: 0, c: '#9af06a' });
          sfx.settle(3);
        } else sfx.miss();
        if (!s.balls.some(b => b.state === 'play' || b.state === 'lane' || b.state === 'queue')) { st.wait = 0.6; env.save(); }
      } else if (e.type === 'back') { /* 打得太轻掉回推头：再打一下，不花珠子 */ }
      else if (e.type === 'nudge') sfx.wall(30);
    }

    // ---------- 自动打（自测、截图、领航用） ----------
    function auto(dt) {
      const A_ = st.auto || (st.auto = { near: { L: false, R: false }, skip: { L: false, R: false }, flipT: { L: 0, R: 0 }, hold: 0 });
      const b = laneBall(), live = playing();
      if (b && !live.length) {
        if (!pl.on) { A_.hold = 0.55 + Math.random() * 0.5; startPlunger('auto'); }
        else if (pl.by === 'auto' && pl.t >= A_.hold) releasePlunger('auto');
      } else if (b && !pl.on && Math.random() < 0.02) { A_.hold = 0.55 + Math.random() * 0.5; startPlunger('auto'); }
      else if (pl.on && pl.by === 'auto' && pl.t >= A_.hold) releasePlunger('auto');
      for (const side of ['L', 'R']) {
        const near = live.some(o => o.vy > -20 && o.y > 112 && o.y < 140 && (side === 'L' ? o.x < CX : o.x > CX) && Math.abs(o.x - (side === 'L' ? CX - 16 : CX + 16)) < 16);
        if (near && !A_.near[side]) { A_.near[side] = true; A_.skip[side] = Math.random() < 0.1 * (window.__autoNoise || 0); }
        if (!near && !live.some(o => o.y >= 108 && (side === 'L' ? o.x < CX : o.x > CX))) A_.near[side] = false;
        if (near && !A_.skip[side] && A_.flipT[side] <= 0 && Math.random() < 0.5) { setFlip(side, 'auto', true); A_.flipT[side] = 0.18; }
        if (A_.flipT[side] > 0) { A_.flipT[side] -= dt; if (A_.flipT[side] <= 0) setFlip(side, 'auto', false); }
      }
    }

    // ---------- 画 ----------
    function drawSlime(ctx, o) {
      const C = cfg.colors(o);
      let rx = o.r * 1.18, ry = o.r * 1.05;
      if (o.squash > 0) { const k = Math.sin(o.squash / 0.2 * Math.PI) * 0.22; rx *= 1 + k; ry *= 1 - k; }
      const x = o.x, y = o.y;
      if (o.state === 'pop') { const t = o.t / 0.25; rx *= 1 + t * 0.5; ry *= 1 - t * 0.6; if (t >= 1) return; }
      const im = A.slimeSprite(Math.round(rx * 2) / 2, Math.round(ry * 2) / 2, C, true, o.flash > 0 || o.state === 'pop');
      MK.spr(ctx, im, Math.round(x - im.width / 2), Math.round(y + o.r * 0.18 - im.height / 2));
      if (!o.sticky && o.state !== 'pop' && o.state !== 'drop' && o.maxHp > 1) {
        const n = o.hp, w = n * 3 - 1, x0 = Math.round(x - w / 2), y0 = Math.round(y - o.r * 1.05 - 3);
        ctx.fillStyle = INK; ctx.fillRect(FX(x0 - 1), FY(y0 - 1), (w + 2) * 2, 6);
        for (let i = 0; i < n; i++) { ctx.fillStyle = o.gold ? A.GOLD[0] : '#ffffff'; ctx.fillRect(FX(x0 + i * 3), FY(y0), 4, 2); }
      }
    }
    // 小灯：一格 3×3，亮的金、灭的暗红
    function lamp(ctx, x, y, on) { ctx.fillStyle = INK; ctx.fillRect(FX(x - 1), FY(y - 1), 10, 10); ctx.fillStyle = on ? A.GOLD[0] : '#5a1a10'; ctx.fillRect(FX(x), FY(y), 6, 6); }
    function draw(ctx) {
      for (const [id] of st.bumpFlash) {
        const c = s.colliders[id]; if (!c) continue;
        const r = c.r, im = A.mushroomSprite(r + 0.5, r * 0.72, Math.round(r), true);
        MK.spr(ctx, im, Math.round(c.x - im.width / 2), Math.round(c.y + r - im.height + 2));
      }
      for (const side of ['L', 'R']) if (st.slingFlash[side] > 0) { const S2 = P.SLING[side]; MK.dots(ctx, S2.A[0], S2.A[1], S2.C[0], S2.C[1], '#fff6c0', 1); }
      // 通道口的灯：刚滚过去亮一秒
      for (const k of ['L', 'R']) { const Ln = P.LANES[k], x = Math.round((Ln.sx0 + Ln.sx1) / 2) - 1; lamp(ctx, x, Ln.y0 + 2, st.laneFlash[k] > 0 && Math.sin(st.time * 14) > -0.5); }
      for (const o of s.slimes) drawSlime(ctx, o);
      if (cfg.drawOver) for (const o of s.slimes) cfg.drawOver(ctx, o, tools);   // 头上的字最后写：别被后画的史莱姆盖住
      for (const p of st.parts) { const a = p.t / p.dur; if (a < 1) { ctx.fillStyle = p.c; ctx.fillRect(FX(Math.round(p.x)), FY(Math.round(p.y)), 2, 2); } }
      for (const f of s.flippers) PinKit.drawFlipper(ctx, f);
      const lb = laneBall();
      MK.lane(ctx, pl.on ? pl.pull() : 0, lb ? ballIm : null, DX);
      for (const b of s.balls) if (b.state === 'play' || b.state === 'stuck') MK.spr(ctx, ballIm, Math.round(b.x - 3.5), Math.round(b.y - 3.5));
      A.drawMeter(ctx, pl.power(), pl.on, DX);
      // 救球灯：出球口上面，亮着写还剩几秒
      const sv = st.saveT > 0 && playing().length > 0;
      lamp(ctx, CX - 2, 134, sv && (st.saveT > 1.5 || Math.sin(st.time * 16) > 0));
      if (sv) MK.label(ctx, '救 ' + Math.ceil(st.saveT), CX + 1, 140, '#9af06a', 'center');
      // 层数（顶上正中）
      const L = m().layer, up = st.layerFlash > 0 && Math.sin(st.time * 16) > 0;
      // 层数写在左上角：正中是史莱姆待的地方
      MK.label(ctx, '第 ' + L + ' 层', P.X0 + 20, 22, up ? '#ffffff' : A.GOLD[0]);   // X0 + 20：左上斜顶的右边
      if (st.multi) MK.label(ctx, '多球 ' + playing().length + ' 颗' + (tools.mult() > 1 ? ' ×' + (Math.round(tools.mult() * 10) / 10) : ''), P.X0 + 20, 30, Math.sin(st.time * 10) > 0 ? '#ffffff' : A.GOLD[0]);
      for (const l of st.labels) { const a = l.t / 1.1; if (a < 1) MK.label(ctx, l.s, l.x, l.y - a * 10, l.c, 'center'); }
      if (m().shots < 4 && playing().length) { MK.label(ctx, '左键/Z', CX - 30, 147, '#fff3d8', 'center'); MK.label(ctx, '右键/M', CX + 30, 147, '#fff3d8', 'center'); }
      if (lb && !pl.on && Math.sin(st.time * 5) > 0) MK.label(ctx, lb.paid ? '再打一下' : '按住', P.LANE_CX, 118, A.GOLD[0], 'center');
      const queued = s.balls.filter(b => b.state === 'queue').length;
      if (queued) MK.label(ctx, '还有 ' + queued + ' 颗', P.LANE_CX - 2, 104, '#9af06a', 'center');
      MK.led(ctx, env.marbles(), env.marbles() <= 0 && !s.balls.some(b => b.paid && b.state !== 'stuck'), st.time);
    }

    const ctrl = {
      s,
      fine(f) { fineTable(f, cfg.bumpers); },
      update(dt) {
        st.time += dt;
        if (st.layerFlash > 0) st.layerFlash -= dt;
        pl.update(dt);
        const want = cfg.target();
        while (famsAlive() + st.pending.length < want) st.pending.push(st.pending.length ? 1.5 + 0.25 * st.pending.length : (live().length ? 1.5 : 0.15));
        for (let i = 0; i < st.pending.length; i++) st.pending[i] -= dt;
        while (st.pending.length && st.pending[0] <= 0) { if (spawnFamily()) st.pending.shift(); else { st.pending[0] = 0.3; break; } }
        for (const o of s.slimes) {
          o.cool = Math.max(0, o.cool - dt); o.flash = Math.max(0, o.flash - dt); o.squash = Math.max(0, o.squash - dt);
          if (o.state === 'drop' || o.state === 'hop') {
            o.t += dt; const t = Math.min(1, o.t / o.dur);
            o.x = o.sx + (o.tx - o.sx) * (o.state === 'drop' ? t : MK.ease(t));
            o.y = o.state === 'drop' ? o.sy + (o.ty - o.sy) * t * t : o.sy + (o.ty - o.sy) * t - 8 * Math.sin(Math.PI * t);
            if (o.state === 'drop' && t > 0.6) o.solid = true;
            if (t >= 1) { o.state = 'live'; o.solid = true; o.x = o.tx; o.y = o.ty; o.squash = 0.2; o.hopIn = (o.sticky ? 5 : 3) + Math.random() * 3; }
          } else if (o.state === 'live') { o.hopIn -= dt; if (o.hopIn <= 0) { o.hopIn = (o.sticky ? 5 : 3) + Math.random() * 3; hop(o); } }
          else if (o.state === 'pop') o.t += dt;
        }
        s.slimes = s.slimes.filter(o => !(o.state === 'pop' && o.t > 0.3));
        // 球：排队的往推头上挪；什么球都没有了，等一下装一颗新的（花珠子）
        if (!laneBall()) { const q = s.balls.find(b => b.state === 'queue'); if (q) q.state = 'lane'; }
        if (!s.balls.some(b => b.state === 'play' || b.state === 'lane' || b.state === 'queue')) { st.wait -= dt; if (st.wait <= 0) loadPaid(); }
        if (playing().length) st.saveT = Math.max(0, st.saveT - dt);
        P.advance(s, dt, st.acc);
        for (const e of s.events.splice(0)) onEvent(e);
        multiCheck();
        for (const p of st.parts) { p.t += dt; p.vy += 220 * dt; p.x += p.vx * dt; p.y += p.vy * dt; }
        st.parts = st.parts.filter(p => p.t < p.dur);
        for (const l of st.labels) l.t += dt;
        st.labels = st.labels.filter(l => l.t < 1.1);
        for (const [id, t] of st.bumpFlash) { if (t - dt <= 0) st.bumpFlash.delete(id); else st.bumpFlash.set(id, t - dt); }
        for (const k of ['L', 'R']) { st.slingFlash[k] = Math.max(0, st.slingFlash[k] - dt); st.laneFlash[k] = Math.max(0, st.laneFlash[k] - dt); }
        if (cfg.update) cfg.update(dt, tools);
      },
      draw,
      down(p) {
        const lb = laneBall();
        // 台上有球在跑：鼠标点哪里都是拍挡板（推头上那颗用空格打）；手机上按发射道那一条才是拉弹簧
        const overLane = p.inCard && p.x >= A.CX0 + (P.LANE_X - 4) * 2;
        if (lb && (!playing().length || (p.touch && overLane))) { startPlunger(p.id); return true; }
        if (playing().length) {
          const side = p.touch ? (p.x < A.CX0 + A.CW * 2 ? 'L' : 'R') : p.btn === 2 ? 'R' : 'L';
          setFlip(side, p.id, true);
          return true;
        }
        if (lb) { startPlunger(p.id); return true; }
        return false;
      },
      up(p) { releasePlunger(p.id); setFlip('L', p.id, false); setFlip('R', p.id, false); },
      key(code, down) {
        if (code === 'Space' || code === 'ArrowDown' || code === 'Enter') {
          if (down) startPlunger('key'); else releasePlunger('key');
          return true;
        }
        if (code === 'KeyZ' || code === 'ArrowLeft' || code === 'ShiftLeft') { setFlip('L', code, down); return true; }
        if (code === 'KeyM' || code === 'ArrowRight' || code === 'ShiftRight' || code === 'Slash') { setFlip('R', code, down); return true; }
        return false;
      },
      cancel() { pl.cancel(); flipAllOff(); },
      leave() { pl.cancel(); flipAllOff(); },
      auto,
      inPlay() { return pl.on || s.balls.some(b => b.state === 'play' || ((b.state === 'lane' || b.state === 'queue') && b.paid)); },
      busy() { return pl.on; },
      hint() {
        const h = cfg.hint ? cfg.hint(tools) : '';
        if (h) return h;
        const lb = laneBall();
        if (lb && pl.on) return '松手打出去';
        if (lb && !playing().length) return lb.paid ? '推头上这颗不花珠子：按住拉弹簧，松手打' : '按住卡（或空格）拉弹簧，松手把钢珠打上去';
        if (lb && playing().length) return '推头上还有一颗：空格（手机按发射道）';
        if (m().shots < 4 && playing().length) return '拍挡板接球，别让它从两片中间掉下去';   // 哪个键拍哪片，台面上挡板底下写着
        return '';
      },
      info() {
        // 大台左栏窄：一样一行，要紧的在前（放不下从后往前丢）
        const out = cfg.info(tools);
        if (st.multi) out.unshift(['多球碎了 ' + st.multi.kills + ' 只', A.GOLD[0]]);
        if (saveFor() > 0) out.push(st.saveT > 0 && playing().length ? ['救球亮着 ' + Math.ceil(st.saveT) + ' 秒', '#9af06a'] : ['过通道亮救球', null]);
        return out;
      },
      onUpgrade(k) { if (cfg.onUpgrade) cfg.onUpgrade(k, tools); },
      debug() { return { balls: s.balls.map(b => b.state), slimes: s.slimes.length, kills: m().kills, layer: m().layer, marbles: env.marbles(), multi: !!st.multi, saveT: st.saveT }; },
    };
    if (cfg.init) cfg.init(tools);
    return ctrl;
  }
  return { make, fineTable };
})();
