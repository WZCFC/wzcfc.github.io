/*
 * 第 5 台 · 蘑菇洞（打怪的第二台）。弹球台，同草地史莱姆的打法，多两样：
 *   蓝史莱姆一碎裂成两只小的（小的一下就碎），台上越打越多；只有小的吐筹码。
 *   三个蘑菇是弹柱：碰一下把球狠狠弹开，球在史莱姆堆里乱撞。
 *   连碎：1.5 秒里接着碎（大的裂开也算），第 N 只吐的 ×(1 + 【倍】×(N-1))。
 *   金蘑菇（碰运气）：3% 的大史莱姆是金的，裂出来的两只小的也是金的，碎了 ×5。
 *   蓝宝石（手上功夫 = 这台的大奖）：亲手连碎 5 只。矿工灯（打得深）：打到第 20 层（只有小的算层数）。
 */
Machines.def('shroom', env => {
  'use strict';
  const A = env.A, R = env.R;
  const BLUE = A.BLUE_SLIME, SMALL = ['#e6f6ff', '#8ccaff', '#3a7ad8'], DEEP = ['#a8d0ff', '#3a80e0', '#1c4a9a'], GOLDS = ['#fff6c0', '#ffd23a', '#d89a10'];
  const fmt = v => String(Math.round(v * 10) / 10);
  const m = () => env.m();
  const chain = { n: 0, t: 0, jack: false };
  return PinKit.make(env, {
    bumpers: [[40, 62, 5.5], [78, 62, 5.5], [59, 80, 5.5]],
    colors: o => (o.gold ? GOLDS : o.size === 'small' ? SMALL : o.maxHp >= 4 ? DEEP : BLUE),
    target: () => env.val('n'),
    spawn: () => [{ hp: env.val('h') + R.layerHp(m().layer), size: 'big', gold: env.luck(0.03) }],
    died(o, t) {
      chain.n = chain.t > 0 ? chain.n + 1 : 1;
      chain.t = 1.5;
      if (chain.n >= 2) t.label(o.x, o.y - o.r - 16, '连碎 ×' + chain.n, chain.n >= 5 ? '#ffffff' : A.GOLD[0]);
      if (chain.n >= 5 && !chain.jack) { chain.jack = true; env.jackpot(); }
      if (o.size === 'big') {
        const hp = 1 + t.layerHp();
        for (const d of [-1, 1]) t.addSlime({ hp, size: 'small', gold: o.gold }, o.fam, [o.x, o.y, o.x + d * 10, o.y + 2]);
        return;
      }
      const k = 1 + env.val('x') * (chain.n - 1);
      const base = env.val('v') * t.layerMult() * k * (o.gold ? 5 : 1);
      t.pay(base, o, o.gold ? '金 ×5' : null);
      if (o.gold) env.find('luck');
      t.killCount(1);
    },
    update(dt) { if (chain.t > 0) { chain.t -= dt; if (chain.t <= 0) { chain.n = 0; chain.jack = false; } } },
    info: t => {
      const out = [
        ['第 ' + t.layer() + ' 层：再碎 ' + (10 - m().lk) + ' 只到下一层', null],
        ['大的 ' + env.val('n') + ' 只 · ' + (env.val('h') + t.layerHp()) + ' 下裂开', null],
        ['小的碎一只吐 ' + fmt(env.val('v') * t.layerMult()) + ' 个' + (t.layer() > 1 ? '（层数 ×' + fmt(t.layerMult()) + '）' : ''), null],
      ];
      if (env.val('x') > 0) out.push(['连碎：每多一只多 ' + env.val('x') + ' 倍', null]);
      if (chain.t > 0 && chain.n > 0) out.push(['连碎 ×' + chain.n + '（' + chain.t.toFixed(1) + ' 秒内接着碎）· 5 只 = 大奖', A.GOLD[0]]);
      return out;
    },
  });
});
