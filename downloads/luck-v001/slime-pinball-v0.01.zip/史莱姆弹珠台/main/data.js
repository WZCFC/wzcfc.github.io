/*
 * 主线的条目（照《史莱姆主线 · 执行方案 v3》，数都是先填的）。ready: false 的是还没做的，游戏里先不出。
 *   STAGES  八关：代号、名字、zoom 镜头（1 是草地那么近；打穿进这一关，镜头往后拉到这个倍数，史莱姆跟着小一圈；没写的照上一关）、
 *           count 这关的密度（底子几只 + 哪个节点加）、出场表（from 第几层起才有）、boss；
 *           layers 每层：hp 血（中个头；写成 [[血, 几份], …] 就是这层有高有低，照份数抽）、need 碎够几只往下、big 大个的几成（挨一下裂两只）
 *             血跟着弹珠一下打多少定：草地照玻璃珠 1、骨球 3（力道后面才露，前期靠多撞几下），菜园照老手的骨球 12、火山弹 20 起（菜园才膨胀，火山弹的数跟着菜园配）；
 *             不是一层比一层难：难一层、松一层
 *   SLIMES  史莱姆：tier 档、血（这层的几倍）、金币（血的几倍）
 *   BOSSES  boss：tier 档、血、多大（中个头的几倍）、hop 几秒蹦一次、spit 几秒吐一只、spitHp 吐的那只几血、x 左右两个落点、y 站多高、战利品
 *   MARBLES 主线弹珠：tier 档、大小（玻璃珠的几倍）、重、fen 一下几份、bag / dur 底子几颗、撞几下碎（树上那一组往上加）、
 *           from 哪台小游戏开了才露（这颗球在斩草除根的树里买）
 *   档：弹珠比史莱姆低 → "叮"，不掉血；一样或高一档 → 正常打（一下 = 份 × 力道，金珠 ×2，重击 ×2）；高两档起 → 碾压（直接爆，弹珠不弹开、不掉耐久，接着走）
 *   NODES   所有能买的（斩草除根的树 + 每台小游戏里头的）：
 *           id、name、where 在哪台（main 斩草除根、dog / volcano / ring 那台小游戏）、group 斩草除根那边分在哪一组、
 *           gold / tix 每一级的价（金币、tixId 那台的奖券；一个价最多两种钱）、vals 第 0 级到满级这个数是多少（pct 的是百分比）、
 *           露（第四节）：pre 前面这几个都买过一级、preMax 前面这几个都买满、at 别的时候（coin 挣到第一枚金币、open:台 开了那台）、stage 这一世打到过第几关
 *           part 台上的零件（买了马上装），shows 买了这一样那台小游戏上桌，ball 解锁一颗球，call 买了打哪通电话、showCall 露出来打哪通，
 *           up / kind 小游戏里头的：up 是十八台那版的哪一项（签、价、速），kind 是 cheap 降价、helper 小人、auto 自动买弹珠
 *           eff 栏里那一行的那一句（不另写名字，一句话说清点完怎么样；栏宽放得下 7 个字），{d} 换成多买一级那个数变了多少；first 一级都没买时的写法
 *           买满的收进最底下"买满了"
 *   GROUPS  斩草除根那边的组：一颗球一组、球的本事一组（骨刺、着火）、台子一组、一关的东西一组、一种史莱姆的复活一组；
 *           ball 这一组算哪颗球的（无头玩家养球用）；desk: 'jar' 的在桌上金币罐那一页（金币那几样）
 *   CATS    分类：kind 'ball' 的一种弹珠一类，在桌上柜台那一屏（一种一页：blurb 一句它的脾气、pay 花什么钱）；
 *           kind 'scene' 的一个场景一类，在机台右栏（顶上一排小页签）。一类里的组：头一组不写组名，后面的写
 *   MINIS   桌上的小游戏（第一阶段三台；跟着节点上桌）：box 一盒几颗、boxPrice 一盒多少金币（开台就是买第一盒）、tix 奖券叫什么、
 *           bot 小人一颗几秒、slot 桌上哪一格、call 开台那通电话（简单讲这台怎么打、券拿去干什么）
 *           chain 弹无虚发：一颗母珠连着白打，每多白打一杆，撞出的多几倍（第一杆 ×1；先填）
 *   CALLS   电话：一通一样新东西；lines 一句一句的字幕
 *   PERKS   转生树（照刮个爽：一次性的开东西，能升级的加数）
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.MainData = api;
}(typeof self !== 'undefined' ? self : globalThis, function () {
  'use strict';
  // 一级比一级贵一点：a 起，每级 ×r，取整，后一级至少比前一级多 1
  const ramp = (a, r, n) => { const o = []; let x = a; for (let i = 0; i < n; i++) { o.push(Math.max(o.length ? o[o.length - 1] + 1 : 1, Math.round(x))); x *= r; } return o; };
  // n 级、每级加 d：第 0 级 base，满级 base + n·d
  const step = (d, n, base) => { const o = []; for (let i = 0; i <= n; i++) o.push(Math.round(((base || 0) + d * i) * 1e6) / 1e6); return o; };
  const L = (hp, need, big) => ({ hp, need, big: big || 0 });
  // 七层的排法（11-11 从十层压到七层，照菜园）：第 i 层的血是 h 的几倍、几份；要碎几只；大个的几成。难一层松一层
  const PAT = [[[1, 2], [2, 1]], [[1, 1], [2, 1]], [[1.33, 1], [2.67, 1]], [[2, 1], [4, 1]], [[1.33, 1], [2.67, 2]],
    [[2, 1], [4, 1], [6, 1]], [[2.67, 1], [5.33, 1], [8, 1]]];
  const NEED = [2, 2, 3, 4, 3, 4, 5], BIG = [0.2, 0.3, 0.3, 0.35, 0.4, 0.4, 0.4];
  const round2 = x => { if (x < 10) return Math.max(1, Math.round(x)); const k = Math.pow(10, Math.floor(Math.log10(x)) - 1); return Math.round(x / k) * k; };
  const LAY7 = h => PAT.map((p, i) => L(p.map(([a, w]) => [round2(a * h), w]), NEED[i], BIG[i]));
  const STAGES = [
    // 草地（血都先填）：玻璃珠一下 1（力道买了弹力绳才露），前两层都是 1 血；第 3 层冒 2 血的（撞两下），第 5 层冒 3 血的（撞三下），靠耐久多撞几下。
    //   第 4 层起是墙 A：一层里一半是玻璃珠一两下碎的，一半是 4～9 血、要骨球的（骨球一下 3；骨球力道买了骨刺几率才露，一级加 1：4 血、5 血、6 血一级碎一种）。
    //   打不动的趴在台上不走，台上慢慢挤满硬的；难一层（4、6）松一层（5）。11-11 从十层压到七层
    { n: 1, k: 'grass', name: '草地', zoom: 1, count: { base: 1, node: 'count1' }, mix: [['mud', 10]], boss: 'grassKing',
      layers: [L(1, 1), L([[1, 2], [2, 1]], 2), L([[1, 2], [2, 1], [3, 1]], 2, 0.2),
        L([[2, 2], [4, 1]], 3, 0.3), L([[1, 2], [3, 1]], 2, 0.3), L([[2, 1], [5, 1]], 3, 0.35), L([[2, 1], [4, 1], [6, 1]], 3, 0.4)] },
    // 菜园（血都先填）：11-11 改成第一世就打（来电之前要用火山弹打掉大蜗牛），血照第一世的火山弹一下 10 配：一半一下碎，一半两三下；
    //   第 2 层起有蜗牛（墙 B，血 ×1.5），骨球、骨刺、玻璃珠都"叮"，只有火山弹砸得开。难一层松一层，七层
    { n: 2, k: 'garden', name: '菜园', zoom: 0.75, count: { base: 7, node: 'count2' }, mix: [['mud', 5], ['slug', 3], ['snail', 2]], from: { snail: 2 }, boss: 'snailKing',
      layers: [L([[3, 2], [6, 1]], 2, 0.2), L([[3, 1], [6, 1]], 2, 0.3), L([[4, 1], [8, 1]], 2, 0.3), L([[5, 1], [10, 1]], 2, 0.35),
        L([[4, 1], [8, 2]], 2, 0.4), L([[5, 1], [10, 1], [15, 1]], 3, 0.4), L([[6, 1], [12, 1], [18, 1]], 3, 0.4)] },
    // 第 3～8 关（11-11 全套粗做，血都先填）：照菜园那七层的排法，h 是这一关第 1 层的血（照这关那颗新珠子一下打多少配）
    { n: 3, k: 'cave', name: '蘑菇洞', count: { base: 5, node: 'count3' }, mix: [['mud', 4], ['blue', 6]], boss: 'shroomKing', layers: LAY7(30) },
    { n: 4, k: 'swamp', name: '沼泽', count: { base: 5, node: 'count4' }, mix: [['mud', 5], ['amber', 4], ['blue', 1.5]], from: { blue: 4 }, boss: 'swampKing', layers: LAY7(80) },
    { n: 5, k: 'river', name: '冰河', count: { base: 5, node: 'count5' }, mix: [['mud', 5], ['frozen', 4.5], ['amber', 0.8]], from: { amber: 5 }, boss: 'iceKing', layers: LAY7(400) },
    { n: 6, k: 'sea', name: '地下海', count: { base: 5, node: 'count6' }, mix: [['jelly', 6], ['puffer', 2], ['crab', 2]], from: { puffer: 2, crab: 4 }, boss: 'jellyKing', layers: LAY7(2000) },
    { n: 7, k: 'lava', name: '岩浆', count: { base: 5, node: 'count7' }, mix: [['lava', 7], ['rock', 3]], from: { rock: 3 }, boss: 'volcanoKing', layers: LAY7(5000) },
    { n: 8, k: 'castle', name: '史莱姆王城', count: { base: 6, node: 'count8' }, mix: [['mud', 2], ['guard', 3], ['snail', 1], ['blue', 1], ['amber', 1], ['frozen', 1], ['lava', 1]], boss: 'slimeKing', layers: LAY7(30000) },
  ];
  // 夜：打掉史莱姆王，钻到地球另一边，又是草地，这回是夜里。八关照白天的景（压暗），血和金币 ×NIGHT（先填）
  const NIGHT = 10;
  for (const d of STAGES.slice(0, 8)) {
    STAGES.push(Object.assign({}, d, {
      n: d.n + 8, day: d.n, night: true, name: '夜·' + d.name, mul: NIGHT,
      layers: d.layers.map(l => ({ hp: Array.isArray(l.hp) ? l.hp.map(([h, w]) => [h * NIGHT, w]) : l.hp * NIGHT, need: l.need, big: l.big })),
    }));
  }
  const SLIMES = {
    mud: { name: '泥史莱姆', tier: 1, hp: 1, gold: 1 },
    slug: { name: '鼻涕虫', tier: 2, hp: 0.8, gold: 1, how: '身上一层黏液，玻璃珠一碰就滑开' },
    snail: { name: '蜗牛', tier: 3, hp: 1.5, gold: 1.5, how: '背着硬壳，骨球、玻璃珠撞上去只"叮"一声' },
    // 后六关的（11-11 粗做）：split 碎了裂成两只小的（小的血是它的几成）、still 不动、sticky 轻的珠子撞上粘一会儿、smash 一下砸碎金币几倍、
    //   move 怎么挪（drift 漂、walk 横着走、march 排队左右走）、puff 挨一下鼓起来、hot 慢的珠子碰一下多掉 1 下耐久
    blue: { name: '蓝史莱姆', tier: 3, hp: 1, gold: 0.6, split: 0.4, how: '碎了裂成两只小的，往两边蹦' },
    amber: { name: '琥珀史莱姆', tier: 5, hp: 1.2, gold: 1, still: true, sticky: true, how: '不动；轻的珠子撞上去粘一会儿' },
    frozen: { name: '冰冻史莱姆', tier: 7, hp: 1, gold: 1, still: true, smash: 2, how: '冻在冰里不动，一下砸碎金币翻倍' },
    jelly: { name: '水母', tier: 8, hp: 1, gold: 1, move: 'drift', how: '在水里左右漂' },
    puffer: { name: '河豚', tier: 9, hp: 1, gold: 1.5, puff: true, how: '挨一下鼓成刺球，大一半、弹得狠' },
    crab: { name: '寄居蟹', tier: 9, hp: 1.5, gold: 1.5, move: 'walk', how: '背着壳横着走，碰墙掉头' },
    lava: { name: '岩浆史莱姆', tier: 10, hp: 1, gold: 1, hot: true, how: '烫：慢的珠子碰一下多掉 1 下耐久' },
    rock: { name: '黑石史莱姆', tier: 11, hp: 1.5, gold: 1.5, still: true, smash: 2, how: '一层凉了的硬壳，不动' },
    guard: { name: '卫兵史莱姆', tier: 12, hp: 1.4, gold: 1.5, move: 'march', how: '戴着头盔排着队左右走' },
  };
  // 个头：中的是常见的；大的挨一下裂成两只小的（小的血是它的一半）；小的只从大的裂出来。r 是满血时的半径（台面格）
  const SIZES = { s: { hp: 0.5, r: 4.6 }, m: { hp: 1, r: 6 }, b: { hp: 1, r: 7.8 } };
  const BOSSES = {
    // 草地大王 12 血、大蜗牛 20 血（11-11 改成第一世就打：到 boss 手里一般只剩两三颗，骨球一下 3～6、火山弹一下 10～13，五六下打掉）
    grassKing: { k: 'grassKing', name: '草地大王', tier: 1, hp: 12, r: 2.5, hop: 4, spit: 6, spitHp: 1, x: [72, 108], y: 88, trophy: '草冠' },
    snailKing: { k: 'snailKing', name: '大蜗牛', tier: 3, hp: 20, r: 2.4, hop: 6, spit: 7, spitHp: 8, x: [70, 110], y: 86, trophy: '花壳', spitKind: 'slug' },
    // 后六个（11-11 粗做，血先填）：cap 伞从上面撞只弹开、dieSplit 打掉裂成几只、sticky 挨着的轻珠子粘一下、breath 几秒吹一口冷气冻住最近的珠子、
    //   drift 画八字漂（不蹦）、slow 碰到的珠子慢一半、spitN 一次吐几只、eat 几秒吞一只挨着的
    shroomKing: { k: 'shroomKing', name: '蘑菇王', tier: 4, hp: 1500, r: 2.5, hop: 5, spit: 5, spitKind: 'blue', x: [70, 110], y: 84, trophy: '蘑菇伞', cap: true, dieSplit: 4 },
    swampKing: { k: 'swampKing', name: '沼泽王', tier: 5, hp: 6000, r: 2.5, hop: 6, spit: 7, spitKind: 'amber', x: [70, 110], y: 86, trophy: '大琥珀', sticky: true },
    iceKing: { k: 'iceKing', name: '冰王', tier: 7, hp: 25000, r: 2.5, hop: 6, spit: 9, spitKind: 'frozen', x: [70, 110], y: 86, trophy: '冰冠', breath: 10 },
    jellyKing: { k: 'jellyKing', name: '大水母', tier: 9, hp: 1e5, r: 2.8, hop: 0, spit: 10, spitKind: 'jelly', x: [70, 110], y: 80, trophy: '水母灯', drift: true, slow: true },
    volcanoKing: { k: 'volcanoKing', name: '火山王', tier: 11, hp: 3e5, r: 2.8, hop: 7, spit: 8, spitKind: 'lava', spitN: 3, x: [70, 110], y: 84, trophy: '熔岩心' },
    slimeKing: { k: 'slimeKing', name: '史莱姆王', tier: 13, hp: 1.5e6, r: 3.4, hop: 8, spit: 15, spitKind: 'guard', spitN: 3, eat: 6, x: [74, 106], y: 82, trophy: '王冠' },
  };
  // 重：0 轻、1 普通、2 重、3 很重。磨挡板：普通 1、重 2、很重 5
  // 大小最多 1.5：发射道只有 11 格宽
  const MARBLES = {
    glass: { name: '玻璃珠', tier: 1, r: 1, weight: 1, fen: 1, bag: 1, dur: 1, set: 'pin', how: '起手的弹珠，撞一下史莱姆或者栏杆就碎' },
    bone: { name: '骨球', tier: 2, r: 1.15, weight: 1, fen: 3, bag: 4, dur: 2, from: 'dog', set: 'pin', how: '2 档：一下打 3 份' },
    lava: { name: '火山弹', tier: 3, r: 1, weight: 2, fen: 10, bag: 4, dur: 2, from: 'volcano', set: 'pin', how: '3 档：烫的硬石头，砸得开蜗牛壳；泥史莱姆一碰就碎' },
    // 后十颗（11-11 粗做，数先填）。set：用哪套台面（flick 弹指、bowl 保龄、kick 足球）；dur 弹指、足球是几杆（几脚）、保龄是撞几下
    taw: { name: '大母珠', tier: 4, r: 1.5, weight: 2, fen: 30, bag: 2, dur: 4, from: 'ring', set: 'flick', how: '4 档：弹指，被它撞开的史莱姆滑出去砸别的' },
    iron: { name: '铁母珠', tier: 5, r: 1.4, weight: 3, fen: 80, bag: 2, dur: 4, from: 'ice', set: 'flick', how: '5 档：很重，推着史莱姆走' },
    egg: { name: '蛋', tier: 6, r: 1.3, weight: 0, fen: 150, bag: 3, dur: 2, from: 'hen', set: 'flick', how: '6 档：轻，碎了溅一圈' },
    bowl: { name: '保龄球', tier: 7, r: 2.2, weight: 3, fen: 400, bag: 2, dur: 3, from: 'bowl', set: 'bowl', how: '7 档：很重，压着走，撞飞的砸后面的' },
    snow: { name: '雪球', tier: 8, r: 1.8, weight: 2, fen: 900, bag: 2, dur: 3, from: 'snow', set: 'bowl', how: '8 档：越滚越大' },
    hook: { name: '鱼钩', tier: 9, r: 1.5, weight: 3, fen: 2000, bag: 2, dur: 3, from: 'fish', set: 'bowl', how: '9 档：钩住一只拖着走' },
    soccer: { name: '足球', tier: 10, r: 1.8, weight: 1, fen: 5000, bag: 2, dur: 4, from: 'soccer', set: 'kick', how: '10 档：踢飞的史莱姆砸别的' },
    coins: { name: '一摞硬币', tier: 11, r: 1.6, weight: 2, fen: 12000, bag: 2, dur: 5, from: 'coin', set: 'kick', how: '11 档：撞一下崩出一枚' },
    rubber: { name: '橡胶珠', tier: 12, r: 1.3, weight: 1, fen: 30000, bag: 2, dur: 5, from: 'circus', set: 'kick', how: '12 档：弹得快，撞墙不减速' },
    pool: { name: '台球', tier: 13, r: 1.3, weight: 2, fen: 60000, bag: 2, dur: 3, from: 'pool', set: 'kick', how: '13 档：一发三颗' },
  };
  // 哪颗球在前（右栏的组、左栏的顺序）
  const BALLS = ['glass', 'bone', 'lava', 'taw', 'iron', 'egg', 'bowl', 'snow', 'hook', 'soccer', 'coins', 'rubber', 'pool'];
  // 后十颗：哪台小游戏给、那台的券、本事那一组（first 每套第一颗没有本事）
  const LATE = [
    { k: 'taw', mini: 'ring', G: 3000, T: 4, first: true, blurb: '弹指：撞开的史莱姆滑出去砸别的' },
    { k: 'iron', mini: 'ice', G: 2e4, T: 4, abil: 'push', an: '推', blurb: '很重，推着走，夹住的一下算两下' },
    { k: 'egg', mini: 'hen', G: 6e4, T: 4, abil: 'splash', an: '溅', blurb: '轻，碎了溅一圈' },
    { k: 'bowl', mini: 'bowl', G: 2e5, T: 4, first: true, blurb: '保龄：很重，压着走，撞飞的砸后面的' },
    { k: 'snow', mini: 'snow', G: 8e5, T: 4, abil: 'grow', an: '越滚越大', blurb: '每碎一只大一圈' },
    { k: 'hook', mini: 'fish', G: 3e6, T: 4, abil: 'hooked', an: '钩', blurb: '钩住一只拖着走' },
    { k: 'soccer', mini: 'soccer', G: 1e7, T: 4, first: true, blurb: '足球：踢飞的史莱姆砸别的，踢进门退一脚' },
    { k: 'coins', mini: 'coin', G: 3e7, T: 4, abil: 'chip', an: '崩', blurb: '撞一下崩出一枚，压着碎的金币翻倍' },
    { k: 'rubber', mini: 'circus', G: 1e8, T: 4, abil: 'bouncy', an: '弹', blurb: '弹得快，撞台边不减速' },
    { k: 'pool', mini: 'pool', G: 3e8, T: 4, abil: 'rack', an: '开球', blurb: '一发三颗，摆成三角' },
  ];
  // 后六关的场景页：代号、页签图标、名字；sk 是这关在 STAGES 里的 k
  const LATE_ST = [
    { id: 'cave', n: 3, name: '蘑菇洞', g: 2000 }, { id: 'marsh', n: 4, name: '沼泽', g: 8000 }, { id: 'river', n: 5, name: '冰河', g: 4e4 },
    { id: 'sea', n: 6, name: '地下海', g: 2e5 }, { id: 'magma', n: 7, name: '岩浆', g: 6e5 }, { id: 'castle', n: 8, name: '王城', g: 3e6 },
  ];
  const WEAR = [1, 1, 2, 5];
  // 栏杆磨弹珠：撞墙、导轨比 wall 重，撞柱子比 post 重，才掉 1 下耐久
  const RAIL_WEAR = { wall: 50, post: 30 };
  // 挡板：头一副盖出口几成，挡板耐久的底子
  const FLIP = { cover: 0.4, dur: 30 };
  // 骨刺：飞多快（台面格/秒）、飞多久、多大、几根散开多宽（弧度）
  const SPIKE = { speed: 150, life: 0.7, r: 1.6, spread: 0.5 };
  // 着火：烧几秒、一秒掉几成血（火势往上乘）
  const FIRE = { dur: 3, pct: 0.1 };
  // 复活：碎了以后几秒聚回来、台上最多几只（密度的几倍）
  const REVIVE = { delay: 0.3, board: 2 };

  // 每台小游戏吐的券叫什么（柜台那一页"花什么钱"用；MINIS 里也写着）
  const MINI_TIX = { dog: '骨头券', volcano: '火山券', ring: '母珠券', ice: '冰块券', hen: '鸡蛋券', bowl: '球瓶券', snow: '雪球券', fish: '鱼钩券', soccer: '足球券', coin: '铜钱券', circus: '马戏券', pool: '台球券' };
  // ---------- 斩草除根那边的组 ----------
  const GROUPS = {
    glass: { name: '玻璃珠', ball: 'glass' },
    bone: { name: '骨球', ball: 'bone' },
    spike: { name: '骨刺', ball: 'bone' },
    lava: { name: '火山弹', ball: 'lava' },
    fire: { name: '着火', ball: 'lava' },
    grass: { name: '台子' },
    garden: { name: '菜园' },
    gold: { name: '金币', desk: 'jar' },
    'rv:mud': { name: '泥史莱姆复活' },
    'rv:slug': { name: '鼻涕虫复活' },
    'rv:snail': { name: '蜗牛复活' },
  };
  for (const B of LATE) { GROUPS[B.k] = { name: MARBLES[B.k].name, ball: B.k }; if (B.abil) GROUPS[B.abil] = { name: B.an, ball: B.k }; }
  for (const T of LATE_ST) GROUPS['st:' + T.id] = { name: T.name };
  GROUPS.night = { name: '夜' };
  // 分类：icon 是页签上的图（节点图标；m: 开头是那颗弹珠）。弹珠进桌上的柜台，场景留在机台右栏
  const CATS = [
    { id: 'glass', kind: 'ball', ball: 'glass', name: '玻璃珠', icon: 'm:glass', groups: ['glass'], blurb: '起手的弹珠，撞几下就碎', pay: '只要金币' },
    { id: 'bone', kind: 'ball', ball: 'bone', name: '骨球', icon: 'm:bone', groups: ['bone', 'spike'], blurb: '比玻璃珠硬，碎的时候崩出骨刺', pay: '金币加骨头券（一骨作气吐的）' },
    { id: 'lava', kind: 'ball', ball: 'lava', name: '火山弹', icon: 'm:lava', groups: ['lava', 'fire'], blurb: '烫的硬石头，砸得开蜗牛壳', pay: '金币加火山券（火上浇冰吐的）' },
    { id: 'grass', kind: 'scene', name: '草地', icon: 'grass', groups: ['grass', 'rv:mud'] },
    { id: 'garden', kind: 'scene', name: '菜园', icon: 'garden', groups: ['garden', 'rv:slug', 'rv:snail'] },
  ];
  // 后十颗珠子进柜台（一种一页），后六关、夜进机台右栏
  for (const B of LATE) {
    const MI = B.mini;
    CATS.splice(CATS.findIndex(c => c.kind === 'scene'), 0, { id: B.k, kind: 'ball', ball: B.k, name: MARBLES[B.k].name, icon: 'm:' + B.k, groups: B.abil ? [B.k, B.abil] : [B.k], blurb: B.blurb, pay: '金币加' + MINI_TIX[MI] });
  }
  for (const T of LATE_ST) CATS.push({ id: T.id, kind: 'scene', name: T.name, icon: 'st:' + T.id, groups: ['st:' + T.id] });
  CATS.push({ id: 'night', kind: 'scene', name: '夜', icon: 'night', groups: ['night'] });
  const GROUP_ORDER = CATS.flatMap(c => c.groups);

  // ---------- 节点 ----------
  const N = o => Object.assign({ where: 'main', pre: [], preMax: [], gold: null, tix: null, tixId: null, vals: [0, 1] }, o);
  const NODES = [];
  const add = o => NODES.push(N(o));
  // 玻璃珠（只要金币）
  add({ id: 'bag', name: '弹珠袋', group: 'glass', at: 'coin', gold: ramp(1, 1.45, 7), vals: step(1, 7), icon: 'bag', eff: '多带 {d} 颗弹珠' });
  add({ id: 'dur', name: '耐久', group: 'glass', pre: ['bag'], gold: ramp(2, 1.5, 5), vals: step(1, 5), icon: 'glass', eff: '多撞 {d} 下才碎' });
  // 力道放到后面（买了弹力绳才露）：前期草地碎得快靠多撞几下，力道管血高的、墙和大王；一级 +1 份、级数少（价先填）
  add({ id: 'power', name: '力道', group: 'glass', pre: ['sling'], gold: [15, 40], vals: [0, 1, 2], icon: 'dmg', eff: '一下多打 {d} 份' });
  // 台子 · 草地
  add({ id: 'count1', name: '草地密度', group: 'grass', pre: ['dur'], gold: [2, 3, 4, 6, 8, 11, 15, 20, 26], vals: step(1, 9), icon: 'count', eff: '草地多趴 {d} 只' });
  add({ id: 'flip1', name: '挡板', group: 'grass', pre: ['count1'], gold: [8], part: true, shows: 'dog', call: 'flipKeys', icon: 'flip1', eff: '装上两片挡板' });
  // 金币两条：加算（赏金，碎一只多给几枚）早早露，买了耐久就露、跟草地密度一起；买满了露乘算（金币加成，再多给几成）。
  //   两条一起金币涨得快，后面一档一档的价才拉得开（价先填）
  add({ id: 'gold1', name: '赏金', group: 'gold', pre: ['dur'], gold: [3, 8, 15], vals: step(1, 3), icon: 'gold', eff: '每只多 {d} 金币' });
  add({ id: 'flip1b', name: '挡板加长', group: 'grass', pre: ['flip1'], gold: ramp(5, 1.3, 5), tix: [1, 1, 2, 2, 3], tixId: 'dog', vals: step(0.05, 5), pct: true, part: true, icon: 'flip2', eff: '多盖出口 {d}%' });
  add({ id: 'restart', name: '重来', group: 'grass', pre: ['gold1'], gold: [8], part: true, icon: 'restart', eff: '随时重开一轮' });
  add({ id: 'gold2', name: '金币加成', group: 'gold', preMax: ['gold1'], gold: ramp(12, 1.45, 10), vals: step(0.1, 10), pct: true, icon: 'gold', eff: '金币多给 {d}%' });
  add({ id: 'goldSlime', name: '金史莱姆', group: 'gold', pre: ['gold1'], gold: ramp(6, 1.3, 10), vals: step(0.01, 10), pct: true, icon: 'goldSlime', first: '1% 金的给 5 倍', eff: '金史莱姆多 {d}%' });
  add({ id: 'sling', name: '弹力绳', group: 'grass', pre: ['flip1b'], gold: [25], tix: [3], tixId: 'dog', part: true, icon: 'sling', eff: '两边装上弹力绳' });
  add({ id: 'lanes', name: '小孔', group: 'grass', pre: ['sling'], gold: [50], tix: [4], tixId: 'dog', part: true, icon: 'lanes', eff: '钻过小孔打双倍' });
  add({ id: 'recycle', name: '回收', group: 'grass', preMax: ['count1'], gold: [40], tix: [4], tixId: 'dog', part: true, icon: 'recycle', eff: '没碎的收回再用' });
  add({ id: 'flip2', name: '挡板再加长', group: 'grass', preMax: ['flip1b'], gold: ramp(30, 1.4, 4), tix: ramp(4, 1.3, 4), tixId: 'dog', vals: step(0.05, 4), pct: true, part: true, icon: 'flip2', eff: '再多盖出口 {d}%' });
  // 骨球（金币 + 骨头券）
  add({ id: 'boneBall', name: '骨球', group: 'bone', at: 'open:dog', gold: [6], tix: [2], tixId: 'dog', ball: 'bone', icon: 'm:bone', eff: '先养几级再换上' });
  // 骨球袋 10 级（最多 12 颗）、骨球耐久 5 级（最多撞 6 下）：草地一颗碎几只看撞几下，骨球一颗跟玻璃珠差不多，打得过玻璃珠全靠颗数；
  //   底子只有 2 颗、撞 1 下，前几级压得很便宜，养得快（价先填）
  add({ id: 'boneBag', name: '骨球袋', group: 'bone', pre: ['boneBall'], gold: ramp(4, 1.3, 10), tix: [1, 1, 1, 1, 2, 2, 2, 3, 3, 4], tixId: 'dog', vals: step(1, 10), icon: 'bag', eff: '多带 {d} 颗骨球' });
  add({ id: 'boneDur', name: '骨球耐久', group: 'bone', pre: ['boneBall'], gold: ramp(4, 1.4, 5), tix: [1, 1, 2, 2, 3], tixId: 'dog', vals: step(1, 5), icon: 'm:bone', eff: '多撞 {d} 下才碎' });
  // 骨刺那一条是骨球的构筑（一轮多打几下、穿过去打几只）：墙 A 前后就要买得起，前几级压便宜（价先填）
  // 骨球力道放到骨刺后面（买了骨刺就露，草地大王要它）：一级 +1 份，一下 3→6，墙 A 那几层 4 血、5 血、6 血的一级碎一种（价先填）
  add({ id: 'bonePow', name: '骨球力道', group: 'bone', pre: ['spike'], gold: [10, 20, 40], tix: [1, 2, 3], tixId: 'dog', vals: [0, 1, 2, 3], icon: 'dmg', eff: '一下多打 {d} 份' });
  add({ id: 'spike', name: '骨刺', group: 'spike', pre: ['boneDur'], gold: [20], tix: [2], tixId: 'dog', shows: 'volcano', icon: 'spike', eff: '5% 崩出骨刺' });
  add({ id: 'spikeP', name: '骨刺几率', group: 'spike', pre: ['spike'], gold: ramp(5, 1.35, 9), tix: [1, 1, 2, 2, 3, 3, 4, 5, 6], tixId: 'dog', vals: step(0.05, 9), pct: true, icon: 'spike', eff: '骨刺几率多 {d}%' });
  add({ id: 'spikeN', name: '骨刺根数', group: 'spike', pre: ['spikeP'], gold: [20, 40, 80], tix: [2, 4, 6], tixId: 'dog', vals: step(1, 3), icon: 'spikes', eff: '一次多崩 {d} 根' });
  add({ id: 'spikePierce', name: '骨刺穿透', group: 'spike', pre: ['spikeN'], gold: [25, 50, 100], tix: [3, 5, 8], tixId: 'dog', vals: step(1, 3), icon: 'pierce', eff: '骨刺多穿 {d} 只' });
  // 台子 · 菜园（第一次看到菜园才露）
  add({ id: 'count2', name: '菜园密度', group: 'garden', stage: 2, gold: ramp(50, 1.3, 6), vals: step(1, 6), icon: 'count', eff: '菜园多趴 {d} 只' });
  add({ id: 'bossBall', name: '过关补珠', group: 'garden', stage: 2, gold: ramp(60, 1.5, 3), tix: ramp(5, 1.5, 3), tixId: 'dog', vals: step(1, 3), icon: 'bossBall', first: '过关补 1 颗', eff: '过关多补 {d} 颗' });
  add({ id: 'crit', name: '重击', group: 'garden', stage: 2, pre: ['count2'], gold: ramp(60, 1.25, 10), vals: step(0.02, 10), pct: true, icon: 'crit', first: '2% 重击打双倍', eff: '重击几率多 {d}%' });
  add({ id: 'fdur', name: '挡板耐久', group: 'garden', stage: 2, pre: ['flip2'], gold: ramp(50, 1.3, 5), tix: ramp(4, 1.3, 5), tixId: 'dog', vals: step(10, 5), icon: 'fdur', eff: '挡板多拍 {d} 下' });
  // 火山弹（金币 + 火山券）
  add({ id: 'lavaBall', name: '火山弹', group: 'lava', at: 'open:volcano', gold: [40], tix: [3], tixId: 'volcano', ball: 'lava', icon: 'm:lava', eff: '砸得开蜗牛壳' });
  add({ id: 'lavaBag', name: '火山弹袋', group: 'lava', pre: ['lavaBall'], gold: ramp(30, 1.35, 7), tix: ramp(1, 1.35, 7), tixId: 'volcano', vals: step(1, 7), icon: 'bag', eff: '多带 {d} 颗' });
  add({ id: 'lavaDur', name: '火山弹耐久', group: 'lava', pre: ['lavaBall'], gold: ramp(40, 1.4, 5), tix: ramp(1, 1.4, 5), tixId: 'volcano', vals: step(1, 5), icon: 'm:lava', eff: '多撞 {d} 下才碎' });
  add({ id: 'lavaPow', name: '火山弹力道', group: 'lava', pre: ['lavaBag'], gold: ramp(50, 1.25, 10), tix: ramp(1, 1.25, 10), tixId: 'volcano', vals: step(0.1, 10), pct: true, icon: 'dmg', eff: '一下多打 {d}%' });
  // 着火不再带弹无虚发上桌（11-11）：作者来电以前只有前三台，弹无虚发跟着来电上桌
  add({ id: 'fire', name: '着火', group: 'fire', pre: ['lavaDur'], gold: [200], tix: [6], tixId: 'volcano', icon: 'fire', eff: '砸中 10% 着火' });
  add({ id: 'fireP', name: '着火几率', group: 'fire', pre: ['fire'], gold: ramp(100, 1.25, 8), tix: ramp(2, 1.25, 8), tixId: 'volcano', vals: step(0.05, 8), pct: true, icon: 'fire', eff: '着火几率多 {d}%' });
  add({ id: 'fireHeat', name: '火势', group: 'fire', pre: ['fireP'], gold: ramp(120, 1.25, 10), tix: ramp(2, 1.25, 10), tixId: 'volcano', vals: step(0.1, 10), pct: true, icon: 'heat', eff: '火烧得狠 {d}%' });
  add({ id: 'spread', name: '蔓延', group: 'fire', pre: ['fireHeat'], gold: ramp(300, 1.5, 4), tix: ramp(6, 1.5, 4), tixId: 'volcano', vals: step(1, 4), icon: 'spread',
    first: '火往下传 1 只', eff: '火多传 {d} 只' });
  // 复活：一种史莱姆一组（金币 + 骨头券）
  for (const [k, nm, pre, preMax, stage] of [['mud', '泥史莱姆', ['lavaBag'], [], 0], ['slug', '鼻涕虫', [], ['rvMudP'], 2], ['snail', '蜗牛', [], ['rvMudP'], 2]]) {
    const g = 'rv:' + k, K = 'rv' + k[0].toUpperCase() + k.slice(1), mul = k === 'mud' ? 1 : 3;
    const o = { group: g, tixId: 'dog', stage, revive: k };
    add(Object.assign({ id: K, name: nm + '复活', pre, preMax, gold: [300 * mul], tix: [5 * mul], icon: 'revive', eff: '5% 原地复活' }, o));
    add(Object.assign({ id: K + 'P', name: '复活几率', pre: [K], gold: ramp(150 * mul, 1.25, 9), tix: ramp(2 * mul, 1.25, 9), vals: step(0.05, 9), pct: true, icon: 'revive', eff: '复活几率多 {d}%' }, o));
    add(Object.assign({ id: K + 'Cap', name: '复活上限', pre: [K + 'P'], gold: ramp(250 * mul, 1.35, 5), tix: ramp(2 * mul, 1.35, 5), vals: step(5, 5), icon: 'reviveCap', eff: '一轮多活 {d} 只' }, o));
    add(Object.assign({ id: K + 'Two', name: '复活成两只', pre: [K + 'Cap'], gold: ramp(400 * mul, 1.35, 6), tix: ramp(3 * mul, 1.35, 6), vals: step(0.05, 6), pct: true, icon: 'reviveTwo', first: '5% 活成两只', eff: '活成两只多 {d}%' }, o));
  }
  // 后十颗珠子（11-11 粗做，价先填）：一颗一组——解锁、袋子、耐久、力道（百分比），第二颗起再加本事那两条。
  //   上桌一台带一台：每套第一颗的耐久、后几颗的本事买了，下一台小游戏上桌
  const NEXT = { ring: 'ice', ice: 'hen', hen: 'bowl', bowl: 'snow', snow: 'fish', fish: 'soccer', soccer: 'coin', coin: 'circus', circus: 'pool' };
  const durWord = { flick: '多弹 {d} 杆', bowl: '多撞 {d} 下', kick: '多踢 {d} 脚' };
  const ABIL = {
    push: { name: '推', eff: '夹住的一下算两下', up: { id: 'pushX', name: '夹得狠', vals: step(1, 2, 0), eff: '夹住的多挨 {d} 下', icon: 'dmg' }, icon: 'dmg' },
    splash: { name: '溅', eff: '碎了溅一圈', up: { id: 'splashR', name: '溅得开', vals: step(4, 3, 0), eff: '溅开大 {d} 格', icon: 'spread' }, icon: 'spread' },
    grow: { name: '越滚越大', eff: '每碎一只大一圈', up: { id: 'growMax', name: '滚得更大', vals: step(1, 3, 0), eff: '最多多大 {d} 圈', icon: 'count' }, icon: 'count' },
    hooked: { name: '钩', eff: '钩住一只拖着走', up: { id: 'hookN', name: '多钩', vals: step(1, 2, 0), eff: '多钩 {d} 只', icon: 'pierce' }, icon: 'pierce' },
    chip: { name: '崩', eff: '撞一下崩出一枚', up: { id: 'chipGold', name: '压金', vals: step(1, 3, 0), eff: '压着碎的金币多 ×{d}', icon: 'gold' }, icon: 'spikes' },
    bouncy: { name: '弹', eff: '撞台边不减速', up: { id: 'bouncyV', name: '弹得快', vals: step(0.1, 3, 0), pct: true, eff: '弹得快 {d}%', icon: 'dmg' }, icon: 'spread' },
    rack: { name: '开球', eff: '一发三颗', up: { id: 'rackN', name: '多摆', vals: step(1, 2, 0), eff: '一发多 {d} 颗', icon: 'count' }, icon: 'count' },
  };
  for (const B of LATE) {
    const k = B.k, M = MARBLES[k], g = B.k, G = B.G, T = B.T, tx = B.mini, ti = n => Math.max(1, Math.round(n));
    const U = k + 'Ball';
    add({ id: U, name: M.name, group: g, at: 'open:' + tx, gold: [G], tix: [T], tixId: tx, ball: k, icon: 'm:' + k, eff: '先养几级再换上' });
    add({ id: k + 'Bag', name: M.name + '袋', group: g, pre: [U], gold: ramp(G * 0.3, 1.35, 7), tix: ramp(ti(T * 0.4), 1.35, 7), tixId: tx, vals: step(1, 7), icon: 'bag', eff: '多带 {d} 颗' });
    add({ id: k + 'Dur', name: M.name + '耐久', group: g, pre: [U], gold: ramp(G * 0.4, 1.4, 5), tix: ramp(ti(T * 0.5), 1.4, 5), tixId: tx, vals: step(1, 5), icon: 'm:' + k, eff: durWord[M.set],
      shows: B.first ? NEXT[tx] : undefined });
    add({ id: k + 'Pow', name: M.name + '力道', group: g, pre: [k + 'Bag'], gold: ramp(G * 0.5, 1.25, 10), tix: ramp(ti(T * 0.5), 1.25, 10), tixId: tx, vals: step(0.1, 10), pct: true, icon: 'dmg', eff: '一下多打 {d}%' });
    if (B.abil) {
      const A_ = ABIL[B.abil];
      add({ id: B.abil, name: A_.name, group: B.abil, pre: [k + 'Dur'], gold: [G * 1.2], tix: [T * 2], tixId: tx, shows: NEXT[tx], icon: A_.icon, eff: A_.eff });
      const u = A_.up;
      add({ id: u.id, name: u.name, group: B.abil, pre: [B.abil], gold: ramp(G * 0.8, 1.6, u.vals.length - 1), tix: ramp(T * 2, 1.5, u.vals.length - 1), tixId: tx, vals: u.vals, pct: u.pct, icon: u.icon, eff: u.eff });
    }
  }
  // 大母珠：撞开传几手；足球：进门退几次
  add({ id: 'tawChain', name: '传几手', group: 'taw', pre: ['tawDur'], gold: [5000, 12000], tix: [8, 16], tixId: 'ring', vals: [0, 1, 2], icon: 'spread', first: '撞开的再撞开一手', eff: '撞开多传 {d} 手' });
  add({ id: 'goalBack', name: '进门退回', group: 'soccer', pre: ['soccerDur'], gold: [2e7, 5e7], tix: [8, 16], tixId: 'soccer', vals: [0, 1, 2], icon: 'restart', eff: '进门多退 {d} 次' });
  // 后六关：一关一组（第一次看到这一关才露）——密度、金币 ×2
  for (const T of LATE_ST) {
    add({ id: 'count' + T.n, name: T.name + '密度', group: 'st:' + T.id, stage: T.n, gold: ramp(T.g, 1.3, 6), vals: step(1, 6), icon: 'count', eff: T.name + '多趴 {d} 只' });
    add({ id: 'goldx' + T.n, name: '金币 ×2', group: 'st:' + T.id, stage: T.n, pre: ['count' + T.n], gold: [T.g * 6], vals: [1, 2], icon: 'gold', eff: '金币翻一倍' });
  }
  // 夜（第一次打穿史莱姆王城才露）：三样没顶的（级数先给到 20）
  const geo = (a, r, n) => { const o = [1]; for (let i = 0; i < n; i++) o.push(Math.round(o[o.length - 1] * r * 1000) / 1000); return o; };
  add({ id: 'nightBag', name: '夜·珠袋', group: 'night', stage: 9, gold: ramp(3e7, 3, 8), vals: step(1, 8), icon: 'bag', eff: '每种珠子多带 {d} 颗' });
  add({ id: 'nightDmg', name: '夜·力道', group: 'night', stage: 9, gold: ramp(5e7, 4, 20), vals: geo(1, 1.5, 20), icon: 'dmg', eff: '力道再 ×1.5' });
  add({ id: 'nightGold', name: '夜·金币', group: 'night', stage: 9, gold: ramp(5e7, 4, 20), vals: geo(1, 1.5, 20), icon: 'gold', eff: '金币再 ×1.5' });

  // ---------- 小游戏里头（这台的奖券；有几样再加金币） ----------
  const CHEAP = step(-0.08, 10, 1);   // 降价：一盒弹珠的金币价 × 这个（一级便宜原价的 8%）
  // 一骨作气
  // 骨头签（每发抽几根 = 几个洞有骨头）升得太快：每级金币 + 券混着买，前几级金币多，越往后要的券越多（价先填）
  add({ id: 'dog.n', where: 'dog', up: 'n', name: '骨头签', tixId: 'dog', gold: ramp(5, 1.45, 8), tix: ramp(1, 1.6, 8), vals: step(1, 8, 1), tag: '签', eff: '多抽 {d} 根骨头' });
  add({ id: 'dog.v', where: 'dog', up: 'v', name: '骨头价', pre: ['dog.n'], tixId: 'dog', tix: ramp(2, 1.45, 8), gold: ramp(6, 1.4, 8), vals: step(1, 8, 1), tag: '价', eff: '一根多 {d} 张券' });
  add({ id: 'dog.cheap', where: 'dog', kind: 'cheap', name: '降价', pre: ['dog.v'], tixId: 'dog', tix: ramp(2, 1.35, 10), vals: CHEAP, icon: 'gold', eff: '一盒便宜 8%' });
  add({ id: 'dog.helper', where: 'dog', kind: 'helper', name: '小人', pre: ['dog.cheap'], tixId: 'dog', tix: [20], gold: [100], icon: 'helper', eff: '雇小人帮你打' });
  add({ id: 'dog.auto', where: 'dog', kind: 'auto', name: '自动买弹珠', pre: ['dog.helper'], preMax: ['dog.cheap'], tixId: 'dog', tix: [60], gold: [400], icon: 'helper', eff: '打光了自动买' });
  // 火上浇冰
  add({ id: 'volcano.n', where: 'volcano', up: 'n', name: '亮洞', tixId: 'volcano', tix: ramp(1, 1.5, 5), vals: step(1, 5, 2), tag: '签', eff: '多亮 {d} 个洞' });
  add({ id: 'volcano.v', where: 'volcano', up: 'v', name: '洞价', pre: ['volcano.n'], tixId: 'volcano', tix: ramp(1, 1.4, 8), gold: ramp(15, 1.5, 8), vals: step(1, 8, 1), tag: '价', eff: '一洞多 {d} 张券' });
  add({ id: 'volcano.s', where: 'volcano', up: 's', name: '填坑', pre: ['volcano.v'], tixId: 'volcano', tix: [4, 10], vals: [3, 2, 1], tag: '速', eff: '填坑少要 {d} 颗' });
  add({ id: 'volcano.cheap', where: 'volcano', kind: 'cheap', name: '降价', pre: ['volcano.s'], tixId: 'volcano', tix: ramp(2, 1.35, 10), vals: CHEAP, icon: 'gold', eff: '一盒便宜 8%' });
  add({ id: 'volcano.helper', where: 'volcano', kind: 'helper', name: '小人', pre: ['volcano.cheap'], tixId: 'volcano', tix: [20], gold: [200], icon: 'helper', eff: '雇小人帮你打' });
  add({ id: 'volcano.auto', where: 'volcano', kind: 'auto', name: '自动买弹珠', pre: ['volcano.helper'], preMax: ['volcano.cheap'], tixId: 'volcano', tix: [60], gold: [800], icon: 'helper', eff: '打光了自动买' });
  // 弹无虚发（第一阶段只上桌、能开，里头先这三样）
  add({ id: 'ring.n', where: 'ring', up: 'n', name: '补珠', tixId: 'ring', tix: ramp(2, 1.6, 3), vals: [2, 3, 4, 5], tag: '签', eff: '换母珠多补 {d} 颗' });
  add({ id: 'ring.v', where: 'ring', up: 'v', name: '珠价', pre: ['ring.n'], tixId: 'ring', tix: ramp(2, 1.6, 4), vals: [1, 2, 3, 5, 8], tag: '价', eff: '一颗多 {d} 张券' });
  add({ id: 'ring.a', where: 'ring', up: 'a', name: '瞄准线', pre: ['ring.v'], tixId: 'ring', tix: [5, 12], vals: [1, 2, 3], tag: '准', eff: '瞄准线长一截' });
  add({ id: 'ring.cheap', where: 'ring', kind: 'cheap', name: '降价', pre: ['ring.v'], tixId: 'ring', tix: ramp(2, 1.35, 10), vals: CHEAP, icon: 'gold', eff: '一盒便宜 8%' });

  // 后九台（11-11 粗做，价先填）：ups 是这台的几样（k 是台子里 env.val(k) 那个键），G 是这台一盒的金币价，后面几样照它配
  const LATE_MINI = {
    ice: [{ k: 'n', tag: '签', name: '亮洞', vals: step(1, 4, 2), eff: '多亮 {d} 个洞' }, { k: 'v', tag: '价', name: '洞价', vals: step(1, 8, 1), eff: '一洞多 {d} 张券' },
      { k: 'h', tag: '速', name: '冰脆', vals: [3, 2, 1], eff: '少砸 {d} 下就碎' }, { k: 'k', tag: '救', name: '冻得多', vals: [1, 2, 3], eff: '一块多冻 {d} 颗' }],
    hen: [{ k: 'n', tag: '签', name: '窝大', vals: step(1, 6, 3), eff: '窝里多攒 {d} 个蛋' }, { k: 'v', tag: '价', name: '蛋价', vals: step(1, 8, 1), eff: '一个蛋多 {d} 张券' },
      { k: 's', tag: '速', name: '母鸡急', vals: [5, 4, 3, 2], eff: '少惹 {d} 下就飞' }],
    bowl: [{ k: 'v', tag: '价', name: '瓶价', vals: step(1, 8, 1), eff: '一个瓶多 {d} 张券' }, { k: 'g', tag: '签', name: '金瓶', vals: [0, 1, 2, 3], eff: '每局多 {d} 个金瓶' },
      { k: 'a', tag: '准', name: '瞄准线', vals: [1, 2, 3], eff: '瞄准线长一截' }, { k: 'r', tag: '救', name: '护栏', vals: [0, 1, 2], eff: '多 {d} 球有护栏' }],
    snow: [{ k: 'n', tag: '签', name: '补雪', vals: step(1, 4, 1), eff: '一发多补 {d} 个' }, { k: 'v', tag: '价', name: '雪价', vals: step(1, 8, 1), eff: '一个雪球多 {d} 张券' }],
    fish: [{ k: 'b', tag: '签', name: '鱼多', vals: step(0.1, 4, 0.3), pct: true, eff: '咬钩几率多 {d}%' }, { k: 'v', tag: '价', name: '鱼价', vals: step(1, 8, 1), eff: '一条鱼多 {d} 张券' },
      { k: 'a', tag: '准', name: '收竿', vals: [0.6, 0.8, 1, 1.2], eff: '浮漂沉得久一点' }],
    soccer: [{ k: 'n', tag: '签', name: '补球', vals: step(1, 4, 1), eff: '一脚多补 {d} 个球' }, { k: 'v', tag: '价', name: '洞价', vals: step(1, 8, 1), eff: '一洞多 {d} 张券' }],
    coin: [{ k: 'n', tag: '签', name: '滚币', vals: step(1, 5, 1), eff: '一发多滚进 {d} 枚' }, { k: 'v', tag: '价', name: '币价', vals: step(1, 8, 1), eff: '一枚多 {d} 张券' },
      { k: 'g', tag: '品', name: '金币', vals: step(0.05, 4, 0.05), pct: true, eff: '金的多 {d}%' }],
    circus: [{ k: 'v', tag: '价', name: '洞价', vals: step(1, 8, 1), eff: '一洞多 {d} 张券' }, { k: 's', tag: '速', name: '谢幕', vals: [6, 5, 4, 3], eff: '少顶 {d} 下就谢幕' },
      { k: 'n', tag: '救', name: '抛球', vals: step(1, 3, 2), eff: '谢幕多抛 {d} 个' }],
    pool: [{ k: 'n', tag: '签', name: '补球', vals: step(1, 4, 1), eff: '一杆多滚进 {d} 颗' }, { k: 'v', tag: '价', name: '球价', vals: step(1, 8, 1), eff: '一颗多 {d} 张券' }],
  };
  const LATE_BOX = { ice: 2e4, hen: 6e4, bowl: 2e5, snow: 8e5, fish: 3e6, soccer: 1e7, coin: 3e7, circus: 1e8, pool: 3e8 };
  for (const id of Object.keys(LATE_MINI)) {
    const G = LATE_BOX[id], ups = LATE_MINI[id];
    let prev = null;
    ups.forEach((u, i) => {
      const n = u.vals.length - 1, nid = id + '.' + u.k;
      add({ id: nid, where: id, up: u.k, name: u.name, tixId: id, pre: prev ? [prev] : [], tix: ramp(2 + i, 1.45, n), gold: i ? ramp(G * 0.05, 1.45, n) : null, vals: u.vals, pct: u.pct, tag: u.tag, eff: u.eff });
      prev = nid;
    });
    add({ id: id + '.cheap', where: id, kind: 'cheap', name: '降价', pre: [prev], tixId: id, tix: ramp(2, 1.35, 10), vals: CHEAP, icon: 'gold', eff: '一盒便宜 8%' });
    add({ id: id + '.helper', where: id, kind: 'helper', name: '小人', pre: [id + '.cheap'], tixId: id, tix: [20], gold: [G * 0.3], icon: 'helper', eff: '雇小人帮你打' });
    add({ id: id + '.auto', where: id, kind: 'auto', name: '自动买弹珠', pre: [id + '.helper'], preMax: [id + '.cheap'], tixId: id, tix: [60], gold: [G], icon: 'helper', eff: '打光了自动买' });
  }

  // ---------- 桌上的小游戏（第一阶段：一骨作气、火上浇冰、弹无虚发；跟着节点上桌） ----------
  const MINIS = [
    { id: 'dog', name: '一骨作气', tix: '骨头券', box: 10, boxPrice: 5, slot: 'L1', call: 'dogOpen', bot: { sec: 6 } },
    { id: 'volcano', name: '火上浇冰', tix: '火山券', box: 10, boxPrice: 30, slot: 'R1', call: 'volcanoOpen', bot: { sec: 8 } },
    { id: 'ring', name: '弹无虚发', tix: '母珠券', box: 10, boxPrice: 3000, slot: 'L2', call: 'ringOpen', bot: { sec: 8 }, chain: 0.5 },
    // 后九台（11-11 粗做）：台位挨着绒布那一列先排满，再往外
    { id: 'ice', name: '冰消瓦解', tix: '冰块券', box: 10, boxPrice: LATE_BOX.ice, slot: 'R2', call: 'iceOpen', bot: { sec: 8 } },
    { id: 'hen', name: '鸡飞蛋打', tix: '鸡蛋券', box: 10, boxPrice: LATE_BOX.hen, slot: 'L3', call: 'henOpen', bot: { sec: 8 } },
    { id: 'bowl', name: '东倒西歪', tix: '球瓶券', box: 6, boxPrice: LATE_BOX.bowl, slot: 'R3', call: 'bowlOpen', bot: { sec: 10 } },
    { id: 'snow', name: '越滚越大', tix: '雪球券', box: 10, boxPrice: LATE_BOX.snow, slot: 'L4', call: 'snowOpen', bot: { sec: 8 } },
    { id: 'fish', name: '愿者上钩', tix: '鱼钩券', box: 10, boxPrice: LATE_BOX.fish, slot: 'R4', call: 'fishOpen', bot: { sec: 8 } },
    { id: 'soccer', name: '临门一脚', tix: '足球券', box: 10, boxPrice: LATE_BOX.soccer, slot: 'L5', call: 'soccerOpen', bot: { sec: 8 } },
    { id: 'coin', name: '推陈出新', tix: '铜钱券', box: 10, boxPrice: LATE_BOX.coin, slot: 'R5', call: 'coinOpen', bot: { sec: 8 } },
    { id: 'circus', name: '接二连三', tix: '马戏券', box: 10, boxPrice: LATE_BOX.circus, slot: 'L6', call: 'circusOpen', bot: { sec: 8 } },
    { id: 'pool', name: '落袋为安', tix: '台球券', box: 10, boxPrice: LATE_BOX.pool, slot: 'R6', call: 'poolOpen', bot: { sec: 8 } },
  ];

  // ---------- 电话：只讲玩家自己悟不出来的——开场、挡板怎么拍、每台小游戏第一次开台、转生。台上不再写提示 ----------
  const CALLS = {
    opening: { lines: ['喂？我是桃败俗。', '史莱姆闹灾了，帮我砸干净。', '按住拉弹簧，松手打出去。', '砸碎一只，给你一枚金币。'] },
    flipKeys: { lines: ['挡板装好了。', '左键（或 Z）拍左边，右键（或 M）拍右边。'] },
    dogOpen: { lines: ['这台叫一骨作气。', '点一下抽骨头，拉弹簧打进有骨头的洞。', '中了吐骨头券，拿回斩草除根买东西。'] },
    volcanoOpen: { lines: ['这台叫火上浇冰，打进亮洞吐火山券。', '三个岩浆坑填满，火山喷发，一颗吐三倍。', '火山券换火山弹，砸得开蜗牛壳。'] },
    ringOpen: { lines: ['这台叫弹无虚发。', '往后拉，松手弹母珠，把珠子撞出圈。'] },
    prestige: { lines: ['打不过很正常。', '回去重来，我给你带点好东西。', '桌上那个闹钟看看。'] },
    // 第一次见草地大王就打掉了的（少见）：转生按钮在这一轮收工的时候开
    prestigeWin: { lines: ['草地大王都打掉了，行啊。', '回去重来，我给你带点好东西。', '桌上那个闹钟看看。'] },
    iceOpen: { lines: ['这台叫冰消瓦解。', '拉弹簧打铁珠，砸碎冰块放出冻住的珠子。', '珠子落进亮洞吐冰块券，换铁母珠。'] },
    henOpen: { lines: ['这台叫鸡飞蛋打。', '打中母鸡惹她，惹够了她飞起来，窝里的蛋滚出来。', '蛋落进亮洞吐鸡蛋券，换蛋。'] },
    bowlOpen: { lines: ['这台叫东倒西歪。', '在球上按住往后拉，松手滚出去。', '瓶子滚进后面的坑吐球瓶券，换保龄球。'] },
    snowOpen: { lines: ['这台叫越滚越大。', '往后拉弹一个雪球，一样大的碰上粘成大一号。', '推下台边的吐雪球券，换雪球。'] },
    fishOpen: { lines: ['这台叫愿者上钩。', '拉弹簧把饵打进塘里，浮漂一沉就点一下收竿。', '钓上来吐鱼钩券，换鱼钩。'] },
    soccerOpen: { lines: ['这台叫临门一脚。', '往后拉、松手踢，踢进门上亮着的洞。', '进了吐足球券，换足球。'] },
    coinOpen: { lines: ['这台叫推陈出新。', '往后拉弹一枚硬币，推板把台边的推下去。', '掉下去的吐铜钱券，换一摞硬币。'] },
    circusOpen: { lines: ['这台叫接二连三。', '海豹顶一下倍数加一，落进中奖洞才算。', '吐马戏券，换橡胶珠。'] },
    poolOpen: { lines: ['这台叫落袋为安。', '往后拉打母球；母球没进袋，下一杆不花钱。', '进袋吐台球券，换台球。'] },
    // 第一次带一套新打法的珠子上台
    setFlick: { lines: ['大母珠不走弹簧，是弹的。', '在台上按住往后拉，松手弹出去，停在哪下一杆就从哪打。', '弹一杆掉一下耐久。'] },
    setBowl: { lines: ['保龄球从台底滚。', '按住往后拉定方向，松手滚上去，滚到台顶就收。'] },
    setKick: { lines: ['足球是踢的。', '按住往后拉，松手踢出去，在史莱姆中间乱弹。', '一脚掉一下耐久，踢进台顶的门退回一下。'] },
    // 作者来电（11-11）：火山弹打掉第一个新 boss（大蜗牛）。挂了以后送扳手（右上角，随时开开发者面板）、转生开了、弹无虚发上桌
    creator: { lines: ['火山弹把大蜗牛烧穿了，漂亮。', '跟你说句实话。', '我只来得及打磨前三关：', '斩草除根、一骨作气、火上浇冰。',
      '后面的关卡都是换皮，', '机制屎，数值还臭。', '我已经没时间打磨了。', '可我还是想让评委玩到完整的游戏，', '所以送你一个神秘妙妙工具：',
      '右上角那把扳手，随时打开开发者工具。', '我做了不同材质的弹珠、', '不同的击发方式，', '解锁弹珠的小游戏也做了一整排。', '以后想让每个环节都简单好玩。',
      '桌上的闹钟也能转生了。', '剩下的，随便玩吧。'] },
    night: { lines: ['史莱姆王打掉了！', '钻到地球另一边了，这边是夜里。', '夜里的史莱姆硬得多。树上长出了夜那一段。'] },
  };

  // ---------- 转生树（第一批 8 条；照刮个爽：一次性的开东西，能升级的加数，转很多次慢慢买完） ----------
  //   单独一屏（右上角"转生"）。老手是根（第一次转生白送），底下三枝：金币（起步金币 → 金光）、弹珠（大袋子 → 厚玻璃）、小游戏（开台打折 → 奖券多 → 小人快）
  //   pos：第几列（0～2）、第几行（0～3）；pre：前面那样买过一级才能买；icon 用节点的图标（cloth 红布、ticket 骨头券）
  const PERKS = [
    { id: 'elder', name: '老手', icon: 'dmg', pos: [1, 0], costs: [0], free: true, eff: '每种弹珠力道翻倍', how: '第一次转生白送' },
    { id: 'seed', name: '起步金币', icon: 'gold', pos: [0, 1], pre: ['elder'], costs: [2, 6, 18], vals: [0, 30, 150, 800], eff: '每一世开头先给一笔金币' },
    { id: 'shine', name: '金光', icon: 'goldSlime', pos: [0, 2], pre: ['seed'], costs: [6, 18, 54], vals: [0, 1, 2, 3], eff: '金史莱姆多 1%' },
    { id: 'bigBag', name: '大袋子', icon: 'bag', pos: [1, 1], pre: ['elder'], costs: [3, 9, 27], vals: [0, 1, 2, 3], eff: '每种弹珠多带 1 颗' },
    { id: 'thick', name: '厚玻璃', icon: 'glass', pos: [1, 2], pre: ['bigBag'], costs: [3, 9, 27], vals: [0, 1, 2, 3], eff: '每种弹珠多撞 1 下才碎' },
    { id: 'regular', name: '开台打折', icon: 'cloth', pos: [2, 1], pre: ['elder'], costs: [4, 12, 36], vals: [1, 0.8, 0.64, 0.5], eff: '小游戏一盒弹珠便宜两成' },
    { id: 'tickets', name: '奖券多', icon: 'ticket', pos: [2, 2], pre: ['regular'], costs: [4, 12, 36, 100], vals: [1, 1.25, 1.5, 1.75, 2], eff: '小游戏吐的券多 25%' },
    { id: 'quick', name: '小人快', icon: 'helper', pos: [2, 3], pre: ['tickets'], costs: [5, 15, 45, 120], vals: [1, 1.25, 1.5, 1.75, 2], eff: '小人打得快 25%' },
  ];
  // 全局的小人速率（花金币）
  const HELPER_SPEED = { vals: [1, 1.3, 1.6, 2, 2.5, 3], costs: [500, 1500, 4000, 10000, 25000] };

  return { ramp, step, LATE, LATE_ST, LATE_MINI, MINI_TIX, NIGHT, STAGES, SLIMES, SIZES, BOSSES, MARBLES, BALLS, WEAR, RAIL_WEAR, FLIP, SPIKE, FIRE, REVIVE, GROUPS, GROUP_ORDER, CATS, NODES, MINIS, CALLS, PERKS, HELPER_SPEED };
}));
