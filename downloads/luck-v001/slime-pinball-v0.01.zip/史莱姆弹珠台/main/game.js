/*
 * 主线的壳（照《史莱姆主线 · 执行方案 v3》）：桌子、电话、拿起放下、两边栏、存档、暂停、开发者面板，还有桌上的小游戏。
 *   一轮的规矩在 main/run.js，存档和算数在 main/rules.js，条目在 main/data.js，台子的画在 main/art.js，桌子在 main/desk.js，栏的画法在 main/ui.js。
 *   小游戏的打法照十八台那版（machines/*.js），这里给它们一个 env：弹珠、奖券、宝贝记在主线存档的 S.mini[id]，升级是节点（S.tree 里 'dog.n' 这种）。
 *   画面两种：
 *     桌子（desk）：整张桌子一倍铺满整屏，不出两边栏；斩草除根 2 倍摆在正中，小游戏一台一个展台（名牌底下堆着这台的券）。
 *       点一台拿起来；盖着红布的点一下开台（开台就是买第一盒弹珠，价签上写着）。
 *       桌上的东西有了才摆，点了单开一页（游戏停住）：柜台（弹珠，一种一页）、金币罐（金币那几样）、打卡钟（小人）、闹钟（转生树）；电话在柜台右边。
 *     机台（card）：拿起的那台放正中（镜头从桌上推近）。左上角"回桌上"；电话响的时候换成"接电话"。
 *   开场（新存档）：空桌子上一块绒布，电话响 → 接起来听桃败俗说 → 斩草除根落到绒布上 → 镜头推近 → 装上拉杆 → 第一颗弹珠。
 *   电话：只讲玩家自己悟不出来的（data.js 的 CALLS：开场、挡板怎么拍、每台小游戏第一次开台、转生）。排着队，台上没有弹珠在跑才响；
 *     接起来整个游戏停住，点一下说下一句。台上、卡底下不再写提示字。
 *   两边栏只在机台里（挣到第一枚金币以后）：
 *     左边：钱箱，一种钱一行，一行也是去那台的按钮（金币是斩草除根的，一种券是一台的）：现在这台黄边，那台有买得起的亮绿点，
 *           最底下挂着上了桌还没开的那台（开台价 + 进度条）。底下一排桌上那几件的小图标（柜台、金币、小人），点了开同一页，镜头不动。
 *     右边：场景（顶上一排小页签：草地、菜园，有东西买的亮绿点），底下只列这一类（复活另起小标题；买满的收进"买满了"）；
 *           斩草除根还没有场景的东西就不出。拿着小游戏换成这台的：一盒弹珠（金币）、这台的节点。
 *     换弹珠：手上不止一种，斩草除根卡的左上角一排小按钮，一种球一个（挑着的黄边；打到一半换的下一轮才上）。
 *     一行两行字那么高：不写名字，一句话就是这个节点（"多带 1 颗弹珠"），别的是像素图标 + 数（价钱、几级）。
 *     价：金币、这台的券，或者金币 + 一种券，不够的那一半标红。按住一行连着买。
 *   转生树：单独一屏，桌上的闹钟打开（能转生才摆上）；老手是根，底下三枝，前面那样买过一级才能买。
 *   键：空格 按住拉弹簧、松手发球；Z / ← 拍左挡板，M / → 拍右挡板；鼠标左键左、右键右；R 重来（买了以后）。
 *       Tab 照钱箱的顺序换台；Esc 暂停；` 或 F2 开发者面板。
 *   地址参数：?reset 清档  ?auto 自动手打  ?nointro 跳过开场  ?demo=名字 截图（test/main_demo.js）
 */
(() => {
  'use strict';
  const q = new URLSearchParams(location.search);
  const W = 640, H = 360, A = Art, D = MainData, R = MainRules, MA = MainArt, MD = MainDesk, U = MainUI, P = MainLine, FX = MainFX, INK = A.INK, GOLD = A.GOLD;
  const R18 = Rules;
  const TEST = q.has('demo') || q.has('selftest');
  const cv = document.getElementById('v'), screenCtx = cv.getContext('2d');
  const base = document.createElement('canvas'); base.width = W; base.height = H;
  const baseCtx = base.getContext('2d');
  // 斩草除根推近的时候分三层上屏：底下（桌子）→ 台面那一层（关卡底图 + 史莱姆，屏幕真分辨率，见 drawWorld）→ 上面（卡框、导轨、挡板、弹珠、两边栏）
  const over = document.createElement('canvas'); over.width = W; over.height = H;
  const octx = over.getContext('2d');
  let ctx = baseCtx, worldPass = null;
  const mainBuf = document.createElement('canvas'); mainBuf.width = W; mainBuf.height = H;
  const mctx = mainBuf.getContext('2d');
  const STORE = 'slime-main-v4', PREFS = 'slime-main-prefs';
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const ease = t => 1 - Math.pow(1 - clamp(t, 0, 1), 3);
  const easeIO = t => { t = clamp(t, 0, 1); return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; };
  const lerp = (a, b, t) => a + (b - a) * t;
  const C = { text: '#fff3d8', dim: '#c8a8a0', gold: '#ffe680', red: '#ff8a7a', green: '#a8f07a', blue: '#9ad0ff', gray: '#8a7a80' };
  const LEFT = { x: 4, y: 4, w: 116 }, RIGHT = { x: 520, y: 4, w: 116 }, BACK = { x: 4, y: 4, w: 116, h: 24 };
  const MAIN_NAME = '斩草除根';
  const nameOf = id => (id === 'main' ? MAIN_NAME : R.MBY[id].name);

  // ---------- 存档 ----------
  const store = {
    get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
    set(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* 存不了就算了 */ } },
    del(k) { try { localStorage.removeItem(k); } catch (e) { /* 同上 */ } },
  };
  if (q.has('reset') || TEST) store.del(STORE);
  const S = R.load(store.get(STORE)) || R.newSave();
  const prefs = (() => { try { return Object.assign({ sound: true }, JSON.parse(store.get(PREFS) || '{}')); } catch (e) { return { sound: true }; } })();
  if (TEST) prefs.sound = false;
  const savePrefs = () => { if (!TEST) store.set(PREFS, JSON.stringify(prefs)); };
  let saveIn = -1, wiping = false;
  const save = () => { if (saveIn < 0) saveIn = 0.5; };
  const flushSave = () => { if (wiping) return; saveIn = -1; S.savedAt = Date.now(); store.set(STORE, JSON.stringify(S)); };
  window.addEventListener('pagehide', flushSave);
  window.addEventListener('beforeunload', flushSave);

  // =========================================================================
  // 声音（现场合成）。sfxM 给小游戏用（十八台那一套），sfx 是主线的
  // =========================================================================
  let ac = null, out = null, noiseBuf = null;
  function audio() { if (!prefs.sound || !ac) return null; if (ac.state === 'suspended') ac.resume(); return ac; }
  function unlockAudio() {
    if (!prefs.sound) return;
    if (!ac) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      ac = new AC();
      out = ac.createGain(); out.gain.value = 0.5;
      const comp = ac.createDynamicsCompressor(); out.connect(comp); comp.connect(ac.destination);
      noiseBuf = ac.createBuffer(1, ac.sampleRate, ac.sampleRate);
      const d = noiseBuf.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    }
    if (ac.state === 'suspended') ac.resume();
  }
  function tone(f0, f1, dur, type, vol, delay) {
    const a = audio(); if (!a || a.state !== 'running') return;
    const t = a.currentTime + (delay || 0), o = a.createOscillator(), gn = a.createGain();
    o.type = type; o.frequency.setValueAtTime(f0, t);
    if (f1 !== f0) o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    gn.gain.setValueAtTime(0.0001, t); gn.gain.exponentialRampToValueAtTime(Math.max(0.0002, vol), t + 0.005); gn.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(gn); gn.connect(out); o.start(t); o.stop(t + dur + 0.02);
  }
  function noise(dur, type, freq, qq, vol, delay) {
    const a = audio(); if (!a || a.state !== 'running') return;
    const t = a.currentTime + (delay || 0), src = a.createBufferSource(), f = a.createBiquadFilter(), gn = a.createGain();
    src.buffer = noiseBuf; f.type = type; f.frequency.value = freq; f.Q.value = qq;
    gn.gain.setValueAtTime(Math.max(0.0002, vol), t); gn.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f); f.connect(gn); gn.connect(out); src.start(t, Math.random() * 0.5); src.stop(t + dur + 0.02);
  }
  const lastSfx = {};
  const gate = (k, gap) => { if (!ac) return false; const t = ac.currentTime; if (lastSfx[k] && t - lastSfx[k] < gap) return false; lastSfx[k] = t; return true; };
  const semi = n => Math.pow(2, n / 12);
  const imp = v => v * 4.8;
  const sfxBase = {
    ratchet(p) { tone(420 + 520 * p, 380 + 480 * p, 0.03, 'square', 0.035); },
    launch(p) { noise(0.09, 'lowpass', 1600 + 1600 * p, 0.8, 0.25 + 0.3 * p); tone(200, 70, 0.14, 'sine', 0.3 + 0.3 * p); },
    pin(i, id) { if (gate('pin', 0.018)) tone(1800 + ((id || 0) * 53) % 900, 1650, 0.045, 'triangle', clamp(imp(i) / 3500, 0.03, 0.15)); },
    bump(i) { if (gate('bump', 0.03)) tone(640, 420, 0.07, 'sine', clamp(imp(i) / 3500, 0.05, 0.18)); },
    rim(i) { if (gate('rim', 0.04)) noise(0.035, 'bandpass', 2600, 2.5, clamp(imp(i) / 9000, 0.02, 0.07)); },
    wall(i) { if (gate('wall', 0.03)) noise(0.04, 'lowpass', 900, 1, clamp(imp(i) / 4500, 0.03, 0.14)); },
    settle(k) { [0, 4, 7, 12, 16].slice(0, Math.min(5, 1 + Math.ceil(k / 2))).forEach((n, i) => tone(784 * semi(n), 784 * semi(n), 0.16, 'triangle', 0.09, i * 0.035)); },
    win() { [0, 4, 7, 12].forEach((n, i) => tone(660 * semi(n), 660 * semi(n), 0.22, 'triangle', 0.16, i * 0.06)); noise(0.25, 'highpass', 5000, 0.7, 0.08, 0.05); },
    woof() { tone(330, 180, 0.12, 'sawtooth', 0.12); tone(300, 160, 0.1, 'square', 0.06, 0.13); },
    clink() { if (gate('clink', 0.03)) tone(2600 + Math.random() * 1000, 2300, 0.05, 'sine', 0.06); },
    miss() { tone(190, 110, 0.18, 'sine', 0.2); noise(0.07, 'lowpass', 420, 1, 0.12); },
    fallback() { tone(320, 150, 0.22, 'triangle', 0.12); },
    upgrade() { tone(440, 880, 0.16, 'square', 0.06); tone(660, 1320, 0.2, 'sine', 0.08, 0.05); },
    buy() { tone(1320, 1320, 0.05, 'square', 0.05); tone(1760, 1760, 0.08, 'triangle', 0.06, 0.05); },
    deny() { tone(160, 120, 0.12, 'square', 0.08); },
    lift() { noise(0.12, 'bandpass', 900, 1.2, 0.06); },
    tab() { tone(900, 900, 0.03, 'square', 0.04); },
    maxed() { [0, 4, 7, 12, 16, 19, 24].forEach((n, i) => tone(523 * semi(n), 523 * semi(n), 0.35, 'triangle', 0.14, i * 0.07)); noise(0.5, 'highpass', 4000, 0.6, 0.1, 0.3); },
    flip() { if (gate('flip', 0.04)) { noise(0.03, 'bandpass', 1800, 1.5, 0.08); tone(240, 140, 0.05, 'square', 0.05); } },
    splat(k) { if (gate('splat', 0.02)) { const s = semi(Math.min(k - 1, 10) * 1.5); tone(500 * s, 980 * s, 0.09, 'triangle', 0.13); noise(0.08, 'highpass', 3000, 0.8, 0.06 + 0.006 * Math.min(k, 8)); } },
    slime(i) { if (gate('slime', 0.03)) { tone(320, 170, 0.09, 'sine', clamp(i / 600, 0.06, 0.18)); noise(0.05, 'lowpass', 700, 1, 0.06); } },
    pop() { if (gate('pop', 0.02)) { tone(500, 980, 0.09, 'triangle', 0.13); noise(0.08, 'highpass', 3000, 0.8, 0.06); } },
    sling() { if (gate('sling', 0.05)) tone(880, 520, 0.06, 'square', 0.06); },
    clack(i) { if (gate('clack', 0.015)) tone(2400 + Math.random() * 400, 2000, 0.03, 'triangle', clamp(i / 1200, 0.03, 0.14)); },
    pinHit(i) { if (gate('pinHit', 0.02)) { noise(0.06, 'bandpass', 1300, 2, clamp(i / 900, 0.04, 0.2)); tone(950, 620, 0.05, 'triangle', clamp(i / 2000, 0.02, 0.08)); } },
    roll() { noise(0.5, 'lowpass', 260, 1, 0.08); },
    stone() { tone(210, 120, 0.12, 'sine', 0.16); noise(0.08, 'lowpass', 800, 1, 0.08); },
    sizzle() { noise(0.35, 'highpass', 3800, 0.7, 0.07, 0.04); },
    crack(i) { if (gate('crack', 0.03)) { noise(0.06, 'highpass', 2600, 1.2, clamp(i / 900, 0.05, 0.14)); tone(1400, 900, 0.05, 'square', 0.04); } },
    shatter() { noise(0.18, 'highpass', 3200, 0.7, 0.16); for (let k = 0; k < 3; k++) tone(2200 + k * 700 + Math.random() * 300, 1800, 0.08 + k * 0.03, 'triangle', 0.06); },
    rumble() { tone(70, 50, 0.7, 'sawtooth', 0.08); noise(0.7, 'lowpass', 200, 1, 0.12); },
    erupt() { tone(110, 40, 0.7, 'sawtooth', 0.16); noise(0.6, 'lowpass', 500, 1, 0.22); noise(0.4, 'highpass', 3000, 0.6, 0.05, 0.1); },
    strike() { noise(0.45, 'bandpass', 1400, 0.8, 0.18); [0, 4, 7, 12].forEach((n, i) => tone(523 * semi(n), 523 * semi(n), 0.2, 'triangle', 0.1, 0.1 + i * 0.05)); },
    jackpot() { [0, 4, 7, 12, 7, 12, 16, 19, 24].forEach((n, i) => tone(523 * semi(n), 523 * semi(n), 0.25, 'square', 0.07, i * 0.07)); noise(0.6, 'highpass', 5000, 0.6, 0.1, 0.4); },
    find() { [12, 16, 19, 24, 28].forEach((n, i) => tone(523 * semi(n), 523 * semi(n), 0.18, 'triangle', 0.1, i * 0.05)); },
    layer() { [0, 5, 9].forEach((n, i) => tone(440 * semi(n), 440 * semi(n), 0.14, 'square', 0.06, i * 0.06)); },
    coin() { if (gate('coin', 0.05)) tone(2200, 2000, 0.04, 'sine', 0.025); },
    tix() { if (gate('tix', 0.06)) tone(1500, 1800, 0.035, 'square', 0.012); },
    open() { [0, 4, 7, 12, 16].forEach((n, i) => tone(392 * semi(n), 392 * semi(n), 0.25, 'triangle', 0.12, i * 0.06)); },
  };
  const sfx = Object.assign({}, sfxBase, {
    crit() { tone(1200, 400, 0.08, 'square', 0.1); noise(0.06, 'highpass', 2500, 1, 0.12); },
    ding() { if (gate('ding', 0.05)) { tone(1900, 1900, 0.18, 'triangle', 0.12); tone(2850, 2850, 0.12, 'sine', 0.05); } },
    boom() { tone(90, 35, 0.8, 'sawtooth', 0.2); noise(0.7, 'lowpass', 600, 1, 0.3); noise(0.3, 'highpass', 3000, 0.7, 0.08, 0.05); },
    hop() { if (gate('jump', 0.2)) tone(140, 260, 0.18, 'sine', 0.12); },
    spit() { tone(600, 300, 0.1, 'sine', 0.1); noise(0.06, 'lowpass', 900, 1, 0.08); },
    thud() { tone(80, 40, 0.25, 'sine', 0.3); noise(0.2, 'lowpass', 300, 1, 0.2); },
    snap() { noise(0.12, 'bandpass', 1500, 2, 0.2); tone(500, 120, 0.15, 'square', 0.08); },
    crack2() { noise(0.4, 'highpass', 1800, 0.8, 0.2); tone(300, 60, 0.4, 'sawtooth', 0.1); },
    stage() { [0, 4, 7, 12, 16, 19].forEach((n, i) => tone(392 * semi(n), 392 * semi(n), 0.3, 'triangle', 0.12, 0.1 + i * 0.07)); },
    plunger() { tone(180, 90, 0.18, 'square', 0.1); noise(0.1, 'lowpass', 600, 1, 0.15); tone(1200, 1200, 0.06, 'triangle', 0.06, 0.12); },
    part() { [0, 7, 12].forEach((n, i) => tone(660 * semi(n), 660 * semi(n), 0.14, 'square', 0.06, i * 0.05)); noise(0.15, 'highpass', 4000, 0.6, 0.06, 0.1); },
    split() { if (gate('split', 0.04)) { tone(420, 260, 0.1, 'sine', 0.14); noise(0.07, 'lowpass', 900, 1, 0.08); } },
    usedUp() { tone(700, 1100, 0.08, 'triangle', 0.06); tone(1100, 1100, 0.1, 'triangle', 0.05, 0.08); },
    restart() { tone(300, 900, 0.22, 'square', 0.05); noise(0.15, 'highpass', 2500, 0.7, 0.05); },
    reveal() { [12, 19, 24].forEach((n, i) => tone(523 * semi(n), 523 * semi(n), 0.14, 'triangle', 0.08, i * 0.05)); },
    // 电话：老式座机的铃（两个音快速来回），接起来"咔"，挂上"咚"，说话一个字一下"嘀"
    ring() { for (let k = 0; k < 6; k++) { tone(1320, 1320, 0.045, 'square', 0.045, k * 0.09); tone(1660, 1660, 0.045, 'square', 0.035, k * 0.09 + 0.045); } },
    pickup() { noise(0.05, 'bandpass', 1200, 1.5, 0.12); tone(300, 200, 0.06, 'square', 0.05); },
    hangup() { tone(220, 110, 0.12, 'square', 0.08); noise(0.08, 'lowpass', 600, 1, 0.12); },
    talk() { if (gate('talk', 0.05)) tone(520 + Math.random() * 160, 480, 0.035, 'square', 0.03); },
    freeze() { noise(0.3, 'highpass', 4200, 0.7, 0.08); tone(1800, 2400, 0.12, 'sine', 0.05); },
  });
  const sfxM = Object.assign({}, sfxBase, { hop(i) { if (gate('hop', 0.02)) tone(1100 + i * 35, 1100 + i * 35, 0.028, 'square', 0.045); } });
  function toggleSound() { prefs.sound = !prefs.sound; savePrefs(); if (!prefs.sound && ac) ac.suspend(); if (prefs.sound) { unlockAudio(); sfx.tab(); } }

  // =========================================================================
  // 画面状态
  // =========================================================================
  const ui = {
    time: 0, mouse: { x: -1, y: -1 }, hover: null,
    view: 'card', cur: 'main', tr: null,
    intro: null, plungerIn: 1, call: null, ringT: 0, confirm: null, opening: null,
    camZ: 1, slideL: 0, slideR: 0, backIn: 0, ptree: false, ppFlash: 0, cat: null, scrollL: 0, scrollR: 0, maxL: 0, maxR: 0, showMax: false,
    page: null, shopCat: null, scrollS: 0, maxS: 0,   // 桌上那几件打开的那一页（shop 柜台 / jar 金币罐 / clock 打卡钟）
    coins: [], parts: [], labels: [], pops: [], toasts: [], flying: 0, shake: 0,
    money: [], tixFly: {},   // 钱飞（花出去的金币和券、吐出来的券）；tixFly：每种券还在路上的张数（钱箱先不加）
    paused: false, dev: false, devFlash: 0, devStage: 0, speed: 1, stageOpen: false, hold: null, burst: null, layerFlash: 0, layerFlip: 0, stageFlash: 0, flash: {}, deny: null,
    laneFlash: { L: 0, R: 0 }, slingFlash: { L: 0, R: 0 }, partFlash: null, auto: q.has('auto'), bossIn: 0, chipFlash: 0, deskFlash: 0, trickleT: 0,
    rep: null,   // 按住一行连着买：{ go, t, next }
    press: null, // 刚按下去的那个按钮（键帽落下去）：{ id, t, held }
  };
  const stageKey = n => { const d = R.stage(n) || D.STAGES[0]; return (d.night ? 'night:' : '') + d.k; };
  const FL = window.MainFlat;
  const isFlat = () => run.mode !== 'pin';
  const run = MainRun.create(S, {
    rng: Math.random,
    noise: +(q.get('noise') || 0),
    fx: onFx,
    sfx: (k, a) => { if (k !== 'pop' && sfx[k]) sfx[k](a); },
    save,
    shake: v => { ui.shake = Math.max(ui.shake, v); },
    hold: () => !!ui.call || !!ui.intro || !!ui.confirm || !!ui.ptree || !!ui.page,
  });

  FX.setOnBurst((e, k) => sfx.splat(k));
  function toast(s, c) { ui.toasts.push({ s, c: c || C.text, t: 0 }); if (ui.toasts.length > 3) ui.toasts.shift(); }

  // ---------- 一轮里的事：粒子、飘字、金币飞进钱箱 ----------
  // 钱箱在左上；左上角有按钮（回桌上 / 接电话）的时候往下让一格
  const LAYER_FLIP = 0.3;                      // 过层那块字翻一下多久
  const BOSS_LAG = { hold: 0.35, speed: 0.8 };  // boss 血条：掉的那截白着停多久、一秒缩多少（满血的几成）
  const moneyY = () => Math.round(LEFT.y + (BACK.h + 4) * ease(ui.backIn));
  const GOLD_AT = () => ({ x: LEFT.x + 15 - 124 * (1 - ease(ui.slideL)), y: moneyY() + 12 });
  function burst(x, y, n, speed, cols, up) {
    for (let i = 0; i < n; i++) {
      const a = (i / n) * Math.PI * 2 + Math.random() * 0.5, v = speed * (0.6 + Math.random() * 0.6);
      ui.parts.push({ x: x + Math.cos(a) * 2, y: y + Math.sin(a) * 2, vx: Math.cos(a) * v, vy: Math.sin(a) * v - (up || 30), t: 0, dur: 0.45 + Math.random() * 0.25, c: cols[i % cols.length] });
    }
  }
  // 桌上的粒子（屏幕坐标，nat）
  function burstNat(x, y, n, speed, cols) {
    for (let i = 0; i < n; i++) {
      const a = Math.PI + (i / (n - 1 || 1)) * Math.PI, v = speed * (0.6 + Math.random() * 0.6);
      ui.parts.push({ nat: true, x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v * 0.5, t: 0, dur: 0.4 + Math.random() * 0.2, c: cols[i % cols.length] });
    }
  }
  // 飘字往上飘 10 格：起点压低一点，飘到头也不钻进卡顶的标题、boss 血条底下
  const label = (s, x, y, c, big, wait) => ui.labels.push({ s, x, y: Math.max(y, big ? 22 : 28), t: -(wait || 0), c: c || C.gold, big: !!big });
  // 金币：先等 wait 秒（跟着炸开那一下），在原地往上蹦一下、往两边散开一点，再飞进钱箱
  const COIN_HOP = 0.16, COIN_FLY = 0.5;
  function payCoins(g, x, y, wait) {
    const n = clamp(Math.ceil(g), 1, 6), share = g / n;
    ui.flying += g;
    for (let i = 0; i < n; i++) ui.coins.push({ x0: A.FX(x) + (Math.random() - 0.5) * 6, y0: A.FY(y) + (Math.random() - 0.5) * 6, dx: (n > 1 ? (i / (n - 1) - 0.5) * 2 : 0) * (3 + n) + (Math.random() - 0.5) * 2, hop: 4 + Math.random() * 3, t: -(wait || 0) - i * 0.05, share });
  }
  // ---------- 钱飞 ----------
  //   花出去：金币（券）从钱箱飞到按的那个按钮上，落上去一闪。钱箱那个数买的那一下就减了，钱箱往下一沉
  //   券进来：从那台底座的出票口往上吐出一截，再划一道弧飞进钱箱那台那一行，到了才加数，那一行往上一顶
  //   桌上小人打出来的：从出票口吐出来，蹦到名牌底下那摞券上
  //   walletAt：这一帧钱箱里金币、每种券画在哪（左栏先记；开着页的话页顶上那排盖过去）
  let walletAt = {};
  const SPEND_T = 0.3, TIX_OUT = 0.16, TIX_FLY = 0.42, DESK_TIX = 0.4;
  function spendFly(p, hid, quiet) {
    const h = p && HITS.find(q => q.id === hid);
    if (!h) return;
    const go = (key, img, amount) => {
      const from = walletAt[key];
      if (!from) return;
      const n = quiet ? 1 : clamp(Math.ceil(Math.log10(amount + 1)), 1, 4);
      for (let i = 0; i < n; i++) ui.money.push({ k: 'out', img, x0: from.x, y0: from.y, x1: h.x + h.w - 16 + (Math.random() - 0.5) * 8, y1: h.y + h.h / 2 + (Math.random() - 0.5) * 4, t: -i * 0.05, dur: SPEND_T });
      ui.flash['out:' + key] = ui.time;
    };
    if (p.gold > 0) go('gold', MA.COIN, p.gold);
    if (p.tix > 0) go('t:' + p.tixId, MA.ticket(p.tixId), p.tix);
  }
  // 出票口在屏幕上哪（拿着这台、或者在桌上；别的时候 null）
  function slotAt(id) {
    const cam = ui.tr ? null : ui.view === 'card' && ui.cur === id ? MD.camFor(id) : ui.view === 'desk' ? MD.FULL : null;
    if (!cam) return null;
    const s = MD.slotAt(id), [x, y] = MD.toScreen(cam, s.x, s.y);
    return { x, y };
  }
  function ticketsOut(id, n) {
    const k = clamp(Math.ceil(n), 1, 4), share = n / k;
    ui.tixFly[id] = (ui.tixFly[id] || 0) + n;
    for (let i = 0; i < k; i++) ui.money.push({ k: 'in', id, share, t: -i * 0.08, dur: TIX_OUT + TIX_FLY, dx: Math.round((i - (k - 1) / 2) * 4) });
  }
  function deskTicket(id) {
    const s = MD.slotAt(id), r = MD.deskRect(id);
    ui.money.push({ k: 'desk', id, x0: s.x, y0: s.y, x1: Math.round(r.x + r.w / 2 - 8), y1: r.y + 112, t: 0, dur: DESK_TIX });
  }
  function updateMoney(dt) {
    for (const m of ui.money) {
      m.t += dt;
      // 券：出票口或者钱箱看不见了（放下、换台、桌上那一页开着），直接落进去
      if (m.k === 'in' && !m.done && !(slotAt(m.id) && walletAt['t:' + m.id])) m.t = Math.max(m.t, m.dur);
      if (m.k === 'desk' && ui.view !== 'desk') m.t = m.dur;
      if (m.done || m.t < m.dur) continue;
      m.done = true;
      if (m.k === 'out') ui.money.push({ k: 'ping', x: m.x1, y: m.y1, t: 0, dur: 0.12 });
      else if (m.k === 'in') { ui.tixFly[m.id] = Math.max(0, (ui.tixFly[m.id] || 0) - m.share); ui.flash['wt:' + m.id] = ui.time; ui.flash['tin:' + m.id] = ui.time; sfx.tix(); }
    }
    ui.money = ui.money.filter(m => !m.done);
    for (const id of Object.keys(ui.tixFly)) if (!ui.money.some(m => m.k === 'in' && m.id === id)) ui.tixFly[id] = 0;
  }
  function drawMoney() {
    for (const m of ui.money) {
      if (m.t < 0) continue;
      if (m.k === 'out') {
        const u = ease(clamp(m.t / m.dur, 0, 1)), x = lerp(m.x0, m.x1, u), y = lerp(m.y0, m.y1, u) - 14 * Math.sin(Math.PI * u);
        const w = m.img.width * 2, h = m.img.height * 2;
        ctx.drawImage(m.img, Math.round(x / 2) * 2 - w / 2, Math.round(y / 2) * 2 - h / 2, w, h);
      } else if (m.k === 'ping') {
        const d = Math.round(3 + 6 * m.t / m.dur);
        ctx.fillStyle = '#ffffff';
        for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) ctx.fillRect(Math.round(m.x + dx * d) - 1, Math.round(m.y + dy * d) - 1, 2, 2);
      } else if (m.k === 'in') {
        const s = slotAt(m.id), to = walletAt['t:' + m.id];
        if (!s || !to) continue;
        const tk = MA.ticket(m.id), tw = tk.width * 2, th = tk.height * 2;
        if (m.t < TIX_OUT) {
          // 从缝里往上吐出来（缝下面的那截还藏着）
          const u = m.t / TIX_OUT;
          ctx.save(); ctx.beginPath(); ctx.rect(0, 0, W, s.y); ctx.clip();
          ctx.drawImage(tk, Math.round(s.x - tw / 2 + m.dx), Math.round(s.y - th * u), tw, th);
          ctx.restore();
        } else {
          const u = ease(clamp((m.t - TIX_OUT) / TIX_FLY, 0, 1)), x0 = s.x + m.dx, y0 = s.y - th / 2;
          const x = lerp(x0, to.x, u), y = lerp(y0, to.y, u) - 24 * Math.sin(Math.PI * u);
          ctx.drawImage(tk, Math.round(x / 2) * 2 - tw / 2, Math.round(y / 2) * 2 - th / 2, tw, th);
        }
      } else if (m.k === 'desk' && ui.view === 'desk' && !ui.tr) {
        // 先从缝里往下吐出来一截（缝上面那截还藏着），再蹦到那摞券上
        const tk = MA.ticket(m.id), u = clamp(m.t / m.dur, 0, 1), OUT = 0.3;
        if (u < OUT) {
          ctx.save(); ctx.beginPath(); ctx.rect(0, m.y0, W, H); ctx.clip();
          ctx.drawImage(tk, Math.round(m.x0 - tk.width / 2), Math.round(m.y0 - tk.height + tk.height * u / OUT));
          ctx.restore();
        } else {
          const v = (u - OUT) / (1 - OUT), x = lerp(m.x0, m.x1, v), y = lerp(m.y0 + tk.height / 2, m.y1, v) - 4 * Math.sin(Math.PI * v);
          ctx.drawImage(tk, Math.round(x - tk.width / 2), Math.round(y - tk.height / 2));
        }
      }
    }
  }
  function onFx(type, o) {
    A.setCard('swamp');
    if (type === 'hit') {
      FX.hit({ x: o.x, y: o.y, nx: o.nx, ny: o.ny, cols: MA.slimeColors(o.m), big: o.m.r >= 6 });
      if (o.shard) FX.spikeStick({ x: o.x, y: o.y, a: Math.atan2(o.m.y - o.y, o.m.x - o.x) });
      if (o.crit) label('重击 ×2', o.m.x, o.m.y - o.m.r - 6, '#ffd23a');
      else if (o.gold) label('金珠 ×2', o.m.x, o.m.y - o.m.r - 6, '#ffd23a');
    } else if (type === 'kill') {
      const m = o.m, cols = MA.slimeColors(m);
      const r = FX.kill({ id: m.id, x: m.x, y: m.y, r: m.r, cols, crush: o.crush, boss: m.boss, fire: o.fire, shard: o.shard, kind: m.kind }), w = r.delay;
      if (r.shake) ui.shake = Math.max(ui.shake, 0.12);
      label('+' + R.num(o.g), m.x, m.y - m.r - 4, m.gold ? '#fff6c0' : C.gold, false, w);
      if (m.gold) label('金 ×' + run.K.goldX, m.x, m.y - m.r - 13, '#ffd23a', false, w);
      else if (o.crit) label('重击 ×2', m.x, m.y - m.r - 13, '#ffd23a', false, w);
      payCoins(o.g, m.x, m.y, w);
    } else if (type === 'split') FX.splash({ x: o.x, y: o.y, cols: MA.slimeColors(o.m), n: 6 });
    else if (type === 'ding') FX.ding({ x: o.x, y: o.y });
    else if (type === 'crush') FX.crushed(o.x, o.y, run.s.balls);
    else if (type === 'shatter') FX.shatter({ x: o.x, y: o.y, kind: o.kind, cols: MA.BALL_C[o.kind] || A.MARB.glass });
    else if (type === 'usedUp') FX.poof({ x: o.x, y: o.y }); else if (type === 'crack') FX.crack({ x: o.b.x, y: o.b.y, cols: MA.BALL_C[o.b.kind] || A.MARB.glass });
    else if (type === 'burn') FX.ignite({ id: o.m.id, x: o.m.x, y: o.m.y - o.m.r });
    else if (type === 'burnTick') FX.burnTick({ id: o.m.id, x: o.m.x, y: o.m.y - o.m.r });
    else if (type === 'freeze') burst(o.m.x, o.m.y, 6, 40, ['#ffffff', '#a8e8ff'], 10);
    else if (type === 'flipCrack') { const f = run.s.flippers.find(q => q.side === o.side), tp = f ? P.tipOf(f) : [o.x, o.y]; FX.flipCrack({ x: (o.x + tp[0]) / 2, y: (o.y + tp[1]) / 2 }); }
    else if (type === 'flipBreak') { const f = run.s.flippers.find(q => q.side === o.side), tp = f ? P.tipOf(f) : null; FX.flipBreak({ side: o.side, x: o.x, y: o.y, tx: tp && tp[0], ty: tp && tp[1] }); ui.shake = Math.max(ui.shake, 0.2); }
    else if (type === 'lane') ui.laneFlash[o.side] = 1;
    else if (type === 'goldBall') FX.sparkle({ x: o.b.x, y: o.b.y, n: 6, layer: 'o' });
    else if (type === 'sling') ui.slingFlash[o.x < P.CXF ? 'L' : 'R'] = 0.1;
    else if (type === 'launch') { if (!S.seen.launch) { S.seen.launch = 1; save(); } }
    else if (type === 'layer') { ui.layerFlash = 1.6; ui.layerFlip = LAYER_FLIP; label('第 ' + o.layer + ' 层', P.CXF, 70, '#ffffff', true); }
    else if (type === 'boss') { ui.bossIn = 0; label(o.o.def.name + '！', P.CXF, 44, '#ff8a7a', true); }
    else if (type === 'thud') FX.dust({ x: o.x, y: o.y, w: o.w });
    else if (type === 'spit') FX.splash({ x: o.m.x, y: o.m.y, cols: MA.slimeColors(o.m), n: 4 });
    else if (type === 'bossDown' && !o.next) { FX.sparkle({ x: o.m.x, y: o.m.y, n: 16 }); sfx.crack2(); deskDirty = true; }
    else if (type === 'bossDown') {
      const from = stageKey(run.st.stage), to = stageKey(Math.min(D.STAGES.length, run.st.stage + 1));
      const sh = MA.shatter(from, o.m.x, o.m.y, Math.floor(Math.random() * 1e9));
      const toN = Math.min(D.STAGES.length, run.st.stage + 1);
      ui.burst = { t: -0.3, from, to, toN, z0: ui.camZ, z1: R.zoomOf(toN), pieces: sh.pieces, crack: sh.crack, x: o.m.x, y: o.m.y };
      sfx.crack2(); deskDirty = true;
    } else if (type === 'stage') { ui.stageFlash = 2.2; label('第 ' + o.stage + ' 关 · ' + R.stage(o.stage).name, P.CXF, 60, '#ffffff', true); sfx.stage(); }
    else if (type === 'stuck') label('往下还没挖好', P.CXF, 60, C.text, true);
    else if (type === 'bagAdd') label('弹珠 +' + o.n, P.LANE_CX - 6, 100, C.green);
    else if (type === 'start') { ui.parts = ui.parts.filter(p => p.nat); ui.labels = []; FX.clear(); }
    else if (type === 'end') { if (o.why === 'out' && S.runs <= 3) toast('弹珠用完了，从第 1 层重来', C.text); }
    else if (type === 'parts') { if (o.sling) partInstalled('sling'); if (o.lanes) partInstalled('lanes'); }
    else if (type === 'flipNew') partInstalled('flip');
    else if (type === 'reveal') revealedList(o.list);
    // 骨刺崩出来、回收（珠子飞回珠袋）、复活（往回收、"啵"站起来，变两只的写 ×2）、火传过去
    else if (type === 'spikes') FX.spikeOut({ x: o.x, y: o.y });
    else if (type === 'recycle') { const im = MA.ballSprite(o.kind, 0, false, true); FX.flyBack({ x: o.x, y: o.y, img: im, tx: trayX() + im.width / 2, ty: 146 + im.height / 2 }); }
    else if (type === 'revive') FX.revive({ id: o.m.id, two: o.two, dur: D.REVIVE.delay });
    else if (type === 'revived') { FX.revived({ x: o.x, y: o.y, r: o.r, cols: MA.slimeColors({ kind: o.kind }) }); if (o.two) label('×2', o.x, o.y - 10, C.green); }
    else if (type === 'spread') FX.spread(o);
    // 后十颗、后六关（11-11 粗做）
    else if (type === 'flick') { const k = 'aim:' + run.mode; if (!S.seen[k]) { S.seen[k] = 1; save(); } }
    else if (type === 'poof') FX.poof({ x: o.x, y: o.y });
    else if (type === 'goal') { label('进门！', o.x, FL.Y0 + 10, '#ffffff', true); FX.sparkle({ x: o.x, y: FL.Y0 + 2, n: 8, layer: 'o' }); }
    else if (type === 'refund') label('耐久 +1', o.b.x, o.b.y - 8, C.green);
    else if (type === 'knock') FX.dust({ x: o.x, y: o.y, w: 3 });
    else if (type === 'splash') FX.splash({ x: o.x, y: o.y, cols: ['#fff6c0', '#ffd23a', '#e0a010'], n: 8 });
    else if (type === 'chip') FX.sparkle({ x: o.x, y: o.y, n: 3, layer: 'o' });
    else if (type === 'pinch') label('夹 ×' + run.K.push.x, o.m.x, o.m.y - o.m.r - 6, '#ffd23a');
    else if (type === 'grow') FX.sparkle({ x: o.b.x, y: o.b.y, n: 4, layer: 'o' });
    else if (type === 'hooked') FX.ding({ x: o.m.x, y: o.m.y });
    else if (type === 'stick') FX.splash({ x: o.b.x, y: o.b.y, cols: MA.PAL.amber, n: 3 });
    else if (type === 'cap') FX.ding({ x: o.x, y: o.y });
    else if (type === 'puff') burst(o.m.x, o.m.y, 5, 30, MA.PAL.puffer, 6);
    else if (type === 'breath') { burst(o.b.x, o.b.y, 8, 45, ['#ffffff', '#a8e8ff'], 8); label('冻住了', o.b.x, o.b.y - 8, '#a8e8ff'); }
    else if (type === 'eat') { FX.splash({ x: o.m.x, y: o.m.y, cols: MA.slimeColors(o.m), n: 4 }); label('吃了一只', o.o.x, o.o.y - o.o.r - 8, '#ff8a7a'); }
  }
  // 台上装了新零件：白边闪、冒金星
  function partInstalled(k) {
    ui.partFlash = { k, t: 0 };
    sfx.part();
    for (const [x, y] of MA.partOutline(k).filter((_, i) => i % 6 === 0)) ui.parts.push({ x, y, vx: (Math.random() - 0.5) * 40, vy: -20 - Math.random() * 30, t: 0, dur: 0.6, c: Math.random() < 0.5 ? '#ffffff' : GOLD[0] });
  }
  // 节点在哪一类（弹珠的在桌上柜台那一屏，场景的在机台右栏；金币的、小游戏里的没有）
  const catOf = n => (n.where === 'main' ? D.CATS.find(c => c.groups.includes(n.group)) || null : null);
  // 节点在桌上哪一件里（柜台、金币罐）；不在桌上的 null
  function objOf(n) {
    if (n.where !== 'main') return null;
    const c = catOf(n);
    if (c) return c.kind === 'ball' ? 'shop' : null;
    return (D.GROUPS[n.group] && D.GROUPS[n.group].desk) || null;
  }
  // 冒了新节点：那几行黄边闪一会儿、那一类的页签闪；不在这台的，钱箱里那台那一行闪；
  //   在桌上那几件里的：桌上那件、机台左边那个小图标闪，"回桌上"也闪
  function revealedList(list) {
    if (!list || !list.length) return;
    for (const n of list) {
      ui.flash['n:' + n.id] = ui.time; ui.flash['rv:' + n.id] = ui.time; ui.flash['w:' + n.where] = ui.time;
      const c = catOf(n), o = objOf(n);
      if (c) ui.flash[(c.kind === 'ball' ? 'shop:' : 'cat:') + c.id] = ui.time;
      if (o) { ui.flash['obj:' + o] = ui.time; ui.flash['dock:' + o] = ui.time; ui.deskFlash = 6; }
    }
    ui.flash.reveal = ui.time; sfx.reveal(); ui.trickleT = 0;
  }
  // 一下最多露两样，多出来的攒着：哪台手上"新"的少于两样，隔一会儿给那台露一样（一次只露一样）
  function trickle() {
    for (const w of walletIds()) {
      if (R.fresh(S, w) >= 2) continue;
      const l = R.reveal(S, 1, w);
      if (l.length) { revealedList(l); save(); return l; }
    }
    return [];
  }

  // =========================================================================
  // 电话：排着队（R.nextCall）；台上没有弹珠在跑才响。接起来整个游戏停住，一句一句打字，点一下往下说
  // =========================================================================
  function ringing() {
    const k = R.nextCall(S);
    if (!k || ui.call || ui.tr || ui.opening || ui.confirm || ui.paused || ui.dev || ui.ptree || ui.page) return null;
    if (ui.intro && (ui.intro.phase !== 'ring' || ui.intro.t < 0.8)) return null;
    if (ui.view === 'card' && ui.cur === 'main' && run.playing().length) return null;
    return k;
  }
  function answer() {
    const k = ringing(); if (!k) return false;
    ui.call = { k, i: 0, n: 0, t: 0 };
    leaveInputs();
    sfx.pickup();
    return true;
  }
  function advanceCall() {
    const c = ui.call; if (!c) return;
    const lines = D.CALLS[c.k].lines;
    if (c.n < lines[c.i].length) { c.n = lines[c.i].length; return; }
    c.i++; c.n = 0;
    if (c.i >= lines.length) hangUp();
    else sfx.tab();
  }
  function hangUp() {
    const k = ui.call.k;
    ui.call = null;
    R.hangUp(S, k); save();
    sfx.hangup();
    if (k === 'opening' && ui.intro) { ui.intro.phase = 'place'; ui.intro.t = 0; }
    else if (k === 'prestige' || k === 'prestigeWin') { ui.ppFlash = 6; ui.deskFlash = 6; }   // 桌上的闹钟闪、"回桌上"闪
    // 作者来电：右上角扳手亮黄闪，闹钟闪，弹无虚发上了桌（R.hangUp 里给的）
    else if (k === 'creator') { ui.devFlash = 12; ui.ppFlash = 6; ui.deskFlash = 6; ui.flash['w:ring'] = ui.time; deskDirty = true; }
  }
  function updateCall(dt) {
    const c = ui.call; if (!c) return;
    c.t += dt;
    const line = D.CALLS[c.k].lines[c.i], was = Math.floor(c.n);
    c.n = Math.min(line.length, c.n + dt * 20);
    if (Math.floor(c.n) > was && Math.floor(c.n) % 2 === 1) sfx.talk();
  }

  // =========================================================================
  // 小游戏：每台一个台子（machines/*.js），拿起来才动；雇了小人的不拿着也自己打（R.tickBots）
  // =========================================================================
  const ctrls = {}, cardCache = {};
  const M18 = id => R18.BY[id];
  function ctrl(id) {
    if (!ctrls[id] && Machines.has(id) && R.miniOpen(S, id)) { A.setCard(id); ctrls[id] = Machines.make(id, makeEnv(id)); }
    return ctrls[id] || null;
  }
  function makeEnv(id) {
    const M = M18(id);
    const env = {
      id, M, A, sfx: sfxM,
      mini: R.MBY[id],                     // 这台在 data.js 里的那一条（MINIS）
      m: () => S.mini[id],
      marbles: () => S.mini[id].marbles,
      val: k => R.miniVal(S, id, k),
      lvl: k => R.miniLv(S, id, k),
      lv: () => 0,                         // 十八台的技能树主线没有
      first: () => S.mini[id].shots === 0, // 这台一发都还没打过：第一发必中
      luck: p => Math.random() < p,
      spend() {
        const m = S.mini[id];
        if (m.marbles <= 0) { deny('marbles'); return false; }
        m.marbles -= 1; m.shots += 1; save(); return true;
      },
      refund() { S.mini[id].marbles += 1; save(); },
      // 发 base 张奖券（乘宝贝加成）。at：台面哪一格飘字
      award(base, o) {
        o = o || {};
        const n = R.award(S, id, base);
        if (n > 0) { ui.chipFlash = 0.3; ticketsOut(id, n); if (o.at) popAt(o.at[0], o.at[1], '+' + R.num(n), o.color || MA.TIX_C[id]); }
        save();
        return n;
      },
      find(k) { const m = S.mini[id]; if (m.cab[k]) return false; m.cab[k] = 1; celebrateFind(id, k); save(); return true; },
      jackpot() { const first = env.find('skill'); sfxM.jackpot(); ui.shake = Math.max(ui.shake, 0.3); return { first, won: 0 }; },
      kill() { return false; },
      toast: (s, c) => toast(s, c), deny: w => deny(w), save,
      pop: (sx, sy, s, c) => popAt(sx, sy, s, c),
      shake: v => { ui.shake = Math.max(ui.shake, v); },
    };
    return env;
  }
  function popAt(sx, sy, s, color) { ui.pops.push({ x: A.FX(sx), y: A.FY(sy), s, color: color || C.gold, t: 0 }); }
  function deny(what) {
    ui.deny = { what, t: 0.4 }; sfx.deny();
    if (what === 'marbles' && ui.cur !== 'main') toast('弹珠打光了：右边买一盒', C.red);
  }
  function celebrateFind(id, k) {
    const it = M18(id).items.find(x => x.k === k);
    sfxM.find();
    toast('找到宝贝：' + it.name + '（这台的奖券 +10%）', C.gold);
  }
  // 卡（4 倍）：虚化的卡面 + 这台不动的那一层。买了改场地的升级要重画
  function miniCard(id) {
    if (!cardCache[id]) { A.setCard(id); const c = ctrl(id); cardCache[id] = A.renderMachineCard(id, c ? f => c.fine(f) : null); }
    return cardCache[id];
  }
  // 桌上那张（1 倍，不虚化）
  const deskCards = {};
  const deskCard = id => deskCards[id] || (deskCards[id] = A.cardCanvas(id));
  // 在桌上点盖着红布的台：开台（买第一盒弹珠）→ 红布掀走 → 拿起来
  function openMini(id) {
    const p = R.boxPrice(S, id), res = R.openMini(S, id);
    if (!res) { deny('open:' + id); if (S.gold < p) toast('还差 ' + R.num(p - S.gold) + ' 金币', C.red); return false; }
    sfxM.open();
    delete cardCache[id];
    ctrl(id);
    ui.opening = { id, t: 0 };
    deskDirty = true;
    revealedList(res.revealed);
    save();
    return true;
  }
  // 钱箱里点上了桌还没开的那台：回到桌上掀红布（钱不够就在这儿说）
  function openFromWallet(id) {
    const p = R.boxPrice(S, id);
    if (S.gold < p) { deny('w:' + id); toast('还差 ' + R.num(p - S.gold) + ' 金币', C.red); return false; }
    if (ui.view === 'card') return drop(() => openMini(id));
    return openMini(id);
  }
  function flashKey(k) { ui.flash[k] = ui.time; }
  function buyBox(id, quiet) {
    const p = R.boxPrice(S, id);
    if (!R.buyBox(S, id)) { if (!quiet) { deny('box'); toast('还差 ' + R.num(p - S.gold) + ' 金币', C.red); } return false; }
    sfx.buy(); flashKey('box:' + id); spendFly({ gold: p }, 'box', quiet); save();
    return true;
  }
  // 还差多少：哪一半不够写哪一半
  function lackText(p) {
    const l = R.lack(S, p), out = [];
    if (l.gold) out.push(R.num(p.gold - S.gold) + ' 金币');
    if (l.tix) out.push(R.num(p.tix - R.tixOf(S, p.tixId)) + ' 张' + R.MBY[p.tixId].tix);
    return out.length ? '还差 ' + out.join(' + ') : '';
  }
  // 买一级（斩草除根的、小游戏里的都走这里）。quiet：按住连着买的后几下（不弹字、声音轻）
  function buyNode(id, quiet) {
    const n = R.BY[id];
    if (!n || !R.visible(S, n)) return false;
    if (R.state(S, n) !== 'can') {
      if (!quiet) { deny('node:' + id); const p = R.price(S, n), t = p && lackText(p); if (t) toast(t, C.red); }
      return false;
    }
    // 一轮打到一半买数值的：下一轮才生效
    const mid = n.where === 'main' && run.st.phase === 'play' && !R.isPart(n) && run.marblesLeft() > 0;
    const p0 = R.price(S, n), res = R.buy(S, id);
    if (!res) return false;
    spendFly(p0, 'node:' + id, quiet);
    run.refresh();
    sfx.buy(); if (!quiet) sfx.upgrade();
    flashKey('n:' + id);
    if (n.where !== 'main') {
      const c = ctrls[n.where];
      A.setCard(n.where);
      if (n.up && c && c.onUpgrade) c.onUpgrade(n.up);
      if (n.up && c && c.refine && c.refine(n.up)) delete cardCache[n.where];
      if (n.kind) deskDirty = true;
    }
    if (res.shown) { deskDirty = true; ui.flash['w:' + res.shown] = ui.time; ui.deskFlash = 6; }
    revealedList(res.revealed);
    if (!quiet) {
      if (n.ball) toast('有' + D.MARBLES[n.ball].name + '了：卡左上角点它换上', C.green);
      else if (mid && !ui.rep) toast(run.K.restart ? '下一轮生效（重来马上用上）' : '下一轮生效', C.text);
    }
    save();
    return true;
  }
  const tapNode = n => buyNode(n.id);
  // 组名上的"换上"：这轮带哪种弹珠（下一轮生效；重来马上换）
  function pickBall(kind) {
    if (R.pickOf(S) === kind || !R.setPick(S, kind)) return false;
    sfx.tab(); save();
    if (run.st.phase === 'play' && run.st.run && run.st.run.kind !== kind) toast(run.K.restart ? '下一轮带上（重来马上换）' : '下一轮带上', C.text);
    return true;
  }

  // =========================================================================
  // 桌子、拿起放下
  // =========================================================================
  let deskDirty = true, deskSig = '', deskCanvas = null;
  // 斩草除根摆没摆上：开场电话那会儿只有绒布（1），落下来以后摆上了（2）
  const mainOnDesk = () => (ui.intro && (ui.intro.phase === 'ring' || (ui.intro.phase === 'place' && !ui.intro.landed)) ? 1 : 2);
  // 桌子那张底图看什么：哪台上了桌、开了没、战利品几个，桌上那几件摆没摆（柜台里摆哪几种弹珠的罐子）
  function deskVm() {
    const shop = shopCats().map(c => c.ball);
    return {
      main: mainOnDesk(), shown: D.MINIS.filter(M => R.miniShown(S, M.id)).map(M => M.id), open: D.MINIS.filter(M => R.miniOpen(S, M.id)).map(M => M.id), trophies: Object.keys(S.trophies).length,
      shop: shop.length ? shop : null, clock: R.anyHelper(S) ? 1 : 0, alarm: ptOn() ? 1 : 0,
    };
  }
  function desk() {
    const vm = deskVm(), sig = JSON.stringify(vm);
    if (!deskCanvas || sig !== deskSig) { deskSig = sig; deskCanvas = MD.render(vm); }
    deskDirty = false;
    return deskCanvas;
  }
  // 拿起 id：桌子 → 那台（镜头推近）。手上拿着别的就先放下。没开的小游戏拿不起来（先在桌上开台）
  function lift(id) {
    if (ui.tr || ui.call || ui.opening || ui.confirm) return false;
    if (ui.intro && ui.intro.phase !== 'lift') return false;
    if (id !== 'main' && !R.miniOpen(S, id)) return false;
    if (ui.view === 'card') { if (ui.cur === id) return false; return drop(() => lift(id)); }
    ui.tr = { kind: 'lift', id, t: 0, dur: id === 'main' ? 0.5 : 0.45 };
    sfx.lift();
    return true;
  }
  function drop(then) {
    if (ui.tr || ui.view !== 'card') return false;
    leaveCard();
    ui.tr = { kind: 'drop', id: ui.cur, t: 0, dur: 0.4, then };
    ui.view = 'desk';
    sfx.lift();
    return true;
  }
  function leaveCard() {
    if (ui.cur === 'main') run.cancel();
    else { const c = ctrls[ui.cur]; if (c) { A.setCard(ui.cur); if (c.cancel) c.cancel(); if (c.leave) c.leave(); } }
  }
  function trDone() {
    const tr = ui.tr; ui.tr = null;
    if (tr.kind === 'lift') {
      ui.view = 'card'; ui.cur = tr.id; ui.scrollR = 0;
      if (tr.id !== 'main') { const c = ctrl(tr.id); if (c && c.enter) { A.setCard(tr.id); c.enter(); } }
      if (ui.intro && ui.intro.phase === 'zoom') { ui.intro.phase = 'plunger'; ui.intro.t = 0; }
    } else { ui.scrollR = 0; if (tr.then) tr.then(); }
  }
  const anyShown = () => D.MINIS.some(M => R.miniShown(S, M.id));

  // =========================================================================
  // 开场：空桌子电话响 → 接 → 斩草除根落到绒布上 → 推近 → 装拉杆 → 第一颗弹珠
  // =========================================================================
  function startIntro() {
    ui.intro = { phase: 'ring', t: 0 };
    ui.view = 'desk'; ui.cur = 'main'; ui.plungerIn = 0;
    R.queueCall(S, 'opening');
    run.startRun();
    run.st.wait = 1e9;   // 拉杆没装上之前不上弹珠
  }
  // 落下来那一下：-220 → 0（重力，0.42 秒）
  function mainDrop() {
    const I = ui.intro;
    if (!I) return 0;
    if (I.phase === 'ring') return null;
    if (I.phase === 'place' && !I.landed) { const t = clamp(I.t / 0.42, 0, 1); return -Math.round((1 - t * t) * 220); }
    return 0;
  }
  function updateIntro(dt) {
    const I = ui.intro;
    I.t += dt;
    if (I.phase === 'place') {
      if (I.t >= 0.42 && !I.landed) {
        I.landed = true; deskDirty = true;
        sfx.thud(); ui.shake = 0.25;
        const r = MD.deskRect('main');
        for (const x of [r.x + 8, r.x + r.w - 8]) burstNat(x, r.y + r.h, 6, 60, ['#c8364a', '#e8c048', '#a8283a']);
      }
      if (I.t >= 1.0) { I.phase = 'lift'; I.t = 0; }
    } else if (I.phase === 'lift') { if (lift('main')) { I.phase = 'zoom'; I.t = 0; } }
    else if (I.phase === 'plunger') {
      ui.plungerIn = clamp(I.t / 0.9, 0, 1);
      if (I.t >= 0.9 && !I.clunk) { I.clunk = true; sfx.plunger(); ui.shake = 0.12; A.setCard('swamp'); FX.clunk({ x: P.LANE_CX, y: 152 }); }
      if (I.t >= 1.25) { run.st.wait = 0.05; I.phase = 'ball'; I.t = 0; }
    } else if (I.phase === 'ball' && run.laneBall()) {
      ui.intro = null; ui.plungerIn = 1;
      S.seen.opening = 1; save();
    }
  }
  // 开场里点一下：电话响着就接；落台、装拉杆的时候快进
  function skipIntro() {
    const I = ui.intro; if (!I) return;
    if (I.phase === 'ring') answer();
    else if (I.phase === 'place' && I.landed) I.t = Math.max(I.t, 1.0);
    else if (I.phase === 'plunger' && I.t < 0.9) I.t = 0.9;
  }

  // =========================================================================
  // 斩草除根（4 倍，画在 g 上：机台界面直接画屏幕，桌子上先画进 mainBuf 再缩一半）
  // =========================================================================
  function lamp(g, x, y, on) { g.fillStyle = INK; g.fillRect(A.FX(x - 1), A.FY(y - 1), 10, 10); g.fillStyle = on ? GOLD[0] : '#5a1a10'; g.fillRect(A.FX(x), A.FY(y), 6, 6); }
  // ---------- 台面那一层：关卡底图 + 史莱姆，镜头放远按 ui.camZ 缩 ----------
  // 先照"镜头不缩"的大小、按整数倍画进 wbuf（盖住放远以后台面那一格看得到的地方），再平滑缩进台面那一格：
  // 什么倍率像素都一样大，边上不到一个像素的过渡（执行方案 v1 第七节"镜头放远"、第十一节第 9 条）
  const WIN = () => ({ x: A.CX0 + 28, y: A.CY0 + 40, w: 328, h: 252 });   // 台面那一格（原生像素，卡面格 x 7..88、y 10..72）
  const anchorPx = () => ({ x: A.CX0 + MA.ANCHOR.x * 4, y: A.CY0 + MA.ANCHOR.y * 4 });
  const ANCHOR_B = { x: MA.ANCHOR.x * 2, y: MA.ANCHOR.y * 2 };          // 同一个点，台面格
  let wbuf = null, wctx = null;
  // g：画到哪（变换是单位阵，g 上一个像素 = 原生的 1/k）；dx：屏幕抖的那一下（原生像素）
  function drawWorld(g, k, dx) {
    const z = ui.camZ, Wn = WIN(), an = anchorPx();
    const Rn = { x: an.x + (Wn.x - an.x) / z, y: an.y + (Wn.y - an.y) / z, w: Wn.w / z, h: Wn.h / z };
    const M = Math.max(1, Math.ceil(k * z - 1e-6)), bw = Math.ceil(Rn.w * M), bh = Math.ceil(Rn.h * M);
    if (!wbuf || wbuf.width < bw || wbuf.height < bh) {
      const nb = document.createElement('canvas');
      nb.width = Math.max(bw, wbuf ? wbuf.width : 0); nb.height = Math.max(bh, wbuf ? wbuf.height : 0);
      wbuf = nb; wctx = nb.getContext('2d');
    }
    wctx.setTransform(1, 0, 0, 1, 0, 0);
    wctx.clearRect(0, 0, bw + 1, bh + 1);
    wctx.imageSmoothingEnabled = false;
    wctx.setTransform(M, 0, 0, M, -Rn.x * M, -Rn.y * M);
    drawWorldContent(wctx, z, an, Wn);
    g.save();
    g.imageSmoothingEnabled = true; g.imageSmoothingQuality = 'low';
    g.drawImage(wbuf, 0, 0, Rn.w * M, Rn.h * M, (Wn.x + dx) * k, Wn.y * k, Wn.w * k, Wn.h * k);
    g.restore();
  }
  function drawWorldContent(g, z, an, Wn) {
    const B = ui.burst, X0 = A.CX0, Y0 = A.CY0;
    // 垫一层深色：底图万一盖不满（镜头比大底图还远），也不漏出桌子
    g.fillStyle = '#141a30'; g.fillRect(an.x + (Wn.x - an.x) / z, an.y + (Wn.y - an.y) / z, Wn.w / z, Wn.h / z);
    const wa = MA.worldArt(B ? B.to : stageKey(run.st.stage));
    g.drawImage(wa.c, X0 + wa.cx * 4, Y0 + wa.cy * 4);
    // 台面格大小的东西（碎掉的上一关、史莱姆）：放大 1/z 画，缩回来正好在台面格的地方、台面格的个头
    const zoomed = draw => { g.save(); g.translate(an.x, an.y); g.scale(1 / z, 1 / z); g.translate(-an.x, -an.y); draw(); g.restore(); };
    if (B) zoomed(() => {
      g.beginPath(); g.rect(Wn.x, Wn.y, Wn.w, Wn.h); g.clip();
      if (B.t < 0) { g.drawImage(MA.stageCanvas(B.from), X0, Y0); g.drawImage(B.crack, X0, Y0); }
      else for (const p of B.pieces) {
        const tt = Math.max(0, B.t - p.delay);
        const x = X0 + p.x0 * 4 + p.vx * 4 * tt, y = Y0 + p.y0 * 4 + (p.vy * tt + 120 * tt * tt) * 4;
        g.drawImage(p.c, Math.round(x / 2) * 2, Math.round(y / 2) * 2);
      }
    });
    // 史莱姆：照台面格的位置、个头放大 1/z（画的是"镜头不缩"时的样子），整层缩回来就对上物理
    //   hits：这一轮带的这颗球几下碎它（档低打不动的 0、高两档碾压的 1），头上画几格
    const M = R.marbleOf(run.K, run.st.run ? run.st.run.kind : R.pickOf(S)), dmg = M.fen * M.power;
    const hitsOf = o => (M.tier < o.tier ? 0 : M.tier >= o.tier + 2 ? 1 : Math.ceil(Math.max(0, o.hp) / dmg - 1e-6));
    const at = o => { const p = Object.create(o); p.x = ANCHOR_B.x + (o.x - ANCHOR_B.x) / z; p.y = ANCHOR_B.y + (o.y - ANCHOR_B.y) / z; p.r = o.r / z; p.hits = hitsOf(o); return FX.look(o, p); };
    const toW = (x, y) => ({ x: ANCHOR_B.x + (x - ANCHOR_B.x) / z, y: ANCHOR_B.y + (y - ANCHOR_B.y) / z });
    FX.drawGround(g, toW);
    // 要复活的：溅开的往回收的同时，原地鼓起一团，鼓圆了蹦出来（底边贴着史莱姆脚底）；变两只的鼓两团
    for (const rv of run.st.revives) {
      const k = 1 - clamp(rv.t / D.REVIVE.delay, 0, 1), r0 = rv.r || 5, wob = Math.sin(ui.time * 16) * 0.04 * (1 - k);
      for (const dx of rv.two ? [-4, 4] : [0]) {
        const r = (rv.two ? r0 * 0.75 : r0) / z, rx = Math.max(2, r * (1.7 - 0.5 * k + wob)), ry = Math.max(1, r * (0.22 + 0.75 * k * k));
        const im = A.slimeSprite(Math.round(rx * 2) / 2, Math.round(ry * 2) / 2, MA.slimeColors({ kind: rv.kind }), false, false);
        const p = toW(rv.x + dx * k, rv.y + r0 * 1.2 + 2);
        MK.spr(g, im, Math.round(p.x - im.width / 2), Math.round(p.y - im.height));
      }
    }
    for (const o of run.s.slimes) if (!o.boss) MA.drawSlime(g, at(o), ui.time);
    for (const o of run.s.slimes) if (o.boss) MA.drawSlime(g, at(o), ui.time);
    FX.drawWorld(g, toW);
  }
  // 卡框、硬件（导轨、弹弓、发射道、发力灯、口子）：压在台面那一层上面
  function drawFrame(g) {
    g.drawImage(MA.frameCanvas(), A.CX0, A.CY0);
    g.drawImage(isFlat() ? MA.flatCanvas(run.mode) : MA.hardwareCanvas(run.s.parts), A.CX0, A.CY0);
  }
  function drawTable(g) {
    const s = run.s, st = run.st;
    if (s.parts.sling) for (const side of ['L', 'R']) if (ui.slingFlash[side] > 0) { const S2 = P.SLING[side]; MK.dots(g, S2.A[0], S2.A[1], S2.C[0], S2.C[1], '#fff6c0', 1); }
    if (s.parts.lanes) for (const k of ['L', 'R']) { const Ln = P.LANES[k], x = Math.round((Ln.sx0 + Ln.sx1) / 2) - 1; lamp(g, x, Ln.y0 + 2, ui.laneFlash[k] > 0 && Math.sin(ui.time * 14) > -0.5); }
    // 刚装上的零件：白点描一圈，闪三下
    if (ui.partFlash && Math.sin(ui.partFlash.t * 18) > -0.2) for (const [x, y] of MA.partOutline(ui.partFlash.k)) MK.px(g, x, y, '#ffffff');
    for (const p of ui.parts) if (!p.nat) { const a = p.t / p.dur; if (a < 1) { g.fillStyle = p.c; g.fillRect(A.FX(Math.round(p.x)), A.FY(Math.round(p.y)), 2, 2); } }
    FX.drawFlipTrails(g, s.flippers);
    for (const f of s.flippers) MA.drawFlipper(g, f, st.flips[f.side]);
    const lb = run.laneBall(), flat = isFlat();
    // 拉杆：开场时从卡底下滑上来
    if (ui.plungerIn > 0 && !flat) {
      const off = Math.round((1 - easeIO(ui.plungerIn)) * 18) * 2;
      g.save();
      g.beginPath(); g.rect(A.CX0, A.CY0, MA.CW4, MA.CH4); g.clip();
      g.translate(0, off);
      MK.lane(g, run.pl.on ? run.pl.pull() : 0, lb ? MA.ballSprite(lb.kind, Math.min(2, lb.crack), lb.gold) : null, P.DX);
      g.restore();
    }
    FX.drawTrails(g, s.balls);
    for (const b of s.balls) if (b.state === 'play' || b.state === 'rest') {
      const im = MA.ballSprite(b.kind, Math.min(2, b.crack), b.gold, false, b.r0 ? b.r / b.r0 : 1);
      MK.spr(g, im, Math.round(b.x - im.width / 2), Math.round(b.y - im.height / 2));
      // 被冻住、粘住：身上一圈白点
      if (b.hold > 0 && Math.sin(ui.time * 10) > -0.5) MK.ring(g, b.x, b.y, b.r + 1.5, b.frozenT ? '#a8e8ff' : '#ffffff', 3);
    }
    if (flat) drawAim(g);
    FX.drawOver(g);
    // 骨刺：画好的尖骨片，尖朝前，身后两点残影
    FX.drawSpikes(g, st.shards);
    if (!flat) A.drawMeter(g, run.pl.power(), run.pl.on, P.DX);
    // 教你瞄：打空过一轮以后，发力灯边上标出砸中那一只的力度
    if (!flat && st.phase === 'play' && !S.seen.firstKill && S.runs >= 1 && lb && !ui.intro) {
      const o = run.normals().find(m => m.stay && m.state !== 'pop');
      if (o) {
        const p = run.powerFor(o.tx, o.ty - o.r * 0.3), M = A.METER, y = M.y + M.h - 2 - Math.round(p * 108);
        g.fillStyle = INK; g.fillRect(A.FX(M.x - 3 + P.DX), A.FY(y - 1), 8, 6);
        g.fillStyle = GOLD[0]; g.fillRect(A.FX(M.x - 2 + P.DX), A.FY(y), 6, 2);
        if (Math.sin(ui.time * 5) > -0.3) MK.label(g, '拉到这', M.x + P.DX - 4, y - 4, GOLD[0], 'right');
      }
    }
    drawTray(g);
    drawRestart(g);
    drawPicks(g);
    drawStagePick(g);
    for (const l of ui.labels) {
      const a = l.t / (l.big ? 1.6 : 1.1);
      if (a >= 1 || a < 0) continue;
      if (l.big) Txt.draw(g, l.s, A.FX(l.x), A.FY(l.y - a * 6), { align: 'center', size: 16, color: l.c });
      else MK.label(g, l.s, l.x, l.y - a * 10, l.c, 'center');
    }
  }
  // 平台面：拉着的时候画皮筋（珠子到手）和出手那条虚线（拉满变金）；没拉的时候停着那颗外头一圈虚线闪
  function drawAim(g) {
    const st = run.st, A_ = st.aim;
    if (!A_) {
      const rb = run.restBalls();
      if (!rb.length || run.s.balls.some(b => b.state === 'play') || st.phase !== 'play' || ui.intro) return;
      const b = rb[0];
      if (Math.sin(ui.time * 5) > -0.3) MK.ring(g, b.x, b.y, b.r + 3, '#ffffff', 3);
      if (!S.seen['aim:' + run.mode]) MK.label(g, run.mode === 'bowl' ? '按住往后拉，左右挪' : '按住往后拉', b.x, b.y - b.r - 12, GOLD[0], 'center');
      return;
    }
    const b = A_.b, sh = run.aimShot(A_);
    MK.dots(g, b.x, b.y, A_.x, A_.y, '#9a8aa8', 2);
    if (!sh) return;
    const r0 = b.r + 2, len = 12 + 46 * sh.p;
    MK.dots(g, b.x + sh.ux * r0, b.y + sh.uy * r0, b.x + sh.ux * (r0 + len), b.y + sh.uy * (r0 + len), sh.p >= 1 ? GOLD[0] : '#ffffff', 3);
  }
  // 弹珠袋：卡底那条深色槽（台面格 146..153）里排着还没上的弹珠，从发射道往左排（下一颗挨着发射道）；平台面从右边往左排
  const trayX = () => (isFlat() ? FL.X1 - 9 : P.LANE_X - 9);
  function drawTray(g) {
    const bag = run.st.bag;
    if (!bag.length || ui.plungerIn < 1) return;
    const n = Math.min(bag.length, 12), x0 = trayX();
    for (let i = Math.min(n, FX.flyingBack()); i < n; i++) MK.spr(g, MA.ballSprite(bag[i], 0, false, true), Math.round(x0 - 8 * i), 146);
    if (bag.length > n) MK.label(g, '+' + (bag.length - n), Math.round(x0 - 8 * n) - 2, 146, C.text, 'right');
  }
  // 重来（树上买的按钮）：卡底那条槽的左头
  const RESTART_BTN = { x: 16, y: 145, w: 30, h: 9 };
  function drawRestart(g) {
    if (!run.K.restart || ui.intro) return;
    const b = RESTART_BTN, X = A.FX(b.x), Y = A.FY(b.y), w = b.w * 2, h = b.h * 2, on = run.st.phase === 'play', hot = g === ctx && ui.hover === 'restart';
    // 打着的时候是绿键帽；没在打（点了也没用）是平的灰牌子
    let f;
    if (on) f = U.key(g, X, Y, w, h, { kind: 'go', hot, down: g === ctx && pressing('restart') });
    else { U.rr(g, X, Y + U.LIP - 1, w, h - U.LIP + 1, '#3c4352', INK, 2); f = { x: X + 1, y: Y + U.LIP, w: w - 2, h: h - U.LIP - 2, P: { ink: '#9aa0ac', out: INK } }; }
    const ic = MA.nodeIcon('restart');
    g.drawImage(ic, f.x + 1, f.y + Math.round((f.h - ic.height) / 2));
    Txt.draw(g, '重来', f.x + 18, f.y, { color: f.P.ink, outline: f.P.out });
    if (g === ctx) hit('restart', X, Y, w, h, () => doRestart());
  }
  // 换弹珠（手上不止一种）：卡左上角一排小按钮，一种球一个；挑着的按进去（打到一半换的下一轮才上）
  const PICK_BTN = { x: 6, y: 4, w: 11, h: 10, gap: 1 };   // 台面格（原生是两倍）
  function drawPicks(g) {
    const balls = R.ownedBalls(S);
    if (balls.length < 2 || ui.intro) return;
    const pick = R.pickOf(S), b = PICK_BTN;
    // 多了一排放不下（压到关卡名）：只放一个"现在带的"，点开一格一格挑
    if (balls.length > 4) { drawPickMenu(g, balls, pick); return; }
    balls.forEach((k, i) => {
      const id = 'pick:' + k, on = k === pick, hot = g === ctx && ui.hover === id;
      const X = A.FX(b.x + i * (b.w + b.gap)) + (g === ctx ? shakeOf(id) : 0), Y = A.FY(b.y), w = b.w * 2, h = b.h * 2;
      // 挑着的按进去（蓝绿，跟页签一样）；别的是深蓝键帽
      const f = U.key(g, X, Y, w, h, { kind: on ? 'cur' : 'idle', hot, down: g === ctx && pressing(id) });
      const im = MA.nodeIcon('m:' + k);
      g.drawImage(im, Math.round(f.x + (f.w - im.width) / 2), Math.round(f.y + (f.h - im.height) / 2));
      if (g === ctx && !on) hit(id, X, Y, w, h, () => pickBall(k));
    });
  }
  const PICK_ROW = 5;
  function drawPickMenu(g, balls, pick) {
    const b = PICK_BTN, live = g === ctx, open = live && ui.pickOpen;
    // 收着：现在带的那颗，右边一个小三角
    const id0 = 'pick:open', X0 = A.FX(b.x), Y0 = A.FY(b.y), w0 = (b.w + 6) * 2, h0 = b.h * 2;
    const f0 = U.key(g, X0, Y0, w0, h0, { kind: open ? 'cur' : 'idle', hot: live && ui.hover === id0, down: live && pressing(id0) });
    const im0 = MA.nodeIcon('m:' + pick);
    g.drawImage(im0, Math.round(f0.x + 2), Math.round(f0.y + (f0.h - im0.height) / 2));
    const cx = Math.round(f0.x + f0.w - 8), cy = Math.round(f0.y + f0.h / 2 - 2);
    g.fillStyle = f0.P.ink;
    for (let j = 0; j < 3; j++) g.fillRect(cx - (open ? j : 2 - j), cy + j, 1 + (open ? j : 2 - j) * 2, 1);
    if (live) hit(id0, X0, Y0, w0, h0, () => { ui.pickOpen = !ui.pickOpen; ui.stageOpen = false; sfx.tab(); return true; });
    if (!open) return;
    // 开着：点别处收起（先压一块整张卡的），下面一格一格
    const pr = MD.playRect(ui.cur);
    hit('pick:shade', pr.x, 12, pr.w, 336, () => { ui.pickOpen = false; return true; });
    const rows = Math.ceil(balls.length / PICK_ROW), px = A.FX(b.x) - 4, py = A.FY(b.y + b.h + 1) - 2;
    const pw = PICK_ROW * (b.w + b.gap) * 2 + 6, ph = rows * (b.h + b.gap) * 2 + 6;
    U.rr(g, px, py, pw, ph, U.C.navyLo, INK, 2);
    balls.forEach((k, i) => {
      const id = 'pick:' + k, on = k === pick, X = px + 4 + (i % PICK_ROW) * (b.w + b.gap) * 2, Y = py + 4 + Math.floor(i / PICK_ROW) * (b.h + b.gap) * 2, w = b.w * 2, h = b.h * 2;
      const f = U.key(g, X, Y, w, h, { kind: on ? 'cur' : 'idle', hot: ui.hover === id, down: pressing(id) });
      const im = MA.nodeIcon('m:' + k);
      g.drawImage(im, Math.round(f.x + (f.w - im.width) / 2), Math.round(f.y + (f.h - im.height) / 2));
      hit(id, X, Y, w, h, () => { if (!on) pickBall(k); ui.pickOpen = false; return true; });
    });
  }
  // 选关（打掉过一关的 boss 以后）：卡右上角一个键，写着下一轮从哪关打起；点开一列这一世打通过的关，挑一个
  const STAGE_BTN = { x: 142, y: 4, w: 32, h: 10 };   // 台面格（原生是两倍）
  const stageLabel = n => { const d = R.stage(n); return (d.night ? '夜' : '') + d.name.replace('夜·', '').replace('史莱姆', ''); };
  function pickStage(n) {
    const v = n >= S.maxStage ? 0 : n;
    if ((S.from || 0) === v) return;
    S.from = v; sfx.tab(); save();
    if (run.st.phase === 'play') toast('下一轮从' + R.stage(n).name + '打起' + (run.K.restart ? '（重来马上换）' : ''), C.text);
  }
  function drawStagePick(g) {
    if (S.maxStage < 2 || ui.intro) return;
    const b = STAGE_BTN, live = g === ctx, open = live && ui.stageOpen, cur = R.startStage(S);
    const id0 = 'stage:open', X0 = A.FX(b.x), Y0 = A.FY(b.y), w0 = b.w * 2, h0 = b.h * 2;
    const f0 = U.key(g, X0, Y0, w0, h0, { kind: open ? 'cur' : 'idle', hot: live && ui.hover === id0, down: live && pressing(id0) });
    Txt.draw(g, stageLabel(cur), Math.round(f0.x + (f0.w - 8) / 2), f0.y + Math.round(f0.h / 2 - 7), { align: 'center', color: f0.P.ink, outline: f0.P.out });
    const cx = Math.round(f0.x + f0.w - 7), cy = Math.round(f0.y + f0.h / 2 - 2);
    g.fillStyle = f0.P.ink;
    for (let j = 0; j < 3; j++) g.fillRect(cx - (open ? j : 2 - j), cy + j, 1 + (open ? j : 2 - j) * 2, 1);
    if (live) hit(id0, X0, Y0, w0, h0, () => { ui.stageOpen = !ui.stageOpen; ui.pickOpen = false; sfx.tab(); return true; });
    if (!open) return;
    // 开着：点别处收起；一列最多六关，多了往左再排一列
    const pr = MD.playRect(ui.cur);
    hit('stage:shade', pr.x, 12, pr.w, 336, () => { ui.stageOpen = false; return true; });
    const n = S.maxStage, cols = Math.ceil(n / 6), rows = Math.min(6, n), gap = 2;
    const pw = cols * (w0 + gap) + 6, ph = rows * (h0 + gap) + 6, px = X0 + w0 + 4 - pw, py = Y0 + h0 + 2;
    U.rr(g, px, py, pw, ph, U.C.navyLo, INK, 2);
    for (let i = 1; i <= n; i++) {
      const id = 'stage:' + i, on = i === cur, c = Math.floor((i - 1) / 6), X = px + pw - 3 - (c + 1) * (w0 + gap) + gap, Y = py + 4 + ((i - 1) % 6) * (h0 + gap);
      const f = U.key(g, X, Y, w0, h0, { kind: on ? 'cur' : 'idle', hot: ui.hover === id, down: pressing(id) });
      Txt.draw(g, stageLabel(i), Math.round(f.x + f.w / 2), f.y + Math.round(f.h / 2 - 7), { align: 'center', color: f.P.ink, outline: f.P.out });
      hit(id, X, Y, w0, h0, () => { pickStage(i); ui.stageOpen = false; return true; });
    }
  }
  function doRestart() { if (run.restart()) { ui.burst = null; ui.labels = []; } else sfx.deny(); }
  // 卡顶那条：哪一关第几层 + 这一层碎了几只（小方块）；boss 来了换成血条
  function drawTop(g) {
    const st = run.st, X0 = A.CX0, w = MA.CW4;
    if (!S.seen.firstKill && !st.boss) return;   // 第一只没碎之前卡顶什么都不写
    if (!st.boss) {
      const SD = R.stage(st.stage), fl_ = (ui.layerFlash > 0 && Math.sin(ui.time * 16) > 0) || (ui.stageFlash > 0 && Math.sin(ui.time * 12) > 0);
      const s = st.bossDue >= 0 ? SD.name + ' · boss 要来了' : st.burst ? '打穿了！' : st.stuck ? SD.name + ' · 往下还没挖好' : SD.name + ' 第 ' + st.layer + ' 层';
      const tw = Txt.width(s, 16);
      const need = R.layerOf(st.stage, st.layer).need, pips = st.bossDue < 0 && !st.burst && !st.stuck ? need : 0;
      const pw = pips ? pips * 8 + 6 : 0, x0 = Math.round(X0 + w / 2 - (tw + pw) / 2);
      // 过层：那块字竖着翻一下（压扁到没、再撑开）
      const flip = ui.layerFlip > 0 ? Math.abs(Math.cos(Math.PI * (1 - ui.layerFlip / LAYER_FLIP))) : 1;
      if (flip < 1) { g.save(); g.translate(0, 28); g.scale(1, Math.max(0.08, flip)); g.translate(0, -28); }
      Txt.draw(g, s, x0, 20, { size: 16, color: fl_ || (st.bossDue >= 0 && Math.sin(ui.time * 12) > 0) ? '#ffffff' : C.gold });
      if (flip < 1) g.restore();
      for (let i = 0; i < pips; i++) {
        const px = x0 + tw + 8 + i * 8;
        g.fillStyle = INK; g.fillRect(px, 24, 7, 8);
        g.fillStyle = i < st.lk ? '#a8f07a' : '#3a2a1a'; g.fillRect(px + 1, 25, 5, 6);
        if (i < st.lk) { g.fillStyle = '#e8ffd0'; g.fillRect(px + 1, 25, 5, 1); }
      }
      ui.bossIn = 0;
    }
    if (st.boss && st.boss.state !== 'pop') {
      ui.bossIn = Math.min(1, ui.bossIn + 1 / 30);
      const o = st.boss, bw = 170, bx = Math.round(X0 + w / 2 - bw / 2), by = Math.round(lerp(-30, 16, ease(ui.bossIn)));
      plate(g, bx - 4, by - 2, bw + 8, 30, '#2a0c16', INK);
      Txt.draw(g, o.def.name, bx + 4, by + 1, { color: C.red });
      Txt.draw(g, R.num(Math.max(0, o.hp)) + ' / ' + R.num(o.maxHp), bx + bw - 4, by + 1, { align: 'right', color: C.text });
      // 掉的那截先白着（hpLag），停一下再缩到现在的血
      const lag = o.hpLag != null ? o.hpLag : o.hp;
      barRaw(g, bx, by + 16, bw, 9, lag / o.maxHp, '#ffffff', '#4a1018');
      const hw = Math.round((bw - 2) * clamp(o.hp / o.maxHp, 0, 1));
      if (hw > 0) { g.fillStyle = o.flash > 0 ? '#ffd0c8' : '#fe4c40'; g.fillRect(bx + 1, by + 17, hw, 7); }
    }
  }
  // split：推近看的那张（台面那一层留给 present 在屏幕真分辨率上画）；不 split：桌上那张（mainBuf，原生大小直接画）
  function drawMainCard(g, split) {
    A.setCard('swamp');
    if (!split) drawWorld(g, 1, 0);
    drawFrame(g);
    drawTable(g);
    drawTop(g);
  }
  function renderMainBuf() {
    mctx.imageSmoothingEnabled = false;
    mctx.clearRect(0, 0, W, H);
    drawMainCard(mctx);
  }

  // =========================================================================
  // 小游戏的卡（4 倍）
  // =========================================================================
  const CLOTH = {};
  function clothCanvas(w) {
    if (CLOTH[w]) return CLOTH[w];
    const c = document.createElement('canvas'); c.width = w + 8; c.height = 90;
    MD.cloth(c.getContext('2d'), 4, 4, w, 84);
    return (CLOTH[w] = c);
  }
  function drawMiniCard(id) {
    A.setCard(id);
    if (!R.miniOpen(S, id)) return;
    ctx.drawImage(miniCard(id), 0, 0);
    const c = ctrl(id);
    if (c) c.draw(ctx);   // 卡底下不写提示：怎么打开台那通电话讲过；弹珠打光了右栏那一盒会闪
  }

  // =========================================================================
  // 桌子那一屏
  // =========================================================================
  // cam：镜头（FULL 是整张桌子）；liveMain：先把斩草除根重画进 mainBuf；skip：这一台不画（机台界面里它另画在上面）
  function drawDeskScene(cam, liveMain, skip) {
    const dc = desk();
    ctx.imageSmoothingEnabled = false;
    if (cam.z === 1) ctx.drawImage(dc, 0, 0);
    else ctx.drawImage(dc, cam.x, cam.y, cam.w, cam.h, 0, 0, W, H);
    const place = r => { const [x, y] = MD.toScreen(cam, r.x, r.y); return { x, y, w: r.w * cam.z, h: r.h * cam.z }; };
    const flat = cam.z === 1 && !ui.tr;
    // 摆件：金币罐（铜名牌上写着多少金币）、战利品（摆在柜台顶上）；桌上那几件能点
    if (cam.z === 1) {
      const O = MD.OBJ;
      if (S.earned > 0) {
        MD.jar(ctx, O.jar.x, O.jar.y, clamp(Math.log10(S.gold + 1) / 4, 0.04, 1));
        MD.goldPlate(ctx, O.jar.x + O.jar.w / 2, MD.PLATE_Y, R.num(Math.max(0, S.gold - ui.flying)));
      }
      let tx = O.shop.x + 8;
      for (const k of Object.keys(S.trophies)) { if (k === 'grassKing') ctx.drawImage(MA.CROWN, tx, O.shop.y - MA.CROWN.height * 2 + 2, MA.CROWN.width * 2, MA.CROWN.height * 2); tx += 30; }
      if (flat) deskObjs();
    }
    // 电话（跟着镜头一起缩放）
    {
      const rg = !!ringing(), PH = MD.PHONE;
      ctx.save(); ctx.translate(-cam.x * cam.z, -cam.y * cam.z); ctx.scale(cam.z, cam.z);
      MD.phone(ctx, PH.x, PH.y, rg, ui.time);
      ctx.restore();
      if (flat && rg) {
        hit('phone', PH.x - 6, PH.y - 4, PH.w + 12, PH.h + 8, () => answer());
        if (ui.intro && Math.sin(ui.time * 5) > -0.2) Txt.draw(ctx, '接电话', PH.x + PH.w / 2, PH.y - 18, { align: 'center', color: C.gold });
      }
    }
    // 小游戏
    for (const M of D.MINIS) {
      if (!R.miniShown(S, M.id) || M.id === skip) continue;
      const z = cam.z, r = place(MD.deskRect(M.id)), open = R.miniOpen(S, M.id), hot = flat && ui.hover === 'card:' + M.id;
      const up = hot ? -2 : 0;
      if (hot) { ctx.save(); ctx.globalAlpha = 0.9; ctx.drawImage(tint(MD.cardMask(MD.cw(M.id)), U.C.yellow), r.x - 2, r.y - 2 + up, r.w + 4, r.h + 4); ctx.restore(); }
      ctx.drawImage(deskCard(M.id), Math.round(r.x), Math.round(r.y + up), Math.round(r.w), Math.round(r.h));
      // 红布：没开的盖着；正在开的往上掀走
      const op = ui.opening && ui.opening.id === M.id ? ease(ui.opening.t / 0.55) : null;
      if (!open || op != null) {
        const cc = clothCanvas(MD.cw(M.id));
        ctx.save();
        if (op != null) ctx.globalAlpha = 1 - op;
        ctx.drawImage(cc, Math.round(r.x - 4 * z), Math.round(r.y - 4 * z + up - (op || 0) * 140), Math.round(cc.width * z), Math.round(cc.height * z));
        ctx.restore();
      }
      if (z !== 1) continue;
      if (!open) {
        // 价签：开台就是买第一盒弹珠
        const p = R.boxPrice(S, M.id), ts = R.num(p), tw = Txt.width(ts, 12) + 16;
        const dx = ui.deny && ui.deny.what === 'open:' + M.id ? Math.round(Math.sin(ui.deny.t * 60) * 2) : 0;
        MD.tag(ctx, Math.round(r.x + r.w / 2 - tw / 2) + dx, r.y + 30 + up, ts, S.gold < p);
      } else if (op == null) {
        // 雇了小人：卡右边站着一个（打光了蹲着不动）。奖券数在左栏钱箱里，卡上不写
        const m = S.mini[M.id];
        if (R.hasHelper(S, M.id)) { const rb = A.robotCanvas(M18(M.id).kind), bob = !m.bot.idle && m.bot.play && Math.sin(ui.time * 6 + r.x) > 0 ? -1 : 0; ctx.drawImage(rb, r.x + r.w - 10, r.y + 60 + bob, rb.width, rb.height); }
        // 名牌正下方一摞券（越多摞得越高，最多四张）+ 几张，跟名牌居中对齐
        const tk = MA.ticket(M.id), nt = Math.min(4, 1 + Math.floor(Math.log10(m.chips + 1))), ns = R.num(m.chips);
        const pw = tk.width + 3 + Txt.width(ns, 12), p0 = Math.round(r.x + r.w / 2 - pw / 2);
        for (let i = 0; i < nt; i++) ctx.drawImage(tk, p0 + (i % 2), r.y + 111 - i * 2);
        Txt.draw(ctx, ns, p0 + tk.width + 3, r.y + 109, { color: flashing('wt:' + M.id, 0.3) ? '#ffffff' : MA.TIX[M.id].pal[0] });
      }
      if (flat && !ui.opening && !ui.intro) hit('card:' + M.id, r.x, r.y, r.w, r.h + 20, () => (open ? lift(M.id) : openMini(M.id)));
    }
    // 斩草除根（活的：先画进 mainBuf，再缩到桌上的大小）
    if (liveMain) renderMainBuf();
    if (skip === 'main') return;
    const off = mainDrop();
    if (off === null) return;
    const mr = place(MD.deskRect('main')), hotM = flat && ui.hover === 'card:main';
    if (hotM) { ctx.save(); ctx.globalAlpha = 0.9; ctx.drawImage(tint(MD.cardMask(96), U.C.yellow), mr.x - 2, mr.y - 2, mr.w + 4, mr.h + 4); ctx.restore(); }
    ctx.imageSmoothingEnabled = cam.z === 1;
    ctx.drawImage(mainBuf, 128, 12, 384, 336, mr.x, mr.y + off, mr.w, mr.h);
    ctx.imageSmoothingEnabled = false;
    if (flat && !ui.intro) hit('card:main', mr.x, mr.y, mr.w, mr.h, () => lift('main'));
  }
  // 桌上那几件：有了才摆（柜台：露了弹珠的东西；金币罐：露了金币的东西；打卡钟：雇了小人；闹钟：能转生了）
  const objsOn = () => [shopOn() && 'shop', jarOn() && 'jar', R.anyHelper(S) && 'clock', ptOn() && 'alarm'].filter(Boolean);
  // 点得到的框（连底下那排名牌；最窄 40，跟名牌一样宽）
  function objRect(k) {
    const o = MD.OBJ[k], top = o.y - (k === 'clock' ? 8 : 0), bw = Math.max(o.w, 40);
    return { x: Math.round(o.x + o.w / 2 - bw / 2), y: top, w: bw, h: MD.PLATE_Y + 14 - top };
  }
  // 那一件里有没有买得起的（绿点）
  function objCan(k) {
    if (k === 'shop') return shopCats().some(c => catNodes(c).some(n => R.state(S, n) === 'can'));
    if (k === 'jar') return goldVis().some(n => R.state(S, n) === 'can');
    if (k === 'clock') { const c = R.speedCost(S); return c != null && S.gold >= c; }
    if (k === 'alarm') return !!S.canPrestige || D.PERKS.some(p => { const c = R.perkCost(S, p.id); return !p.free && c != null && R.perkOpen(S, p.id) && S.pp >= c; });
    return false;
  }
  const deskHas = () => anyShown() || objsOn().length > 0;
  // 桌上才点得到的有买得起的（"回桌上"亮）：闹钟（转生）。柜台、金币罐、打卡钟、没开的那台在左栏自己亮，一样事不亮两处
  const deskOnlyCan = () => objsOn().includes('alarm') && objCan('alarm');
  function openObj(k) { return k === 'alarm' ? openPTree() : openPage(k); }
  // 一圈 1 格的框
  function frame(x, y, w, h, col) { ctx.fillStyle = col; ctx.fillRect(x, y, w, 1); ctx.fillRect(x, y + h - 1, w, 1); ctx.fillRect(x, y, 1, h); ctx.fillRect(x + w - 1, y, 1, h); }
  // 指着描黄边，冒了新的闪白边，有买得起的挂绿点；闹钟能转生还没看过挂红点
  function deskObjs() {
    if (ui.opening || ui.intro) return;
    for (const k of objsOn()) {
      const r = objRect(k), id = 'obj:' + k, hot = ui.hover === id;
      const fl = (flashing(id, 3) || (k === 'alarm' && ui.ppFlash > 0)) && Math.sin(ui.time * 10) > 0;
      if (hot || fl) frame(r.x - 3, r.y - 3, r.w + 6, r.h + 6, fl ? '#ffffff' : U.C.yellow);
      if (k === 'alarm' && S.canPrestige && !S.seen.prestigeTab) { ctx.fillStyle = INK; ctx.fillRect(r.x + r.w - 1, r.y - 4, 7, 7); ctx.fillStyle = U.C.red; ctx.fillRect(r.x + r.w, r.y - 3, 5, 5); }
      else if (objCan(k)) U.dot(ctx, r.x + r.w - 1, r.y - 4);
      hit(id, r.x - 3, r.y - 3, r.w + 6, r.h + 6, () => openObj(k));
    }
  }
  const tintCache = new Map();
  function tint(c, col) {
    const k = c.width + 'x' + c.height + col;
    if (!tintCache.has(k)) { const t = document.createElement('canvas'); t.width = c.width; t.height = c.height; const g = t.getContext('2d'); g.drawImage(c, 0, 0); g.globalCompositeOperation = 'source-in'; g.fillStyle = col; g.fillRect(0, 0, t.width, t.height); tintCache.set(k, t); }
    return tintCache.get(k);
  }
  // 镜头推近 / 拉远：整张桌子（连卡）一起变
  function drawTransition() {
    const tr = ui.tr, k = easeIO(tr.t / tr.dur), target = MD.camFor(tr.id);
    const cam = tr.kind === 'lift' ? MD.lerpCam(MD.FULL, target, k) : MD.lerpCam(target, MD.FULL, k);
    drawDeskScene(cam, true);
  }

  // =========================================================================
  // 两边栏：一帧画一遍，能点的地方记进 HITS（下一下点的时候用）
  // =========================================================================
  let HITS = [];
  function hit(id, x, y, w, h, go, o) { HITS.push(Object.assign({ id, x, y, w, h, go }, o || {})); }
  const hitIn = (h, p) => p.x >= h.x && p.y >= h.y && p.x < h.x + h.w && p.y < h.y + h.h;
  const flashing = (k, dur) => ui.flash[k] != null && ui.time - ui.flash[k] < (dur || 0.3);
  const panelsOn = () => S.earned > 0;
  const shakeOf = id => (ui.deny && ui.deny.what === id ? Math.round(Math.sin(ui.deny.t * 60) * 2) : 0);
  // 栏里的一行（技能行的画法）：画、记点击，返回占多高（连行距）。rep：按住连着买（go(true) 是后几下）
  // 新冒出来的一行：在自己那一格里从下往上滑进来（SLIDE_T 秒），底下那几行不动
  const SLIDE_T = 0.28;
  function panelRow(o, x, y, w, ox, box, go, rep) {
    o.hot = o.hot || ui.hover === o.id;
    o.down = pressing(o.id); o.t = ui.time;
    const rt = o.rv != null ? (ui.time - o.rv) / SLIDE_T : 1, slide = rt >= 0 && rt < 1;
    if (slide) { ctx.save(); ctx.beginPath(); ctx.rect(x - 4, y, w + 8, U.ROW_H + 1); ctx.clip(); }
    const h = U.skillRow(ctx, x + shakeOf(o.id), y + (slide ? Math.round((1 - ease(rt)) * (U.ROW_H + 1)) : 0), w, o);
    if (slide) ctx.restore();
    if (go && y + h > box.y && y < box.y + box.h) hit(o.id, x + ox, y, w, h, go, rep ? { rep: true } : null);
    return h + 3;
  }

  // 两边栏底下垫一条桌子（跟着栏一起滑进来）：推近以后旁边的台子不从栏缝里露出来
  function sideStrips() {
    if (!panelsOn() || ui.intro) return;
    const dc = MD.plain();
    if (ui.slideL > 0) ctx.drawImage(dc, 0, 0, 122, H, Math.round(-124 * (1 - ease(ui.slideL))), 0, 122, H);
    if (ui.slideR > 0) ctx.drawImage(dc, 518, 0, 122, H, 518 + Math.round(124 * (1 - ease(ui.slideR))), 0, 122, H);
  }
  function scrollBar(x, y, h, at, max) {
    const bh = Math.max(16, Math.round(h * h / (h + max))), by = Math.round(y + (h - bh) * at / max);
    ctx.fillStyle = '#141a36'; ctx.fillRect(x, y, 2, h);
    ctx.fillStyle = '#8a96c0'; ctx.fillRect(x, by, 2, bh);
  }

  // ---------- 左上角：回桌上 / 接电话 ----------
  // 听筒：一道拱，两头朝下是听的、说的那两个碗
  const HANDSET = A.outlined(['..xxxxxxxxx..', '.xhhhhhhhhhx.', 'xxx.......xxx', 'xxx.......xxx'], { x: '#e8343a', h: '#ff8a7a' }, INK);
  function backBtn() {
    if (ui.intro) return null;
    if (ringing()) return { label: '接电话', go: () => answer(), ring: true };
    if (ui.view === 'card' && !ui.tr && (deskHas() || ui.cur !== 'main')) return { label: '回桌上', go: () => drop(), flash: ui.deskFlash > 0, lit: deskOnlyCan() };
    return null;
  }
  // 往回的箭头（回桌上）
  const BACK_ARROW = A.outlined(['.....x', '....xx', '...xxx', '..xxxx', '.xxxxx', 'xxxxxx', '.xxxxx', '..xxxx', '...xxx', '....xx', '.....x'], { x: '#ffffff' }, INK);
  const BACK_ARROW_D = A.sprite(['.....x', '....xx', '...xxx', '..xxxx', '.xxxxx', 'xxxxxx', '.xxxxx', '..xxxx', '...xxx', '....xx', '.....x'], { x: '#3a2410' });
  // 刚按的那个按钮：按着不放、或者松手后 0.12 秒内，键帽落下去
  const pressing = id => !!ui.press && ui.press.id === id && (ui.press.held || ui.time - ui.press.t < 0.12);
  function drawBack() {
    const b = backBtn(), k = ease(ui.backIn);
    if (!b || k < 0.05) return;
    const x = BACK.x + Math.round(-124 * (1 - k)), y = BACK.y, fl = b.flash && Math.sin(ui.time * 8) > 0;
    const f = U.key(ctx, x, y, BACK.w, BACK.h, { kind: b.ring ? 'red' : b.lit ? 'lit' : 'idle', hot: ui.hover === 'back', down: pressing('back'), flash: fl, t: ui.time });
    if (b.ring) {
      const jig = Math.floor(ui.time * 22) % 2 ? 1 : -1, hop = Math.floor(ui.time * 11) % 2 ? -1 : 0;
      ctx.drawImage(HANDSET, f.x + 5 + jig, f.y + 4 + hop, HANDSET.width * 2, HANDSET.height * 2);
      Txt.draw(ctx, b.label, f.x + f.w / 2 + 12, f.y + 1, { align: 'center', size: 16, color: f.P.ink, outline: f.P.out });
    } else {
      const ar = b.lit ? BACK_ARROW_D : BACK_ARROW;
      ctx.drawImage(ar, f.x + 6 + (b.lit ? 1 : 0), f.y + Math.round((f.h - ar.height) / 2));
      Txt.draw(ctx, b.label, f.x + f.w / 2 + 6, f.y + 1, { align: 'center', size: 16, color: f.P.ink, outline: f.P.out });
    }
    hit('back', x, y, BACK.w, BACK.h, b.go);
  }

  // ---------- 左栏：钱箱（一种钱一行，点一行去那台）+ 桌上那几件的小图标（点了开同一页，镜头不动） ----------
  // 红布（钱箱里还没开的那台）
  const CLOTH_ICON = A.outlined(['hhhhhhhhhhh', 'rrrrrrrrrrr', 'rrrhrrrrrrr', 'rrrrrrrrrrr', 'rrrrrrrhrrr', 'ddddddddddd', 'd.d.d.d.d.d'], { h: '#e85a6a', r: '#c8364a', d: '#8a2030' }, INK);
  // 那台有没有买得起的（钱箱里的绿点）：那台的节点；小游戏弹珠打光了，再看买不买得起一盒
  function canBuyAt(where) {
    for (const n of D.NODES) if (n.where === where && R.visible(S, n) && R.state(S, n) === 'can') return true;
    return where !== 'main' && R.miniOpen(S, where) && S.mini[where].marbles <= 0 && S.gold >= R.boxPrice(S, where);
  }
  // 钱箱里的台（Tab 照这个顺序换）：斩草除根（金币那块）、开了的小游戏（一种券一行）
  const walletIds = () => ['main'].concat(D.MINIS.filter(M => R.miniOpen(S, M.id)).map(M => M.id));
  const curMachine = () => (ui.view === 'card' && !ui.tr ? ui.cur : null);
  // 上了桌还没开的头一台（钱箱最底下挂着）
  const nextShut = () => D.MINIS.find(M => R.miniShown(S, M.id) && !R.miniOpen(S, M.id)) || null;
  function goMachine(id) {
    if (curMachine() === id) return false;
    if (!lift(id)) return false;
    sfx.tab();
    return true;
  }
  // Tab：照钱箱的顺序换台（只有斩草除根的时候在桌子和它之间来回）
  function cycleMachine(dir) {
    const ids = walletIds();
    if (ui.view !== 'card') return lift(ids.includes(ui.cur) ? ui.cur : 'main');
    if (ids.length <= 1) { if (deskHas()) drop(); return false; }
    const i = Math.max(0, ids.indexOf(ui.cur));
    return goMachine(ids[(i + (dir || 1) + ids.length) % ids.length]);
  }
  // 左栏的键帽：金币那块（有了别的台才是按钮）、一种券一行、没开的那台、桌上那几件
  const GOLD_H = 36, ROW_H = 22, LOCK_H = 33, DOCK_W = 36, DOCK_H = 38;
  // 那台的按钮什么样：在这台按进去，那台有买得起的亮黄，不然深蓝
  const keyKind = (id, can) => (curMachine() === id ? 'cur' : can ? 'lit' : 'idle');
  function drawLeft() {
    if (ui.slideL <= 0.001) return;
    const ox = Math.round(-124 * (1 - ease(ui.slideL)));
    ctx.save(); ctx.translate(ox, 0);
    const x = LEFT.x, w = LEFT.w, my = moneyY(), bump = flashing('coinIn', 0.08) ? 2 : flashing('out:gold', 0.08) ? -2 : 0;
    walletAt.gold = GOLD_AT();
    const shown = Math.max(0, S.gold - ui.flying);
    const minis = D.MINIS.filter(M => R.miniOpen(S, M.id)), shut = nextShut(), switcher = minis.length > 0 || !!shut;
    let y;
    if (!switcher) {
      // 只有斩草除根：钱箱是块木牌，只看不点（没有按钮底下那道厚边）
      const deep = S.runs > 0 ? '最深 ' + R.stage(S.best.stage).name + ' ' + S.best.layer + ' 层' : '金币';
      U.moneyBox(ctx, x, my - bump, w, R.num(shown), deep, MA.COIN);
      y = my + 43;
    } else {
      // 金币那块就是斩草除根的按钮：金币 + 数，底下台名
      const id = 'w:main', kind = keyKind('main', canBuyAt('main'));
      const f = U.key(ctx, x + shakeOf(id), my - bump, w, GOLD_H, { kind, hot: ui.hover === id, down: pressing(id), t: ui.time, notch: kind === 'cur' });
      ctx.drawImage(MA.COIN, f.x + 4, f.y + 3, MA.COIN.width * 2, MA.COIN.height * 2);
      Txt.draw(ctx, R.num(shown), f.x + 21, f.y + 1, { size: 16, color: kind === 'lit' ? f.P.ink : U.C.yellow, outline: f.P.out });
      Txt.draw(ctx, MAIN_NAME, f.x + 21, f.y + 17, { color: f.P.sub, outline: f.P.out });
      hit(id, x + ox, my, w, GOLD_H, () => goMachine('main'));
      y = my + GOLD_H + 3;
      // 开了的小游戏：一种券一行（票、几张、台名）
      for (const M of minis) {
        const mid = M.id, wid = 'w:' + mid, k2 = keyKind(mid, canBuyAt(mid)), fl = flashing(wid, 1.2) && Math.sin(ui.time * 16) > 0;
        const tb = flashing('tin:' + mid, 0.08) ? 2 : flashing('out:t:' + mid, 0.08) ? -2 : 0;
        const r = U.key(ctx, x + shakeOf(wid), y - tb, w, ROW_H, { kind: k2, hot: ui.hover === wid, down: pressing(wid), flash: fl, t: ui.time, notch: k2 === 'cur' });
        const tk = MA.ticket(mid);
        ctx.drawImage(tk, r.x + 3, r.y + Math.round((r.h - tk.height * 2) / 2), tk.width * 2, tk.height * 2);
        walletAt['t:' + mid] = { x: r.x + 3 + tk.width + ox, y: y + Math.round(ROW_H / 2) };
        const vc = k2 === 'lit' ? r.P.ink : k2 === 'cur' || flashing('wt:' + mid, 0.3) ? '#ffffff' : MA.TIX[mid].pal[0];
        Txt.draw(ctx, R.num(Math.max(0, Math.round(S.mini[mid].chips - (ui.tixFly[mid] || 0)))), r.x + 6 + tk.width * 2, r.y + 2, { color: vc, outline: r.P.out });
        Txt.draw(ctx, M.name, r.x + r.w - 4, r.y + 2, { align: 'right', color: r.P.sub, outline: r.P.out });
        hit(wid, x + ox, y, w, ROW_H, () => goMachine(mid));
        y += ROW_H + 3;
      }
      // 上了桌还没开的那台：红布、台名、开台价；钱够了整块亮黄，不够红字 + 一条攒到几成
      if (shut) {
        const sid = shut.id, wid = 'w:' + sid, p = R.boxPrice(S, sid), ok = S.gold >= p, fl = flashing(wid, 1.2) && Math.sin(ui.time * 16) > 0;
        const r = U.key(ctx, x + shakeOf(wid), y, w, LOCK_H, { kind: ok ? 'lit' : 'idle', hot: ui.hover === wid, down: pressing(wid), flash: fl, t: ui.time });
        ctx.drawImage(CLOTH_ICON, r.x + 2, r.y + Math.round((r.h - CLOTH_ICON.height * 2) / 2), CLOTH_ICON.width * 2, CLOTH_ICON.height * 2);
        Txt.draw(ctx, shut.name, r.x + 31, r.y + 1, { color: r.P.ink, outline: r.P.out });
        ctx.drawImage(MA.COIN, r.x + 31, r.y + 17);
        const px = r.x + 31 + MA.COIN.width + 2, tw = Txt.draw(ctx, R.num(p), px, r.y + 15, { color: ok ? r.P.ink : U.C.red, outline: r.P.out });
        if (!ok) { const bx = px + tw + 4, bw = r.x + r.w - 4 - bx; if (bw >= 12) U.bar(ctx, bx, r.y + 19, bw, 6, S.gold / p, U.C.bar); }
        hit(wid, x + ox, y, w, LOCK_H, () => openFromWallet(sid));
        y += LOCK_H + 3;
      }
    }
    // 桌上那几件：柜台、金币罐、打卡钟（闹钟不放，转生在桌上点）；里面有买得起的整块亮黄
    const dk = objsOn().filter(k => k !== 'alarm');
    if (dk.length) {
      y += 2;
      const gap = Math.floor((w - DOCK_W * 3) / 2);
      dk.forEach((k, i) => {
        const bx = x + i * (DOCK_W + gap), id = 'dock:' + k, fl = flashing(id, 3) && Math.sin(ui.time * 10) > 0;
        const r = U.key(ctx, bx + shakeOf(id), y, DOCK_W, DOCK_H, { kind: objCan(k) ? 'lit' : 'idle', hot: ui.hover === id, down: pressing(id), flash: fl, t: ui.time });
        const ic = MD.icon(k);
        ctx.drawImage(ic, r.x + Math.round((r.w - ic.width) / 2), r.y + 2);
        Txt.draw(ctx, DOCK_NAME[k], r.x + r.w / 2, r.y + r.h - 13, { align: 'center', color: r.P.ink, outline: r.P.out });
        hit(id, bx + ox, y, DOCK_W, DOCK_H, () => openPage(k));
      });
    }
    ctx.restore();
  }
  // 小人页：每台的开关（自动打、自动买），底下小人速率（全局，花金币）
  function drawHelpers(x, y0, w, ox, box) {
    let y = y0;
    for (const M of D.MINIS) {
      const m = S.mini[M.id];
      if (!R.hasHelper(S, M.id)) continue;
      const auto = R.hasAuto(S, M.id), bh = auto ? 56 : 36, hid = 'bp:' + M.id;
      // 还没有自动买：整张是"打 / 歇着"的开关（打着按进去、绿的）；有了：一张牌子，底下两个开关
      let fx = x, fy = y, P = null;
      if (auto) U.rr(ctx, x, y, w, bh, U.C.navy, INK, 2, U.C.navyHi, U.C.navyLo);
      else { const fk = U.key(ctx, x, y, w, bh, { kind: m.bot.play ? 'on' : 'idle', hot: ui.hover === hid, down: pressing(hid) }); fx = fk.x - 1; fy = fk.y - 1; P = fk.P; }
      const rb = A.robotCanvas(M18(M.id).kind);
      ctx.drawImage(rb, fx + 3, fy + 3);
      Txt.draw(ctx, M.name, fx + 24, fy + 2, { color: P ? P.ink : U.C.text, outline: P ? P.out : INK });
      const st = !m.bot.play ? ['歇着', U.C.dim] : m.bot.idle ? ['弹珠打光了', U.C.red] : ['在打 · 剩 ' + m.marbles, U.C.green2];
      Txt.draw(ctx, st[0], fx + 24, fy + 17, { color: P && P.out === null && st[1] !== U.C.red ? P.sub : st[1], outline: P ? P.out : INK });
      if (auto) {
        const tw = Math.floor((w - 12) / 2), TH = U.TOGGLE_H;
        U.toggle(ctx, x + 4, y + 34, tw, '自动打', m.bot.play, ui.hover === hid, pressing(hid));
        U.toggle(ctx, x + 8 + tw, y + 34, tw, '自动买', m.bot.buy, ui.hover === 'bb:' + M.id, pressing('bb:' + M.id));
        if (y + 34 > box.y && y + 34 + TH < box.y + box.h) {
          hit(hid, x + 4 + ox, y + 34, tw, TH, () => { m.bot.play = !m.bot.play; m.bot.idle = false; sfx.tab(); save(); });
          hit('bb:' + M.id, x + 8 + tw + ox, y + 34, tw, TH, () => { m.bot.buy = !m.bot.buy; sfx.tab(); save(); });
        }
      } else if (y + bh > box.y && y < box.y + box.h) hit('bp:' + M.id, x + ox, y, w, bh, () => { m.bot.play = !m.bot.play; m.bot.idle = false; sfx.tab(); save(); });
      y += bh + 3;
    }
    // 小人速率
    const c = R.speedCost(S), l = S.helperSpeed, V = D.HELPER_SPEED.vals, mx = D.HELPER_SPEED.costs.length;
    const o = { id: 'speed', teal: false, icon: MA.nodeIcon('helper'), lv: l, lvMax: mx, state: c == null ? 'max' : S.gold >= c ? 'can' : 'poor' };
    if (c == null) { o.done = '满了'; o.text = '小人打得快 ' + Math.round((V[mx] - V[0]) * 100) + '%'; }
    else { o.price = { n: R.num(c), icon: MA.COIN, poor: S.gold < c }; o.text = '小人打得快 ' + Math.round((V[l + 1] - V[l]) * 100) + '%'; }
    y += panelRow(o, x, y, w, ox, box, () => { if (R.buySpeed(S)) { sfx.buy(); sfx.upgrade(); flashKey('speed'); spendFly({ gold: c }, 'speed'); save(); } else { deny('speed'); if (c != null) toast('还差 ' + R.num(c - S.gold) + ' 金币', C.red); } });
    return y - y0;
  }
  // ---------- 右栏：齿轮 + 升级（斩草除根的场景那几类；拿着小游戏换成这台的）。弹珠的在桌上柜台 ----------
  function drawRight() {
    // 齿轮（暂停、声音）：开场完了一直在
    if (!ui.intro) { U.gear(ctx, 612, 4, ui.hover === 'gear', pressing('gear')); hit('gear', 612, 4, 24, 22, () => { ui.paused = true; leaveInputs(); }); }
    // 扳手（作者来电送的）：开发者工具
    // 作者说到"右上角那把扳手"那句，扳手就先亮出来闪着（挂了电话才点得开）
    const wrenchLine = ui.call && ui.call.k === 'creator' && ui.call.i >= D.CALLS.creator.lines.findIndex(s => s.includes('扳手'));
    if (wrenchLine) U.wrench(ctx, 584, 4, false, false, Math.sin(ui.time * 10) > 0);
    else if (!ui.intro && devOK()) { U.wrench(ctx, 584, 4, ui.hover === 'devtool', pressing('devtool'), ui.devFlash > 0 && Math.sin(ui.time * 10) > 0); hit('devtool', 584, 4, 24, 22, () => { ui.dev = true; ui.devFlash = 0; ui.devStage = 0; leaveInputs(); }); }
    if (ui.slideR <= 0.001) return;
    const mini = ui.view === 'card' && !ui.tr && ui.cur !== 'main' && R.miniOpen(S, ui.cur) ? ui.cur : null;
    const cats = mini ? [] : sceneCats(), cat = mini ? null : curCat(cats);
    if (!mini && !cat) return;
    const ox = Math.round(124 * (1 - ease(ui.slideR)));
    ctx.save(); ctx.translate(ox, 0);
    const x = RIGHT.x, w = RIGHT.w;
    const inner = U.tealPanel(ctx, x, 28, w, H - 32, mini ? nameOf(mini) : cat.name);
    // 分类页签不跟着滚；底下这一类能滚
    const top = cats.length ? inner.y + catTabs(cats, cat, inner.x, inner.y + 3, inner.w, ox) + 5 : inner.y;
    const box = { x: inner.x, y: top, w: inner.w, h: inner.y + inner.h - top };
    if (cats.length) { ctx.fillStyle = U.C.tealRow; ctx.fillRect(inner.x, top - 2, inner.w, 1); }
    ctx.save(); ctx.beginPath(); ctx.rect(inner.x - 2, top, inner.w + 4, box.h); ctx.clip();
    const y0 = top + 3 - ui.scrollR;
    const hgt = mini ? drawMiniPanel(mini, inner.x, y0, inner.w, ox, box) : drawTree(cat, inner.x, y0, inner.w, ox, box);
    ctx.restore();
    ui.maxR = Math.max(0, hgt + 6 - box.h);
    ui.scrollR = clamp(ui.scrollR, 0, ui.maxR);
    if (ui.maxR > 0) scrollBar(x + w - 3, top + 2, box.h - 4, ui.scrollR, ui.maxR);
    hit('scroll:R', x + ox, top, w, box.h, null, { wheel: 'R' });
    ctx.restore();
  }
  // 斩草除根的树：先挑一类（data.js 的 CATS），这一类一组一段（头一组不写组名，复活另起小标题）；
  //   组里没买满的照表上的顺序；买满的收进最底下"买满了（N）"（点一下展开）
  // 金币罐那一页的节点（金币那几样）：露着的
  const goldVis = () => D.NODES.filter(n => n.where === 'main' && D.GROUPS[n.group] && D.GROUPS[n.group].desk === 'jar' && R.visible(S, n));
  // 这一类露着的节点；有露着的才出页签
  const catNodes = c => D.NODES.filter(n => n.where === 'main' && c.groups.includes(n.group) && R.visible(S, n));
  const catsOn = () => D.CATS.filter(c => catNodes(c).length > 0);
  const sceneCats = () => catsOn().filter(c => c.kind === 'scene');
  // 柜台里卖的弹珠（挣到第一枚金币以后）；柜台、金币罐有东西才摆上桌
  const shopCats = () => (S.earned > 0 ? catsOn().filter(c => c.kind === 'ball') : []);
  const shopOn = () => shopCats().length > 0;
  const jarOn = () => S.earned > 0 && goldVis().length > 0;
  const catLive = c => catNodes(c).some(n => R.state(S, n) !== 'max');
  // 挑着的那类：没挑过才挑头一个还有东西买的；点进一类就待着（买满了也不跳走）。key：右栏 cat、柜台 shopCat
  function curCat(list, key) {
    key = key || 'cat';
    if (!list.length) return null;
    let c = list.find(k => k.id === ui[key]);
    if (!c) c = list.find(catLive) || list[0];
    ui[key] = c.id;
    return c;
  }
  // 分类页签：一类一格（图标），挑着的按进去，别的类有买得起的亮黄、冒了新的闪白边。返回多高
  function catTabs(cats, cat, x, y, w, ox) {
    const n = cats.length, gap = 2, tw = Math.min(24, Math.floor((w - gap * (n - 1)) / n)), th = 22;
    cats.forEach((c, i) => {
      const tx = x + i * (tw + gap), on = c.id === cat.id, id = 'cat:' + c.id, hot = ui.hover === id;
      const fl = !on && flashing(id, 1.6) && Math.sin(ui.time * 16) > 0;
      // 挑着的按进去；别的类里有买得起的整块亮黄
      const kind = on ? 'cur' : catNodes(c).some(nn => R.state(S, nn) === 'can') ? 'lit' : 'idle';
      const f = U.key(ctx, tx, y, tw, th, { kind, hot, down: pressing(id), flash: fl, t: ui.time });
      const ic = MA.nodeIcon(c.icon);
      ctx.drawImage(ic, Math.round(f.x + (f.w - ic.width) / 2), Math.round(f.y + (f.h - ic.height) / 2));
      hit(id, tx + ox, y, tw, th, () => { if (ui.cat !== c.id) { ui.cat = c.id; ui.scrollR = 0; ui.showMax = false; sfx.tab(); } return true; });
    });
    return th;
  }
  function drawTree(cat, x, y0, w, ox, box) {
    let y = y0;
    if (!cat) { Txt.block(ctx, '碎史莱姆挣金币，这里就有东西买', x + 4, y + 4, w - 8, { color: U.C.dim }); return 40; }
    const vis = catNodes(cat), done = vis.filter(n => R.state(S, n) === 'max');
    cat.groups.forEach((g, i) => {
      const live = vis.filter(n => n.group === g && R.state(S, n) !== 'max');
      if (!live.length) return;
      if (i > 0) y += groupHead(D.GROUPS[g], x, y);
      for (const n of live) y += nodeRow(n, x, y, w, ox, box);
    });
    if (done.length) y += maxedFold(done, x, y, w, ox, box);
    return y - y0;
  }
  // 小标题（黄字）
  function groupHead(G, x, y) {
    Txt.draw(ctx, G.name, x + 2, y + 1, { color: U.C.yellow });
    return 15;
  }
  // 买满了的收起来（主线的树、小游戏的栏、桌上那几页共用一个开关）。ncol：展开以后摆几栏（柜台 2）
  function maxedFold(done, x, y, w, ox, box, col, ncol) {
    const id = 'showMax', hh = 19, y0 = y;
    const fk = U.key(ctx, x, y, w, hh, { kind: ui.showMax ? 'cur' : 'idle', hot: ui.hover === id, down: pressing(id) });
    Txt.draw(ctx, (ui.showMax ? '▲ ' : '▼ ') + '买满了（' + done.length + '）', fk.x + fk.w / 2, fk.y + 1, { align: 'center', color: U.C.yellow });
    if (y + hh > box.y && y < box.y + box.h) hit(id, x + ox, y, w, hh, () => { ui.showMax = !ui.showMax; sfx.tab(); });
    y += hh + 3;
    if (ui.showMax) {
      const nc = ncol || 1, gap = 8, cw = nc > 1 ? Math.floor((w - gap) / 2) : w;
      for (let i = 0; i < done.length; i += nc) {
        let rh = 0;
        for (let j = 0; j < nc && i + j < done.length; j++) rh = nodeRow(done[i + j], x + j * (cw + gap), y, cw, ox, box, col);
        y += rh;
      }
    }
    return y - y0;
  }
  // 这一级的价：金币、券，或者金币 + 券；不够的那一半标红
  function priceOf(o, n) {
    const p = R.price(S, n);
    if (!p) return;
    const l = R.lack(S, p), parts = [];
    if (p.gold > 0) parts.push({ n: R.num(p.gold), icon: MA.COIN, poor: l.gold });
    if (p.tix > 0) parts.push({ n: R.num(p.tix), icon: MA.ticket(p.tixId), poor: l.tix });
    o.price = parts[0];
    if (parts[1]) o.price2 = parts[1];
  }
  // 一个节点一行（斩草除根的、小游戏里头的一个画法）：一句话 + 价钱 + 几级，不写名字。col：图标那一栏多宽（小游戏的图标大，22）
  function nodeRow(n, x, y, w, ox, box, col) {
    const st = R.state(S, n), lvl = R.lv(S, n.id), mx = R.maxLv(n), id = 'node:' + n.id;
    const icon = n.icon ? MA.nodeIcon(n.icon) : A.upCanvas(n.tag, M18(n.where).chip);
    const o = { id, icon, iconScale: 1, col, text: R.effText(S, n), state: st, lv: lvl, lvMax: mx };
    if (flashing('n:' + n.id, 1.6)) o.flash = Math.sin(ui.time * 16) > 0;
    o.rv = ui.flash['rv:' + n.id];
    if (st === 'max') o.done = mx > 1 ? '满了' : R.isPart(n) ? '装上了' : '有了';
    else { priceOf(o, n); if (lvl === 0) o.tag = '新'; }
    return panelRow(o, x, y, w, ox, box, quiet => buyNode(n.id, quiet), true);
  }
  // 拿着小游戏：一盒弹珠（金币）、这台的节点（这台的券，有几样加金币）
  function drawMiniPanel(id, x, y0, w, ox, box) {
    const M = M18(id), MM = R.MBY[id], m = S.mini[id];
    let y = y0;
    {
      const p = R.boxPrice(S, id), o = { id: 'box', icon: A.marbleCanvas(M.marble), iconScale: 2, col: 22, text: '一盒 ' + MM.box + ' 颗', state: S.gold >= p ? 'can' : 'poor', price: { n: R.num(p), icon: MA.COIN, poor: S.gold < p }, note: '剩 ' + m.marbles, noteColor: m.marbles <= 0 ? C.red : null };
      o.kind = m.marbles <= 0 && S.gold >= p ? 'lit' : 'idle';
      if (flashing('box:' + id)) o.flash = true;
      y += panelRow(o, x, y, w, ox, box, quiet => buyBox(id, quiet), true);
    }
    const vis = R.miniNodes(id).filter(n => R.visible(S, n)), done = vis.filter(n => R.state(S, n) === 'max');
    for (const n of vis) if (R.state(S, n) !== 'max') y += nodeRow(n, x, y, w, ox, box, 22);
    if (done.length) y += maxedFold(done, x, y, w, ox, box, 22);
    return y - y0;
  }

  // =========================================================================
  // 桌上那几件打开的那一页（单开一屏，游戏停住；× / Esc / 点框外头关上）：柜台、金币罐、打卡钟。闹钟开的是转生树
  //   桌上点那一件、机台左边点小图标，开的是同一页
  // =========================================================================
  const DOCK_NAME = { shop: '柜台', jar: '金币', clock: '小人' };
  const PAGE_W = { shop: 480, jar: 248, clock: 256 };
  function openPage(k) {
    if (ui.page === k) return false;
    if (ui.ptree || ui.call || ui.tr || ui.opening || ui.intro || ui.confirm) return false;
    ui.page = k; ui.scrollS = 0; ui.showMax = false;
    leaveInputs(); sfx.tab();
    return true;
  }
  function closePage() { if (!ui.page) return false; ui.page = null; ui.rep = null; ui.showMax = false; sfx.tab(); return true; }
  // 框：顶上标题页签，右上角 ×，× 左边写着手上的钱（wallet）；返回里头那块
  function pageFrame(title, w, h, wallet) {
    const x = Math.round((W - w) / 2), y = Math.round((H - h) / 2);
    hit('pgout', 0, 0, W, H, () => closePage());
    hit('pgin', x, y, w, h, null);
    const inner = U.tealPanel(ctx, x, y, w, h, title);
    U.chip(ctx, x + w - 24, y, 22, 20, '×', ui.hover === 'pgclose', undefined, pressing('pgclose'));
    hit('pgclose', x + w - 24, y, 22, 20, () => closePage());
    if (wallet) {
      let wx = x + w - 30;
      for (let i = wallet.length - 1; i >= 0; i--) {
        const it = wallet[i], ns = R.num(it.n);
        wx -= Txt.width(ns, 12); Txt.draw(ctx, ns, wx, y + 3, { color: it.col });
        wx -= it.icon.width + 3; ctx.drawImage(it.icon, wx, y + 3 + Math.round((12 - it.icon.height) / 2));
        if (it.key) walletAt[it.key] = { x: wx + it.icon.width / 2, y: y + 9 };
        wx -= 10;
      }
    }
    return inner;
  }
  // 页里能滚的那一块：draw(y0, box) 画内容、返回多高
  function pageBody(x, top, w, h, draw) {
    const box = { x, y: top, w, h };
    ctx.save(); ctx.beginPath(); ctx.rect(x - 2, top, w + 4, h); ctx.clip();
    const hgt = draw(top - ui.scrollS, box);
    ctx.restore();
    ui.maxS = Math.max(0, hgt + 4 - h);
    ui.scrollS = clamp(ui.scrollS, 0, ui.maxS);
    if (ui.maxS > 0) scrollBar(x + w + 1, top, h, ui.scrollS, ui.maxS);
    hit('scroll:S', x, top, w, h, null, { wheel: 'S' });
  }
  function drawPage() {
    if (!ui.page) return;
    HITS = [];
    ctx.fillStyle = 'rgba(10,12,24,0.66)'; ctx.fillRect(0, 0, W, H);
    if (ui.page === 'shop') drawShop();
    else if (ui.page === 'jar') drawJar();
    else drawCrew();
  }
  // 这一类要哪种券（金币加券的那几样）
  function catTix(cat) {
    for (const n of catNodes(cat)) { const p = R.price(S, n); if (p && p.tix > 0) return p.tixId; }
    return null;
  }
  // 柜台：左边一竖排，一种弹珠一格（下一种还没露的挂一格"？"）；右边这一种：大图、名字、带着没带、一句脾气、花什么钱；
  //   底下两栏：养它（这颗球自己的数）、本事（球的本事）；只有一组有东西就对半分两栏。买满了的收在最底下
  function drawShop() {
    const list = shopCats(), cat = curCat(list, 'shopCat'), tix = cat && catTix(cat);
    const wallet = [{ key: 'gold', icon: MA.COIN, n: S.gold, col: U.C.gold }];
    if (tix) wallet.push({ key: 't:' + tix, icon: MA.ticket(tix), n: R.tixOf(S, tix), col: MA.TIX[tix].pal[0] });
    // 高照内容定（左边那一竖排、右边这一种哪个高按哪个），最高 340
    const L = cat && shopLayout(cat), RH = U.ROW_H + 3, more = D.CATS.some(c => c.kind === 'ball' && !list.includes(c));
    const bodyH = !L ? 0 : 15 + Math.max(0, ...L.cols.map(c => c.rows.length)) * RH + (L.done.length ? 26 + (ui.showMax ? Math.ceil(L.done.length / 2) * RH : 0) : 0);
    // 左边那排：六种以内一竖排大格；多了排两列小格（不然后面几种出了页底）
    const nCell = list.length + (more ? 1 : 0), two = nCell > 6, tw = two ? 56 : 60, th = two ? 38 : 44, nRow = Math.ceil(nCell / (two ? 2 : 1));
    const ph = clamp(27 + Math.max(nRow * (th + 4) + 4, 48 + bodyH + 8), 150, 340);
    const inner = pageFrame('柜台', PAGE_W.shop, ph, wallet);
    if (!cat) return;
    const tx = inner.x + 4, cellAt = i => (two ? [tx + (i % 2) * (tw + 4), inner.y + 4 + Math.floor(i / 2) * (th + 4)] : [tx, inner.y + 4 + i * (th + 4)]);
    list.forEach((c, i) => {
      const [cx, ty] = cellAt(i);
      const on = c.id === cat.id, id = 'shop:' + c.id, hot = ui.hover === id;
      const fl = !on && flashing(id, 3) && Math.sin(ui.time * 10) > 0;
      const kind = on ? 'cur' : catNodes(c).some(n => R.state(S, n) === 'can') ? 'lit' : 'idle';
      const f = U.key(ctx, cx, ty, tw, th, { kind, hot, down: pressing(id), flash: fl, t: ui.time });
      const b = MA.ballSprite(c.ball, 0, false, true), k = two ? 2 : 3;
      ctx.drawImage(b, Math.round(f.x + f.w / 2 - b.width * k / 2), f.y + 3, b.width * k, b.height * k);
      Txt.draw(ctx, c.name, f.x + f.w / 2, f.y + (two ? 19 : 25), { align: 'center', color: f.P.ink, outline: f.P.out });
      hit(id, cx, ty, tw, th, () => { if (ui.shopCat !== c.id) { ui.shopCat = c.id; ui.scrollS = 0; ui.showMax = false; sfx.tab(); } return true; });
    });
    if (more) {
      const [cx, ty] = cellAt(list.length);
      U.rr(ctx, cx, ty, tw, th, U.C.navyLo, INK, 2);
      Txt.draw(ctx, '？', cx + tw / 2, ty + Math.round(th / 2) - 8, { align: 'center', size: 16, color: U.C.dim });
    }
    // 这一种
    const rx = tx + (two ? tw * 2 + 4 : tw) + 8, rw = inner.x + inner.w - 6 - rx, hy = inner.y + 5;
    const big = MA.ballSprite(cat.ball, 0, false, true);
    ctx.drawImage(big, rx, hy + 1, big.width * 4, big.height * 4);
    Txt.draw(ctx, cat.name, rx + 36, hy, { size: 16, color: U.C.yellow });
    if (R.pickOf(S) === cat.ball) {
      U.rr(ctx, rx + rw - 44, hy + 2, 44, 18, U.C.green2, INK, 2);
      Txt.draw(ctx, '带着', rx + rw - 22, hy + 4, { align: 'center', color: '#0f2a10', outline: null });
    } else if (R.owned(S, cat.ball)) {
      const id = 'swap:' + cat.ball;
      U.chip(ctx, rx + rw - 44, hy, 44, 20, '换上', ui.hover === id, undefined, pressing(id));
      hit(id, rx + rw - 44, hy, 44, 20, () => pickBall(cat.ball));
    }
    Txt.draw(ctx, cat.blurb, rx + 36, hy + 18, { color: U.C.text });
    Txt.draw(ctx, cat.pay, rx + rw, hy + 18, { align: 'right', color: U.C.dim });
    ctx.fillStyle = U.C.tealRow; ctx.fillRect(rx, hy + 35, rw, 1);
    const top = hy + 39;
    pageBody(rx, top, rw, inner.y + inner.h - 4 - top, (y0, box) => shopBody(cat, rx, y0, rw, box));
  }
  // 两栏怎么分：一组一栏（头一组"养它"，第二组"本事：组名"）；只有一组有东西就对半分
  function shopLayout(cat) {
    const vis = catNodes(cat), done = vis.filter(n => R.state(S, n) === 'max');
    const cols = cat.groups.map((g, i) => ({ head: i === 0 ? '养它' : '本事：' + D.GROUPS[g].name, rows: vis.filter(n => n.group === g && R.state(S, n) !== 'max') })).filter(c => c.rows.length).slice(0, 2);
    if (cols.length === 1) { const r = cols[0].rows, k = Math.ceil(r.length / 2); cols.push({ head: null, rows: r.slice(k) }); cols[0].rows = r.slice(0, k); }
    return { cols, done };
  }
  function shopBody(cat, x, y0, w, box) {
    const { cols, done } = shopLayout(cat), gap = 8, cw = Math.floor((w - gap) / 2);
    let yb = y0;
    cols.forEach((c, i) => {
      const cx = x + i * (cw + gap);
      let y = y0;
      if (c.head) Txt.draw(ctx, c.head, cx + 2, y + 1, { color: U.C.yellow });
      y += 15;
      for (const n of c.rows) y += nodeRow(n, cx, y, cw, 0, box);
      yb = Math.max(yb, y);
    });
    if (done.length) yb += maxedFold(done, x, yb + (cols.length ? 2 : 0), w, 0, box, null, 2) + 2;
    return yb - y0;
  }
  // 金币罐：顶上多少金币、挣过多少；底下金币那几样
  function drawJar() {
    const vis = goldVis(), live = vis.filter(n => R.state(S, n) !== 'max'), done = vis.filter(n => R.state(S, n) === 'max');
    const RH = U.ROW_H + 3, ch = live.length * RH + (done.length ? 22 + (ui.showMax ? done.length * RH : 0) : 0);
    const inner = pageFrame('金币罐', PAGE_W.jar, Math.min(320, 69 + ch));
    ctx.drawImage(MA.COIN, inner.x + 6, inner.y + 6, MA.COIN.width * 2, MA.COIN.height * 2);
    walletAt.gold = { x: inner.x + 6 + MA.COIN.width, y: inner.y + 6 + MA.COIN.height };
    Txt.draw(ctx, R.num(S.gold), inner.x + 12 + MA.COIN.width * 2, inner.y + 5, { size: 16, color: U.C.gold });
    Txt.draw(ctx, '挣过 ' + R.num(S.earned), inner.x + inner.w - 6, inner.y + 8, { align: 'right', color: U.C.dim });
    const bx = inner.x + 4, bw = inner.w - 8;
    pageBody(bx, inner.y + 30, bw, inner.h - 34, (y0, box) => {
      let y = y0;
      for (const n of live) y += nodeRow(n, bx, y, bw, 0, box);
      if (done.length) y += maxedFold(done, bx, y, bw, 0, box);
      return y - y0;
    });
  }
  // 打卡钟：每台雇了的小人一张（自动打、自动买），底下小人速率（花金币）
  function drawCrew() {
    let ch = U.ROW_H + 3;
    for (const M of D.MINIS) if (R.hasHelper(S, M.id)) ch += (R.hasAuto(S, M.id) ? 56 : 36) + 3;
    const inner = pageFrame('小人', PAGE_W.clock, Math.min(320, 39 + ch), [{ key: 'gold', icon: MA.COIN, n: S.gold, col: U.C.gold }]);
    const bx = inner.x + 4, bw = inner.w - 8;
    pageBody(bx, inner.y + 4, bw, inner.h - 8, (y0, box) => drawHelpers(bx, y0, bw, 0, box));
  }

  // ---------- 电话字幕、提示、飘字 ----------
  function drawCall() {
    const c = ui.call; if (!c) return;
    ctx.fillStyle = 'rgba(10,12,24,0.35)'; ctx.fillRect(0, 0, W, H);
    const line = D.CALLS[c.k].lines[c.i], shown = line.slice(0, Math.floor(c.n));
    const w = 384, h = 50, x = 128, y = H - h - 8;
    U.rr(ctx, x, y, w, h, U.C.navy, INK, 3, U.C.navyHi, U.C.navyLo);
    ctx.fillStyle = U.C.yellow; ctx.fillRect(x + 3, y + 4, 2, h - 8);
    ctx.drawImage(HANDSET, x + 10, y + 6, HANDSET.width * 2, HANDSET.height * 2);
    Txt.draw(ctx, '桃败俗', x + 44, y + 5, { color: U.C.yellow });
    Txt.draw(ctx, shown, x + 12, y + 25, { size: 16, color: U.C.text });
    if (c.n >= line.length && Math.sin(ui.time * 6) > 0) { ctx.fillStyle = U.C.yellow; for (let k = 0; k < 4; k++) ctx.fillRect(x + w - 18 + k, y + h - 14 + k, 8 - 2 * k, 1); }
  }
  function drawToasts() {
    ui.toasts.forEach((t, i) => {
      const a = Math.min(1, t.t / 0.15, (2.4 - t.t) / 0.4);
      if (a <= 0) return;
      const tw = Txt.width(t.s, 12) + 16, x = Math.round(W / 2 - tw / 2), y = 280 - i * 20;
      ctx.globalAlpha = a;
      U.rr(ctx, x, y, tw, 17, U.C.navy, INK, 2);
      Txt.draw(ctx, t.s, W / 2, y + 2, { align: 'center', color: t.c });
      ctx.globalAlpha = 1;
    });
  }
  function drawFloaters() {
    for (const p of ui.parts) if (p.nat) { const a = p.t / p.dur; if (a < 1) { ctx.fillStyle = p.c; ctx.fillRect(Math.round(p.x), Math.round(p.y), 2, 2); } }
    const to = GOLD_AT();
    for (const c of ui.coins) {
      if (c.t < 0) continue;
      let x, y;
      if (c.t < COIN_HOP) { const u = c.t / COIN_HOP; x = c.x0 + c.dx * u; y = c.y0 - c.hop * Math.sin(Math.PI * u); }
      else { const t = clamp((c.t - COIN_HOP) / COIN_FLY, 0, 1), x1 = c.x0 + c.dx; x = lerp(x1, to.x, ease(t)); y = lerp(c.y0, to.y, t) - 30 * Math.sin(Math.PI * t); }
      ctx.drawImage(MA.COIN, Math.round(x / 2) * 2 - 5, Math.round(y / 2) * 2 - 5, 10, 10);
    }
    for (const p of ui.pops) { const a = p.t / 0.9; if (a < 1) Txt.draw(ctx, p.s, p.x, p.y - a * 18, { align: 'center', color: p.color }); }
  }

  // =========================================================================
  // 转生树（单独一屏）：桌上的闹钟打开；老手是根，底下三枝，前面那样买过一级才能买；点一格买一级。
  //   转生按钮在右下角（能转的时候）；转完树还开着，接着拿新的转生点买；Esc / × 关上
  // =========================================================================
  const STAR_ICON = () => MA.nodeIcon('star');
  const ptOn = () => S.canPrestige || S.prestiges > 0;
  // 开发者工具开不开得了：作者来电送了扳手（S.devTool），或者网址带 ?dev
  const devOK = () => !!S.devTool || q.has('dev');
  function openPTree() {
    if (ui.ptree || ui.page || ui.call || ui.tr || ui.opening || ui.intro) return false;
    ui.ptree = true; leaveInputs(); sfx.tab();
    if (!S.seen.prestigeTab) { S.seen.prestigeTab = 1; save(); }
    return true;
  }
  const PT = { x: 80, y: 10, w: 480, h: 340, tile: 34 };
  // 一格的左上角：三列、四行；字写在格子右边，格子上下只走连线
  const ptTile = p => ({ x: Math.round(PT.x + PT.w / 2 + (p.pos[0] - 1) * 140 - 43), y: PT.y + 34 + p.pos[1] * 64 });
  const perkIconOf = (p, gray) => (p.icon === 'cloth' ? CLOTH_ICON : p.icon === 'ticket' ? MA.ticket('dog') : MA.nodeIcon(p.icon || 'star', gray));
  function buyPerkAt(p) {
    const c = R.perkCost(S, p.id), id = 'perk:' + p.id;
    if (p.free) return false;
    if (!R.perkOpen(S, p.id)) { deny(id); toast('先买 ' + p.pre.map(k => R.PBY[k].name).join('、'), C.red); return false; }
    if (c == null) return false;
    if (!R.buyPerk(S, p.id)) { deny(id); toast('还差 ' + R.num(c - S.pp) + ' 转生点', C.red); return false; }
    sfx.buy(); sfx.upgrade(); flashKey(id); save();
    return true;
  }
  function drawPTree() {
    if (!ui.ptree) return;
    HITS = [];
    ctx.fillStyle = 'rgba(10,12,24,0.72)'; ctx.fillRect(0, 0, W, H);
    const { x, y, w, h, tile } = PT;
    U.rr(ctx, x, y, w, h, U.C.navy, INK, 3, U.C.navyHi, U.C.navyLo);
    Txt.draw(ctx, '转生树', x + 12, y + 8, { size: 16, color: U.C.yellow });
    // 转生点
    const ps = R.num(S.pp), pw = Txt.width(ps, 16);
    ctx.drawImage(STAR_ICON(), x + w - 44 - pw - 18, y + 9);
    Txt.draw(ctx, ps, x + w - 44, y + 8, { size: 16, color: U.C.yellow, align: 'right' });
    U.chip(ctx, x + w - 30, y + 6, 22, 20, '×', ui.hover === 'ptclose', undefined, pressing('ptclose'));
    hit('ptclose', x + w - 30, y + 6, 22, 20, () => { ui.ptree = false; sfx.tab(); });
    // 连线：买过的那样往下亮黄，没买的暗
    for (const p of D.PERKS) for (const k of p.pre || []) {
      const a = ptTile(R.PBY[k]), b = ptTile(p), lit = R.perk(S, k) > 0, col = lit ? U.C.yellow : '#3c4670';
      const ax = a.x + tile / 2, ay = a.y + tile, bx = b.x + tile / 2, by = b.y, my = Math.round((ay + by) / 2);
      const seg = (x0, y0, x1, y1) => { ctx.fillStyle = INK; ctx.fillRect(Math.min(x0, x1) - 2, Math.min(y0, y1) - 2, Math.abs(x1 - x0) + 4, Math.abs(y1 - y0) + 4); };
      const segC = (x0, y0, x1, y1) => { ctx.fillStyle = col; ctx.fillRect(Math.min(x0, x1) - 1, Math.min(y0, y1) - 1, Math.abs(x1 - x0) + 2, Math.abs(y1 - y0) + 2); };
      const path = ax === bx ? [[ax, ay, bx, by]] : [[ax, ay, ax, my], [ax, my, bx, my], [bx, my, bx, by]];
      for (const q of path) seg(...q);
      for (const q of path) segC(...q);
    }
    // 一格一样：图标（2 倍）、底下名字、再底下价钱或者几级；格子底边一排小方块是几级
    let hov = null;
    for (const p of D.PERKS) {
      const t = ptTile(p), id = 'perk:' + p.id, l = R.perk(S, p.id), c = R.perkCost(S, p.id), open = R.perkOpen(S, p.id), n = p.costs.length;
      const has = l > 0, full = p.free ? has : c == null, can = !p.free && open && c != null && S.pp >= c, hot = ui.hover === id;
      if (hot) hov = p;
      // 能买的一格是键帽（买得起亮黄，买不起深蓝）；买满了、白送的、还没开的是平的（买满黄边）
      const dx = shakeOf(id), bx0 = t.x - 1 + dx, by0 = t.y - 1, ts = tile + 2, fl = flashing(id, 0.6);
      let fk;
      if (!p.free && open && !full) fk = U.key(ctx, bx0, by0, ts, ts, { kind: can ? 'lit' : 'idle', hot, down: pressing(id), flash: fl, t: ui.time });
      else {
        U.rr(ctx, bx0, by0 + U.LIP - 1, ts, ts - U.LIP + 1, has ? U.C.tealRow : '#20253e', fl ? '#ffffff' : full ? U.C.yellow : INK, 3, has ? U.C.tealRowHi : null);
        fk = { x: bx0 + 1, y: by0 + U.LIP, w: ts - 2, h: ts - U.LIP - 2 };
      }
      const gray = !open && !has, ic = perkIconOf(p, gray), iw = ic.width * 2, ih = ic.height * 2;
      if (gray && (p.icon === 'cloth' || p.icon === 'ticket')) ctx.globalAlpha = 0.45;
      ctx.drawImage(ic, Math.round(fk.x + (fk.w - iw) / 2), fk.y + Math.max(0, Math.round((fk.h - 5 - ih) / 2)), iw, ih);
      ctx.globalAlpha = 1;
      const py = fk.y + fk.h - 5;
      if (!p.free && n > 1) for (let i = 0; i < n; i++) { const qx = Math.round(fk.x + fk.w / 2 - (n * 5 - 1) / 2) + i * 5; ctx.fillStyle = INK; ctx.fillRect(qx - 1, py, 6, 5); ctx.fillStyle = i < l ? U.C.yellow : '#3c4670'; ctx.fillRect(qx, py + 1, 4, 3); }
      const lx = t.x + tile + 5;
      Txt.draw(ctx, p.name, lx, t.y + 3, { color: !open && !has ? U.C.dim : full ? U.C.yellow : U.C.text });
      const y2 = t.y + 19;
      if (p.free) Txt.draw(ctx, has ? '白送了' : '转生白送', lx, y2, { color: has ? U.C.green2 : U.C.dim });
      else if (full) Txt.draw(ctx, '满了', lx, y2, { color: U.C.green2 });
      else {
        const s2 = R.num(c);
        ctx.drawImage(STAR_ICON(), lx, y2 - 1);
        Txt.draw(ctx, s2, lx + 15, y2, { color: !open ? U.C.dim : S.pp < c ? U.C.red : U.C.gold });
      }
      if (!p.free) hit(id, t.x - 3, t.y - 3, tile + 60, tile + 6, () => buyPerkAt(p));
      else hit(id, t.x - 3, t.y - 3, tile + 60, tile + 6, null);
    }
    // 左下角：指着的那样说什么
    const bx = x + 12, by = y + h - 44, bw = w - (S.canPrestige ? 164 : 24);
    U.rr(ctx, bx, by, bw, 36, U.C.navyLo, INK, 2);
    if (hov) {
      const l = R.perk(S, hov.id), c = R.perkCost(S, hov.id);
      Txt.draw(ctx, hov.name + (hov.free ? '' : '  ' + l + '/' + hov.costs.length), bx + 8, by + 4, { color: U.C.yellow });
      const need = !R.perkOpen(S, hov.id) ? '先买 ' + hov.pre.map(k => R.PBY[k].name).join('、') : hov.free ? hov.how : c == null ? '买满了' : '';
      Txt.draw(ctx, hov.eff + (need ? '（' + need + '）' : ''), bx + 8, by + 19, { color: U.C.text });
    } else {
      Txt.draw(ctx, '转生点照这一世最深打到哪一层给', bx + 8, by + 4, { color: U.C.dim });
      Txt.draw(ctx, '点一格买一级；前面那样买过才能买', bx + 8, by + 19, { color: U.C.dim });
    }
    // 右下角：转生
    if (S.canPrestige) {
      const kx = x + w - 148, ky = y + h - 44;
      U.bigButton(ctx, kx, ky, 136, 36, '转生', ui.hover === 'prestige', 'gold', '+' + R.ppFor(S) + ' 转生点', pressing('prestige'));
      hit('prestige', kx, ky, 136, 36, () => { ui.confirm = 'prestige'; sfx.tab(); });
    }
  }

  // =========================================================================
  // 转生确认、暂停、开发者面板
  // =========================================================================
  function doPrestige() {
    const r = R.prestige(S);
    ui.confirm = null;
    if (!r) return false;
    leaveInputs();
    for (const id of Object.keys(ctrls)) delete ctrls[id];
    for (const id of Object.keys(cardCache)) delete cardCache[id];
    deskDirty = true;
    if (ui.view === 'card' && ui.cur !== 'main') ui.cur = 'main';
    ui.burst = null; ui.labels = []; ui.showMax = false; ui.scrollR = 0; ui.scrollL = 0; ui.rep = null;
    run.startRun();
    sfx.maxed();
    toast('+' + r.pts + ' 转生点', C.gold);
    if (r.first) toast('老手：每种弹珠力道 ×2', C.green);
    save();
    return true;
  }
  function drawConfirm() {
    if (!ui.confirm) return;
    HITS = [];
    ctx.fillStyle = 'rgba(10,12,24,0.66)'; ctx.fillRect(0, 0, W, H);
    const x = 196, y = 100, w = 248, h = 150;
    U.rr(ctx, x, y, w, h, U.C.navy, INK, 3, U.C.navyHi, U.C.navyLo);
    Txt.draw(ctx, '转生', x + w / 2, y + 8, { align: 'center', size: 16, color: U.C.yellow });
    const lines = [['这一世的金币、技能、小游戏都清掉，', U.C.text], ['从草地第 1 层重新打。', U.C.text], ['拿 ' + R.ppFor(S) + ' 转生点，买转生树。', U.C.gold]];
    lines.forEach(([s, c], i) => Txt.draw(ctx, s, x + 16, y + 32 + i * 15, { color: c }));
    const bw = (w - 44) / 2;
    U.bigButton(ctx, x + 16, y + h - 46, bw, 32, '转生', ui.hover === 'yes', 'gold', null, pressing('yes'));
    hit('yes', x + 16, y + h - 46, bw, 32, () => doPrestige());
    U.bigButton(ctx, x + 28 + bw, y + h - 46, bw, 32, '算了', ui.hover === 'no', 'dim', null, pressing('no'));
    hit('no', x + 28 + bw, y + h - 46, bw, 32, () => { ui.confirm = null; sfx.tab(); });
  }
  function leaveInputs() { ui.rep = null; run.cancel(); for (const id in ctrls) { const c = ctrls[id]; if (c && c.cancel) { A.setCard(id); c.cancel(); } } }
  function drawOverlay() {
    if (!ui.dev && !ui.paused) return;
    HITS = [];
    ctx.fillStyle = 'rgba(10,12,24,0.66)'; ctx.fillRect(0, 0, W, H);
    if (ui.dev) { drawDev(); return; }
    const x = 220, y = 104, w = 200, h = 150;
    U.rr(ctx, x, y, w, h, U.C.navy, INK, 3, U.C.navyHi, U.C.navyLo);
    Txt.draw(ctx, '暂停', x + w / 2, y + 8, { align: 'center', size: 16, color: U.C.yellow });
    const btns = [
      { id: 'resume', label: '接着打', kind: 'gold', go: () => { ui.paused = false; } },
      { id: 'sound', label: prefs.sound ? '声音：开' : '声音：关', go: () => toggleSound() },
    ];
    if (ui.view === 'card' && ui.cur === 'main' && run.st.phase === 'play') btns.push({ id: 'pquit', label: '这一轮收工', go: () => { ui.paused = false; run.quit(); } });
    btns.forEach((b, i) => {
      const by = y + 34 + i * 36;
      U.bigButton(ctx, x + 16, by, w - 32, 30, b.label, ui.hover === b.id, b.kind || 'teal', null, pressing(b.id));
      hit(b.id, x + 16, by, w - 32, 30, b.go);
    });
  }
  // 开发者工具（作者来电送的扳手，或者网址带 ?dev）：一行一类，左边写类名，右边一排键
  function drawDev() {
    const x = 92, y = 40, w = 456, h = 272, L = x + 14, B0 = x + 72, BW = 90, BG = 4, RH = 30;
    U.rr(ctx, x, y, w, h, '#14202a', INK, 3, '#2a4050');
    Txt.draw(ctx, '开发者工具', L, y + 9, { size: 16, color: C.blue });
    Txt.draw(ctx, '` 或 F2 开关 · 随便点，坏了就清存档', x + 112, y + 13, { color: C.dim });
    const btn = (id, bx, by, bw, lab, kind, go) => { U.bigButton(ctx, bx, by, bw, 24, '', ui.hover === id, kind); Txt.draw(ctx, lab, bx + bw / 2, by + 5, { align: 'center', color: kind === 'gold' ? '#3a2410' : kind === 'dim' ? '#9aa0ac' : '#ffffff', outline: kind === 'gold' ? null : INK }); hit(id, bx, by, bw, 24, go); };
    const at = i => B0 + i * (BW + BG);
    let yy = y + 34;
    const row = label => { Txt.draw(ctx, label, L, yy + 5, { color: C.text }); const r = yy; yy += RH; return r; };
    const done = () => { deskDirty = true; run.refresh(); save(); sfx.buy(); };
    // 金币
    let r = row('金币');
    [[1e4, '+1万'], [1e6, '+100万'], [1e8, '+1亿'], [1e10, '+100亿']].forEach(([n, s], i) => btn('g' + n, at(i), r, BW, s, 'gold', () => { S.gold += n; S.earned += n; done(); }));
    // 斩草除根
    r = row('主台');
    btn('boss', at(0), r, BW, '叫 boss', 'teal', () => { run.jumpBoss(); ui.dev = false; });
    btn('kill', at(1), r, BW, '打掉 boss', 'teal', () => { if (run.killBoss()) ui.dev = false; else sfx.deny(); });
    btn('auto', at(2), r, BW, ui.auto ? '自动手：开' : '自动手：关', 'teal', () => { ui.auto = !ui.auto; sfx.tab(); });
    btn('speed', at(3), r, BW, '速度 ×' + ui.speed, ui.speed > 1 ? 'gold' : 'teal', () => { ui.speed = ui.speed >= 4 ? 1 : ui.speed * 2; sfx.tab(); });
    // 关卡：− 第几关 + ，从这关打（中间的关一路看过去，节点照露）
    r = row('关卡');
    const NS = D.STAGES.length, dsN = clamp(ui.devStage || run.st.stage || 1, 1, NS), mid = BW * 2 + BG - 64;
    btn('dvS-', at(0), r, 28, '−', 'teal', () => { ui.devStage = Math.max(1, dsN - 1); sfx.tab(); });
    U.rr(ctx, at(0) + 32, r + 2, mid, 20, '#0c141c', INK, 2);
    Txt.draw(ctx, '第 ' + dsN + ' 关 · ' + R.stage(dsN).name, at(0) + 32 + mid / 2, r + 6, { align: 'center', color: C.gold });
    btn('dvS+', at(1) + BW - 28, r, 28, '+', 'teal', () => { ui.devStage = Math.min(NS, dsN + 1); sfx.tab(); });
    btn('dvGo', at(2), r, BW, '从这关打', 'gold', () => {
      for (let i = 2; i <= dsN; i++) revealedList(R.seeStage(S, i));
      S.from = dsN >= S.maxStage ? 0 : dsN;
      run.quit(); run.startRun(dsN); ui.burst = null; ui.labels = [];
      deskDirty = true; save(); sfx.buy(); ui.dev = false;
    });
    const lastL = R.stage(run.st.stage).layers.length;
    btn('dvLayer', at(3), r, BW, '跳到第 ' + lastL + ' 层', 'teal', () => { run.setLayer(lastL); ui.dev = false; });
    // 弹珠
    r = row('弹珠');
    const ballNodes = k => D.NODES.filter(n => n.where === 'main' && D.GROUPS[n.group] && D.GROUPS[n.group].ball === k);
    const maxNodes = list => { for (const n of list) { S.tree[n.id] = R.maxLv(n); S.revealed[n.id] = 1; } };
    btn('allBalls', at(0), r, BW, '全部弹珠', 'teal', () => {
      for (const k of D.BALLS) { const u = R.BALL_NODES[k] && R.BALL_NODES[k].unlock; if (u) { S.tree[u] = Math.max(1, S.tree[u] || 0); S.revealed[u] = 1; } }
      revealedList(R.reveal(S, 999)); done();
    });
    btn('maxBall', at(1), r, BW, '这颗升满', 'teal', () => { maxNodes(ballNodes(R.pickOf(S))); revealedList(R.reveal(S, 999)); done(); });
    btn('maxBalls', at(2), r, BW, '有的全升满', 'teal', () => { for (const k of R.ownedBalls(S)) maxNodes(ballNodes(k)); revealedList(R.reveal(S, 999)); done(); });
    btn('maxMain', at(3), r, BW, '台子全升满', 'teal', () => { maxNodes(D.NODES.filter(n => n.where === 'main' && !(D.GROUPS[n.group] && D.GROUPS[n.group].ball) && R.preOK(S, n))); revealedList(R.reveal(S, 999)); done(); });
    // 小游戏
    r = row('小游戏');
    const cur = ui.view === 'card' && ui.cur !== 'main' && R.miniOpen(S, ui.cur) ? ui.cur : null;
    btn('nextShow', at(0), r, BW, '下一台上桌', 'teal', () => { const M = D.MINIS.find(mm => !S.shown[mm.id]); if (!M) return sfx.deny(); S.shown[M.id] = 1; ui.flash['w:' + M.id] = ui.time; ui.deskFlash = 6; done(); ui.dev = false; });
    btn('openAll', at(1), r, BW, '全开小游戏', 'teal', () => {
      for (const M of D.MINIS) { S.shown[M.id] = 1; if (!R.miniOpen(S, M.id)) { S.gold += R.boxPrice(S, M.id); const o = R.openMini(S, M.id); if (o) revealedList(o.revealed); ctrl(M.id); } R.hangUp(S, M.call); }
      revealedList(R.reveal(S, 999)); done();
    });
    btn('chips', at(2), r, BW, '各种券 +1000', 'teal', () => { let any = false; for (const M of D.MINIS) if (S.mini[M.id]) { S.mini[M.id].chips += 1000; any = true; } if (!any) return sfx.deny(); done(); });
    btn('maxUp', at(3), r, BW, cur ? '这台升满' : '开了的全升满', 'teal', () => {
      const ids = cur ? [cur] : D.MINIS.filter(M => R.miniOpen(S, M.id)).map(M => M.id);
      if (!ids.length) return sfx.deny();
      for (const id of ids) { for (const n of R.miniNodes(id)) { S.tree[n.id] = R.maxLv(n); S.revealed[n.id] = 1; } delete ctrls[id]; delete cardCache[id]; }
      revealedList(R.reveal(S, 999)); done();
    });
    // 转生
    r = row('转生');
    btn('canP', at(0), r, BW, S.canPrestige ? '能转生了' : '开转生', S.canPrestige ? 'dim' : 'teal', () => { if (S.canPrestige) return sfx.deny(); S.canPrestige = true; ui.ppFlash = 6; ui.deskFlash = 6; done(); });
    btn('pp', at(1), r, BW, '+50 转生点', 'teal', () => { S.pp += 50; done(); });
    btn('perksAll', at(2), r, BW, '转生树全买', 'teal', () => { for (const p of D.PERKS) S.perks[p.id] = p.free ? 1 : p.costs.length; done(); });
    btn('reveal', at(3), r, BW, '够得着的全露', 'teal', () => { revealedList(R.reveal(S, 999)); done(); });
    // 清存档（按住）
    yy += 4;
    btn('wipe', L, yy, w - 28, ui.hold ? '按住……松手就不清' : '按住 1.5 秒：清存档从头来', 'red', null);
    HITS[HITS.length - 1].hold = true;
    if (ui.hold) { ctx.fillStyle = '#ffe680'; ctx.fillRect(L + 2, yy + 2, Math.round((w - 32) * ui.hold.t / ui.hold.sec), 20); Txt.draw(ctx, '按住……松手就不清', L + (w - 28) / 2, yy + 5, { align: 'center', color: INK, outline: null }); }
    btn('close', x + w - 34, y + 8, 24, '×', 'red', () => { ui.dev = false; });
    Txt.draw(ctx, '金币 ' + R.num(S.gold) + ' · 挣过 ' + R.num(S.earned) + ' · 最深 ' + R.stage(S.best.stage).name + ' ' + S.best.layer + ' 层 · ' + S.runs + ' 轮 · 转生 ' + S.prestiges + ' 次', L, y + h - 18, { color: C.dim });
  }
  function wipeSave() { wiping = true; saveIn = -1; store.del(STORE); location.reload(); }

  // ---------- 小件 ----------
  function plate(g, x, y, w, h, fill, edge) { g.fillStyle = edge || INK; g.fillRect(x, y, w, h); g.fillStyle = fill; g.fillRect(x + 2, y + 2, w - 4, h - 4); }
  function barRaw(g, x, y, w, h, k, col, back) {
    g.fillStyle = INK; g.fillRect(x, y, w, h);
    g.fillStyle = back || '#3a1a22'; g.fillRect(x + 1, y + 1, w - 2, h - 2);
    g.fillStyle = col; g.fillRect(x + 1, y + 1, Math.round((w - 2) * clamp(k, 0, 1)), h - 2);
  }

  // =========================================================================
  // 输入
  // =========================================================================
  function toNative(e) { const b = cv.getBoundingClientRect(); return { x: (e.clientX - b.left) * W / b.width, y: (e.clientY - b.top) * H / b.height }; }
  // 最上面那个（滚轮区只管滚轮，不挡点击）
  const topHit = p => { for (let i = HITS.length - 1; i >= 0; i--) if (!HITS[i].wheel && hitIn(HITS[i], p)) return HITS[i]; return null; };
  function inPanels(p) {
    if (ui.slideL > 0.5 && p.x < LEFT.x + LEFT.w + 2) return true;
    if (ui.backIn > 0.5 && p.x < BACK.x + BACK.w + 2 && p.y < BACK.y + BACK.h + 2) return true;
    if (ui.slideR > 0.5 && p.x >= RIGHT.x - 2) return true;
    return p.x >= 610 && p.y < 28;
  }
  function cardInput(kind, p, btn, pid, ptype) {
    if (ui.cur === 'main') {
      A.setCard('swamp');
      const sx = (p.x - A.CX0) / 2, sy = (p.y - A.CY0) / 2;
      if (kind === 'down') run.down({ x: p.x, y: p.y, sx, sy, btn, id: pid, touch: ptype === 'touch' });
      else if (kind === 'up') run.up({ x: p.x, y: p.y, sx, sy, btn, id: pid });
      else if (kind === 'move') run.move({ sx, sy, id: pid });
      return;
    }
    const id = ui.cur, c = ctrl(id);
    if (!c) return;
    A.setCard(id);
    const r = MD.playRect(id), inCard = p.x >= r.x && p.x < r.x + r.w && p.y >= r.y && p.y < r.y + r.h;
    const P2 = { x: p.x, y: p.y, sx: (p.x - A.CX0) / 2, sy: (p.y - A.CY0) / 2, btn, id: pid, inCard, touch: ptype === 'touch' };
    if (kind === 'down') { if (c.down) c.down(P2); }
    else if (kind === 'up') { if (c.up) c.up(P2); }
    else if (kind === 'move') { if (c.move) c.move(P2); }
  }
  function pointerDown(p, btn, pid, ptype) {
    unlockAudio();
    const h = topHit(p);
    if (ui.confirm || ui.dev || ui.paused || ui.ptree) { if (h && btn === 0) { ui.press = { id: h.id, t: ui.time, held: true }; if (h.hold) ui.hold = { t: 0, sec: 1.5, go: wipeSave }; else if (h.go) h.go(); } return; }
    // 桌上那一页：跟栏里一样，按住一行连着买
    if (ui.page) { if (h && h.go && btn === 0) { ui.press = { id: h.id, t: ui.time, held: true }; const ok = h.go(); if (h.rep && ok) ui.rep = { go: h.go, t: 0, next: 0.4, n: 0 }; } return; }
    if (ui.call) { if (btn === 0) advanceCall(); return; }
    if (ui.intro) { if (btn === 0) skipIntro(); return; }
    if (h && h.go && btn === 0) {
      ui.press = { id: h.id, t: ui.time, held: true };
      const ok = h.go();
      // 按住一行：0.4 秒以后连着买，越买越快，买不起了停
      if (h.rep && ok) ui.rep = { go: h.go, t: 0, next: 0.4, n: 0 };
      return;
    }
    if (inPanels(p) || ui.tr || ui.opening) return;
    if (ui.view === 'card') cardInput('down', p, btn, pid, ptype);
  }
  function pointerUp(p, btn, pid) {
    if (ui.hold) ui.hold = null;
    if (ui.press) ui.press.held = false;
    ui.rep = null;
    if (ui.view === 'card' && !ui.tr) cardInput('up', p, btn, pid);
  }
  function pointerMove(p) {
    ui.mouse = p;
    const h = topHit(p);
    ui.hover = h ? h.id : null;
    let hot = !!(h && h.go) || !!ui.call;
    if (ui.view === 'card' && !ui.tr && !ui.dev && !ui.paused && !ui.call && !ui.confirm && !ui.ptree && !ui.page) {
      if (ui.cur !== 'main' || isFlat()) cardInput('move', p);
      const r = MD.playRect(ui.cur);
      if (!hot && p.x >= r.x && p.x < r.x + r.w && !inPanels(p)) hot = true;
    }
    cv.style.cursor = hot ? 'pointer' : 'default';
  }
  cv.addEventListener('pointerdown', e => { e.preventDefault(); try { cv.setPointerCapture(e.pointerId); } catch (_) { /* 无所谓 */ } pointerDown(toNative(e), e.button, 'p' + e.pointerId + ':' + e.button, e.pointerType); });
  cv.addEventListener('pointerup', e => { e.preventDefault(); pointerUp(toNative(e), e.button, 'p' + e.pointerId + ':' + e.button); });
  cv.addEventListener('pointercancel', e => { pointerUp(toNative(e), e.button, 'p' + e.pointerId + ':' + e.button); });
  cv.addEventListener('pointermove', e => pointerMove(toNative(e)));
  cv.addEventListener('contextmenu', e => e.preventDefault());
  cv.addEventListener('wheel', e => {
    const p = toNative(e), h = HITS.find(hh => hh.wheel && hitIn(hh, p));
    if (!h) return;
    e.preventDefault();
    if (h.wheel === 'L') ui.scrollL = clamp(ui.scrollL + e.deltaY * 0.4, 0, ui.maxL);
    else if (h.wheel === 'S') ui.scrollS = clamp(ui.scrollS + e.deltaY * 0.4, 0, ui.maxS);
    else ui.scrollR = clamp(ui.scrollR + e.deltaY * 0.4, 0, ui.maxR);
  }, { passive: false });
  const GAME_KEYS = new Set(['Space', 'ArrowDown', 'ArrowUp', 'ArrowLeft', 'ArrowRight', 'KeyZ', 'KeyM', 'ShiftLeft', 'ShiftRight', 'Enter', 'Slash', 'Tab']);
  window.addEventListener('keydown', e => {
    if (GAME_KEYS.has(e.code)) e.preventDefault();
    unlockAudio();
    // 开发者面板：作者来电送了扳手以后才开得了（网址带 ?dev 的也行）
    if (e.code === 'Backquote' || e.code === 'F2') { e.preventDefault(); if (!e.repeat && (ui.dev || devOK())) { ui.dev = !ui.dev; ui.devFlash = 0; ui.devStage = 0; leaveInputs(); } return; }
    if (ui.confirm) { if (e.code === 'Escape') ui.confirm = null; return; }
    if (ui.ptree && !ui.dev) { if (e.code === 'Escape') { ui.ptree = false; sfx.tab(); } return; }
    if (ui.page && !ui.dev) { if (e.code === 'Escape') closePage(); return; }
    if (e.code === 'Escape') { if (ui.dev) ui.dev = false; else { ui.paused = !ui.paused; leaveInputs(); } return; }
    if (e.repeat) return;
    if (ui.dev) return;
    if (ui.paused) { if (e.code === 'Space' || e.code === 'Enter') ui.paused = false; return; }
    if (ui.call) { if (e.code === 'Space' || e.code === 'Enter') advanceCall(); return; }
    if (ui.intro) { if (e.code === 'Space' || e.code === 'Enter') skipIntro(); return; }
    if (ui.tr || ui.opening) return;
    if (e.code === 'Tab') { cycleMachine(e.shiftKey ? -1 : 1); return; }
    if (ui.view === 'desk') { if (e.code === 'Space' || e.code === 'Enter') lift('main'); return; }
    if (ui.cur === 'main') run.key(e.code, true);
    else { const c = ctrl(ui.cur); if (c && c.key) { A.setCard(ui.cur); c.key(e.code, true); } }
  });
  window.addEventListener('keyup', e => {
    if (GAME_KEYS.has(e.code)) e.preventDefault();
    if (ui.view !== 'card' || ui.tr || ui.call) return;
    if (ui.cur === 'main') run.key(e.code, false);
    else { const c = ctrl(ui.cur); if (c && c.key) { A.setCard(ui.cur); c.key(e.code, false); } }
  });
  window.addEventListener('blur', () => leaveInputs());

  // =========================================================================
  // 每帧
  // =========================================================================
  // 镜头：打穿那一下（碎块飞出去的时候）往后拉到下一关的倍数；新一轮回草地直接推回来
  function updateCam(dt) {
    const B = ui.burst;
    if (B && B.z1 !== B.z0) { ui.camZ = B.z0 + (B.z1 - B.z0) * easeIO(clamp(B.t / 1.2, 0, 1)); return; }
    const tz = R.zoomOf(run.st.stage);
    if (tz >= ui.camZ) ui.camZ = tz;
    else ui.camZ = Math.max(tz, ui.camZ - dt * 0.5);
  }
  function update(dt) {
    ui.time += dt;
    if (saveIn >= 0) { saveIn -= dt; if (saveIn < 0) flushSave(); }
    if (ui.hold) { ui.hold.t += dt; if (ui.hold.t >= ui.hold.sec) { const g = ui.hold.go; ui.hold = null; g(); } }
    const running = !ui.paused && !ui.dev && !ui.call && !ui.confirm && !ui.ptree && !ui.page;
    if (ui.call && !ui.paused && !ui.dev) updateCall(dt);
    // 电话铃：响着就隔一会儿响一串
    if (ringing()) { ui.ringT -= dt; if (ui.ringT <= 0) { sfx.ring(); ui.ringT = 1.5; } } else ui.ringT = 0;
    if (ui.tr && running) { ui.tr.t += dt; if (ui.tr.t >= ui.tr.dur) trDone(); }
    if (ui.opening && running) { ui.opening.t += dt; if (ui.opening.t >= 0.55) { const id = ui.opening.id; ui.opening = null; lift(id); } }
    if (running) {
      if (ui.intro) updateIntro(dt);
      const mainLive = ui.intro || (ui.view === 'card' && ui.cur === 'main' && !ui.tr);
      if (mainLive) {
        if (ui.auto && !ui.intro) run.auto(dt);
        run.update(dt);
        FX.update(run.st.hitstop > 0 ? 0 : dt, run.s.balls, run.s.flippers);
        if (ui.burst) { ui.burst.t += dt; if (ui.burst.t > 1.6) ui.burst = null; }
      }
      updateCam(dt);
      if (ui.view === 'card' && ui.cur !== 'main' && !ui.tr) {
        const c = ctrl(ui.cur);
        if (c) { A.setCard(ui.cur); if (ui.auto && c.auto) c.auto(dt); c.update(dt); }
      }
      // 雇了小人的小游戏：不拿着就自己打
      for (const e of R.tickBots(S, dt, ui.view === 'card' ? ui.cur : null)) {
        save();
        if (e.n > 0) ui.flash['wt:' + e.id] = ui.time;
        if (ui.view === 'desk' && !ui.tr && e.n > 0) { const r = MD.deskRect(e.id); ui.pops.push({ x: r.x + r.w / 2, y: r.y + 20, s: '+' + e.n, color: MA.TIX_C[e.id], t: 0 }); deskTicket(e.id); }
      }
      // 攒着没露的：手上"新"的不到两样，隔一会儿露一样
      ui.trickleT += dt;
      if (ui.trickleT > 2.5) { ui.trickleT = 0; trickle(); }
      for (const p of ui.parts) { p.t += dt; p.vy += 220 * dt; p.x += p.vx * dt; p.y += p.vy * dt; }
      ui.parts = ui.parts.filter(p => p.t < p.dur);
      for (const l of ui.labels) l.t += dt;
      ui.labels = ui.labels.filter(l => l.t < (l.big ? 1.6 : 1.1));
      for (const k of ['L', 'R']) { ui.slingFlash[k] = Math.max(0, ui.slingFlash[k] - dt); ui.laneFlash[k] = Math.max(0, ui.laneFlash[k] - dt); }
      ui.layerFlash = Math.max(0, ui.layerFlash - dt); ui.stageFlash = Math.max(0, ui.stageFlash - dt); ui.layerFlip = Math.max(0, ui.layerFlip - dt);
      // boss 血条：掉的那截停 BOSS_LAG.hold 秒再往下缩
      const bo = run.st.boss;
      if (bo) {
        if (bo.hpLag == null || bo.hp > bo.hpLag) { bo.hpLag = bo.hp; bo.lagHold = 0; }
        else if (bo.hp < bo.hpLag) {
          if (bo.lastHp !== bo.hp) { bo.lagHold = BOSS_LAG.hold; bo.lastHp = bo.hp; }
          if (bo.lagHold > 0) bo.lagHold -= dt;
          else bo.hpLag = Math.max(bo.hp, bo.hpLag - bo.maxHp * BOSS_LAG.speed * dt);
        }
      }
      if (ui.partFlash) { ui.partFlash.t += dt; if (ui.partFlash.t > 1) ui.partFlash = null; }
      ui.deskFlash = Math.max(0, ui.deskFlash - dt);
      ui.ppFlash = Math.max(0, ui.ppFlash - dt);
      ui.devFlash = Math.max(0, ui.devFlash - dt);
    }
    // 按住一行连着买（开着桌上那一页也算）
    if (ui.rep && !ui.paused && !ui.dev && !ui.call && !ui.confirm) {
      ui.rep.t += dt;
      while (ui.rep && ui.rep.t >= ui.rep.next) { if (!ui.rep.go(true)) { ui.rep = null; break; } ui.rep.next += ui.rep.n++ < 6 ? 0.1 : 0.05; }
    }
    for (const p of ui.pops) p.t += dt;
    ui.pops = ui.pops.filter(p => p.t < 0.9);
    for (const t of ui.toasts) t.t += dt;
    ui.toasts = ui.toasts.filter(t => t.t < 2.4);
    // 金币飞进钱箱：落地一颗减一份
    for (const c of ui.coins) { c.t += dt; if (c.t >= COIN_HOP + COIN_FLY && !c.done) { c.done = true; ui.flying = Math.max(0, ui.flying - c.share); sfx.coin(); ui.flash.coinIn = ui.time; } }
    ui.coins = ui.coins.filter(c => !c.done);
    if (!ui.coins.length) ui.flying = 0;
    updateMoney(dt);
    // 两边栏：只在机台里（拿起来那一下滑进来，放下那一下滑出去）；挣到第一枚金币才有。
    //   右栏：拿着小游戏是这台的；斩草除根有场景那几类才出。左上角按钮有了钱箱往下让
    const held = ui.tr ? (ui.tr.kind === 'lift' ? ui.tr.id : null) : ui.view === 'card' ? ui.cur : null;
    const onL = panelsOn() && !ui.intro && held != null, onR = onL && (held !== 'main' || sceneCats().length > 0);
    ui.slideL = clamp(ui.slideL + (onL ? dt : -dt) / 0.45, 0, 1);
    ui.slideR = clamp(ui.slideR + (onR ? dt : -dt) / 0.45, 0, 1);
    ui.backIn = clamp(ui.backIn + (backBtn() ? dt : -dt) / 0.3, 0, 1);
    ui.chipFlash = Math.max(0, ui.chipFlash - dt);
    ui.shake = Math.max(0, ui.shake - dt);
    if (ui.deny) { ui.deny.t -= dt; if (ui.deny.t <= 0) ui.deny = null; }
  }
  function render() {
    HITS = []; walletAt = {};
    ctx = baseCtx; worldPass = null;
    ctx.imageSmoothingEnabled = false;
    ctx.fillStyle = MD.COLORS.floor; ctx.fillRect(0, 0, W, H);
    const sh = ui.shake > 0 ? Math.round(Math.sin(ui.time * 70) * 2 * Math.min(1, ui.shake * 4)) * 2 : 0;
    if (ui.tr) drawTransition();
    else if (ui.view === 'desk') { ctx.save(); ctx.translate(sh, 0); drawDeskScene(MD.FULL, true); ctx.restore(); }
    else {
      drawDeskScene(MD.camFor(ui.cur), false, ui.cur);   // 底下是推近的桌子（旁边的台子压在两边栏下面）
      if (ui.cur === 'main') {
        // 从这儿往后画到上面那一层（透明底）；台面那一层 present 里补
        worldPass = { dx: sh };
        ctx = octx; ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, W, H); ctx.imageSmoothingEnabled = false;
      }
      ctx.save(); ctx.translate(sh, 0);
      if (ui.cur === 'main') drawMainCard(ctx, true);
      else drawMiniCard(ui.cur);
      ctx.restore();
      const pr = MD.playRect(ui.cur);
      // 卡上的按钮（重来）要压在整张卡的 hit 上面：挪到最后
      const onCard = HITS.filter(h => h.id === 'restart' || h.id.startsWith('pick:') || h.id.startsWith('stage:'));
      HITS = HITS.filter(h => !onCard.includes(h));
      hit('card', pr.x, 12, pr.w, 336, null);
      HITS = HITS.concat(onCard);
    }
    sideStrips();
    drawLeft();
    drawBack();
    drawRight();
    drawFloaters();
    drawCall();
    drawPTree();
    drawPage();
    drawMoney();
    drawToasts();
    drawConfirm();
    drawOverlay();
  }

  // ---------- 屏幕：先整数倍放大，再平滑缩到窗口 ----------
  function fit() {
    const dpr = window.devicePixelRatio || 1;
    let z = Math.min(window.innerWidth / W, window.innerHeight / H) * dpr;
    if (z >= 1 && z - Math.floor(z) < 0.04) z = Math.floor(z);
    z = Math.max(0.5, z);
    const k = Math.max(1, Math.ceil(z - 1e-6));
    if (cv.width !== W * k || cv.height !== H * k) { cv.width = W * k; cv.height = H * k; }
    cv.style.width = W * z / dpr + 'px'; cv.style.height = H * z / dpr + 'px';
  }
  function present() {
    screenCtx.setTransform(1, 0, 0, 1, 0, 0);
    screenCtx.imageSmoothingEnabled = false;
    screenCtx.drawImage(base, 0, 0, cv.width, cv.height);
    if (!worldPass) return;
    A.setCard('swamp');
    drawWorld(screenCtx, cv.width / W, worldPass.dx);
    screenCtx.imageSmoothingEnabled = false;
    screenCtx.drawImage(over, 0, 0, cv.width, cv.height);
  }
  fit();
  window.addEventListener('resize', fit);

  // 开局：新存档走开场（电话）；老存档直接坐在斩草除根前
  if (!S.seen.opening && !q.has('nointro')) startIntro();
  else {
    if (!S.seen.opening) { S.seen.opening = 1; R.hangUp(S, 'opening'); }
    run.startRun();
    ui.slideL = ui.slideR = panelsOn() ? 1 : 0;
  }

  let last = performance.now();
  function tick(now) {
    const dt = Math.min(0.05, Math.max(0, (now - last) / 1000));
    last = now;
    if (!window.__freeze) for (let i = 0; i < ui.speed; i++) update(dt);   // 开发者工具的速度 ×2 ×4：一帧多推几下
    render();
    present();
  }
  if (TEST) { const loop = () => { tick(performance.now()); setTimeout(loop, 16); }; setTimeout(loop, 16); }
  else { const frame_ = now => { tick(now); requestAnimationFrame(frame_); }; requestAnimationFrame(frame_); }

  // 给测试用
  window.__main = {
    S, run, ui, R, D, A, MA, MD, U, sfx, ctrls,
    update, render, present, pointerDown, pointerUp, pointerMove, tapNode, buyNode, flushSave, onFx,
    lift, drop, openMini, openFromWallet, buyBox, pickBall, goMachine, cycleMachine, walletIds, canBuyAt, doPrestige,
    startIntro, skipIntro, answer, advanceCall, ringing, trickle, ctrl, openPTree, openPage, closePage, openObj, objsOn, shopCats, sceneCats, deskHas, prefs,
    hits: () => HITS.slice(), deskDirty: () => { deskDirty = true; },
  };
  if (TEST) { const s = document.createElement('script'); s.src = 'test/main_demo.js'; document.body.appendChild(s); }
})();
