/*
 * 写字：宋体 12 像素在 Chrome 里出的是点阵字（嵌在字体里的位图），画进离屏画布，按透明度切成纯色，
 * 外面描一圈深边，跟像素画一个路子。标题用宋体 16 像素。字画在原生 640×360 那一层，一格 = 1 像素。
 *   Txt.draw(ctx, '草地史莱姆', x, y, { size: 12, color, outline, align: 'left'|'center'|'right' })
 *   Txt.width(str, size)：字宽（不算描边）
 *   Txt.wrap(str, size, maxW)：按宽度断行（中文一个字一个字断，英文和数字不拆开）
 */
window.Txt = (function () {
  'use strict';
  const INK = '#1b2628';
  const FONT = { 12: '12px SimSun, "NSimSun", "Songti SC", monospace', 16: '16px SimSun, "NSimSun", "Songti SC", monospace' };
  const meas = document.createElement('canvas').getContext('2d');
  const cache = new Map();
  let n = 0;
  function width(str, size) { meas.font = FONT[size || 12]; return Math.ceil(meas.measureText(String(str)).width); }
  function render(str, size, color, outline) {
    const key = size + '|' + color + '|' + outline + '|' + str;
    let c = cache.get(key);
    if (c) return c;
    const w = width(str, size) + 4, h = size + 6;
    c = document.createElement('canvas'); c.width = Math.max(1, w); c.height = h;
    const x = c.getContext('2d');
    x.font = FONT[size]; x.textBaseline = 'top'; x.fillStyle = '#fff';
    x.fillText(String(str), 2, 2);
    const d = x.getImageData(0, 0, w, h), p = d.data, on = new Uint8Array(w * h);
    for (let i = 0; i < w * h; i++) on[i] = p[i * 4 + 3] > 110 ? 1 : 0;
    const [r, g, b] = hex(color), [or, og, ob] = outline ? hex(outline) : [0, 0, 0];
    for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) {
      const k = j * w + i, q = k * 4;
      if (on[k]) { p[q] = r; p[q + 1] = g; p[q + 2] = b; p[q + 3] = 255; continue; }
      const near = outline && ((i > 0 && on[k - 1]) || (i < w - 1 && on[k + 1]) || (j > 0 && on[k - w]) || (j < h - 1 && on[k + w]));
      if (near) { p[q] = or; p[q + 1] = og; p[q + 2] = ob; p[q + 3] = 255; } else p[q + 3] = 0;
    }
    x.putImageData(d, 0, 0);
    if (++n > 3000) { cache.clear(); n = 0; }
    cache.set(key, c);
    return c;
  }
  function hex(h) { const v = parseInt(h.slice(1), 16); return [(v >> 16) & 255, (v >> 8) & 255, v & 255]; }
  // (x, y) 是字的左上角（描边往外多出 1 格）
  function draw(ctx, str, x, y, o) {
    o = o || {};
    const size = o.size || 12, c = render(String(str), size, o.color || '#fff3d8', o.outline === undefined ? INK : o.outline);
    const w = c.width - 4;
    const ax = o.align === 'center' ? Math.round(x - w / 2) : o.align === 'right' ? x - w : x;
    ctx.drawImage(c, Math.round(ax) - 2, Math.round(y) - 2);
    return w;
  }
  function wrap(str, size, maxW) {
    const out = [];
    for (const para of String(str).split('\n')) {
      // 数和后面的量词粘在一起（"4 个"不拆到两行）
      const toks = para.match(/[A-Za-z0-9.+\-×%→>/:,'()]+(?: ?[个根颗只下层倍档球台发秒级次星格])?|\s+|./gu) || [''];
      let line = '';
      for (const t of toks) {
        if (width(line + t, size) > maxW && line.trim() && !/^[。，、）」』：；！？％]$/.test(t)) { out.push(line.replace(/\s+$/, '')); line = t.replace(/^\s+/, ''); } else line += t;
      }
      out.push(line);
    }
    return out;
  }
  // 一段多行字；返回总高
  function block(ctx, str, x, y, maxW, o) {
    o = o || {};
    const size = o.size || 12, lh = o.lh || size + 3, lines = wrap(str, size, maxW);
    lines.forEach((l, i) => draw(ctx, l, x, y + i * lh, o));
    return lines.length * lh;
  }
  return { draw, width, wrap, block, render, INK };
})();
