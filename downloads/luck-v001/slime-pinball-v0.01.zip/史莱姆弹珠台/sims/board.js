/*
 * 火山坑的钉阵：场地、发射道、钉子跟基础机同一套（sim.js），不一样的地方：
 *   1. 钉阵中间是火山，山坡上三个岩浆坑。冰珠从上面掉进坑口，就停在坑里（凝成石头），这一发结束。
 *      坑口（卡面画好的那三个坑）：(34,116)、(88,102)、(64,128)，横半径 10.4。坑口周围不钉钉子，珠子才掉得进去。
 *   2. 一次能有好几颗珠子（喷发的时候山顶喷出一把火山弹），珠子之间不互相撞。火山弹不进坑。
 *   3. 底下 9 个洞跟基础机一样；落进哪个洞发 land 事件，中没中台子自己算（亮着的洞每发重抽）。
 * 结构固定：同一个力度永远落同一个地方；随机只来自抽亮洞、喷发和人手。
 */
(function (root, factory) {
  const Sim = typeof module === 'object' && module.exports ? require('../sim.js') : root.Sim;
  const api = factory(Sim);
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.Board = api;
}(typeof self !== 'undefined' ? self : globalThis, function (Sim) {
  'use strict';
  const { DT, X0, X1, Y0, YB, CH, LANE_X, LANE_TOP, LANE_CX, HEAD_Y, REST_Y, PEG_R, STRIP, BALL_R } = Sim;
  const PITS = [{ x: 34, y: 116, rx: 10.4, ry: 5.2 }, { x: 88, y: 102, rx: 10.4, ry: 5.2 }, { x: 64, y: 128, rx: 10.4, ry: 5.2 }];
  const CRATER = { x: 64, y: 78 };
  const BOMB_R = 3;
  const PIT_V = 95;   // 跑得快的珠子从坑口上蹦过去，慢下来的才掉进去
  function pegs() {
    return Sim.pegPositions({ door: null }).filter(([x, y]) => !PITS.some(p => Math.abs(x - p.x) < p.rx - 1 && y > p.y - 12 && y < p.y + 6));
  }
  function create(seed) {
    const c = Sim.DEFAULTS;
    const s = { cfg: c, colliders: [], cells: null, stamp: 0, quiet: false, events: [], balls: [], rng: Sim.rng(seed >>> 0), time: 0 };
    Sim.addSeg(s, X0, Y0 + CH, X0, YB, 'wall', c.wallE, c.wallF, 60, 90);
    Sim.addSeg(s, X1, Y0 + CH, X1, YB, 'wall', c.wallE, c.wallF, 60, 90);
    Sim.addSeg(s, X0, Y0 + CH, X0 + CH, Y0, 'roof', c.roofE, c.roofF, 60, 90);
    Sim.addSeg(s, X0 + CH, Y0, X1 - CH, Y0, 'roof', c.roofE, c.roofF, 60, 90);
    Sim.addSeg(s, X1 - CH, Y0, X1, Y0 + CH, 'roof', c.roofE, c.roofF, 60, 90);
    Sim.addWall(s, LANE_X, LANE_TOP, LANE_X, YB, 'lane', c.laneE, 0.02);
    Sim.addSeg(s, LANE_X, HEAD_Y, X1, HEAD_Y, 'head', 0.1, 0.2, LANE_CX, 100);
    Sim.addSeg(s, LANE_X, LANE_TOP, LANE_X - c.guard[0], LANE_TOP + c.guard[1], 'guard', 0.3, 0.02, LANE_X - 8, LANE_TOP - 4);
    for (const [x, y, r] of pegs()) Sim.addCircle(s, x, y, r, r === PEG_R ? 'peg' : 'bump', c.pegE, c.pegF);
    Sim.buildGrid(s);
    return s;
  }
  const emit = (s, e) => { if (!s.quiet) s.events.push(e); };
  // 冰珠：从推头上打出去
  function launch(s, p) {
    const b = { x: LANE_CX, y: REST_Y, vx: 0, vy: -Sim.launchSpeed(s.cfg, Math.max(0, Math.min(1, p))), r: BALL_R, kind: 'ice', t: 0, alive: true };
    s.balls.push(b);
    emit(s, { type: 'launch', p });
    return b;
  }
  // 喷发：山顶喷出 n 颗火山弹，往两边上方撒
  function erupt(s, n, rnd, goldIdx) {
    rnd = rnd || s.rng;
    for (let i = 0; i < n; i++) {
      const side = i % 2 ? 1 : -1, ang = -Math.PI / 2 + side * (0.25 + 0.75 * rnd()), sp = 90 + 90 * rnd();
      s.balls.push({ x: CRATER.x + side * 2, y: CRATER.y, vx: Math.cos(ang) * sp, vy: Math.sin(ang) * sp, r: BOMB_R, kind: 'bomb', gold: i === goldIdx, t: -i * 0.06, alive: true });
    }
    emit(s, { type: 'erupt', n });
  }
  const holeAt = x => Math.max(0, Math.min(8, Math.floor((x - X0) / 10)));
  function step(s) {
    s.time += DT;
    for (const b of s.balls) {
      if (!b.alive) continue;
      b.t += DT;
      if (b.t < 0) continue;   // 火山弹一颗一颗喷
      b.vy += s.cfg.gravity * DT;
      b.x += b.vx * DT; b.y += b.vy * DT;
      for (let k = 0; k < 4; k++) { const h = Sim.deepest(s, b); if (!h) break; Sim.resolve(s, b, h); }
      if (b.kind === 'ice') {
        // 掉回推头：退回来，不算这一发
        if (b.x > LANE_X && b.y >= REST_Y - 0.5 && b.vy >= 0 && b.t > 0.05) { b.alive = false; emit(s, { type: 'fallback', b }); continue; }
        if (b.vy > 0 && b.x < LANE_X && Math.hypot(b.vx, b.vy) < PIT_V) for (let i = 0; i < PITS.length; i++) {
          if (s.full && s.full[i]) continue;   // 填满的坑是一块石头，珠子从上面滚过去
          const p = PITS[i], u = (b.x - p.x) / (p.rx - 3.5), v = (b.y - (p.y - 1)) / 3.2;
          if (u * u + v * v <= 1) { b.alive = false; emit(s, { type: 'pit', b, pit: i, x: b.x, y: b.y }); break; }
        }
        if (!b.alive) continue;
      }
      if (b.x < LANE_X && b.y >= STRIP - b.r) { b.alive = false; emit(s, { type: 'land', b, hole: holeAt(b.x), x: b.x, y: b.y }); continue; }
      if (b.t > 12) { b.alive = false; emit(s, b.kind === 'ice' ? { type: 'fallback', b, stuck: true } : { type: 'land', b, hole: holeAt(b.x), x: b.x, y: b.y }); }
    }
    s.balls = s.balls.filter(b => b.alive);
  }
  function advance(s, dt, acc) {
    acc.t += dt;
    let n = 0;
    while (acc.t >= DT && n < 400) { step(s); acc.t -= DT; n++; }
  }
  // 一口气算一发：力度 p 落在哪（洞号，或者 'pit0'..'pit2'，或者 null = 退回）
  function outcome(p, full) {
    const s = create(1); s.quiet = false; s.full = full || null;
    launch(s, p);
    for (let i = 0; i < 480 * 13 && s.balls.length; i++) step(s);
    for (const e of s.events) {
      if (e.type === 'land') return e.hole;
      if (e.type === 'pit') return 'pit' + e.pit;
      if (e.type === 'fallback') return null;
    }
    return null;
  }
  return { PITS, CRATER, BOMB_R, create, launch, erupt, step, advance, outcome, pegs, holeAt };
}));
