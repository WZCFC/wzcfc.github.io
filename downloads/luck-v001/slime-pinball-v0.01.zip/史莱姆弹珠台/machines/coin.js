/*
 * 推陈出新（推币机；俯视，小台 64 宽，11-11 粗做）。深灰台面上铺着一层铜钱，顶上一块推板，台面下边是台沿，过了台沿掉下去的归你。
 *   在卡上按住往后拉，松手从下面的币口弹一枚铜钱上去（只能往前弹）。弹出去的同时，顶上滚进【签】枚，推板往前推一趟再退回来。
 *   推下台沿的一枚吐【价】张券；金的【品】几率出现，一枚 ×5。推板只跟着你弹的那一下走（不打不推）。
 *   古钱（碰运气）：滚进来的 1% 是古钱（×10）。存钱猪（手上功夫 = 大奖）：一推掉下 8 枚。钱袋（打得深）：掉下 500 枚。
 */
Machines.def('coin', env => {
  'use strict';
  const { A, sfx } = env;
  const T = window.TopDown, K = A.kit, INK = A.INK;
  const BOX = { x0: 14, x1: 114 }, EDGE = 150, LAUNCH = { x: 64, y: 160 };
  const PUSH = { rest: 66, out: 92, tOut: 1.1, tBack: 0.6 };
  const CR = 6, VMAX = 230, PULL = 44, CAP = 40;
  const s = T.create();
  const st = { state: 'aim', drag: null, quiet: 0, acc: { t: 0 }, time: 0, py: PUSH.rest, pv: 0, cycle: null, fell: 0, falling: [], auto: null, shotN: 0 };
  const m = () => env.m();
  // 铜钱：圆的、一圈厚边、中间方孔
  const coinIm = (C, key) => A.layerSprite('cash:' + key, CR * 2 + 2, CR * 2 + 2, L => {
    K.lE(L, CR + 1, CR + 1, CR, CR, (x, y, u, v) => { const d = u * u + v * v; return d > 0.62 ? (u + v < -0.3 ? C[0] : C[2]) : u + v < -0.5 ? C[0] : C[1]; });
    for (const [dx, dy] of [[0, 0], [1, 0], [0, 1], [1, 1]]) K.lset(L, CR + dx, CR + dy, '#20140c');
  });
  const COPPER = coinIm(['#ffc888', '#d8803a', '#8a4a1e'], 'cu'), GOLDC = coinIm(['#fff3a0', '#ffd23a', '#c47a10'], 'au'), OLD = coinIm(['#b8f0c8', '#4ab07a', '#22704a'], 'old');
  const imOf = b => (b.old ? OLD : b.gold ? GOLDC : COPPER);
  const coins = () => s.bodies.filter(b => b.alive);
  const mk = (x, y, o) => T.add(s, Object.assign({ kind: 'coin', x, y, r: CR, m: 1, mu: 90, drag: 1.2, e: 0.25, we: 0.35, box: BOX }, o));
  function placeOne(y0, y1, blink) {
    for (let k = 0; k < 40; k++) {
      const x = BOX.x0 + CR + 2 + Math.random() * (BOX.x1 - BOX.x0 - 2 * CR - 4), y = y0 + Math.random() * (y1 - y0);
      if (s.bodies.some(b => b.alive && Math.hypot(b.x - x, b.y - y) < b.r + CR + 0.5)) continue;
      const old = env.luck(0.01);
      return mk(x, y, { old, gold: !old && Math.random() < env.val('g'), born: blink ? 0.01 : 1 });
    }
    return null;
  }
  for (let i = 0; i < 30; i++) placeOne(PUSH.rest + 6, EDGE - 4, false);

  // ---------- 弹 ----------
  function startDrag(p) { if (st.state !== 'aim') return false; st.drag = { x0: p.sx, y0: p.sy, x: p.sx, y: p.sy, by: p.id }; st.state = 'drag'; return true; }
  function pullVec() {
    const d = st.drag; let dx = d.x - d.x0, dy = d.y - d.y0; const l = Math.hypot(dx, dy);
    if (l > PULL) { dx *= PULL / l; dy *= PULL / l; }
    if (l > 0.01 && dy / Math.hypot(dx, dy) < 0.5) { const ll = Math.min(l, PULL), sx = Math.sign(dx) || 1; dy = 0.5 * ll; dx = sx * Math.sqrt(ll * ll - dy * dy); }
    return { dx, dy, l: Math.min(l, PULL) };
  }
  function release() {
    if (st.state !== 'drag') return;
    const { dx, dy, l } = pullVec();
    st.drag = null;
    if (l < 3) { st.state = 'aim'; return; }
    if (!env.spend()) { st.state = 'aim'; return; }
    const v = T.shotFromDrag(dx, dy, PULL, VMAX);
    const b = mk(LAUNCH.x, LAUNCH.y, { fresh: true });
    b.vx = v.vx; b.vy = v.vy;
    let n = 0;
    for (let i = 0; i < env.val('n') && coins().length < CAP; i++) if (placeOne(PUSH.rest + 4, PUSH.rest + 22, true)) n++;
    if (n) sfx.clink();
    st.cycle = { t: 0 }; st.fell = 0; st.quiet = 0; st.shotN += 1; st.state = 'roll';
    sfx.launch(v.p * 0.5);
  }
  // 推板：往前推 tOut 秒、退回 tBack 秒；往前的时候碰到的铜钱跟着走
  function pusher(dt) {
    const c = st.cycle;
    if (!c) { st.py = PUSH.rest; st.pv = 0; return; }
    c.t += dt;
    const { rest, out, tOut, tBack } = PUSH;
    if (c.t < tOut) { const u = c.t / tOut; st.py = rest + (out - rest) * (0.5 - 0.5 * Math.cos(Math.PI * u)); st.pv = (out - rest) * Math.PI / 2 / tOut * Math.sin(Math.PI * u); }
    else if (c.t < tOut + tBack) { const u = (c.t - tOut) / tBack; st.py = out - (out - rest) * u; st.pv = 0; }
    else { st.py = rest; st.pv = 0; st.cycle = null; }
  }
  // 推板往前走的时候，一枚顶一枚：挨着的两枚，把靠台沿那一枚整个挪开（推力一路传下去，不像碰撞那样一枚分一半）
  function shove() {
    if (!(st.pv > 0)) return;
    const B = s.bodies.filter(b => b.alive).sort((a, b) => a.y - b.y);
    for (let it = 0; it < 2; it++) for (let i = 0; i < B.length; i++) for (let j = i + 1; j < B.length; j++) {
      const a = B[i], b = B[j], dx = b.x - a.x, dy = b.y - a.y, rr = a.r + b.r;
      if (dy <= 0 || dy >= rr || Math.abs(dx) >= rr) continue;
      const d2 = dx * dx + dy * dy;
      if (d2 >= rr * rr) continue;
      const d = Math.sqrt(d2) || 1e-6, pen = rr - d;
      b.x += dx / d * pen; b.y += dy / d * pen;
      const v = st.pv * dy / d; if (b.vy < v) b.vy = v;
    }
  }
  function push() {
    for (const b of s.bodies) {
      if (!b.alive) continue;
      if (b.y - b.r < st.py) { b.y = st.py + b.r; if (b.vy < st.pv) b.vy = st.pv; }
      if (b.fresh && b.y < EDGE - 6) b.fresh = false;
      if (!b.fresh && b.y > EDGE) drop(b);
    }
  }
  function drop(b) {
    b.alive = false;
    st.fell += 1;
    const base = env.val('v') * (b.old ? 10 : b.gold ? 5 : 1);
    env.award(base, { at: [b.x, EDGE - 2], n: Math.min(5, base) });
    st.falling.push({ x: b.x, y: b.y, im: imOf(b), t: 0 });
    m().kills = (m().kills || 0) + 1;
    if (b.old) { env.toast('古钱！×10', A.GOLD[0]); env.find('luck'); }
    if (m().kills >= 500) env.find('deep');
    sfx.coin();
  }
  function settle() {
    if (st.fell >= 8) env.jackpot();
    for (const b of s.bodies) if (b.fresh) b.fresh = false;
    push();
    s.bodies = s.bodies.filter(b => b.alive);
    st.state = 'aim';
    env.save();
  }

  // ---------- 自动弹：往铜钱最靠台沿的那一列弹 ----------
  function auto(dt) {
    const A_ = st.auto || (st.auto = { t: 0 });
    if (st.state !== 'aim' || env.marbles() <= 0) return;
    A_.t += dt; if (A_.t < 0.5) return; A_.t = 0;
    const cs = coins(), tx = cs.length ? cs.reduce((a, b) => (b.y > a.y ? b : a)).x : 64;
    const vx = tx + (Math.random() - 0.5) * 20 - LAUNCH.x, vy = -90, vl = Math.hypot(vx, vy), p = 0.55 + Math.random() * 0.4;
    st.drag = { x0: 0, y0: 0, x: -vx / vl * PULL * p, y: -vy / vl * PULL * p, by: 'auto' };
    st.state = 'drag';
    release();
  }

  return {
    s,
    fine(f) {
      // 台沿：一道金边，底下黑的（掉下去的地方）；币口：下边正中一个小缺口
      for (let x = 14; x <= 113; x++) { f.px(x, EDGE + 1, '#e8c048'); for (let y = EDGE + 2; y <= 153; y++) f.px(x, y, '#0c0c10'); }
      for (let x = LAUNCH.x - 6; x <= LAUNCH.x + 6; x++) f.px(x, EDGE + 1, '#a87a20');
    },
    update(dt) {
      st.time += dt;
      for (const b of s.bodies) if (b.born > 0 && b.born < 1) b.born = Math.min(1, b.born + dt / 0.25);
      if (st.state === 'roll') {
        T.advance(s, dt, st.acc, null, () => { pusher(T.DT); shove(); push(); });
        for (const e of s.events.splice(0)) { if (e.type === 'hit' && e.impact > 20) sfx.clink(); }
        if (!st.cycle && !T.moving(s, 2)) { st.quiet += dt; if (st.quiet > 0.25) { for (const b of s.bodies) b.vx = b.vy = 0; settle(); } } else st.quiet = 0;
      } else s.events.length = 0;
      st.falling = st.falling.filter(q => (q.t += dt) < 0.4);
    },
    draw(ctx) {
      for (const b of coins()) {
        if (b.born > 0 && b.born < 1 && Math.sin(b.born * 20) > 0) continue;
        const im = imOf(b);
        MK.spr(ctx, im, Math.round(b.x - im.width / 2), Math.round(b.y - im.height / 2));
      }
      for (const q of st.falling) { const y = q.y + q.t * 30; if (Math.floor(q.t * 20) % 2 === 0) MK.spr(ctx, q.im, Math.round(q.x - q.im.width / 2), Math.round(y - q.im.height / 2)); }
      // 推板：铝板一道一道竖纹，前沿亮边
      const py = Math.round(st.py);
      MK.rect(ctx, 14, 28, 100, py - 28, '#93a1a8');
      for (let x = 18; x < 114; x += 6) MK.rect(ctx, x, 28, 1, py - 29, '#c8d0d4');
      MK.rect(ctx, 14, py - 2, 100, 1, '#f2f6f6'); MK.rect(ctx, 14, py - 1, 100, 1, INK);
      // 币口上等着的那一枚、拉的皮筋、出手方向
      if ((st.state === 'aim' || st.state === 'drag') && env.marbles() > 0) MK.spr(ctx, COPPER, LAUNCH.x - CR - 1, LAUNCH.y - CR - 1);
      if (st.state === 'drag') {
        const { dx, dy, l } = pullVec();
        if (l >= 3) { const ux = -dx / l, uy = -dy / l; MK.dots(ctx, LAUNCH.x + ux * 8, LAUNCH.y + uy * 8, LAUNCH.x + ux * (14 + 50 * l / PULL), LAUNCH.y + uy * (14 + 50 * l / PULL), l >= PULL * 0.98 ? A.GOLD[0] : '#ffffff', 3, st.time * 3); }
      }
      if (st.state === 'aim' && env.marbles() > 0 && st.shotN < 3 && Math.sin(st.time * 5) > 0) MK.label(ctx, '按住往后拉', 64, 132, A.GOLD[0], 'center');
      if (st.state === 'roll' && st.fell > 0) MK.label(ctx, '掉下 ' + st.fell, 64, py + 4, st.fell >= 8 ? '#ffffff' : A.GOLD[0], 'center');
      MK.led(ctx, env.marbles(), env.marbles() <= 0, st.time);
    },
    down(p) {
      if (p.btn !== 0) return false;
      if (st.state === 'aim') { if (env.marbles() <= 0) { env.deny('marbles'); return true; } return startDrag(p); }
      return true;
    },
    move(p) { if (st.state === 'drag' && st.drag.by !== 'auto') { st.drag.x = p.sx; st.drag.y = p.sy; } },
    up(p) { if (st.state === 'drag' && st.drag.by === p.id) release(); },
    key() { return false; },
    cancel() { if (st.state === 'drag') { st.drag = null; st.state = 'aim'; } },
    leave() { if (st.state === 'drag') { st.drag = null; st.state = 'aim'; } },
    auto,
    inPlay: () => st.state === 'roll' || st.state === 'drag',
    busy: () => st.state === 'drag',
    hint() {
      if (st.state === 'drag') return '松手弹出去（拉回原处不弹）';
      if (st.state !== 'aim' || env.marbles() <= 0) return '';
      return st.shotN < 3 ? '在卡上按住往后拉，松手弹一枚铜钱上去；推板推下台沿的归你' : '';
    },
    info() {
      return [
        ['台上 ' + coins().length + ' 枚 · 一弹滚进 ' + env.val('n') + ' 枚（最多 ' + CAP + '）', null],
        ['掉下一枚吐 ' + env.val('v') + ' 张，金的 ×5（' + Math.round(env.val('g') * 100) + '%）', null],
        ['一推掉下 8 枚 = 大奖', null],
      ];
    },
    onUpgrade() {},
    debug: () => ({ state: st.state, onTable: coins().length, shots: st.shotN, marbles: env.marbles(), fell: m().kills || 0 }),
  };
});
