/*
 * 第 6 台 · 保龄球（俯视的第二台）。一条球道，两边是沟，最后面一道黑坑；十个瓶。
 *   在卡上按住（球挪到按的那一列）往后拉，松手把球滚出去；方向最多斜 25°，拉得越长越快。
 *   一局两球，第一球倒下的瓶留在道上，第二球还能把它们推进坑。瓶滚进后面的坑才算钱（【价】个），掉沟里不算。
 *   全中（第一球十个全倒）：下一局进坑的瓶 ×2；补中（两球十个全倒）：×1.5。瓶挪开 8 格才算倒。
 *   【签】每局几个金瓶（×3）。【救】每局前几球有护栏（球不进沟）。【准】瞄准线。
 *   彩虹瓶（碰运气）：3% 的局冒出一个彩虹瓶，进坑 ×10。金球（手上功夫 = 大奖）：亲手连着三局全中。球鞋（打得深）：这一局 200 个瓶进坑。
 */
Machines.def('bowl', env => {
  'use strict';
  const { A, sfx } = env;
  const T = window.TopDown, INK = A.INK, FX = A.FX, FY = A.FY;
  const LANE = { x0: 24, x1: 104 }, PIT_Y = 32, START = { x: 64, y: 136 }, BR = 9.2, PR = 4.8, VMAX = 200, PULL = 36, MAXA = 25 * Math.PI / 180;
  const s = T.create();
  const st = { state: 'aim', roll: 1, mult: 1, drag: null, quiet: 0, acc: { t: 0 }, time: 0, ballAt: START.x, slide: null, pins: [], ball: null, pitN: 0, labels: [], auto: null, rolls: 0, flash: null };
  const m = () => env.m();
  // 瓶（从上往下看）：白圆、红脖子一圈；金瓶、彩虹瓶；倒了的瓶是躺着的长条（四个方向）
  const pinIm = (C, ring) => A.ballSprite(PR, C, (k, c) => { for (let a = 0; a < 16; a++) { const x = c + Math.cos(a / 16 * Math.PI * 2) * 2.2, y = c + Math.sin(a / 16 * Math.PI * 2) * 2.2; k.P(Math.floor(x), Math.floor(y), Array.isArray(ring) ? ring[a % ring.length] : ring); } k.P(Math.floor(c - 1), Math.floor(c - 1), '#ffffff'); });
  const PIN = { std: pinIm(['#c8d0d4', '#f2f6f6', '#ffffff'], '#fe4c40'), gold: pinIm(['#c47a10', '#ffd23a', '#fff6c0'], '#fe4c40'), rainbow: pinIm(['#c8d0d4', '#f2f6f6', '#ffffff'], ['#fe4c40', '#ffb21a', '#3ccf6a', '#2f86ea', '#a87aff']) };
  const LYING = {};
  function lying(kind, dir) {
    const key = kind + dir;
    if (!LYING[key]) {
      const body = kind === 'gold' ? '#ffd23a' : kind === 'rainbow' ? '#e0d0ff' : '#f2f6f6';
      const ang = dir * Math.PI / 4, ux = Math.cos(ang), uy = Math.sin(ang), n = 13, rows = [];
      for (let y = 0; y < n; y++) {
        let r = '';
        for (let x = 0; x < n; x++) {
          const px = x + 0.5 - n / 2, py = y + 0.5 - n / 2, t = px * ux + py * uy, q = -px * uy + py * ux;
          const tt = Math.max(-4, Math.min(4, t)), d = Math.hypot(t - tt, q), rad = t > 0.5 ? 2.5 : t > -2.5 ? 1.5 : 1.9;
          r += d <= rad ? (t > -2.5 && t < -1 ? 'r' : 'x') : '.';
        }
        rows.push(r);
      }
      LYING[key] = A.outlined(rows, { x: body, r: '#fe4c40' }, INK);
    }
    return LYING[key];
  }
  const BALL = A.ballSprite(BR, A.MARB.bowl, (k, c) => { for (const [dx, dy] of [[-2, -3], [1, -3], [-1, 0]]) { k.P(Math.floor(c + dx), Math.floor(c + dy), INK); k.P(Math.floor(c + dx + 1), Math.floor(c + dy), INK); } });

  // ---------- 一局 ----------
  function setPins() {
    for (const p of st.pins) p.alive = false;
    s.bodies = s.bodies.filter(b => b.alive);
    const spots = A.PIN_SPOTS.map(([x, y]) => [x + (Math.random() - 0.5) * 1.2, y + (Math.random() - 0.5) * 1.2]);
    const gold = new Set(), g = env.val('g');
    while (gold.size < Math.min(g, 10)) gold.add(Math.floor(Math.random() * 10));
    const rainbow = env.luck(0.03) ? Math.floor(Math.random() * 10) : -1;
    st.pins = spots.map(([x, y], i) => T.add(s, { kind: 'pin', x, y, r: PR, m: 1, mu: 90, drag: 1.0, e: 0.6, we: 0.4, box: { x0: 14, x1: 114, y1: 154 }, look: i === rainbow ? 'rainbow' : gold.has(i) ? 'gold' : 'std', down: false, dir: 0, gone: null }));
    st.roll = 1;
  }
  setPins();
  const pinsDown = () => st.pins.filter(p => p.down || p.gone).length;
  function rails() { return st.roll <= env.val('r'); }

  // ---------- 打 ----------
  function startDrag(p) {
    if (st.state !== 'aim') return false;
    if (env.marbles() <= 0) { env.deny('marbles'); return true; }
    const x = Math.max(LANE.x0 + BR + 1, Math.min(LANE.x1 - BR - 1, p.sx));
    st.slide = { x0: st.ballAt, x1: x, t: 0 };
    st.drag = { x0: p.sx, y0: p.sy, x: p.sx, y: p.sy, by: p.id };
    st.state = 'drag';
    return true;
  }
  // 往后拉的向量 → 出手方向（往上，左右最多斜 25°）、力度
  function shot() {
    const d = st.drag; let dx = d.x - d.x0, dy = d.y - d.y0;
    const l = Math.min(PULL, Math.hypot(dx, dy));
    if (l < 3 || dy <= 0) return null;
    let ang = Math.atan2(-dx, dy);   // 0 = 正往上
    ang = Math.max(-MAXA, Math.min(MAXA, ang));
    return { ux: Math.sin(ang), uy: -Math.cos(ang), p: l / PULL };
  }
  function release() {
    if (st.state !== 'drag') return;
    const sh = shot();
    st.drag = null;
    if (!sh) { st.state = 'aim'; return; }
    if (!env.spend()) { st.state = 'aim'; return; }
    st.ballAt = st.slide ? st.slide.x1 : st.ballAt; st.slide = null;
    const sp = VMAX * (0.35 + 0.65 * sh.p);
    st.ball = T.add(s, { kind: 'ball', x: st.ballAt, y: START.y, vx: sh.ux * sp, vy: sh.uy * sp, r: BR, m: 3.5, mu: 8, drag: 0.05, e: 0.6, we: 0.3, box: rails() ? { x0: LANE.x0, x1: LANE.x1 } : null, gutter: false });
    st.state = 'roll'; st.quiet = 0; st.rolls += 1;
    sfx.roll();
  }
  function payPin(p) {
    const base = env.val('v') * (p.look === 'gold' ? 3 : p.look === 'rainbow' ? 10 : 1) * st.mult;
    env.award(base, { at: [p.x, PIT_Y], n: Math.min(8, Math.ceil(base)) });
    st.pitN += 1; m().kills += 1;
    if (p.look === 'rainbow') { env.toast('彩虹瓶进坑！×10', A.GOLD[0]); env.find('luck'); }
    if (m().kills >= 300) env.find('deep');
    sfx.clink();
  }
  function after() {
    for (const p of st.pins) {
      if (!p.alive) continue;
      if (!p.down && p.moved > 8) { p.down = true; p.dir = Math.round(((Math.atan2(p.vy, p.vx) + Math.PI) / (Math.PI / 4))) % 4; sfx.pinHit(Math.hypot(p.vx, p.vy) * 4); }
      if (p.y < PIT_Y) { p.alive = false; p.gone = 'pit'; payPin(p); }
      else if (p.x < LANE.x0 || p.x > LANE.x1) { p.alive = false; p.gone = 'gutter'; }
    }
    const b = st.ball;
    if (b && b.alive) {
      if (!b.gutter && !b.box && (b.x - BR * 0.5 < LANE.x0 || b.x + BR * 0.5 > LANE.x1)) { b.gutter = true; b.solid = false; b.x = b.x < 64 ? 19 : 109; b.vx = 0; b.vy = Math.min(b.vy, -60); sfx.miss(); st.labels.push({ s: '进沟了', x: b.x < 64 ? 30 : 98, y: 120, t: 0, c: '#ff8a7a' }); }
      if (b.y < PIT_Y - BR) b.alive = false;
    }
  }
  function settle() {
    const b = st.ball; if (b) b.alive = false;
    st.ball = null;
    s.bodies = s.bodies.filter(x => x.alive);
    const down = pinsDown();
    const R1 = st.roll === 1;
    if (down >= 10) {
      st.mult = R1 ? 2 : 1.5;
      if (R1) {
        st.flash = { s: '全中！', t: 0 }; sfx.strike();
        m().strikes = (m().strikes || 0) + 1;
        if (m().strikes >= 3) { m().strikes = 0; env.jackpot(); }
      } else { st.flash = { s: '补中！', t: 0 }; sfx.win(); m().strikes = 0; }
      env.toast((R1 ? '全中：下一局进坑的瓶 ×2' : '补中：下一局进坑的瓶 ×1.5'), A.GOLD[0]);
      newFrame();
    } else if (R1) {
      m().strikes = 0;
      st.roll = 2;
      st.state = 'aim';
      if (down === 0) sfx.miss();
    } else { st.mult = 1; newFrame(); }
    env.save();
  }
  function newFrame() { st.state = 'reset'; st.resetT = 0; }

  // ---------- 自动打（自测用）：瞄头瓶稍偏一点 ----------
  function auto(dt) {
    const A_ = st.auto || (st.auto = { t: 0 });
    if (st.state !== 'aim') return;
    A_.t += dt; if (A_.t < 0.5) return; A_.t = 0;
    if (env.marbles() <= 0) return;
    const standing = st.pins.filter(p => p.alive && !p.down);
    const tgt = standing.length ? standing.reduce((a, p) => (p.y > a.y ? p : a)) : { x: 64, y: 74 };
    const x = Math.max(36, Math.min(92, tgt.x + (Math.random() - 0.5) * 10));
    startDrag({ sx: x, sy: 120, id: 'auto' });
    st.slide.t = 1; st.ballAt = x;
    const dx = tgt.x + (Math.random() - 0.5) * (6 + 16 * (window.__autoNoise || 0)) - x, dy = tgt.y - START.y, l = Math.hypot(dx, dy);
    const p = 0.75 + Math.random() * 0.25;
    st.drag.x = st.drag.x0 - dx / l * PULL * p; st.drag.y = st.drag.y0 - dy / l * PULL * p;
    release();
  }

  // ---------- 画 ----------
  function aimLine(ctx) {
    if (st.state !== 'drag') return;
    const sh = shot(), bx = st.slide ? st.slide.x0 + (st.slide.x1 - st.slide.x0) * MK.ease(st.slide.t) : st.ballAt;
    const d = st.drag;
    MK.dots(ctx, bx, START.y, bx + (d.x - d.x0), START.y + (d.y - d.y0), '#ffffff', 2);
    if (!sh) return;
    const a = env.val('a'), reach = a >= 2 ? 140 : 30;
    const hit = a >= 2 ? T.firstHit(s, bx, START.y, BR, sh.ux, sh.uy, reach, null) : null;
    const end = hit ? hit.t : reach;
    MK.dots(ctx, bx + sh.ux * (BR + 2), START.y + sh.uy * (BR + 2), bx + sh.ux * end, START.y + sh.uy * end, A.GOLD[0], 3, st.time * 3);
    if (hit) {
      MK.ring(ctx, hit.hx, hit.hy, BR, '#ffffff', 3);
      if (a >= 3 || env.lv('aim')) { const p = hit.body, kx = p.x - hit.hx, ky = p.y - hit.hy, kl = Math.hypot(kx, ky) || 1; MK.dots(ctx, p.x, p.y, p.x + kx / kl * 30, p.y + ky / kl * 30, '#ff8a7a', 2); }
    }
    MK.label(ctx, Math.round(sh.p * 100) + '%', bx + 12, START.y - 6, sh.p >= 0.98 ? '#ff8a7a' : '#ffffff', 'left');
  }
  function draw(ctx) {
    // 护栏：亮两道白边
    if (rails() && (st.state === 'aim' || st.state === 'drag' || st.state === 'roll')) for (let y = 34; y <= 152; y += 2) { MK.px(ctx, LANE.x0, y, '#fff6c0'); MK.px(ctx, LANE.x1 - 1, y, '#fff6c0'); }
    for (const p of st.pins) {
      if (!p.alive) continue;
      const im = p.down ? lying(p.look, p.dir) : PIN[p.look];
      MK.spr(ctx, im, Math.round(p.x - im.width / 2), Math.round(p.y - im.height / 2));
    }
    const b = st.ball;
    if (b && b.alive) MK.spr(ctx, BALL, Math.round(b.x - BALL.width / 2), Math.round(b.y - BALL.height / 2));
    else if (st.state === 'aim' || st.state === 'drag') {
      const bx = st.slide ? st.slide.x0 + (st.slide.x1 - st.slide.x0) * MK.ease(st.slide.t) : st.ballAt;
      if (env.marbles() > 0) MK.spr(ctx, BALL, Math.round(bx - BALL.width / 2), Math.round(START.y - BALL.height / 2));
    }
    aimLine(ctx);
    // 底下一行：第几球、翻倍
    MK.label(ctx, '第 ' + st.roll + ' 球', 28, 147, '#fff3d8', 'left');
    if (st.mult > 1) MK.label(ctx, '×' + st.mult, 100, 147, Math.sin(st.time * 6) > 0 ? A.GOLD[0] : '#ffffff', 'right');
    if (st.state === 'aim' && env.marbles() > 0 && Math.sin(st.time * 5) > 0 && st.rolls < 3) MK.label(ctx, '按住往后拉', 64, 122, A.GOLD[0], 'center');
    for (const l of st.labels) MK.label(ctx, l.s, l.x, l.y - l.t * 8, l.c || A.GOLD[0], 'center');
    if (st.flash) { const t = st.flash.t; if (t < 1.4 && Math.floor(t * 8) % 2 === 0) MK.label(ctx, st.flash.s, 64, 90, '#ffffff', 'center'); }
    MK.led(ctx, env.marbles(), env.marbles() <= 0, st.time);
  }

  return {
    s,
    fine() {},
    update(dt) {
      st.time += dt;
      if (st.slide && st.slide.t < 1) st.slide.t = Math.min(1, st.slide.t + dt / 0.15);
      if (st.state === 'roll') {
        T.advance(s, dt, st.acc, (a, b) => !(a.kind === 'ball' && b.kind === 'ball'), after);
        for (const e of s.events.splice(0)) { if (e.type === 'hit') { const pinPin = e.a.kind === 'pin' && e.b.kind === 'pin'; if (pinPin) sfx.clack(e.impact); else sfx.pinHit(e.impact * 4); } }
        const ballGone = !st.ball || !st.ball.alive;
        if (ballGone && !T.moving(s, 1.5)) { st.quiet += dt; if (st.quiet > 0.35) settle(); } else st.quiet = 0;
        if (st.ball && st.ball.alive && Math.hypot(st.ball.vx, st.ball.vy) < 3) st.ball.alive = false;   // 球停在道上：算这一球完了
      } else s.events.length = 0;
      if (st.state === 'reset') {
        st.resetT += dt;
        if (st.resetT > 0.6) { setPins(); st.state = 'aim'; st.ballAt = START.x; sfx.hop(6); }
      }
      if (st.flash) { st.flash.t += dt; if (st.flash.t > 1.5) st.flash = null; }
      for (const l of st.labels) l.t += dt;
      st.labels = st.labels.filter(l => l.t < 1);
    },
    draw,
    down(p) {
      if (p.btn !== 0) return false;
      if (st.state === 'aim') return startDrag(p);
      return st.state !== 'aim';
    },
    move(p) { if (st.state === 'drag' && st.drag.by !== 'auto') { st.drag.x = p.sx; st.drag.y = p.sy; } },
    up(p) { if (st.state === 'drag' && st.drag.by === p.id) release(); },
    key() { return false; },
    cancel() { if (st.state === 'drag') { st.drag = null; st.slide = null; st.state = 'aim'; } },
    leave() { if (st.state === 'drag') { st.drag = null; st.slide = null; st.state = 'aim'; } },
    auto,
    inPlay: () => st.state === 'roll' || st.state === 'drag' || st.state === 'reset',
    busy: () => st.state === 'drag',
    hint() {
      if (st.state === 'drag') return '松手滚出去（往下拉才打；拉回原处不打）';
      if (st.state !== 'aim' || env.marbles() <= 0) return '';
      if (st.rolls < 3) return '在卡上按住（球挪到那一列）往后拉，松手滚出去。瓶子滚进后面的黑坑才算钱';
      if (st.roll === 2) return '第二球：把倒在道上的瓶也推进坑';
      return '';
    },
    info() {
      const out = [
        ['一局两球 · 现在第 ' + st.roll + ' 球 · 倒了 ' + pinsDown() + '/10', null],
        ['一个瓶进坑吐 ' + env.val('v') + ' 个' + (env.val('g') ? '（金瓶 ×3）' : ''), null],
      ];
      if (st.mult > 1) out.push(['这一局进坑的瓶 ×' + st.mult + '（上一局' + (st.mult === 2 ? '全中' : '补中') + '）', A.GOLD[0]]);
      out.push(['连着全中 ' + (m().strikes || 0) + '/3（三局 = 大奖）', (m().strikes || 0) ? A.GOLD[0] : null]);
      if (env.val('r')) out.push(['护栏：每局前 ' + env.val('r') + ' 球不进沟', null]);
      return out;
    },
    onUpgrade() {},
    debug: () => ({ state: st.state, roll: st.roll, down: pinsDown(), mult: st.mult, pit: st.pitN, rolls: st.rolls }),
  };
});
