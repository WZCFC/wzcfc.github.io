/*
 * 第 4 台 · 火山坑（进洞的第二台）。钉阵中间一座火山，山坡上三个岩浆坑；底下 9 个洞，亮着的是中奖洞。
 *   按住拉弹簧、松手打冰珠（力度换算、钉阵同基础机：同一个力度永远落同一个地方）。
 *   落进亮洞：吐【价】个。落进岩浆坑：凝成一块石头，【速】块填满一个坑（填满的坑珠子从上面滚过去）。
 *   三个坑都满：火山轰隆一下喷发，一把火山弹（5 颗）撒下来，落进亮洞一颗吐 3 倍；坑清空。
 *   每发打完重新抽亮洞（【签】亮几个）。每发自己挑：填坑，还是直接打洞。
 *   金火山弹（碰运气）：喷发时 3% 有一颗金的，落进亮洞 ×5。黑曜石（手上功夫 = 大奖）：一次喷发 5 颗全进亮洞。
 *   火山石（打得深）：这一局喷发 20 次。保底、力度刻度（技能树进洞那枝）跟基础机一样。
 */
Machines.def('volcano', env => {
  'use strict';
  const { A, sfx } = env;
  const B = window.Board, S = MK.sprites(), INK = A.INK, FX = A.FX, FY = A.FY;
  const s = B.create((Date.now() ^ (Math.random() * 1e9)) >>> 0);
  s.full = [false, false, false];
  const pl = MK.plunger(sfx);
  const iceIm = MK.ball7(A.MARB.ice);
  const bombIm = A.ballSprite(3, ['#a82a1a', '#fe4c40', '#ffb21a']), goldIm = A.ballSprite(3, ['#c47a10', '#ffd23a', '#fff6c0']);
  const flame = A.outlined(['..x..', '.xyx.', '.xyx.', 'xyyyx', 'xywyx', '.xxx.'], { x: '#fe4c40', y: '#ffd23a', w: '#ffffff' }, INK);
  const st = { phase: 'ready', acc: { t: 0 }, time: 0, lit: [], stones: [0, 0, 0], rumble: 0, erupting: 0, eruptHit: 0, eruptHand: false, flashHole: new Map(), pegFlash: new Map(), labels: [], trail: [], auto: null };
  const m = () => env.m();

  // ---------- 看得见的那一层（11-11）：岩浆坑、冰珠掉进坑、喷发 ----------
  // 坑画在台面这一层（卡面虚化以后看不出是坑）：深边、一圈石沿、里头岩浆流着冒泡。
  // 一个坑分【速】段，冰珠掉在哪儿，离得最近的那一段凝成石头（先白一下）；段都盖上了，石缝透红光
  const LAVA = ['#fff3a0', '#ffd23a', '#ff9700', '#e8452a', '#a82a1a'], ROCK = ['#c8c8d4', '#8a8a9a', '#5a5a6a', '#3a3a48'];
  const RIM = ['#c96a48', '#a24a36', '#7a3230'], PIT_IN = '#2a0f22';
  const puffImgs = C => [A.outlined(['ww'], C, INK), A.outlined(['.ww.', 'wwws'], C, INK), A.outlined(['.www.', 'wwwws', '.sss.'], C, INK)];
  const STEAM = puffImgs({ w: '#ffffff', s: '#c8d4dc' }), SMOKE = puffImgs({ w: '#e8e0d8', s: '#a89a90' });
  const CHIPS = [A.outlined(['ab', 'bc'], { a: ROCK[0], b: ROCK[1], c: ROCK[2] }, INK), A.outlined(['abb'], { a: ROCK[0], b: ROCK[1] }, INK), A.outlined(['a', 'b'], { a: ROCK[1], b: ROCK[2] }, INK)];
  const FLARE = A.outlined(['...x...', '..xyx..', '..xyx..', '.xyyyx.', '.xywyx.', 'xyywyyx', 'xywwwyx', '.xyyyx.'], { x: '#fe4c40', y: '#ffd23a', w: '#ffffff' }, INK);
  const fx = [], sinks = [], flare = new Map(), bub = [null, null, null];
  let crust = [[], [], []];   // 每个坑每一段什么时候凝的（null = 还是岩浆）
  const cnt = { pit: 0, rumble: 0, erupt: 0, bomb: 0 };   // 连拍图等这几样
  let erT = -1, mouthT = -1, rumbleSmoke = 0;   // 喷了几秒（-1 = 没在喷）；火山口亮到什么时候
  const rnd = (a, b) => a + Math.random() * (b - a);
  function slots(i) {
    const need = env.val('s');
    if (crust[i].length !== need) { const k = Math.min(need, st.stones[i]); crust[i] = Array.from({ length: need }, (_, j) => (j < k ? -9 : null)); }
    return crust[i];
  }
  // 冰珠掉进坑：往岩浆里沉下去，"滋"冒两团白汽、溅两三滴；掉的那一段凝成石头
  function sinkIce(i, x, y) {
    const p = B.PITS[i], c = slots(i), n = c.length, cx = Math.max(p.x - 7, Math.min(p.x + 7, x));
    let best = -1, bd = Infinity;
    c.forEach((v, j) => { if (v != null) return; const d = Math.abs(p.x - 8 + (j + 0.5) * 16 / n - cx); if (d < bd) { bd = d; best = j; } });
    if (best >= 0) c[best] = st.time + 0.1;
    sinks.push({ i, x0: x, y0: y, x: cx, t: 0 });
    cnt.pit++;
    if (sfx.sizzle) sfx.sizzle();
  }
  function startRumble(shake) {
    st.rumble = 0.6; st.eruptHand = true; sfx.rumble(); if (shake) env.shake(0.6);
    cnt.rumble++; mouthT = st.time + 2; rumbleSmoke = 0;
  }
  function fxUpdate(dt) {
    for (const k of sinks) {
      const p = B.PITS[k.i];
      k.t += dt;
      if (k.t >= 0.04 && !k.sp) { k.sp = true; for (let j = 0; j < 3; j++) fx.push({ k: 'spark', c: LAVA[1 + (j % 2)], x: k.x, y: p.y - 2, vx: rnd(-14, 14), vy: rnd(-32, -20), g: 260, floor: p.y - 1, life: 0.4, t: 0 }); }
      if (k.t >= 0.06 && !k.st) { k.st = true; for (const d of [-1, 1]) fx.push({ k: 'puff', im: STEAM, fr: [0, 1, 2, 1], x: k.x + d * 1.5, y: p.y - 3, vx: d * rnd(2, 5), vy: rnd(-20, -14), drag: 1.2, life: 0.7, t: d > 0 ? -0.08 : 0 }); }
    }
    for (let i = sinks.length - 1; i >= 0; i--) if (sinks[i].t > 0.14) sinks.splice(i, 1);
    for (const p of fx) {
      p.t += dt;
      if (p.t < 0 || p.k === 'splat' || p.land) continue;
      p.vy += (p.g || 0) * dt; p.x += p.vx * dt; p.y += p.vy * dt;
      if (p.drag) { const k = Math.max(0, 1 - p.drag * dt); p.vx *= k; p.vy *= k; }
      if (p.k === 'drop' && p.vy > 0 && p.y >= p.landY) { p.k = 'splat'; p.t = 0; p.life = 1; p.y = Math.round(p.landY); p.x = Math.round(p.x); }
      else if (p.k === 'chip' && p.vy > 0 && p.y >= p.floor) { p.land = true; p.life = p.t + 0.3; }
      else if (p.k === 'spark' && p.vy > 0 && p.y >= p.floor) p.life = 0;
    }
    for (let i = fx.length - 1; i >= 0; i--) { const p = fx[i]; if (p.t >= p.life || p.x < Sim.X0 || p.x > 102) fx.splice(i, 1); }
    // 冒泡：每个坑隔一会儿冒一个
    B.PITS.forEach((p, i) => {
      const b = bub[i];
      if (b && st.time - b.t < 0.3) return;
      if (!b || st.time - b.t > b.gap) bub[i] = { t: st.time, gap: rnd(0.8, 1.8), x: p.x + Math.round(rnd(-5, 5)), y: p.y + Math.round(rnd(-1, 1)) };
    });
    for (const [k, t] of flare) { if (t - dt <= 0) flare.delete(k); else flare.set(k, t - dt); }
    if (erT >= 0) { erT += dt; if (erT > 1.2) erT = -1; }
    if (st.rumble > 0) { rumbleSmoke -= dt; if (rumbleSmoke <= 0) { rumbleSmoke = 0.1; fx.push({ k: 'puff', im: SMOKE, fr: [0, 1, 0], x: B.CRATER.x + rnd(-4, 4), y: B.CRATER.y - 2, vx: rnd(-6, 6), vy: rnd(-16, -10), drag: 1, life: 0.6, t: 0 }); } }
    // 火山弹身后拖一个火星
    for (const b of s.balls) { if (b.kind !== 'bomb' || b.t < 0) continue; (b.tr || (b.tr = [])).unshift([b.x, b.y]); if (b.tr.length > 3) b.tr.length = 3; }
  }
  // 一个坑：外圈深边 → 石沿（左上亮、右下暗）→ 里头：最上一行是坑壁的影子，底下是岩浆（流着的亮点、冒泡），凝了的那一段是石头
  function drawPit(ctx, i) {
    const p = B.PITS[i], c = slots(i), n = c.length, full = s.full[i], hot = st.rumble > 0;
    const glow = hot ? (Math.sin(st.time * 40) > 0 ? LAVA[0] : LAVA[1]) : Math.sin(st.time * 5 + i) > 0 ? LAVA[2] : LAVA[3];
    const flow = Math.floor(st.time * 1.5), b = bub[i], bt = b ? st.time - b.t : 9;
    const lift = hot && full && Math.sin(st.time * 45 + i * 2) > 0 ? 1 : 0;   // 轰隆：石盖往上顶一格
    for (let y = p.y - 6; y <= p.y + 5; y++) for (let x = p.x - 11; x <= p.x + 10; x++) {
      const u = x + 0.5 - p.x, v = y + 0.5 - p.y, e = (a, bb) => (u / a) ** 2 + (v / bb) ** 2;
      if (e(10.8, 6) > 1) continue;   // 正好盖住卡面上画的那个坑
      let col;
      if (e(9.8, 5) > 1) col = INK;
      else if (e(8.2, 3.9) > 1) col = u + v * 2 < -5 ? RIM[0] : u + v * 2 > 5 ? RIM[2] : RIM[1];
      else {
        const r = y - p.y + lift, j = Math.max(0, Math.min(n - 1, Math.floor((u + 8) / (16 / n)))), ft = c[j];
        if (r <= -3) col = PIT_IN;
        else if (r > 3) col = LAVA[0];
        else if (ft != null && st.time >= ft) {
          // 石头：上沿亮、下沿暗；段和段之间、段中间一道缝（满了透红光）
          const x0 = p.x - 8 + j * 16 / n, mid = Math.floor(x0 + 8 / n), seam = n === 1 ? mid : Math.ceil(x0), crack = (n === 1 || (j > 0 && c[j - 1] != null)) && r > -2 && r < 2 && x === seam;
          col = st.time - ft < 0.05 ? '#ffffff' : crack ? (full ? glow : ROCK[3]) : r === -2 ? ROCK[0] : r >= 2 ? ROCK[2] : ROCK[1];
        } else {
          const ph = ((x - p.x + flow + r * 3) % 8 + 8) % 8;
          col = r === -2 ? LAVA[3] : (r === 0 ? ph === 3 || ph === 4 : r === -1 || r === 1 ? ph === 0 : false) ? LAVA[1] : LAVA[2];
          if (b && bt < 0.3) {
            if (bt < 0.15 && x === b.x && y === b.y) col = LAVA[0];
            else if (bt >= 0.15 && Math.abs(x - b.x) + Math.abs(y - b.y) === 1) col = LAVA[1];
            else if (bt >= 0.15 && x === b.x && y === b.y) col = LAVA[4];
          }
        }
      }
      MK.px(ctx, x, y, col);
    }
  }
  // 火山口：轰隆的时候、喷完一会儿亮着（盖在卡面那个口上）
  function drawMouth(ctx) {
    if (!(st.rumble > 0 || st.time < mouthT)) return;
    const cx = B.CRATER.x, cy = B.CRATER.y, flash = erT >= 0 && erT < 0.06, fade = st.rumble > 0 ? 0 : Math.max(0, 1 - (mouthT - st.time) / 1.4);
    const top = flash ? '#ffffff' : st.rumble > 0 ? (Math.sin(st.time * 30) > 0 ? LAVA[0] : LAVA[1]) : fade < 0.5 ? LAVA[1] : LAVA[2];
    const bot = flash ? LAVA[0] : fade < 0.7 ? LAVA[2] : LAVA[3];
    for (let y = cy - 3; y <= cy + 2; y++) for (let x = cx - 9; x <= cx + 8; x++) {
      const u = x + 0.5 - cx, v = y + 0.5 - cy, e = (a, b) => (u / a) ** 2 + (v / b) ** 2;
      if (e(8.2, 2.6) > 1) continue;
      MK.px(ctx, x, y, e(7, 1.7) > 1 ? INK : v < 0 ? top : bot);
    }
  }
  // 岩浆柱：0.1 秒冲上去 26 格，停一下，落回火山口
  function drawFountain(ctx) {
    if (erT < 0 || erT > 0.75) return;
    const t = erT, H = t < 0.1 ? 26 * t / 0.1 : t < 0.3 ? 26 : Math.max(0, 26 - 128 * (t - 0.3) ** 2), k = t < 0.3 ? 1 : 0.75;
    if (H < 2) return;
    const cx = B.CRATER.x, by = B.CRATER.y, top = by - H, rh = 4.6 * k;
    const wAt = v => (3 + 1.2 * (v - top) / H + Math.max(0, 3 - (by - v)) * 0.9) * k;
    const inF = (x, y) => {
      const u = Math.abs(x + 0.5 - cx), v = y + 0.5;
      if (v > by) return false;
      if ((u / rh) ** 2 + ((v - top) / 3) ** 2 <= 1) return true;
      return v >= top && u <= wAt(v);
    };
    const scroll = Math.floor(t * 40);
    for (let y = Math.floor(top - 4); y <= by; y++) for (let x = cx - 9; x <= cx + 8; x++) {
      if (inF(x, y)) {
        const u = Math.abs(x + 0.5 - cx), v = y + 0.5, w = v < top + 2 ? rh : wAt(v);
        MK.px(ctx, x, y, v < top - 1.5 ? LAVA[1] : u < 1 ? ((y + scroll) % 4 === 0 ? LAVA[0] : LAVA[1]) : u < w * 0.7 ? LAVA[2] : LAVA[3]);
      } else if (y < by - 1 && (inF(x - 1, y) || inF(x + 1, y) || inF(x, y - 1) || inF(x, y + 1))) MK.px(ctx, x, y, INK);
    }
  }
  function drawSplats(ctx) {
    for (const p of fx) {
      if (p.k !== 'splat') continue;
      const c = p.t < 0.25 ? LAVA[1] : p.t < 0.55 ? LAVA[3] : p.t < 0.8 ? LAVA[4] : ROCK[3];
      MK.px(ctx, p.x, p.y, c); if (p.t < 0.8) MK.px(ctx, p.x + 1, p.y, c);
    }
  }
  function drawFx(ctx) {
    for (const p of fx) {
      if (p.t < 0 || p.k === 'splat') continue;
      if (p.k === 'spark') MK.px(ctx, p.x, p.y, p.c);
      else if (p.k === 'drop') MK.px(ctx, p.x, p.y, LAVA[1]);
      else if (p.k === 'chip') { if (!p.land || Math.floor(p.t * 16) % 2) MK.sprC(ctx, p.im, p.x, p.y); }
      else if (p.k === 'puff') MK.sprC(ctx, p.im[p.fr[Math.min(p.fr.length - 1, Math.floor(p.t / p.life * p.fr.length))]], p.x, p.y);
    }
  }
  // 亮洞：每发重抽
  function drawLit() {
    let n = env.val('n');
    // 主线里这台第一发必中：九个洞全亮（env.first：这台一发都还没打过）
    if (env.first && env.first()) n = 9;
    const pity = env.lv('pity'), need = pity === 2 ? 2 : pity === 1 ? 3 : Infinity;
    if (m().misses >= need) { n += 1; m().misses = 0; env.toast('保底：这一发多亮一个洞'); }
    const all = [0, 1, 2, 3, 4, 5, 6, 7, 8];
    for (let i = all.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [all[i], all[j]] = [all[j], all[i]]; }
    st.lit = all.slice(0, Math.min(9, n)).sort((a, b) => a - b);
    sfx.settle(st.lit.length);
  }
  drawLit();
  const iceFlying = () => s.balls.some(b => b.kind === 'ice');
  // 力度刻度：每个力度落哪（坑满没满不一样，分开算、记住）
  const gaugeCache = new Map();
  function gauge() {
    const key = s.full.join();
    if (!gaugeCache.has(key)) { const out = []; for (let i = 0; i <= 100; i++) out.push(B.outcome(i / 100, s.full.slice())); gaugeCache.set(key, out); }
    return gaugeCache.get(key);
  }

  function startCharge(by) { if (st.phase !== 'ready' || iceFlying()) return false; if (env.marbles() <= 0) { env.deny('marbles'); return false; } pl.start(by); st.phase = 'charge'; return true; }
  function release() {
    if (st.phase !== 'charge') return;
    const p = pl.release();
    if (!env.spend()) { st.phase = 'ready'; return; }
    B.launch(s, p);
    st.phase = 'fly'; st.trail.length = 0;
    sfx.launch(p);
  }
  function endIce() { st.phase = 'ready'; drawLit(); env.save(); }
  function pay(base, hole, label) {
    const n = env.award(base, { at: [Sim.holeCx(hole), 146], n: Math.min(10, Math.ceil(base / 2)) });
    st.flashHole.set(hole, 0.5);
    if (label) st.labels.push({ s: label, x: Sim.holeCx(hole), y: 138, t: 0 });
    return n;
  }
  function onEvent(e) {
    if (e.type === 'hit') {
      if (e.kind === 'peg') { sfx.pin(e.impact, e.id); st.pegFlash.set(e.id, 0.12); }
      else if (e.kind === 'bump') sfx.bump(e.impact);
      else if (e.kind === 'roof') sfx.rim(e.impact);
      else if (e.kind !== 'head') sfx.wall(e.impact);
    } else if (e.type === 'fallback') { env.refund(); sfx.fallback(); st.phase = 'ready'; }
    else if (e.type === 'pit') {
      const i = e.pit, need = env.val('s');
      st.stones[i] = Math.min(need, st.stones[i] + 1);
      sfx.stone();
      sinkIce(i, e.x, e.y);
      if (st.stones[i] >= need) s.full[i] = true;
      m().misses = 0;
      if (s.full.every(Boolean) && st.rumble <= 0 && st.erupting <= 0) startRumble(true);
      endIce();
    } else if (e.type === 'land') {
      const b = e.b, lit = st.lit.includes(e.hole);
      if (b.kind === 'ice') {
        if (lit) { pay(env.val('v'), e.hole); sfx.win(); m().hits += 1; m().misses = 0; }
        else { sfx.miss(); m().misses += 1; }
        endIce();
      } else {
        st.erupting -= 1; cnt.bomb++;
        if (lit) flare.set(e.hole, 0.3);
        else {
          const hx = Sim.holeCx(e.hole);
          fx.push({ k: 'puff', im: SMOKE, fr: [0, 1, 0], x: hx, y: 144, vx: 0, vy: -10, drag: 1.5, life: 0.45, t: 0 });
          for (const d of [-1, 1]) fx.push({ k: 'spark', c: LAVA[2], x: hx, y: 145, vx: d * rnd(8, 16), vy: rnd(-26, -16), g: 220, floor: 146, life: 0.4, t: 0 });
        }
        if (lit) {
          st.eruptHit += 1;
          const base = env.val('v') * 3 * (b.gold ? 5 : 1);
          pay(base, e.hole, b.gold ? '金 ×5' : null);
          sfx.win();
          if (b.gold) env.find('luck');
        } else sfx.miss();
        if (st.erupting <= 0) {
          if (st.eruptHand && st.eruptHit >= 5) env.jackpot();
          st.eruptHit = 0;
        }
      }
    }
  }
  function erupt() {
    const goldIdx = env.luck(0.03) ? Math.floor(Math.random() * 5) : -1;
    B.erupt(s, 5, Math.random, goldIdx);
    st.erupting = 5; st.eruptHit = 0;
    st.stones = [0, 0, 0]; s.full = [false, false, false];
    m().erupts = (m().erupts || 0) + 1;
    if (m().erupts >= 20) env.find('deep');
    sfx.erupt(); env.shake(0.5);
    erT = 0; mouthT = st.time + 1.4; cnt.erupt++;
    // 三个坑的石盖崩开，岩浆又露出来
    B.PITS.forEach(p => { for (let j = 0; j < 3; j++) fx.push({ k: 'chip', im: CHIPS[j % 3], x: p.x + rnd(-6, 6), y: p.y - 1, vx: rnd(-26, 26), vy: rnd(-55, -35), g: 260, floor: p.y + rnd(2, 9), life: 2, t: 0 }); });
    crust = [[], [], []];
    // 一大团烟往上冒；岩浆从柱顶甩出去，落在山坡上一摊一摊冷掉
    for (let j = 0; j < 4; j++) { const d = j % 2 ? 1 : -1; fx.push({ k: 'puff', im: SMOKE, fr: [1, 2, 2, 1], x: B.CRATER.x + d * rnd(6, 9), y: B.CRATER.y - 3, vx: d * rnd(6, 12), vy: rnd(-18, -10), drag: 0.8, life: rnd(1, 1.3), t: -0.15 - j * 0.1 }); }
    for (let j = 0; j < 4; j++) { const d = j % 2 ? 1 : -1; fx.push({ k: 'drop', x: B.CRATER.x + d * 2, y: B.CRATER.y - 22, vx: d * rnd(14, 34), vy: rnd(-40, -20), g: 240, landY: B.CRATER.y + rnd(10, 46), life: 3, t: -0.08 - j * 0.05 }); }
    env.save();
  }

  // 自动打（自测用）：坑没满先填坑，不然挑亮洞（照力度刻度）
  function auto(dt) {
    const A_ = st.auto || (st.auto = { t: 0, target: 0 });
    if (st.phase === 'ready' && !iceFlying()) {
      A_.t += dt; if (A_.t < 0.3) return; A_.t = 0;
      const g = gauge(), want = [];
      for (let i = 0; i <= 100; i++) { const o = g[i]; if (typeof o === 'string' && !s.full[+o.slice(3)]) want.push(i); }
      const lit = []; for (let i = 0; i <= 100; i++) if (typeof g[i] === 'number' && st.lit.includes(g[i])) lit.push(i);
      const pick = (Math.random() < 0.6 && want.length ? want : lit.length ? lit : want);
      A_.target = pick.length ? pick[Math.floor(Math.random() * pick.length)] / 100 : Math.random();
      const k = window.__autoNoise || 0;
      if (k) A_.target = Math.max(0.02, Math.min(0.99, A_.target + Math.sqrt(-2 * Math.log(1 - Math.random())) * Math.cos(2 * Math.PI * Math.random()) * 0.05 * k));
      startCharge('auto');
    } else if (st.phase === 'charge' && pl.by === 'auto' && Sim.holdPower(pl.t) >= A_.target) release();
  }

  return {
    s,
    fine(f) {
      MK.fineHoles(f);
      MK.fineLane(f, Sim.DEFAULTS.guard);
      MK.finePegs(f, B.pegs());
      f.fineMeter();
    },
    update(dt) {
      st.time += dt;
      if (st.phase === 'charge') pl.update(dt);
      if (st.rumble > 0) { st.rumble -= dt; if (st.rumble <= 0) erupt(); }
      if (s.balls.length) {
        B.advance(s, dt * 1.3, st.acc);
        const ice = s.balls.find(b => b.kind === 'ice');
        if (ice) { st.trail.unshift([ice.x, ice.y]); if (st.trail.length > 6) st.trail.length = 6; } else st.trail.length = 0;
        for (const e of s.events.splice(0)) onEvent(e);
      } else { s.events.length = 0; st.trail.length = 0; }
      fxUpdate(dt);
      for (const mp of [st.flashHole, st.pegFlash]) for (const [k, t] of mp) { if (t - dt <= 0) mp.delete(k); else mp.set(k, t - dt); }
      for (const l of st.labels) l.t += dt;
      st.labels = st.labels.filter(l => l.t < 1);
    },
    draw(ctx) {
      // 洞：亮洞是一盏黄灯 + 一朵小火苗
      for (let i = 0; i < 9; i++) {
        const lit = st.lit.includes(i), fl = st.flashHole.get(i);
        MK.spr(ctx, lit || (fl && Math.sin(fl * 30) > 0) ? S.lampOn : S.lampOff, 16 + 10 * i, 149);
        if (flare.has(i)) MK.spr(ctx, FLARE, Sim.holeCx(i) - 4.5, 136);
        else if (lit) MK.spr(ctx, flame, Sim.holeCx(i) - 3.5, 138 + (Math.sin(st.time * 6 + i) > 0 ? 0 : -1));
      }
      // 岩浆坑（凝了几段一眼看得出，不另画格子、不写字）；冰珠往里沉（只露岩浆面上那一截）
      for (let i = 0; i < 3; i++) drawPit(ctx, i);
      drawSplats(ctx);
      for (const k of sinks) {
        const p = B.PITS[k.i], u = Math.min(1, k.t / 0.12);
        ctx.save(); ctx.beginPath(); ctx.rect(0, 0, ctx.canvas.width, FY(p.y - 1)); ctx.clip();
        MK.spr(ctx, iceIm, Math.round(k.x0 + (k.x - k.x0) * u - 3.5), Math.round(k.y0 + (p.y + 3 - k.y0) * u - 3.5));
        ctx.restore();
      }
      drawMouth(ctx);
      drawFountain(ctx);
      MK.lane(ctx, st.phase === 'charge' ? pl.pull() : 0, env.marbles() > 0 && (st.phase === 'ready' || st.phase === 'charge') && !iceFlying() ? iceIm : null);
      A.drawMeter(ctx, pl.power(), st.phase === 'charge');
      if (env.lv('gauge') && (st.phase === 'ready' || st.phase === 'charge')) MK.gaugeTicks(ctx, gauge(), o => (typeof o === 'number' && st.lit.includes(o) ? A.GOLD[0] : typeof o === 'string' && !s.full[+o.slice(3)] ? '#ff6a3a' : null));
      for (const [id] of st.pegFlash) { const c = s.colliders[id]; if (c && c.kind === 'peg') MK.spr(ctx, S.pegHit, c.x - 2, c.y - 2); }
      drawFx(ctx);
      const t1 = st.trail[2];
      if (t1) MK.px(ctx, t1[0], t1[1], '#a8e8ff');
      for (const b of s.balls) {
        if (b.t < 0) continue;
        if (b.kind === 'ice') MK.spr(ctx, iceIm, Math.round(b.x - 3.5), Math.round(b.y - 3.5));
        else {
          if (b.tr && b.tr[2]) MK.px(ctx, b.tr[2][0], b.tr[2][1], LAVA[2]);
          const im = b.gold ? goldIm : bombIm; MK.spr(ctx, im, Math.round(b.x - im.width / 2), Math.round(b.y - im.height / 2));
        }
      }
      for (const l of st.labels) MK.label(ctx, l.s, l.x, l.y - l.t * 8, A.GOLD[0], 'center');
      MK.led(ctx, env.marbles(), env.marbles() <= 0, st.time);
    },
    down(p) {
      if (!p.inCard || p.btn !== 0) return false;
      if (st.phase === 'ready') { startCharge(p.id); return true; }
      return st.phase !== 'ready';
    },
    up(p) { if (st.phase === 'charge' && pl.by === p.id) release(); },
    key(code, down) {
      if (code !== 'Space' && code !== 'ArrowDown' && code !== 'Enter') return false;
      if (down) startCharge('key'); else if (st.phase === 'charge' && pl.by === 'key') release();
      return true;
    },
    cancel() { if (st.phase === 'charge') { pl.cancel(); st.phase = 'ready'; } },
    leave() { if (st.phase === 'charge') { pl.cancel(); st.phase = 'ready'; } },
    auto,
    inPlay: () => st.phase === 'charge' || s.balls.length > 0 || st.rumble > 0,
    busy: () => st.phase === 'charge',
    hint() {
      if (st.rumble > 0 || st.erupting > 0) return '火山喷发！火山弹落进亮洞，一颗吐 3 倍';
      if (st.phase === 'charge') return '松手发射';
      if (st.phase === 'ready' && env.marbles() > 0 && m().shots < 5) return '按住拉弹簧、松手打。落进亮洞吐筹码；掉进岩浆坑凝成石头，三个坑满了火山喷发';
      return '';
    },
    info() {
      const need = env.val('s');
      const out = [
        ['亮 ' + st.lit.length + ' 个洞 · 中一个吐 ' + env.val('v') + ' 个', null],
        ['坑：' + st.stones.map((k, i) => (s.full[i] ? '满' : k + '/' + need)).join(' · ') + '（三个满了喷发）', null],
        ['喷发：火山弹进亮洞一颗吐 ' + env.val('v') * 3 + ' 个', null],
      ];
      if (st.erupting > 0) out.push(['这一次喷发进了 ' + st.eruptHit + ' 颗（5 颗全进 = 大奖）', A.GOLD[0]]);
      const pity = env.lv('pity');
      if (pity) out.push(['保底：连空 ' + (pity === 2 ? 2 : 3) + ' 发多亮一个（已空 ' + m().misses + '）', null]);
      return out;
    },
    onUpgrade(k) { if (k === 's') { const need = env.val('s'); for (let i = 0; i < 3; i++) { st.stones[i] = Math.min(st.stones[i], need); if (st.stones[i] >= need) s.full[i] = true; } if (s.full.every(Boolean) && st.rumble <= 0 && st.erupting <= 0) startRumble(false); } },
    debug: () => ({ phase: st.phase, lit: st.lit, stones: st.stones, full: s.full, erupts: m().erupts || 0, fx: cnt }),
    // 连拍图用：stones 摆好每个坑凝了几块；rumble 三个坑一下全满、马上轰隆
    cheat(o) {
      const need = env.val('s');
      if (o.stones) o.stones.forEach((k, i) => { st.stones[i] = Math.min(need, k); s.full[i] = st.stones[i] >= need; crust[i] = []; });
      if (o.rumble) { for (let i = 0; i < 3; i++) { st.stones[i] = need; s.full[i] = true; crust[i] = []; } startRumble(true); }
    },
  };
});
