/*
 * 主线的存档和算数（不画画，Node 里也能跑）。照《史莱姆主线 · 执行方案 v3》。
 *   存档 S（v4）：
 *     gold 金币、earned 一共挣过（转生不清，两边栏看它）、tree 每个节点几级（斩草除根的树和小游戏里头的都在这儿）、
 *     revealed 露过的节点（转生不清）、seen 看过的提示、calls 电话（heard 听过的、queue 等着打的）、
 *     maxStage 这一世打到过第几关（只在某一关有用的节点看它）、best 一共最深、life 这一世（deep 最深、runs 几轮）、runs、kills、trophies、
 *     shown 上了桌的小游戏（转生不清，盖回红布）、mini 开了的小游戏（弹珠、奖券、小人开关……）、pick 这轮带哪颗球、
 *     pp 转生点、perks 转生树、prestiges 转了几次、canPrestige 转生按钮有没有、helperSpeed 小人速率几级、
 *     from 下一轮从第几关打起（0 是这一世打到过的最深那关；选关）、devTool 作者来电送的工具（右上角扳手，随时开开发者面板）
 *   钱（第三节）：金币，和每台小游戏一种奖券（存在 S.mini[台].chips）。一个价最多两种钱：金币 + 一种奖券。
 *   露（第四节）：节点只看前置（买过一级 / 买满 / 挣到第一枚金币 / 开了那台 / 这一世打到过那一关）。
 *     一次买下去（开台、第一次看到一关也算）最多露两个新的，机台上桌也算一个；露过的转生不清。
 *   stats(S)：这一轮台子用的数。数值的一轮开头才算进去（买了下一轮生效，"重来"能马上用上）；台上的零件买了马上装
 *   小游戏的打法照十八台那版（machines/*.js，R18.BY[id]），里头的升级换成 data.js 的节点（数从小起）
 */
(function (root, factory) {
  const node = typeof module === 'object' && module.exports;
  const D = node ? require('./data.js') : root.MainData;
  const R18 = node ? require('../rules.js') : root.Rules;
  const api = factory(D, R18);
  if (node) module.exports = api;
  else root.MainRules = api;
}(typeof self !== 'undefined' ? self : globalThis, function (D, R18) {
  'use strict';
  const BY = Object.fromEntries(D.NODES.map(n => [n.id, n]));
  const MBY = Object.fromEntries(D.MINIS.map(m => [m.id, m]));
  const PBY = Object.fromEntries(D.PERKS.map(p => [p.id, p]));
  const LIFE = () => ({ deep: { stage: 1, layer: 1 }, runs: 0 });
  function newSave() {
    return {
      v: 4, gold: 0, earned: 0, tree: {}, revealed: {}, seen: {}, calls: { heard: {}, queue: [] },
      maxStage: 1, best: { stage: 1, layer: 1 }, life: LIFE(), runs: 0, kills: 0, trophies: {},
      shown: {}, mini: {}, pick: 'glass',
      pp: 0, perks: {}, prestiges: 0, canPrestige: false, helperSpeed: 0, savedAt: 0, from: 0, devTool: 0,
    };
  }
  function load(str) {
    try {
      const o = JSON.parse(str);
      if (!o || o.v !== 4) return null;
      const S = Object.assign(newSave(), o);
      S.best = Object.assign({ stage: 1, layer: 1 }, o.best);
      S.life = Object.assign(LIFE(), o.life); S.life.deep = Object.assign({ stage: 1, layer: 1 }, S.life.deep);
      S.calls = { heard: Object.assign({}, o.calls && o.calls.heard), queue: ((o.calls && o.calls.queue) || []).slice() };
      for (const k of ['tree', 'revealed', 'seen', 'trophies', 'shown', 'mini', 'perks']) S[k] = Object.assign({}, o[k] || {});
      for (const id of Object.keys(S.mini)) { S.mini[id] = Object.assign(blankMini(), S.mini[id]); S.mini[id].bot = Object.assign(blankBot(), S.mini[id].bot); }
      if (!owned(S, S.pick)) S.pick = 'glass';
      return S;
    } catch (e) { return null; }
  }

  // =========================================================================
  // 节点：几级、价、露
  // =========================================================================
  const maxLv = n => (n.gold || n.tix || []).length;
  // 夹在上限内：改表把级数砍短了，旧存档也不会读出 undefined
  const lv = (S, id) => (BY[id] ? Math.min(S.tree[id] || 0, maxLv(BY[id])) : 0);
  const maxed = (S, id) => !!BY[id] && lv(S, id) >= maxLv(BY[id]);
  // 这一级的数（没这个节点的算 0）
  const v = (S, id) => (BY[id] ? BY[id].vals[lv(S, id)] : 0);
  const miniOpen = (S, id) => !!S.mini[id];
  const miniShown = (S, id) => !!S.shown[id];
  // 前置够不够（这一世）：pre 都买过一级、preMax 都买满、at、stage；小游戏里头的要那台开着
  function preOK(S, n) {
    if (n.where !== 'main' && !miniOpen(S, n.where)) return false;
    for (const p of n.pre) if (lv(S, p) <= 0) return false;
    for (const p of n.preMax) if (!maxed(S, p)) return false;
    if (n.stage && S.maxStage < n.stage) return false;
    if (n.at === 'coin' && !(S.earned > 0)) return false;
    if (n.at && n.at.startsWith('open:') && !miniOpen(S, n.at.slice(5))) return false;
    return true;
  }
  // 露着：露过（转生不清）+ 这一世前置够了
  const visible = (S, n) => !!S.revealed[n.id] && preOK(S, n);
  // 露着、一级都没买的（"新节点"）几个；where 只数那一台的
  const fresh = (S, where) => D.NODES.filter(n => (!where || n.where === where) && visible(S, n) && lv(S, n.id) === 0).length;
  // 露新的：前置够了、还没露过的，最多露 room 个（where 只露那一台的）。返回露出来的
  //   from：这一下是怎么来的——买了哪个节点（它带出来的先露，再是同一台的）、开了哪台（那台里头的、开台才有的先露）、
  //   'stage:n'（第一次看到第 n 关：那一关的先露）。同一档的照表上的顺序
  function rank(n, from) {
    if (!from) return 0;
    if (from.startsWith('stage:')) return n.stage === +from.slice(6) ? 0 : 1;
    if (MBY[from]) return n.where === from || n.at === 'open:' + from ? 0 : 1;
    if (n.pre.includes(from) || n.preMax.includes(from)) return 0;
    return BY[from] && n.where === BY[from].where ? 1 : 2;
  }
  function reveal(S, room, where, from) {
    room = room == null ? 2 : room;
    const cands = [];
    D.NODES.forEach((n, i) => { if (!S.revealed[n.id] && (!where || n.where === where) && preOK(S, n)) cands.push([rank(n, from), i, n]); });
    cands.sort((a, b) => a[0] - b[0] || a[1] - b[1]);
    const out = cands.slice(0, room).map(c => c[2]);
    for (const n of out) { S.revealed[n.id] = 1; if (n.showCall) queueCall(S, n.showCall); }
    return out;
  }
  // ---------- 钱 ----------
  const tixOf = (S, id) => (S.mini[id] ? S.mini[id].chips : 0);
  // 这一级的价：{ gold, tix, tixId }；买满了 null
  function price(S, n) {
    const l = lv(S, n.id);
    if (l >= maxLv(n)) return null;
    return { gold: n.gold ? n.gold[l] : 0, tix: n.tix ? n.tix[l] : 0, tixId: n.tixId };
  }
  // 哪一半不够
  const lack = (S, p) => ({ gold: p.gold > 0 && S.gold < p.gold, tix: p.tix > 0 && tixOf(S, p.tixId) < p.tix });
  const canPay = (S, p) => { const l = lack(S, p); return !l.gold && !l.tix; };
  function pay(S, p) { S.gold -= p.gold; if (p.tix) S.mini[p.tixId].chips -= p.tix; }
  // 节点的样子：max 买满、can 买得起、poor 钱不够
  function state(S, n) {
    const p = price(S, n);
    if (!p) return 'max';
    return canPay(S, p) ? 'can' : 'poor';
  }
  // 买一级。返回 { n, shown（这一下上桌的台）, revealed（这一下露出来的）}；买不了 null
  function buy(S, id) {
    const n = BY[id];
    if (!n || !visible(S, n)) return null;
    const p = price(S, n);
    if (!p || !canPay(S, p)) return null;
    pay(S, p);
    S.tree[id] = lv(S, id) + 1;
    const res = { n, shown: null, revealed: [] };
    if (n.shows && !S.shown[n.shows]) { S.shown[n.shows] = 1; res.shown = n.shows; }
    if (n.call) queueCall(S, n.call);
    res.revealed = reveal(S, res.shown ? 1 : 2, null, id);
    return res;
  }
  const perk = (S, id) => S.perks[id] || 0;
  const pv = (S, id) => { const p = PBY[id]; return p.vals ? p.vals[Math.min(perk(S, id), p.vals.length - 1)] : perk(S, id); };
  const isPart = n => !!n.part;

  // =========================================================================
  // 这一轮的数
  // =========================================================================
  // 每颗球那一组：几颗、耐久、力道（转生树的大袋子、厚玻璃、老手每种球都算）
  const BALL_NODES = {
    glass: { bag: 'bag', dur: 'dur', pow: 'power' },
    bone: { unlock: 'boneBall', bag: 'boneBag', dur: 'boneDur', pow: 'bonePow' },
    lava: { unlock: 'lavaBall', bag: 'lavaBag', dur: 'lavaDur', pow: 'lavaPow' },
  };
  for (const B of D.LATE) BALL_NODES[B.k] = { unlock: B.k + 'Ball', bag: B.k + 'Bag', dur: B.k + 'Dur', pow: B.k + 'Pow' };
  // 力道：带 pct 的照百分比往上乘；不带的（前期的玻璃珠、骨球）一级 +1 份，一下打的是整数
  function ballStats(S, kind) {
    const M = D.MARBLES[kind], ids = BALL_NODES[kind] || {}, pn = BY[ids.pow], pw = v(S, ids.pow);
    return {
      bag: M.bag + v(S, ids.bag) + pv(S, 'bigBag') + v(S, 'nightBag'),
      dur: M.dur + v(S, ids.dur) + pv(S, 'thick'),
      power: (pn && !pn.pct ? (M.fen + pw) / M.fen : 1 + pw) * (perk(S, 'elder') ? 2 : 1) * (v(S, 'nightDmg') || 1),
    };
  }
  const cap1 = s => s[0].toUpperCase() + s.slice(1);
  const REVIVERS = ['mud', 'slug', 'snail'];
  function stats(S) {
    const balls = {};
    for (const k of D.BALLS) balls[k] = ballStats(S, k);
    const count = {};
    for (const SD of D.STAGES) if (SD.count) count[SD.n] = SD.count.base + v(S, SD.count.node);
    const revive = {};
    for (const k of REVIVERS) { const id = 'rv' + cap1(k); if (lv(S, id) > 0) revive[k] = { p: 0.05 + v(S, id + 'P'), cap: 5 + v(S, id + 'Cap'), two: v(S, id + 'Two') }; }
    return {
      balls, count,
      // 碎一只的金币 =（血 × 这种史莱姆的倍数 + 赏金）×（1 + 金币加成），金的再 × goldX
      goldAdd: v(S, 'gold1'), goldMult: (1 + v(S, 'gold2')) * GOLDX.reduce((a, id) => a * (v(S, id) || 1), 1) * (v(S, 'nightGold') || 1),
      goldChance: v(S, 'goldSlime') + pv(S, 'shine') / 100, goldX: 5,
      critP: v(S, 'crit'),
      cover: lv(S, 'flip1') > 0 ? D.FLIP.cover + v(S, 'flip1b') + v(S, 'flip2') : 0,
      flipDur: D.FLIP.dur + v(S, 'fdur'),
      bossBall: v(S, 'bossBall'),
      sling: lv(S, 'sling') > 0, lanes: lv(S, 'lanes') > 0, restart: lv(S, 'restart') > 0, recycle: lv(S, 'recycle') > 0,
      spike: lv(S, 'spike') > 0 ? { p: 0.05 + v(S, 'spikeP'), n: 1 + v(S, 'spikeN'), pierce: v(S, 'spikePierce') } : null,
      fire: lv(S, 'fire') > 0 ? { p: 0.1 + v(S, 'fireP'), pct: D.FIRE.pct * (1 + v(S, 'fireHeat')), dur: D.FIRE.dur, spread: v(S, 'spread') } : null,
      revive,
      // 后十颗的本事（11-11 粗做）：没买的是 null / 底子
      chain: 1 + v(S, 'tawChain'),
      push: lv(S, 'push') > 0 ? { x: 2 + v(S, 'pushX') } : null,
      splash: lv(S, 'splash') > 0 ? { r: 12 + v(S, 'splashR') } : null,
      grow: lv(S, 'grow') > 0 ? { max: 3 + v(S, 'growMax') } : null,
      hook: lv(S, 'hooked') > 0 ? { n: 1 + v(S, 'hookN') } : null,
      goalBack: 1 + v(S, 'goalBack'),
      chip: lv(S, 'chip') > 0 ? { gold: 3 + v(S, 'chipGold') } : null,
      bouncy: lv(S, 'bouncy') > 0 ? { v: 1 + v(S, 'bouncyV') } : null,
      rack: lv(S, 'rack') > 0 ? 3 + v(S, 'rackN') : 1,
    };
  }
  const GOLDX = D.NODES.filter(n => /^goldx\d$/.test(n.id)).map(n => n.id);
  // 一轮从哪一关打起（选关，11-11）：这一世打通过的关（打掉那关的 boss，下一关就开了）随便挑，从那关第 1 层打；
  //   没挑的（from 0）从打到过的最深那关打；开了新的一关，挑的清掉，又从最深的打
  const startStage = S => Math.max(1, Math.min(S.maxStage, S.from || S.maxStage));
  // 这一关台上趴几只（没写的照上一关）
  const countFor = (K, stageN) => { for (let i = stageN; i >= 1; i--) if (K.count[i] != null) return K.count[i]; return 1; };
  // 点完的效果：{d} 换成多买一级那个数变了多少；买满了的换成一共多了多少
  function effText(S, n) {
    const l = lv(S, n.id);
    if (l === 0 && n.first) return n.first;
    if (!n.eff || !n.eff.includes('{d}')) return n.eff || '';
    const top = l >= maxLv(n), d = top ? Math.abs(n.vals[n.vals.length - 1] - n.vals[0]) : Math.abs(n.vals[l + 1] - n.vals[l]);
    return n.eff.replace('{d}', n.pct ? num(Math.round(d * 1000) / 10) : num(d));
  }

  // =========================================================================
  // 弹珠：一轮带一种（右栏那颗球的组名上挑），袋子装那一种
  // =========================================================================
  const owned = (S, kind) => !!D.MARBLES[kind] && (!BALL_NODES[kind] || !BALL_NODES[kind].unlock || lv(S, BALL_NODES[kind].unlock) > 0);
  const ownedBalls = S => D.BALLS.filter(k => owned(S, k));
  const pickOf = S => (owned(S, S.pick) ? S.pick : 'glass');
  function setPick(S, k) { if (!owned(S, k)) return false; S.pick = k; return true; }
  function marbleOf(K, kind) {
    const M = Object.assign({}, D.MARBLES[kind] || D.MARBLES.glass), B = K.balls[kind] || K.balls.glass;
    M.kind = kind; M.dur = B.dur; M.power = B.power;
    return M;
  }
  function bagFor(S, K) { const k = pickOf(S); return new Array(K.balls[k].bag).fill(k); }

  // =========================================================================
  // 小游戏（第八节）：金币买弹珠 → 打出奖券 → 奖券（有的加金币）买这台的升级 → 小人 → 自动买弹珠
  // =========================================================================
  const M18 = id => R18.BY[id];
  function blankBot() { return { play: true, buy: true, t: 0, idle: false }; }
  function blankMini() { return { marbles: 0, chips: 0, bot: blankBot(), frac: 0, shots: 0, hits: 0, kills: 0, layer: 1, lk: 0, deep: 0, streak: [], misses: 0, potHit: 0, cab: {}, earned: 0, bought: 0 }; }
  const miniId = (id, k) => id + '.' + k;
  const miniLv = (S, id, k) => lv(S, miniId(id, k));
  // 这台的签、价、速：节点表里有的照节点，没有的照十八台那版的第 0 档
  const miniVal = (S, id, k) => { const n = BY[miniId(id, k)]; if (n) return n.vals[lv(S, n.id)]; const u = M18(id) && M18(id).ups && M18(id).ups.find(x => x.k === k); return u ? u.vals[0] : 0; };
  const miniNodes = id => D.NODES.filter(n => n.where === id);
  const hasHelper = (S, id) => miniOpen(S, id) && lv(S, miniId(id, 'helper')) > 0;
  const hasAuto = (S, id) => miniOpen(S, id) && lv(S, miniId(id, 'auto')) > 0;
  const anyHelper = S => D.MINIS.some(M => hasHelper(S, M.id));
  // 一盒弹珠多少金币（开台就是买第一盒）：降价、转生树的开台打折
  const boxPrice = (S, id) => Math.max(1, Math.round(MBY[id].boxPrice * (BY[miniId(id, 'cheap')] ? v(S, miniId(id, 'cheap')) : 1) * pv(S, 'regular')));
  // 开台：上了桌、钱够，买第一盒。返回 { revealed }
  function openMini(S, id) {
    const p = boxPrice(S, id);
    if (miniOpen(S, id) || !miniShown(S, id) || S.gold < p) return null;
    S.gold -= p;
    S.mini[id] = Object.assign(blankMini(), { marbles: MBY[id].box, bought: 1 });
    queueCall(S, MBY[id].call);   // 第一次开台：电话简单讲这台怎么打、券拿去干什么
    return { revealed: reveal(S, 2, null, id) };
  }
  function buyBox(S, id) {
    const p = boxPrice(S, id), m = S.mini[id];
    if (!m || S.gold < p) return false;
    S.gold -= p; m.marbles += MBY[id].box; m.bought++;
    return true;
  }
  // 这台的升级买了几成（小人打得好不好、进度条）
  function miniFrac(S, id) {
    let a = 0, b = 0;
    for (const n of miniNodes(id)) if (n.up) { a += lv(S, n.id); b += maxLv(n); }
    return b ? a / b : 1;
  }
  // 宝贝：一样这台的奖券 +10%；转生树"奖券多"再乘
  const itemsOf = (S, id) => (S.mini[id] ? Object.keys(S.mini[id].cab).length : 0);
  const miniMult = (S, id) => (1 + 0.1 * itemsOf(S, id)) * pv(S, 'tickets');
  // 发 base 张奖券（乘加成），小数攒着下次补上。返回这次到手几张
  function award(S, id, base) {
    const m = S.mini[id]; if (!m) return 0;
    const raw = base * miniMult(S, id) + m.frac, n = Math.floor(raw + 1e-9);
    m.frac = raw - n; m.chips += n; m.earned += n;
    return n;
  }
  // 小人打一颗平均吐几张（统计模型，照这台的签、价、速；先填）
  function botEv(S, id) {
    const val = miniVal(S, id, 'v'), n = miniVal(S, id, 'n');
    if (id === 'dog') return val * Math.min(0.95, 0.25 + 0.075 * n);
    if (id === 'volcano') return val * n / 9 * (0.7 + 2.5 / miniVal(S, id, 's'));
    return val * n * 0.5;
  }
  // 小人速率（全局，花金币）
  const speedOf = S => D.HELPER_SPEED.vals[S.helperSpeed] * pv(S, 'quick');
  const speedCost = S => (S.helperSpeed >= D.HELPER_SPEED.costs.length ? null : D.HELPER_SPEED.costs[S.helperSpeed]);
  function buySpeed(S) { const c = speedCost(S); if (c == null || S.gold < c) return false; S.gold -= c; S.helperSpeed++; return true; }
  // 小人打（不跑物理）：一颗弹珠 sec 秒，吐 botEv 张；打光了：买了自动买、开着、金币够就买一盒，不然停下等你
  function tickBots(S, dt, lifted, rnd) {
    const ev = [];
    rnd = rnd || Math.random;
    for (const M of D.MINIS) {
      const id = M.id, m = S.mini[id];
      if (!hasHelper(S, id) || !m.bot.play || id === lifted) continue;
      const sec = M.bot.sec / speedOf(S);
      m.bot.t += dt;
      while (m.bot.t >= sec) {
        if (m.marbles <= 0) {
          if (hasAuto(S, id) && m.bot.buy && buyBox(S, id)) ev.push({ id, box: true });
          else { m.bot.idle = true; m.bot.t = 0; break; }
        }
        m.bot.t -= sec; m.bot.idle = false;
        m.marbles--; m.shots++;
        ev.push({ id, n: award(S, id, botEv(S, id) * (0.6 + 0.8 * rnd())) });
      }
    }
    return ev;
  }

  // =========================================================================
  // 电话：一通一样新东西；排着队，等这颗弹珠落下才响
  // =========================================================================
  function queueCall(S, k) {
    if (!D.CALLS[k] || S.calls.heard[k] || S.calls.queue.includes(k)) return false;
    S.calls.queue.push(k);
    return true;
  }
  const nextCall = S => S.calls.queue[0] || null;
  function hangUp(S, k) {
    S.calls.heard[k] = 1; S.calls.queue = S.calls.queue.filter(x => x !== k);
    // 作者来电（火山弹打掉第一个新 boss）：送扳手（开发者面板）、转生开了、下一台小游戏上桌，往后随便玩
    if (k === 'creator') { S.devTool = 1; S.canPrestige = true; S.shown.ring = 1; }
  }

  // =========================================================================
  // 一轮完了：记最深；第一次看到一关：露那一关的节点
  // =========================================================================
  function endRun(S, deep) {
    S.runs++; S.life.runs++;
    if (deeper(deep, S.best)) S.best = { stage: deep.stage, layer: deep.layer };
    if (deeper(deep, S.life.deep)) S.life.deep = { stage: deep.stage, layer: deep.layer };
  }
  function seeStage(S, n) {
    if (n <= S.maxStage) return [];
    S.maxStage = n; S.from = 0;
    return reveal(S, 2, null, 'stage:' + n);
  }

  // =========================================================================
  // 转生（第十二节）
  // =========================================================================
  // 转生点：照这一世最深那一层给（一层一个台阶，越深越多；先填）。一关七层，照原来一关十层的台阶放大
  const depthIndex = d => { let n = d.layer; for (let i = 1; i < d.stage; i++) n += stage(i).layers.length; return Math.round(n * 10 / 7); };
  const ppFor = S => Math.max(1, Math.floor(Math.pow(depthIndex(S.life.deep), 1.25)));
  function prestige(S) {
    if (!S.canPrestige) return false;
    const pts = ppFor(S), first = S.prestiges === 0;
    S.pp += pts; S.prestiges++;
    if (first) S.perks.elder = 1;
    S.gold = pv(S, 'seed'); S.tree = {}; S.maxStage = 1; S.from = 0; S.life = LIFE();
    S.mini = {}; S.pick = 'glass'; S.helperSpeed = 0;
    return { pts, first };
  }
  const perkCost = (S, id) => { const p = PBY[id], l = perk(S, id); return l >= p.costs.length ? null : p.costs[l]; };
  // 前面那样（pre）都买过一级
  const perkOpen = (S, id) => (PBY[id].pre || []).every(p => perk(S, p) > 0);
  function buyPerk(S, id) {
    const c = perkCost(S, id);
    if (c == null || S.pp < c || PBY[id].free || !perkOpen(S, id)) return false;
    S.pp -= c; S.perks[id] = perk(S, id) + 1;
    return true;
  }

  // ---------- 数 ----------
  // 数的写法：100 以下带一位小数，1 万起写"万"，1 亿起写"亿"
  function trim(x) { return x >= 100 ? String(Math.floor(x)) : x >= 10 ? String(Math.floor(x * 10) / 10) : String(Math.floor(x * 100) / 100); }
  function num(x) {
    if (x >= 1e8) return trim(x / 1e8) + '亿';
    if (x >= 1e4) return trim(x / 1e4) + '万';
    if (x >= 100 || Number.isInteger(x)) return String(Math.floor(x));
    return String(Math.floor(x * 10 + 1e-9) / 10);
  }
  // 史莱姆的血：取整得好看（10 以下取整，往上留两位）
  function niceHp(x) {
    if (x < 10) return Math.max(1, Math.round(x));
    const k = Math.pow(10, Math.floor(Math.log10(x)) - 1);
    return Math.round(x / k) * k;
  }
  const stage = n => D.STAGES[Math.max(0, Math.min(D.STAGES.length - 1, n - 1))];
  // 这一关的镜头倍数（没写的照上一关）
  const zoomOf = n => { for (let i = Math.max(1, Math.min(D.STAGES.length, n)); i >= 1; i--) if (D.STAGES[i - 1].zoom) return D.STAGES[i - 1].zoom; return 1; };
  const layerOf = (n, l) => { const SD = stage(n); return SD.layers[Math.max(0, Math.min(SD.layers.length - 1, l - 1))]; };
  // 一层的血：写一个数就是都一样；写成 [[血, 几份], …] 就是有高有低，照份数抽
  const hpPool = L => (Array.isArray(L.hp) ? L.hp : [[L.hp, 1]]);
  function rollHp(L, rnd) {
    const P = hpPool(L), tot = P.reduce((a, [, w]) => a + w, 0);
    let x = rnd() * tot;
    for (const [h, w] of P) { x -= w; if (x <= 0) return h; }
    return P[P.length - 1][0];
  }
  const minHp = L => Math.min(...hpPool(L).map(([h]) => h));
  // 深浅比较：先比关，再比层
  const deeper = (a, b) => a.stage > b.stage || (a.stage === b.stage && a.layer > b.layer);
  return {
    BY, MBY, PBY, M18, BALL_NODES, REVIVERS, newSave, load,
    maxLv, lv, maxed, v, preOK, visible, fresh, reveal, tixOf, price, lack, canPay, state, buy, perk, pv, isPart,
    stats, countFor, effText, startStage, owned, ownedBalls, pickOf, setPick, marbleOf, bagFor,
    blankMini, blankBot, miniOpen, miniShown, miniId, miniLv, miniVal, miniNodes, hasHelper, hasAuto, anyHelper, boxPrice, openMini, buyBox, miniFrac,
    itemsOf, miniMult, award, botEv, speedOf, speedCost, buySpeed, tickBots,
    queueCall, nextCall, hangUp, endRun, seeStage, depthIndex, ppFor, prestige, perkCost, perkOpen, buyPerk,
    num, niceHp, stage, zoomOf, layerOf, hpPool, rollHp, minHp, deeper,
  };
}));
