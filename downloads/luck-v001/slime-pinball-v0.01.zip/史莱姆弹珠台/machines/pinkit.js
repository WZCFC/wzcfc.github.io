/*
 * 打怪那一类的弹球台公用件（草地史莱姆、蘑菇洞）。物理在 sims/pinball.js，这里管：
 *   发射（按住拉弹簧、松手打；第一次打出去才扣一颗珠子，掉回发射道再打不花钱）
 *   挡板（左键 / Z / ← 拍左边，右键 / M / → 拍右边；触屏按左半边、右半边）
 *   史莱姆（掉下来、蹦一蹦、撞一下掉一块、撞碎吐筹码）、层数、大奖、救球
 * 每台不一样的写在 cfg 里：
 *   cfg.bumpers        蘑菇弹柱 [[x, y, r]]
 *   cfg.colors(m)      这只史莱姆的颜色 [亮, 身子, 暗]
 *   cfg.target()       台上要保持几"窝"（一窝 = 一只；蘑菇洞是一只大的和它裂出来的小的）
 *   cfg.spawn(fam)     新的一窝：返回 [{ hp, size, gold }]（size: 'big' | 'small'）
 *   cfg.died(m, pk)    一只碎了：发钱、裂开……（pk 是这里的工具，见底下 tools）
 *   cfg.info() / cfg.hint()  加在左边的几行字、提示
 */
window.PinKit = (function () {
  'use strict';
  const A = Art, INK = A.INK, FX = A.FX, FY = A.FY, P = window.Pinball;
  const ALU = A.ALU, RAD = [0, 5, 7, 9];
  const ZONE = { x0: 26, x1: 92, y0: 36, y1: 98 };
  const FLIP_C = { body: '#fe4c40', hi: '#ff8a7a', lo: '#b8322a' };

  // ---------- 不动的那一层：导轨、弹弓、出球口两边的小墙、发射道口的单向门、蘑菇 ----------
  function capsule(f, L, x0, y0, x1, y1, r, col) {
    const vx = x1 - x0, vy = y1 - y0, l2 = vx * vx + vy * vy;
    for (let y = Math.floor(Math.min(y0, y1) - r - 1); y <= Math.ceil(Math.max(y0, y1) + r + 1); y++) for (let x = Math.floor(Math.min(x0, x1) - r - 1); x <= Math.ceil(Math.max(x0, x1) + r + 1); x++) {
      const px = x + 0.5, py = y + 0.5;
      let t = ((px - x0) * vx + (py - y0) * vy) / l2; t = t < 0 ? 0 : t > 1 ? 1 : t;
      const dx = px - (x0 + vx * t), dy = py - (y0 + vy * t), d = Math.hypot(dx, dy);
      if (d <= r) f.lset(L, x, y, typeof col === 'function' ? col(dx, dy, d) : col);
    }
  }
  const metal = (dx, dy) => (dx + dy < -0.6 ? ALU[0] : dx + dy > 0.6 ? ALU[2] : ALU[1]);
  function fineTable(f, bumpers) {
    MK.fineLane(f, [6, 4]);
    const L = f.layer(128, 160);
    for (const k of ['L', 'R']) {
      const [a, b] = P.GUIDE[k];
      capsule(f, L, a[0], a[1], b[0], b[1], 1.3, metal);
      const S = P.SLING[k];
      // 弹弓：三角红塑料，斜边一道白橡皮筋；三个角是钢柱
      f.lP(L, [S.A, S.B, S.C], (x, y) => ((x + y) % 4 === 0 ? FLIP_C.lo : FLIP_C.body));
      capsule(f, L, S.A[0], S.A[1], S.C[0], S.C[1], 1.2, '#ffffff');
      capsule(f, L, S.cap[0], S.cap[1], S.A[0], S.A[1], 1.1, metal);
      for (const p of [S.A, S.B, S.C]) capsule(f, L, p[0], p[1], p[0], p[1], 2, metal);
    }
    capsule(f, L, 30, 127, 34, 134, 1.2, metal);
    capsule(f, L, 86, 127, 82, 134, 1.2, metal);
    f.outl(L);
    f.put(L, 0, 0);
    // 单向门：一条细钢片
    const G = P.GATE;
    for (let i = 0; i <= 10; i++) { const x = G.x0 + (G.x1 - G.x0) * i / 10, y = G.y0 + (G.y1 - G.y0) * i / 10; f.px(Math.floor(x), Math.floor(y), i % 2 ? ALU[0] : ALU[2]); }
    // 出球口：两片挡板中间往下一道黑
    for (let y = 141; y <= 145; y++) for (let x = 50; x <= 66; x++) f.px(x, y, y === 141 ? '#5a1626' : INK);
    for (const [x, y, r] of bumpers || []) { const im = A.mushroomSprite(r + 0.5, r * 0.72, Math.round(r), false), L2 = toLayer(f, im); f.put(L2, Math.round(x - im.width / 2), Math.round(y + r - im.height + 2)); }
    f.fineMeter();
  }
  // 画布 → 图层（fine 那一层只认图层）
  function toLayer(f, im) {
    const L = f.layer(im.width, im.height), d = im.getContext('2d').getImageData(0, 0, im.width, im.height).data;
    for (let j = 0; j < im.height; j++) for (let i = 0; i < im.width; i++) { const k = (j * im.width + i) * 4; if (d[k + 3] > 0) f.lset(L, i, j, '#' + [d[k], d[k + 1], d[k + 2]].map(v => v.toString(16).padStart(2, '0')).join('')); }
    return L;
  }
  // 挡板：每帧按角度现画（胶囊形，红塑料、上沿亮一道、深边，转轴一颗金钉）
  function drawFlipper(ctx, fl) {
    const [tx, ty] = P.tipOf(fl), vx = tx - fl.px, vy = ty - fl.py, l2 = vx * vx + vy * vy, R0 = fl.rp + 0.6;
    const x0 = Math.floor(Math.min(fl.px, tx) - R0 - 1), x1 = Math.ceil(Math.max(fl.px, tx) + R0 + 1), y0 = Math.floor(Math.min(fl.py, ty) - R0 - 1), y1 = Math.ceil(Math.max(fl.py, ty) + R0 + 1);
    const nx = -vy / Math.sqrt(l2), ny = vx / Math.sqrt(l2), up = ny > 0 ? -1 : 1;
    for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) {
      const px = x + 0.5, py = y + 0.5;
      let t = ((px - fl.px) * vx + (py - fl.py) * vy) / l2; t = t < 0 ? 0 : t > 1 ? 1 : t;
      const dx = px - (fl.px + vx * t), dy = py - (fl.py + vy * t), d = Math.hypot(dx, dy), r = fl.rp + (fl.rt - fl.rp) * t + 0.4;
      if (d > r + 0.6) continue;
      let c;
      if (d > r - 0.5) c = INK;
      else { const side = (dx * nx + dy * ny) * up; c = side > r - 1.6 ? FLIP_C.hi : side < -(r - 1.4) ? FLIP_C.lo : FLIP_C.body; }
      ctx.fillStyle = c; ctx.fillRect(FX(x), FY(y), 2, 2);
    }
    ctx.fillStyle = INK; ctx.fillRect(FX(fl.px) - 3, FY(fl.py) - 3, 6, 6);
    ctx.fillStyle = A.GOLD[0]; ctx.fillRect(FX(fl.px) - 1, FY(fl.py) - 1, 2, 2);
  }

  // =========================================================================
  // 台子
  // =========================================================================
  function make(env, cfg) {
    const { sfx } = env;
    const S = MK.sprites();
    const s = P.create({ bumpers: cfg.bumpers || [], flipLen: env.lv('flip') ? 2 : 0 });
    const pl = MK.plunger(sfx);
    const ballIm = MK.ball7(A.MARB.steel);
    const st = { acc: { t: 0 }, wait: 0.3, time: 0, parts: [], labels: [], hold: { L: new Set(), R: new Set() }, pending: [], fam: 0, seq: 0, bumpFlash: new Map(), slingFlash: { L: 0, R: 0 }, ballKills: 0, ballJack: false, auto: null, layerFlash: 0 };
    const m = () => env.m();
    const ball = () => s.ball;
    const live = () => s.slimes.filter(x => x.state !== 'pop');

    // ---------- 史莱姆 ----------
    const radOf = (hp, size) => (size === 'small' ? 4.5 : RAD[Math.max(1, Math.min(3, hp))]);
    function freeSpot(r, avoid) {
      for (let k = 0; k < 40; k++) {
        const x = ZONE.x0 + Math.random() * (ZONE.x1 - ZONE.x0), y = ZONE.y0 + Math.random() * (ZONE.y1 - ZONE.y0);
        if (s.slimes.some(o => o !== avoid && o.state !== 'pop' && Math.hypot((o.tx ?? o.x) - x, (o.ty ?? o.y) - y) < o.r + r + 6)) continue;
        if ((cfg.bumpers || []).some(([bx, by, br]) => Math.hypot(bx - x, by - y) < br + r + 5)) continue;
        const b = ball();
        if (b && b.state === 'play' && Math.hypot(b.x - x, b.y - y) < r + 10) continue;
        return [x, y];
      }
      return null;
    }
    // 新的一只：从顶上的草丛里掉下来
    function addSlime(def, fam, from) {
      const r = radOf(def.hp, def.size);
      const spot = from ? [Math.max(ZONE.x0 - 6, Math.min(ZONE.x1 + 6, from[2])), Math.max(ZONE.y0, Math.min(ZONE.y1 + 10, from[3]))] : freeSpot(r);
      if (!spot) return null;
      const o = {
        id: ++st.seq, fam, size: def.size || 'big', gold: !!def.gold, hp: def.hp, maxHp: def.hp, r,
        x: from ? from[0] : spot[0], y: from ? from[1] : 24, tx: spot[0], ty: spot[1],
        state: from ? 'hop' : 'drop', t: 0, dur: from ? 0.35 : 0.45, sx: from ? from[0] : spot[0], sy: from ? from[1] : 24,
        solid: false, cool: 0, flash: 0, squash: 0, hopIn: 2 + Math.random() * 4,
      };
      s.slimes.push(o);
      return o;
    }
    function spawnFamily() {
      const fam = ++st.fam, defs = cfg.spawn(fam);
      let ok = 0;
      for (const d of defs) if (addSlime(d, fam)) ok++;
      return ok > 0;
    }
    const famsAlive = () => new Set(live().map(o => o.fam)).size;
    function hop(o) {
      const r = o.r, spot = (() => { for (let k = 0; k < 12; k++) { const x = Math.max(ZONE.x0, Math.min(ZONE.x1, o.x + (Math.random() * 2 - 1) * 16)), y = Math.max(ZONE.y0, Math.min(ZONE.y1, o.y + (Math.random() * 2 - 1) * 12)); if (!s.slimes.some(p => p !== o && p.state !== 'pop' && Math.hypot((p.tx ?? p.x) - x, (p.ty ?? p.y) - y) < p.r + r + 4) && !(cfg.bumpers || []).some(([bx, by, br]) => Math.hypot(bx - x, by - y) < br + r + 4)) return [x, y]; } return null; })();
      if (!spot) return;
      o.state = 'hop'; o.t = 0; o.dur = 0.5; o.sx = o.x; o.sy = o.y; o.tx = spot[0]; o.ty = spot[1];
    }
    function burst(o, n, speed) {
      const C = cfg.colors(o);
      for (let i = 0; i < n; i++) {
        const a = (i / n) * Math.PI * 2 + Math.random() * 0.5, v = speed * (0.6 + Math.random() * 0.6);
        st.parts.push({ x: o.x + Math.cos(a) * o.r * 0.6, y: o.y + Math.sin(a) * o.r * 0.6, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 30, t: 0, dur: 0.45 + Math.random() * 0.2, c: i % 3 ? C[1] : C[0] });
      }
    }
    // 撞到一下：掉一块
    function damage(o, impact, e) {
      if (o.state !== 'live' && o.state !== 'hop') return;
      if (o.cool > 0 || impact < 30) { if (impact > 15) { o.squash = Math.max(o.squash, 0.08); sfx.slime(impact * 0.5); } return; }
      o.hp -= 1; o.cool = 0.15; o.flash = 0.08; o.squash = 0.2;
      sfx.slime(impact);
      // 掉下来的那一块：往撞的反方向飞
      const C = cfg.colors(o);
      for (let i = 0; i < 3; i++) st.parts.push({ x: e.x, y: e.y, vx: -e.nx * (40 + i * 25) + (Math.random() - 0.5) * 40, vy: -e.ny * (40 + i * 25) - 20, t: 0, dur: 0.5, c: C[i % 2] });
      if (o.hp <= 0) kill(o);
      else o.r = radOf(o.hp, o.size);
    }
    function kill(o) {
      o.state = 'pop'; o.t = 0; o.solid = false;
      burst(o, 10, 70);
      sfx.pop();
      const b = ball();
      cfg.died(o, tools, b && b.state === 'play');
    }
    // 给每台的 cfg 用的工具
    const tools = {
      env, st, s,
      addSlime,
      burst,
      // 发钱（亲手打的）：at 是台面格
      pay(base, o, label) { const n = env.award(base, { at: [o.x, o.y - o.r], n: Math.min(10, Math.max(1, Math.ceil(base / 2))) }); if (label) st.labels.push({ s: label, x: o.x, y: o.y - o.r - 8, t: 0, c: A.GOLD[0] }); return n; },
      killCount(n) {
        const up = env.kill(n);
        if (up) { st.layerFlash = 1.5; for (const o of live()) if (o.state === 'live') o.squash = 0.25; }
        const b = ball();
        if (b && b.state === 'play') { st.ballKills += n; if (cfg.ballJack && st.ballKills >= cfg.ballJack && !st.ballJack) { st.ballJack = true; env.jackpot(); } }
        return up;
      },
      label(sx, sy, text, c) { st.labels.push({ s: text, x: sx, y: sy, t: 0, c: c || A.GOLD[0] }); },
      layer: () => m().layer,
      layerHp: () => env.R.layerHp(m().layer),
      layerMult: () => env.R.layerMult(m().layer),
    };

    // ---------- 球 ----------
    function loadBall() {
      if (env.marbles() <= 0) return false;
      const b = P.load(s); b.paid = false;
      return true;
    }
    function startPlunger(by) { const b = ball(); if (!b || b.state !== 'lane' || pl.on) return false; pl.start(by); return true; }
    function releasePlunger(by) {
      if (!pl.on || (by != null && pl.by !== by)) return;
      const p = pl.release(), b = ball();
      if (!b || b.state !== 'lane') return;
      if (!b.paid) { if (!env.spend()) return; b.paid = true; st.ballKills = 0; st.ballJack = false; b.age = 0; }
      P.launch(s, p);
      sfx.launch(p);
    }
    function setFlip(side, id, on) {
      const set = st.hold[side];
      if (on) set.add(id); else set.delete(id);
      const f = s.flippers[side === 'L' ? 0 : 1], was = f.on;
      f.on = set.size > 0;
      if (f.on && !was) sfx.flip();
    }
    function flipAllOff() { for (const side of ['L', 'R']) { st.hold[side].clear(); s.flippers[side === 'L' ? 0 : 1].on = false; } }
    function onEvent(e) {
      if (e.type === 'hit') {
        if (e.kind === 'sling') { sfx.sling(); st.slingFlash[e.x < 58 ? 'L' : 'R'] = 0.1; }
        else if (e.kind === 'shroom') { sfx.shroom(); st.bumpFlash.set(e.id, 0.1); for (let i = 0; i < 3; i++) st.parts.push({ x: e.x, y: e.y, vx: (Math.random() - 0.5) * 60, vy: -30 - Math.random() * 40, t: 0, dur: 0.25, c: '#ffffff' }); }
        else if (e.kind === 'post') sfx.bump(e.impact);
        else if (e.kind === 'roof') sfx.rim(e.impact);
        else if (e.kind !== 'head') sfx.wall(e.impact);
      } else if (e.type === 'slime') damage(e.m, e.impact, e);
      else if (e.type === 'flip') { if (e.moving) sfx.clack(e.impact); }
      else if (e.type === 'drain') {
        const b = e;
        if (env.lv('save') && b.age < 2) { env.refund(); env.toast('救球：开球 2 秒里掉的，钢珠退回来了', A.GOLD[0]); }
        else sfx.miss();
        st.wait = 0.6;
        s.ball = null;
        env.save();
      } else if (e.type === 'nudge') sfx.wall(30);
    }

    // ---------- 自动打（自测、截图用） ----------
    function auto(dt) {
      const b = ball();
      if (!b) return;
      const A_ = st.auto || (st.auto = { t: 0, hold: 0, flipT: { L: 0, R: 0 } });
      if (b.state === 'lane') {
        if (!pl.on) { A_.hold = 0.55 + Math.random() * 0.5; startPlunger('auto'); }
        else if (pl.t >= A_.hold) releasePlunger('auto');
        return;
      }
      if (b.state !== 'play') return;
      for (const side of ['L', 'R']) {
        const f = s.flippers[side === 'L' ? 0 : 1];
        const near = b.vy > -20 && b.y > 112 && b.y < 140 && (side === 'L' ? b.x < 58 : b.x > 58) && Math.abs(b.x - (side === 'L' ? 42 : 74)) < 16;
        // 球一回靠过来，先定这一回漏不漏（window.__autoNoise = 1 大约是新手：十回漏一回）
        if (near && !A_.near) { A_.near = true; A_.skip = Math.random() < 0.1 * (window.__autoNoise || 0); }
        if (!near && b.y < 108) A_.near = false;
        if (near && !A_.skip && A_.flipT[side] <= 0 && Math.random() < 0.5) { setFlip(side, 'auto', true); A_.flipT[side] = 0.18; }
        if (A_.flipT[side] > 0) { A_.flipT[side] -= dt; if (A_.flipT[side] <= 0) setFlip(side, 'auto', false); }
      }
    }

    // ---------- 画 ----------
    function drawSlime(ctx, o) {
      const C = cfg.colors(o);
      let rx = o.r * 1.18, ry = o.r * 1.05;
      if (o.squash > 0) { const k = Math.sin(o.squash / 0.2 * Math.PI) * 0.22; rx *= 1 + k; ry *= 1 - k; }
      let x = o.x, y = o.y;
      if (o.state === 'pop') { const t = o.t / 0.25; rx *= 1 + t * 0.5; ry *= 1 - t * 0.6; if (t >= 1) return; }
      const im = A.slimeSprite(Math.round(rx * 2) / 2, Math.round(ry * 2) / 2, C, true, o.flash > 0 || o.state === 'pop');
      MK.spr(ctx, im, Math.round(x - im.width / 2), Math.round(y + o.r * 0.18 - im.height / 2));
      // 血：头上几个白点（一下一个）
      if (o.state !== 'pop' && o.state !== 'drop' && o.maxHp > 1) {
        const n = o.hp, w = n * 3 - 1, x0 = Math.round(x - w / 2), y0 = Math.round(y - o.r * 1.05 - 3);
        ctx.fillStyle = INK; ctx.fillRect(FX(x0 - 1), FY(y0 - 1), (w + 2) * 2, 6);
        for (let i = 0; i < n; i++) { ctx.fillStyle = o.gold ? A.GOLD[0] : '#ffffff'; ctx.fillRect(FX(x0 + i * 3), FY(y0), 4, 2); }
      }
    }
    function draw(ctx) {
      // 蘑菇撞到时亮一下
      for (const [id, t] of st.bumpFlash) {
        const c = s.colliders[id]; if (!c) continue;
        const r = c.r, im = A.mushroomSprite(r + 0.5, r * 0.72, Math.round(r), true);
        MK.spr(ctx, im, Math.round(c.x - im.width / 2), Math.round(c.y + r - im.height + 2));
      }
      for (const side of ['L', 'R']) if (st.slingFlash[side] > 0) { const S2 = P.SLING[side]; MK.dots(ctx, S2.A[0], S2.A[1], S2.C[0], S2.C[1], '#fff6c0', 1); }
      for (const o of s.slimes) drawSlime(ctx, o);
      for (const p of st.parts) { const a = p.t / p.dur; if (a < 1) { ctx.fillStyle = p.c; ctx.fillRect(FX(Math.round(p.x)), FY(Math.round(p.y)), 2, 2); } }
      for (const f of s.flippers) drawFlipper(ctx, f);
      const b = ball();
      MK.lane(ctx, pl.on ? pl.pull() : 0, b && b.state === 'lane' ? ballIm : null);
      if (b && b.state === 'play') MK.spr(ctx, ballIm, Math.round(b.x - 3.5), Math.round(b.y - 3.5));
      A.drawMeter(ctx, pl.power(), pl.on);
      // 层数（顶上正中）和层数刚升的时候闪一下
      const L = m().layer, up = st.layerFlash > 0 && Math.sin(st.time * 16) > 0;
      MK.label(ctx, '第 ' + L + ' 层', 58, 22, up ? '#ffffff' : A.GOLD[0], 'center');
      for (const l of st.labels) { const a = l.t / 1.1; if (a < 1) MK.label(ctx, l.s, l.x, l.y - a * 10, l.c, 'center'); }
      // 挡板怎么按：前几球标在挡板底下
      if (m().shots < 4 && b && b.state === 'play') { MK.label(ctx, '左键/Z', 28, 147, '#fff3d8', 'center'); MK.label(ctx, '右键/M', 88, 147, '#fff3d8', 'center'); }
      if (b && b.state === 'lane' && !pl.on && Math.sin(st.time * 5) > 0) MK.label(ctx, b.paid ? '再打一下' : '按住', 108, 118, A.GOLD[0], 'center');
      MK.led(ctx, env.marbles(), env.marbles() <= 0 && !(b && b.paid), st.time);
    }

    const ctrl = {
      s,
      fine(f) { fineTable(f, cfg.bumpers); },
      update(dt) {
        st.time += dt;
        if (st.layerFlash > 0) st.layerFlash -= dt;
        pl.update(dt);
        // 补史莱姆：少几窝就排队，1.5 秒掉一窝下来
        const want = cfg.target();
        while (famsAlive() + st.pending.length < want) st.pending.push(st.pending.length ? 1.5 + 0.25 * st.pending.length : (live().length ? 1.5 : 0.15));
        for (let i = 0; i < st.pending.length; i++) st.pending[i] -= dt;
        while (st.pending.length && st.pending[0] <= 0) { if (spawnFamily()) st.pending.shift(); else { st.pending[0] = 0.3; break; } }
        // 史莱姆：掉落、蹦、冷却
        for (const o of s.slimes) {
          o.cool = Math.max(0, o.cool - dt); o.flash = Math.max(0, o.flash - dt); o.squash = Math.max(0, o.squash - dt);
          if (o.state === 'drop' || o.state === 'hop') {
            o.t += dt; const t = Math.min(1, o.t / o.dur);
            o.x = o.sx + (o.tx - o.sx) * (o.state === 'drop' ? t : MK.ease(t));
            o.y = o.state === 'drop' ? o.sy + (o.ty - o.sy) * t * t : o.sy + (o.ty - o.sy) * t - 8 * Math.sin(Math.PI * t);
            if (o.state === 'drop' && t > 0.6) o.solid = true;
            if (t >= 1) { o.state = 'live'; o.solid = true; o.x = o.tx; o.y = o.ty; o.squash = 0.2; o.hopIn = 3 + Math.random() * 3; }
          } else if (o.state === 'live') { o.hopIn -= dt; if (o.hopIn <= 0) { o.hopIn = 3 + Math.random() * 3; hop(o); } }
          else if (o.state === 'pop') o.t += dt;
        }
        s.slimes = s.slimes.filter(o => !(o.state === 'pop' && o.t > 0.3));
        // 球
        if (!ball()) { st.wait -= dt; if (st.wait <= 0) loadBall(); }
        else if (ball().state === 'gone') s.ball = null;
        P.advance(s, dt, st.acc);
        for (const e of s.events.splice(0)) onEvent(e);
        if (ball() && ball().state === 'gone') { s.ball = null; }
        // 碎块、小字
        for (const p of st.parts) { p.t += dt; p.vy += 220 * dt; p.x += p.vx * dt; p.y += p.vy * dt; }
        st.parts = st.parts.filter(p => p.t < p.dur);
        for (const l of st.labels) l.t += dt;
        st.labels = st.labels.filter(l => l.t < 1.1);
        for (const [id, t] of st.bumpFlash) { if (t - dt <= 0) st.bumpFlash.delete(id); else st.bumpFlash.set(id, t - dt); }
        for (const k of ['L', 'R']) st.slingFlash[k] = Math.max(0, st.slingFlash[k] - dt);
        if (cfg.update) cfg.update(dt, tools);
      },
      draw,
      down(p) {
        const b = ball();
        if (b && b.state === 'lane') { startPlunger(p.id); return true; }
        if (b && b.state === 'play') {
          const side = p.touch ? (p.x < 320 ? 'L' : 'R') : p.btn === 2 ? 'R' : 'L';
          setFlip(side, p.id, true);
          return true;
        }
        return false;
      },
      up(p) { releasePlunger(p.id); setFlip('L', p.id, false); setFlip('R', p.id, false); },
      key(code, down) {
        if (code === 'Space' || code === 'ArrowDown' || code === 'Enter') {
          if (down) startPlunger('key'); else releasePlunger('key');
          return true;
        }
        if (code === 'KeyZ' || code === 'ArrowLeft' || code === 'ShiftLeft') { setFlip('L', code, down); return true; }
        if (code === 'KeyM' || code === 'ArrowRight' || code === 'ShiftRight' || code === 'Slash') { setFlip('R', code, down); return true; }
        return false;
      },
      cancel() { pl.cancel(); flipAllOff(); },
      leave() { pl.cancel(); flipAllOff(); },
      auto,
      inPlay() { const b = ball(); return pl.on || !!(b && (b.state === 'play' || (b.state === 'lane' && b.paid))); },
      busy() { return pl.on; },
      hint() {
        const b = ball();
        const h = cfg.hint ? cfg.hint(tools) : '';
        if (h) return h;
        if (!b) return env.marbles() > 0 ? '' : '';
        if (b.state === 'lane') return pl.on ? '松手打出去' : b.paid ? '球掉回发射道了：再打一下，不花珠子' : '按住卡（或空格）拉弹簧，松手把钢珠打上去';
        if (m().shots < 4) return '左键或 Z 拍左挡板，右键或 M 拍右挡板。别让球从两片挡板中间掉下去';
        return '';
      },
      info() {
        const out = cfg.info(tools);
        const b = ball();
        if (b && b.state === 'play' && cfg.ballJack) out.push(['这一球碎了 ' + st.ballKills + ' 只（' + cfg.ballJack + ' 只 = 大奖）', st.ballKills ? A.GOLD[0] : null]);
        if (env.lv('save')) out.push(['救球：开球 2 秒里掉的退回来', null]);
        return out;
      },
      onUpgrade(k) { if (cfg.onUpgrade) cfg.onUpgrade(k, tools); },
      debug() { const b = ball(); return { ball: b && b.state, slimes: s.slimes.length, kills: m().kills, layer: m().layer, marbles: env.marbles() }; },
    };
    return ctrl;
  }
  return { make, fineTable, drawFlipper, ZONE, RAD };
})();
