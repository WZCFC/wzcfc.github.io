/*
 * 主线两边栏的画法（照《刮个爽》的样子，像素版）：
 *   钱箱：木板一块（金币图标 + 数），底下一条橙色的条
 *   页签：选中的蓝绿、没选中的灰
 *   一组（像刮个爽的 Catalog）：蓝的、绿的圆角大框，黄字标题；里面一行一行
 *   一行：深蓝圆角条，左边图标框，右边名字（买满了名字发黄、带星）、价钱、Lv 和一条绿进度条
 *   升级框（像刮个爽右边的 Upgrades）：蓝绿色，顶上一个页签形的标题；行是更深的蓝绿
 *   大按钮：底下一条宽按钮；齿轮：右上角
 *   键帽（左栏、右栏、那几页、暂停里的按钮都是）：能点的都有底下一道 3 格厚的边，按下去面落到底；只看的牌子没有这道边。
 *     有能买的整块亮黄、隔一会儿扫一道光；在这台的、挑着的页签按进去（蓝绿），右边一个小尖指着台子；开关开着是按进去的绿色
 *     技能一行：买得起亮黄、买不起深蓝（照样能点，点了抖一下）、买满了是平的牌子
 *   黄牌（原来的小绿点）：9 格黄底一个上箭头，一跳一跳
 * 全是平涂 + 深边，圆角是切掉的像素角（不画渐变、不画光晕）。坐标是原生 640×360。
 */
window.MainUI = (function () {
  'use strict';
  const A = Art, INK = A.INK;
  const C = {
    navy: '#1c2547', navyHi: '#2c3866', navyLo: '#141a36', navyHot: '#26315a',
    blue: '#26468a', blueHi: '#3a62b0', blueLo: '#19305e',
    green: '#22603a', greenHi: '#32804e', greenLo: '#163e26',
    teal: '#2b6c80', tealHi: '#3f8ea4', tealLo: '#1c4c5c', tealRow: '#173c4a', tealRowHi: '#21505f', tealRowHot: '#1d4756',
    wood: ['#d8965e', '#b0703e', '#7a4626'], orange: ['#ffb84a', '#ec921e', '#b0640c'],
    tabOn: ['#6ab4d0', '#3f8eae', '#2a6a86'], tabOff: ['#5a6272', '#3c4352', '#2a303c'],
    yellow: '#ffd84a', text: '#f4f0e6', dim: '#9aa6c0', red: '#ff7a6a', green2: '#8af06a', bar: '#3ccf4a', barBack: '#0d1328', gold: '#ffe680',
    gear: ['#7a8698', '#566070', '#3a4250'],
  };
  const T = (g, s, x, y, o) => Txt.draw(g, s, x, y, o);
  // 圆角块：r 格的切角
  function shape(g, x, y, w, h, r, c) {
    g.fillStyle = c;
    for (let k = 0; k < r; k++) { const ins = r - k; g.fillRect(x + ins, y + k, w - 2 * ins, 1); g.fillRect(x + ins, y + h - 1 - k, w - 2 * ins, 1); }
    g.fillRect(x, y + r, w, h - 2 * r);
  }
  // 圆角框：深边 + 填色；hi/lo 是里面最上一行、最下一行
  function rr(g, x, y, w, h, fill, edge, r, hi, lo) {
    r = r == null ? 2 : r;
    if (edge) shape(g, x, y, w, h, r, edge);
    const e = edge ? 1 : 0;
    shape(g, x + e, y + e, w - 2 * e, h - 2 * e, Math.max(0, r - e), fill);
    if (hi) { g.fillStyle = hi; g.fillRect(x + e + Math.max(1, r - 1), y + e, w - 2 * e - 2 * Math.max(1, r - 1), 1); }
    if (lo) { g.fillStyle = lo; g.fillRect(x + e + Math.max(1, r - 1), y + h - 1 - e, w - 2 * e - 2 * Math.max(1, r - 1), 1); }
  }
  function bar(g, x, y, w, h, k, col, back) {
    g.fillStyle = INK; g.fillRect(x, y, w, h);
    g.fillStyle = back || C.barBack; g.fillRect(x + 1, y + 1, w - 2, h - 2);
    const n = Math.round((w - 2) * Math.max(0, Math.min(1, k)));
    if (n > 0) { g.fillStyle = col || C.bar; g.fillRect(x + 1, y + 1, n, h - 2); }
  }
  // 钱箱：木板 + 橙条。value 写大字，label 写在橙条上
  function moneyBox(g, x, y, w, value, label, icon) {
    rr(g, x, y, w, 40, C.wood[1], INK, 2);
    g.fillStyle = C.wood[0]; g.fillRect(x + 2, y + 1, w - 4, 1); g.fillRect(x + 1, y + 2, 1, 22);
    g.fillStyle = C.wood[2]; g.fillRect(x + 2, y + 24, w - 4, 1);
    // 木纹：两道横线，断开的地方错开
    g.fillStyle = '#9a6034';
    for (let i = 4; i < w - 4; i++) { if ((i + 3) % 23 > 2) g.fillRect(x + i, y + 7, 1, 1); if ((i + 14) % 29 > 2) g.fillRect(x + i, y + 19, 1, 1); }
    // 橙条
    g.fillStyle = INK; g.fillRect(x + 1, y + 25, w - 2, 1);
    shape(g, x + 1, y + 26, w - 2, 13, 1, C.orange[1]);
    g.fillStyle = C.orange[0]; g.fillRect(x + 2, y + 26, w - 4, 1);
    g.fillStyle = C.orange[2]; g.fillRect(x + 2, y + 38, w - 4, 1);
    if (icon) g.drawImage(icon, x + 6, y + 7, icon.width * 2, icon.height * 2);
    T(g, value, x + 20, y + 4, { size: 16, color: C.yellow });
    if (label) T(g, label, x + w / 2, y + 26, { align: 'center', color: '#ffffff', outline: '#7a3a08' });
  }
  function tabs(g, x, y, w, items, sel, hover) {
    const n = items.length, tw = Math.floor((w - (n - 1) * 3) / n), out = [];
    items.forEach((it, i) => {
      const tx = x + i * (tw + 3), on = it.k === sel, P = on ? C.tabOn : C.tabOff, hot = hover === 'tab:' + it.k;
      rr(g, tx, y, tw, 16, P[1], INK, 2, hot && !on ? '#ffffff' : P[0], P[2]);
      T(g, it.label, tx + tw / 2, y + 2, { align: 'center', color: on ? '#ffffff' : '#c8ccd8' });
      if (it.dot) { g.fillStyle = INK; g.fillRect(tx + tw - 7, y + 2, 5, 5); g.fillStyle = C.red; g.fillRect(tx + tw - 6, y + 3, 3, 3); }
      out.push({ id: 'tab:' + it.k, x: tx, y, w: tw, h: 16 });
    });
    return out;
  }
  // 一组（蓝 / 绿的大框，黄字标题）。返回标题下面从哪一行开始放
  function group(g, x, y, w, h, title, kind) {
    const P = kind === 'green' ? [C.greenHi, C.green, C.greenLo] : [C.blueHi, C.blue, C.blueLo];
    rr(g, x, y, w, h, P[1], INK, 3, P[0], P[2]);
    T(g, title, x + w / 2, y + 4, { align: 'center', size: 16, color: C.yellow });
    return y + 24;
  }
  // 一行。o：icon（画布）、iconScale、name、star、price（{ n, poor, icon, iconScale }）、lv / lvMax、done（买满的字）、sub（第二行的灰字）、note（第二行右边的小字）、
  //   state：can / poor / max / lock / none，hot 指着，flash 刚买，teal 蓝绿配色，right（右边小字）
  function row(g, x, y, w, h, o) {
    const teal = !!o.teal;
    const base = teal ? (o.hot ? C.tealRowHot : C.tealRow) : (o.hot ? C.navyHot : C.navy);
    const edge = o.flash ? '#ffffff' : o.state === 'can' && o.blink ? C.yellow : INK;
    rr(g, x, y, w, h, base, edge, 2, teal ? C.tealRowHi : C.navyHi, teal ? '#0f2a34' : C.navyLo);
    // 图标框
    const ib = h - 6;
    if (o.icon) {
      const s = o.iconScale || 2, iw = o.icon.width * s, ih = o.icon.height * s;
      g.drawImage(o.icon, Math.round(x + 3 + (ib - iw) / 2), Math.round(y + 3 + (ib - ih) / 2), iw, ih);
    }
    const tx = x + ib + 6, tw = x + w - 4 - tx;
    const nameCol = o.state === 'lock' ? C.dim : o.state === 'max' ? C.yellow : C.text;
    const nw = T(g, o.name, tx, y + 3, { color: o.nameColor || nameCol });
    if (o.star) drawStar(g, tx + nw + 2, y + 4);
    if (o.right) T(g, o.right, x + w - 5, y + 3, { align: 'right', color: o.rightColor || C.dim });
    // 第二行：价钱（或买满 / 锁着 / 说明）
    const y2 = y + 16;
    if (o.price && o.state !== 'max') {
      let px = tx;
      if (o.price.icon) { const s = o.price.iconScale || 1; g.drawImage(o.price.icon, px, y2 + Math.round((12 - o.price.icon.height * s) / 2) + 1, o.price.icon.width * s, o.price.icon.height * s); px += o.price.icon.width * s + 3; }
      T(g, o.price.n, px, y2, { color: o.state === 'lock' ? C.dim : o.price.poor ? C.red : C.gold });
    } else if (o.done) T(g, o.done, tx, y2, { color: C.green2 });
    else if (o.sub) T(g, o.sub, tx, y2, { color: o.subColor || C.dim });
    if (o.lvMax > 1) {
      const lt = 'Lv' + o.lv;
      T(g, lt, x + w - 5, y2, { align: 'right', color: C.dim });
      bar(g, tx, y + h - 6, tw, 4, o.lv / o.lvMax, o.lv >= o.lvMax ? C.yellow : C.bar);
    } else if (o.frac != null) bar(g, tx, y + h - 6, tw, 4, o.frac, o.frac >= 1 ? C.yellow : C.bar);
    if (o.note && !(o.lvMax > 1)) T(g, o.note, x + w - 5, y2, { align: 'right', color: o.noteColor || C.dim });
  }
  // 价钱的一段：图标 + 数（不够的标红）。返回画到哪
  // ink：亮黄的键帽上那样（深色字、不描边）
  function pricePart(g, px, y2, p, lock, ink) {
    if (p.icon) { const s = p.iconScale || 1; g.drawImage(p.icon, px, y2 + Math.round((12 - p.icon.height * s) / 2) + 1, p.icon.width * s, p.icon.height * s); px += p.icon.width * s + 2; }
    return px + T(g, p.n, px, y2, ink ? { color: ink, outline: null } : { color: lock ? C.dim : p.poor ? C.red : C.gold });
  }
  // 技能一行（照刮个爽的 Upgrades，压成两行字那么高）：键帽（见开头）。买得起的整块亮黄扫光；买不起的深蓝（照样能点，点了抖一下说差多少）；
  //   买满的是平的牌子（没有厚边、点不了）。不写名字，一句话就是这个节点，别的全是像素图标 + 数
  //   左边图标（1 倍，竖着居中）| 第一行那一句 | 第二行价钱（钱的图标 + 数）；第二行右边几级（2/7），没买过的换成"新"
  //   o：icon、iconScale、col（图标那一栏多宽，默认 16）、text、textColor、price（{ n, icon, poor }）、price2（金币 + 券的券那一半）、
  //      done（买满的字，代替价钱）、sub（代替价钱的灰字）、lv / lvMax、note（第二行右边的小字，代替几级）、noteColor、
  //      state（can / poor / max / lock）、kind（不照 state 定键帽样子的时候给）、hot、down、flash、t（扫光）、tag（"新"）
  const ROW_H = 31;
  const skillRowH = () => ROW_H;
  // 平的牌子（买满了、锁着）：跟按进去的键帽一样高，没有厚边
  const FLAT = { ink: C.yellow, sub: C.dim, out: INK };
  function skillRow(g, x, y, w, o) {
    const h = ROW_H, max = o.state === 'max', lock = o.state === 'lock';
    let f;
    if (max || lock) {
      rr(g, x, y + LIP - 1, w, h - LIP + 1, C.tealRow, o.flash ? '#ffffff' : INK, 2, C.tealRowHi, '#0f2a34');
      f = { x: x + 1, y: y + LIP, w: w - 2, h: h - LIP - 2, P: FLAT };
    } else f = key(g, x, y, w, h, { kind: o.kind || (o.state === 'can' ? 'lit' : 'idle'), hot: o.hot, down: o.down, flash: o.flash, t: o.t });
    const P = f.P, lit = P === KEY.lit, col = o.col || 16;
    if (o.icon) {
      const s = o.iconScale || 1, iw = o.icon.width * s, ih = o.icon.height * s;
      g.drawImage(o.icon, Math.round(f.x + 1 + (col - iw) / 2), Math.round(f.y + (f.h - ih) / 2), iw, ih);
    }
    const tx = f.x + col + 2, right = f.x + f.w - 3, ink = lit ? P.ink : null;
    T(g, o.text || '', tx, f.y + 1, { color: o.textColor || (lock ? C.dim : max ? C.yellow : P.ink), outline: P.out });
    const y2 = f.y + 13;
    let end = tx;
    if (o.price && !max) {
      end = pricePart(g, tx, y2, o.price, lock, ink);
      if (o.price2) { end += 1; end += T(g, '+', end, y2, { color: P.sub, outline: P.out }) + 1; end = pricePart(g, end, y2, o.price2, lock, ink); }
    } else if (o.done) end += T(g, o.done, tx, y2, { color: C.green2 });
    else if (o.sub) end += T(g, o.sub, tx, y2, { color: o.subColor || P.sub, outline: P.out });
    // 第二行右边："新"（还没买过）、备注，或者几级（放得下才放）
    const fits = s => end + 4 + Txt.width(s, 12) <= right;
    if (o.tag) {
      const tw = Txt.width(o.tag, 12) + 4;
      if (lit) { rr(g, right - tw + 1, y2 - 1, tw, 13, '#3a2410', null, 1); T(g, o.tag, right - tw + 3, y2 - 1, { color: C.yellow, outline: null }); }
      else { rr(g, right - tw + 1, y2 - 1, tw, 13, C.yellow, INK, 1); T(g, o.tag, right - tw + 3, y2 - 1, { color: '#3a2410', outline: null }); }
    } else if (o.note && fits(o.note)) T(g, o.note, right, y2, { align: 'right', color: o.noteColor || P.sub, outline: P.out });
    else if (o.lvMax > 1) {
      const lt = o.lv + '/' + o.lvMax;
      if (fits(lt)) T(g, lt, right, y2, { align: 'right', color: max ? C.yellow : P.sub, outline: P.out });
    }
    return h;
  }
  // 小三角：开着朝下，收着朝右（现在没用上，留着）
  function fold(g, x, y, open, col) {
    g.fillStyle = INK;
    if (open) { g.fillRect(x - 1, y, 9, 1); for (let k = 0; k < 4; k++) g.fillRect(x - 1 + k, y + 1 + k, 9 - 2 * k, 1); g.fillStyle = col; for (let k = 0; k < 3; k++) g.fillRect(x + k, y + 1 + k, 7 - 2 * k, 1); g.fillRect(x + 3, y + 4, 1, 1); g.fillStyle = INK; g.fillRect(x + 3, y + 5, 1, 1); }
    else { g.fillRect(x, y - 1, 1, 9); for (let k = 0; k < 4; k++) g.fillRect(x + 1 + k, y - 1 + k, 1, 9 - 2 * k); g.fillStyle = col; for (let k = 0; k < 3; k++) g.fillRect(x + 1 + k, y + k, 1, 7 - 2 * k); g.fillRect(x + 4, y + 3, 1, 1); g.fillStyle = INK; g.fillRect(x + 5, y + 3, 1, 1); }
  }
  // 黄牌（那儿有买得起的）：黄底、深色上箭头，一跳一跳。(x, y) 还是原来小绿点的左上角，牌子往外多出 2 格
  const BADGE = A.sprite([
    '.kkkkkkk.',
    'khhhahhhk',
    'kyyaaayyk',
    'kyaaaaayk',
    'kyyyayyyk',
    'kyyyayyyk',
    'kyyyayyyk',
    'kdddddddk',
    '.kkkkkkk.',
  ], { k: INK, h: '#fff6c0', y: '#ffd84a', d: '#d89a20', a: '#3a2410' });
  function dot(g, x, y) {
    const bob = Math.floor(performance.now() / 260) % 2 ? -1 : 0;
    g.drawImage(BADGE, x - 2, y - 2 + bob);
  }
  // 键帽：见开头。kind：idle 深蓝、lit 有能买的、cur 在这台、red 电话
  //   o：hot 指着（面亮一格、白边）、down 正按着、flash 冒新的（白边，闪不闪调用的那边管）、t 时间（扫光）、notch 右边的小尖
  //   返回面那一块 { x, y, w, h, P }：字和图标画在上面；P.ink 字色、P.sub 小字色、P.out 字的描边（亮黄的不描边）
  const LIP = 3;
  const KEY = {
    idle: { face: '#34447e', hot: '#42569c', hi: '#5468aa', lip: '#18203f', ink: '#f4f0e6', sub: '#a8b4d0', out: INK },
    lit: { face: '#ffd84a', hot: '#ffe680', hi: '#fff6c0', lip: '#b8700e', ink: '#3a2410', sub: '#7a5010', out: null, shine: '#fffbe6' },
    cur: { face: '#3f8eae', hot: '#3f8eae', hi: '#2a6a86', lip: '#2a6a86', ink: '#ffffff', sub: '#d8f0f8', out: INK },
    red: { face: '#fe4c40', hot: '#ff6a5a', hi: '#ff9a8a', lip: '#8a2020', ink: '#ffffff', sub: '#ffe0d8', out: INK, shine: '#ffc8bc' },
    on: { face: '#3ccf4a', hot: '#4ad858', hi: '#1f8a2a', lip: '#1f8a2a', ink: '#0f2a10', sub: '#1f5a26', out: null },
    dim: { face: '#4a5262', hot: '#5a6474', hi: '#6a7484', lip: '#262b36', ink: '#e8ecf4', sub: '#b4bac8', out: INK },
    go: { face: '#3a8a44', hot: '#4fae5a', hi: '#7ad884', lip: '#1f5a26', ink: '#ffffff', sub: '#c8f0c8', out: INK },
  };
  const SHINE = { every: 1.9, sweep: 0.45 };
  function key(g, x, y, w, h, o) {
    const kind = o.kind || 'idle', P = KEY[kind], sunk = kind === 'cur' || kind === 'on' || o.down ? LIP - 1 : 0, hot = o.hot && kind !== 'cur';
    const top = y + sunk;
    shape(g, x, top, w, h - sunk, 2, o.flash || hot ? '#ffffff' : INK);
    shape(g, x + 1, top + 1, w - 2, h - sunk - 2, 1, P.lip);
    const fx = x + 1, fy = top + 1, fw = w - 2, fh = h - LIP - 2;
    shape(g, fx, fy, fw, fh, 1, hot ? P.hot : P.face);
    g.fillStyle = P.hi; g.fillRect(fx + 1, fy, fw - 2, 1);
    // 扫光：一道斜的亮条从左扫到右；一个按钮一个起点，一列往下错开着扫
    if (P.shine && o.t != null) {
      const ph = ((((o.t - (x + y) * 0.013) % SHINE.every) + SHINE.every) % SHINE.every) / SHINE.sweep;
      if (ph < 1) {
        const bx = fx - fh + Math.round(ph * (fw + fh + 8));
        g.fillStyle = P.shine;
        for (let j = 1; j < fh - 1; j++) {
          const sx = bx + Math.round((fh - j) * 0.5);
          for (const [a, n] of [[sx, 3], [sx + 5, 1]]) {
            const x0 = Math.max(fx + 1, a), x1 = Math.min(fx + fw - 1, a + n);
            if (x1 > x0) g.fillRect(x0, fy + j, x1 - x0, 1);
          }
        }
      }
    }
    // 小尖：在这台的右边，指着台子
    if (o.notch) {
      const cy = Math.round(fy + fh / 2);
      for (let k = 0; k <= 4; k++) {
        const hh = 4 - k;
        g.fillStyle = INK; g.fillRect(x + w - 1 + k, cy - hh, 1, hh * 2 + 1);
        if (hh > 0) { g.fillStyle = P.face; g.fillRect(x + w - 1 + k, cy - hh + 1, 1, hh * 2 - 1); }
      }
    }
    return { x: fx, y: fy, w: fw, h: fh, P };
  }
  // 钱箱里一种券一行（点一下去那台）：票（2 倍）、几张、哪台；cur 现在拿着的这台（黄边、亮底），dot 那台有买得起的。
  //   lock：上了桌还没开的那台（红布、名字、开台价 + 一条进度条）。返回占多高
  const WALLET_H = 22, WALLET_LOCK_H = 31;
  function walletRow(g, x, y, w, o) {
    const h = o.lock ? WALLET_LOCK_H : WALLET_H, edge = o.flash ? '#ffffff' : o.cur ? C.yellow : INK;
    rr(g, x, y, w, h, o.cur || o.hot ? C.navyHot : C.navy, edge, 2, C.navyHi, C.navyLo);
    if (o.icon) { const s = o.iconScale || 2, ih = o.icon.height * s; g.drawImage(o.icon, x + 3, y + (o.lock ? 4 : Math.round((h - ih) / 2)), o.icon.width * s, ih); }
    if (o.lock) {
      T(g, o.name, x + 34, y + 2, { color: C.text });
      const bx = pricePart(g, x + 34, y + 16, o.price, false) + 4, bw = x + w - 4 - bx;
      if (bw >= 12) bar(g, bx, y + 20, bw, 6, o.frac, o.frac >= 1 ? C.green2 : C.bar);
    } else {
      T(g, o.value, x + 34, y + 4, { color: o.valueColor || C.text });
      T(g, o.name, x + w - 5, y + 4, { align: 'right', color: o.cur ? '#ffffff' : C.dim });
    }
    if (o.dot) dot(g, x + w - 6, y + 1);
    return h;
  }
  // 开关（小人页"自动打""自动买"）：开着是按进去的绿键帽，关着是深蓝的。高 TOGGLE_H
  const TOGGLE_H = 18;
  function toggle(g, x, y, w, label, on, hot, down) {
    const f = key(g, x, y, w, TOGGLE_H, { kind: on ? 'on' : 'idle', hot, down });
    T(g, label, f.x + f.w / 2, f.y, { align: 'center', color: f.P.ink, outline: f.P.out });
  }
  const STAR = A.outlined(['..x..', '.xxx.', 'xxxxx', '.x.x.'], { x: '#ffd84a' }, INK);
  function drawStar(g, x, y) { g.drawImage(STAR, x, y); }
  // 升级框：蓝绿，顶上一个页签形的标题
  function tealPanel(g, x, y, w, h, title) {
    const tw = Math.max(52, Txt.width(title, 16) + 20), tx = Math.round(x + w / 2 - tw / 2);
    rr(g, tx, y, tw, 22, C.teal, INK, 3, C.tealHi);
    rr(g, x, y + 19, w, h - 19, C.teal, INK, 3, null, C.tealLo);
    g.fillStyle = C.teal; g.fillRect(tx + 1, y + 19, tw - 2, 2);
    T(g, title, tx + tw / 2, y + 3, { align: 'center', size: 16, color: '#ffffff' });
    g.fillStyle = C.tealLo; g.fillRect(x + 4, y + 23, w - 8, h - 27);
    return { x: x + 4, y: y + 23, w: w - 8, h: h - 27 };
  }
  // 大按钮：键帽。kind gold 亮黄（扫光）、red 红、dim 灰，别的深蓝
  function bigButton(g, x, y, w, h, label, hot, kind, sub, down) {
    const k = kind === 'gold' ? 'lit' : kind === 'red' ? 'red' : kind === 'dim' ? 'dim' : 'idle';
    const f = key(g, x, y, w, h, { kind: k, hot, down, t: performance.now() / 1000 });
    if (label) T(g, label, f.x + f.w / 2, f.y + (sub ? 1 : Math.round(f.h / 2 - 8)), { align: 'center', size: 16, color: f.P.ink, outline: f.P.out });
    if (sub) T(g, sub, f.x + f.w / 2, f.y + 18, { align: 'center', color: f.P.sub, outline: f.P.out });
    return f;
  }
  // 齿轮（右上角）：圆角灰块里一个齿轮
  const GEAR = A.outlined([
    '...xx...', '.x.xx.x.', 'xxxxxxxx', '.xx..xx.', '.xx..xx.', 'xxxxxxxx', '.x.xx.x.', '...xx...',
  ], { x: '#c8d0dc' }, INK);
  function gear(g, x, y, hot, down) {
    const f = key(g, x, y, 24, 22, { kind: 'dim', hot, down }), s = GEAR.width * 1.6 | 0;
    g.drawImage(GEAR, f.x + Math.round((f.w - s) / 2), f.y + Math.round((f.h - s) / 2), s, s);
  }
  // 扳手（右上角，齿轮左边）：作者来电送的"神秘妙妙工具"，点开开发者面板。lit 亮黄闪（刚送到）
  const WRENCH = A.outlined([
    '......x.x', '......x.x', '.....xxxx', '....xxx..', '...xxx...', '..xxx....', '.xxx.....', 'xxx......', 'xx.......',
  ], { x: '#ffd870' }, INK);
  function wrench(g, x, y, hot, down, lit) {
    const f = key(g, x, y, 24, 22, { kind: lit ? 'lit' : 'dim', hot, down, t: performance.now() / 1000 });
    g.drawImage(WRENCH, f.x + Math.round((f.w - WRENCH.width) / 2), f.y + Math.round((f.h - WRENCH.height) / 2));
  }
  // 小按钮（+ / − 这种）
  // 小按钮（×、换上这种）：键帽，高 20 最合适；on === false 灰的
  function chip(g, x, y, w, h, label, hot, on, down) {
    const f = key(g, x, y, w, h, { kind: on === false ? 'dim' : 'idle', hot, down });
    T(g, label, f.x + f.w / 2, f.y + Math.round(f.h / 2 - 7), { align: 'center', color: on === false ? '#8a90a0' : f.P.ink, outline: f.P.out });
  }
  // 说明框：深蓝圆角，黄字标题，下面几行
  function tip(g, x, y, w, title, lines) {
    const ls = [];
    for (const l of lines) for (const s of Txt.wrap(l.s, 12, w - 16)) ls.push({ s, c: l.c });
    const h = 26 + ls.length * 14 + 4;
    rr(g, x, y, w, h, C.navy, INK, 3, C.navyHi, C.navyLo);
    g.fillStyle = C.yellow; g.fillRect(x + 3, y + 3, 2, 14);
    T(g, title, x + 9, y + 4, { size: 16, color: C.yellow });
    ls.forEach((l, i) => T(g, l.s, x + 8, y + 24 + i * 14, { color: l.c || C.text }));
    return h;
  }
  return { C, shape, rr, bar, moneyBox, tabs, group, row, skillRow, skillRowH, ROW_H, fold, pricePart, dot, key, KEY, LIP, walletRow, WALLET_H, WALLET_LOCK_H, toggle, TOGGLE_H, tealPanel, bigButton, gear, wrench, chip, tip, drawStar, STAR, GEAR };
})();
