/*
 * 第 8 台 · 沼泽（打怪的第三台；第二排的大台）。大台弹球（machines/pinwide.js），同草地史莱姆的打法，多三样：
 *   琥珀史莱姆：橙色、半透明，撞得够快就把钢珠粘住。粘住的要是台上最后一颗，发射道马上补一颗，不花珠子。
 *     粘满三颗它撑破（吐三只的钱），三颗一起放出来——多球。多球打完（台上回到一颗）三秒后，再掉一只琥珀下来。
 *     粘着的球放回桌上、关了游戏都还粘着（记在 m.lock）。
 *   【倍】多球：台上每多一颗球，碎一只多几倍。
 *   【救】救球：开球、从上面的通道滚过去以后，几秒里掉下去的退回发射道。
 *   金琥珀（碰运气）：3% 的泥史莱姆是金的，碎了 ×5。琥珀里的虫（手上功夫 = 大奖）：一次多球碎 10 只。雨靴（打得深）：打到第 20 层。
 */
Machines.def('swamp', env => {
  'use strict';
  const A = env.A, R = env.R, sfx = env.sfx;
  const MUD = ['#d8e08a', '#8aa648', '#566e2a'], DEEPM = ['#b4c070', '#62803a', '#3a5020'], GOLDS = ['#fff6c0', '#ffd23a', '#d89a10'], AMB = A.AMBER;
  const fmt = v => String(Math.round(v * 10) / 10);
  const m = () => env.m();
  let amberT = 0, stuckT = 0, burstT = 0;
  const amberOf = t => t.s.slimes.find(o => o.sticky && o.state !== 'pop');
  // 掉一只琥珀下来；lock = 身上已经粘着几颗（读档接着来）
  function spawnAmber(t, lock) {
    const o = t.addSlime({ hp: 1, r: 6, extra: { sticky: true, cap: 3, stuck: 0, stickMin: 50 } }, 0);
    if (!o) return null;
    for (let i = 0; i < lock; i++) {
      const a = -Math.PI / 2 + (i - (lock - 1) / 2) * 0.9;
      t.s.balls.push({ id: ++t.s.seq, x: o.x, y: o.y, vx: 0, vy: 0, r: 3.5, state: 'stuck', on: o, ox: Math.cos(a), oy: Math.sin(a), paid: true, free: true, age: 0, slow: 0 });
    }
    o.stuck = lock;
    return o;
  }
  return PinWideKit.make(env, {
    colors: o => (o.sticky ? AMB : o.gold ? GOLDS : o.maxHp >= 4 ? DEEPM : MUD),
    target: () => env.val('n'),
    spawn: () => [{ hp: env.val('h') + R.layerHp(m().layer), size: 'big', gold: env.luck(0.03) }],
    save: () => env.val('s'),
    multi: n => 1 + env.val('x') * Math.max(0, n - 1),
    multiJack: 10,
    init(t) { spawnAmber(t, Math.min(2, m().lock || 0)); amberT = 0.5; },
    died(o, t) {
      const k = t.mult();
      const base = env.val('v') * t.layerMult() * k * (o.gold ? 5 : 1);
      t.pay(base, o, o.gold ? '金 ×5' : k > 1 ? '多球 ×' + fmt(k) : null);
      if (o.gold) env.find('luck');
      t.killCount(1);
    },
    onStick(e, t) {
      const o = e.m;
      m().lock = o.stuck;
      if (o.stuck >= o.cap) {
        // 撑破：三颗一起出来
        o.state = 'pop'; o.t = 0; o.solid = false;
        t.burst(o, 16, 100);
        t.releaseFrom(o);
        m().lock = 0;
        t.pay(env.val('v') * t.layerMult() * 3, o, '撑破了！三颗一起出来');
        sfx.pop(); sfx.settle(5); env.shake(0.3);
        burstT = 3;
      } else {
        t.label(o.x, o.y - o.r - 17, '粘住了', AMB[0]);   // 几颗写在它头上（drawOver），这行再往上飘
        if (!t.playing()) t.loadFree();
        stuckT = 3;
      }
      env.save();
    },
    multiEnd() { amberT = 3; },
    update(dt, t) {
      if (stuckT > 0) stuckT -= dt;
      if (burstT > 0) burstT -= dt;
      if (!amberOf(t) && !t.st.multi) { amberT -= dt; if (amberT <= 0) amberT = spawnAmber(t, 0) ? 3 : 0.5; }
    },
    drawOver(ctx, o) { if (o.sticky && o.state !== 'pop' && o.state !== 'drop') MK.label(ctx, o.stuck + '/3', o.x, o.y - o.r - 10, AMB[0], 'center'); },
    hint(t) {
      if (burstT > 0) return '撑破了，多球！' + (t.mult() > 1 ? '碎一只 ×' + fmt(t.mult()) : '别让球掉下去');
      if (stuckT > 0) return '粘住了！推头上补一颗，不花珠子';
      const a = amberOf(t);
      if (a && !m().lock && m().shots < 6 && t.playing()) return '撞橙色的琥珀史莱姆：粘住三颗就多球';
      return '';
    },
    info: t => {
      // 只写右边升级栏看不出来的：层数带来的变化、琥珀粘了几颗（几只、多球几倍右边有）
      const a = amberOf(t), lock = a ? a.stuck : 0, L = t.layer();
      return [
        ['第 ' + L + ' 层' + (L > 1 ? ' ×' + fmt(t.layerMult()) : ''), null],
        ['差 ' + (10 - m().lk) + ' 只下一层', null],
        ['琥珀粘了 ' + lock + '/3 颗', lock ? AMB[0] : null],
        [(env.val('h') + t.layerHp()) + ' 下碎一只', null],
        ['一只吐 ' + fmt(env.val('v') * t.layerMult()) + ' 个', null],
      ];
    },
  });
});
