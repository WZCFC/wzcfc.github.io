/*
 * 临门一脚（足球；俯视，小台 64 宽，11-11 粗做）。草皮球场，顶上一个球门，门里五格，亮着的两格才算；守门员在门前左右扑。
 *   在卡上按住往后拉，松手把罚球点上的球踢出去（只能往前踢）。每踢一脚，两边滚进【签】个球（场上最多 10 个），场上的越攒越多。
 *   球进了门里亮着的格，一个吐【价】张券；进了不亮的格白进。停在场上的球留着，下一脚可以拿来撞。
 *   金足球（碰运气）：滚进来的 3% 是金的（×5）。帽子戏法（手上功夫 = 大奖）：一脚进 3 个。奖杯（打得深）：进 150 个。
 */
Machines.def('soccer', env => {
  'use strict';
  const { A, sfx } = env;
  const T = window.TopDown, INK = A.INK;
  const BOX = { x0: 14, x1: 114, y0: 28, y1: 154 }, SPOT = { x: 64, y: 138 };
  const GOAL = { x0: 42, x1: 86, y: 38 }, SLOTS = 5, SW = (86 - 42) / 5;
  const BR = 4.5, VMAX = 270, PULL = 44, CAP = 10;
  const s = T.create();
  const st = { state: 'aim', drag: null, quiet: 0, acc: { t: 0 }, time: 0, goals: 0, lit: [], fading: [], flash: null, auto: null, shotN: 0, keeper: 0 };
  const m = () => env.m();
  const BALL = A.ballSprite(BR, ['#c8d0d4', '#ffffff', '#ffffff'], (k, c) => { for (const [dx, dy] of [[0, 0], [-1, 0], [0, -1], [-1, -1], [2, 1], [-3, 1], [0, 3]]) k.P(Math.floor(c + dx), Math.floor(c + dy), '#2f3a3c'); });
  const GOLDB = A.ballSprite(BR, ['#c47a10', '#ffd23a', '#fff3a0'], (k, c) => { for (const [dx, dy] of [[0, 0], [-1, 0], [0, -1], [-1, -1]]) k.P(Math.floor(c + dx), Math.floor(c + dy), '#a85a10'); });
  // 守门员（从上往下看）：橙球衣张着两臂、白手套，脑袋一圈棕头发
  const K = A.kit, KEEPER = A.layerSprite('keeper', 18, 12, L => {
    K.lE(L, 9, 7, 7, 3, ['#ffc070', '#ff9700', '#c86a10']);
    for (const x of [2, 16]) K.lE(L, x, 6.5, 1.6, 1.6, '#ffffff');
    K.lE(L, 9, 5.5, 2.6, 2.6, (x, y, u, v) => (v < 0.1 ? '#5a3418' : '#f6c890'));
  });
  const balls = () => s.bodies.filter(b => b.kind === 'ball' && b.alive);
  const mkBall = (x, y, o) => T.add(s, Object.assign({ kind: 'ball', x, y, r: BR, m: 1, mu: 45, drag: 0.6, e: 0.85, we: 0.6, box: BOX }, o));
  // 门柱、守门员：很重的圆盘，每一步摆回原位（只挡不动）
  const posts = [T.add(s, { kind: 'post', x: GOAL.x0, y: GOAL.y, r: 2, m: 1e6, mu: 0, drag: 0, e: 0.7 }), T.add(s, { kind: 'post', x: GOAL.x1, y: GOAL.y, r: 2, m: 1e6, mu: 0, drag: 0, e: 0.7 })];
  const keeper = T.add(s, { kind: 'keeper', x: 64, y: GOAL.y + 7, r: 6.5, m: 1e6, mu: 0, drag: 0, e: 0.6 });
  const keeperX = t => 64 + 17 * Math.sin(t * 1.7) * (0.8 + 0.2 * Math.sin(t * 0.63));
  function pin() {
    posts[0].x = GOAL.x0; posts[0].y = GOAL.y; posts[1].x = GOAL.x1; posts[1].y = GOAL.y;
    keeper.x = keeperX(st.keeper); keeper.y = GOAL.y + 7;
    for (const b of [...posts, keeper]) b.vx = b.vy = 0;
  }
  function drawLit() {
    const all = [0, 1, 2, 3, 4];
    for (let i = 0; i < 2; i++) { const j = i + Math.floor(Math.random() * (5 - i)); [all[i], all[j]] = [all[j], all[i]]; }
    st.lit = all.slice(0, 2).sort((a, b) => a - b);
  }
  drawLit();
  for (const [x, y] of [[40, 90], [88, 96], [64, 80]]) mkBall(x, y);

  // ---------- 踢 ----------
  function startDrag(p) { if (st.state !== 'aim') return false; st.drag = { x0: p.sx, y0: p.sy, x: p.sx, y: p.sy, by: p.id }; st.state = 'drag'; return true; }
  // 往后拉的向量：只能往前踢（出手方向往上至少偏 0.25）
  function pullVec() {
    const d = st.drag; let dx = d.x - d.x0, dy = d.y - d.y0; const l = Math.hypot(dx, dy);
    if (l > PULL) { dx *= PULL / l; dy *= PULL / l; }
    if (l > 0.01 && dy / Math.hypot(dx, dy) < 0.25) { const ll = Math.min(l, PULL), sx = Math.sign(dx) || 1; dy = 0.25 * ll; dx = sx * Math.sqrt(ll * ll - dy * dy); }
    return { dx, dy, l: Math.min(l, PULL) };
  }
  function release() {
    if (st.state !== 'drag') return;
    const { dx, dy, l } = pullVec();
    st.drag = null;
    if (l < 3) { st.state = 'aim'; return; }
    if (!env.spend()) { st.state = 'aim'; return; }
    const v = T.shotFromDrag(dx, dy, PULL, VMAX);
    const b = mkBall(SPOT.x, SPOT.y, { kicked: true });
    b.vx = v.vx; b.vy = v.vy;
    // 两边滚进几个
    const n = env.val('n');
    for (let i = 0; i < n && balls().length < CAP; i++) {
      const left = i % 2 === 0, y = 90 + Math.random() * 40;
      mkBall(left ? 20 : 108, y, { vx: (left ? 1 : -1) * (60 + Math.random() * 50), vy: (Math.random() - 0.5) * 30, gold: env.luck(0.03), rolled: true });
    }
    st.goals = 0; st.quiet = 0; st.shotN += 1; st.state = 'roll';
    sfx.launch(v.p * 0.7);
  }
  // 进门：球心进了门框那一截
  function check(b) {
    if (!b.alive || b.kind !== 'ball') return;
    if (b.y - b.r > GOAL.y - 3 || b.x < GOAL.x0 + 1 || b.x > GOAL.x1 - 1) return;
    b.alive = false;
    const slot = Math.max(0, Math.min(SLOTS - 1, Math.floor((b.x - GOAL.x0) / SW)));
    st.fading.push({ x: b.x, y: b.y, im: b.gold ? GOLDB : BALL, t: 0 });
    if (st.lit.includes(slot)) {
      st.goals += 1;
      const base = env.val('v') * (b.gold ? 5 : 1);
      env.award(base, { at: [b.x, GOAL.y - 4], n: Math.min(6, base) });
      m().kills = (m().kills || 0) + 1;
      st.flash = { slot, t: 0.4 };
      if (b.gold) { env.toast('金足球！×5', A.GOLD[0]); env.find('luck'); }
      if (m().kills >= 150) env.find('deep');
      sfx.win();
    } else sfx.miss();
  }
  function settle() {
    if (st.goals >= 3) env.jackpot();
    s.bodies = s.bodies.filter(b => b.alive);
    drawLit();
    st.state = 'aim';
    env.save();
  }

  // ---------- 自动踢：挑一个场上的球往亮格撞（没有就直接踢亮格） ----------
  function auto(dt) {
    const A_ = st.auto || (st.auto = { t: 0 });
    if (st.state !== 'aim' || env.marbles() <= 0) return;
    A_.t += dt; if (A_.t < 0.4) return; A_.t = 0;
    const slot = st.lit[Math.floor(Math.random() * st.lit.length)], gx = GOAL.x0 + SW * (slot + 0.5), gy = GOAL.y - 4;
    let best = null;
    for (const b of balls()) {
      const tx = gx - b.x, ty = gy - b.y, tl = Math.hypot(tx, ty) || 1;
      const hx = b.x - tx / tl * BR * 2, hy = b.y - ty / tl * BR * 2;
      const vx = hx - SPOT.x, vy = hy - SPOT.y, vl = Math.hypot(vx, vy) || 1;
      const cut = (vx / vl) * (tx / tl) + (vy / vl) * (ty / tl);
      if (vy / vl > -0.25 || cut < 0.4) continue;
      const score = cut - vl / 200;
      if (!best || score > best.score) best = { score, ux: vx / vl, uy: vy / vl, d: vl + tl };
    }
    if (!best) { const vx = gx - SPOT.x, vy = gy - SPOT.y, vl = Math.hypot(vx, vy); best = { ux: vx / vl, uy: vy / vl, d: vl }; }
    const k = window.__autoNoise || 0, a = (Math.random() - 0.5) * 0.08 * k, c = Math.cos(a), sn = Math.sin(a);
    const ux = best.ux * c - best.uy * sn, uy = best.ux * sn + best.uy * c, p = Math.min(1, 0.55 + best.d / 250);
    st.drag = { x0: 0, y0: 0, x: -ux * PULL * p, y: -uy * PULL * p, by: 'auto' };
    st.state = 'drag';
    release();
  }

  return {
    s,
    fine(f) {
      // 球门：白门框、网格（两格一个点），罚球点
      for (let x = GOAL.x0 - 1; x <= GOAL.x1 + 1; x++) for (let y = 28; y < GOAL.y; y++) {
        if (x === GOAL.x0 - 1 || x === GOAL.x1 + 1) f.px(x, y, '#ffffff');
        else if ((x + y) % 3 === 0) f.px(x, y, '#c8e8c8');
      }
      for (let k = 1; k < SLOTS; k++) for (let y = 29; y < GOAL.y - 1; y++) f.px(Math.round(GOAL.x0 + SW * k), y, '#e8ffe8');
      for (const [dx, dy] of [[0, 0], [1, 0], [0, 1], [1, 1]]) f.px(SPOT.x - 1 + dx, SPOT.y + 6 + dy, '#ffffff');
    },
    update(dt) {
      st.time += dt; st.keeper += dt;
      if (st.flash && (st.flash.t -= dt) <= 0) st.flash = null;
      if (st.state === 'roll') {
        T.advance(s, dt, st.acc, null, () => { pin(); for (const b of s.bodies) check(b); });
        for (const e of s.events.splice(0)) { if (e.type === 'hit') { if (e.a.kind === 'keeper' || e.b.kind === 'keeper') sfx.bump(e.impact); else sfx.clack(e.impact); } else if (e.type === 'wall') sfx.wall(e.impact * 0.4); }
        if (!T.moving(s, 2)) { st.quiet += dt; if (st.quiet > 0.25) { for (const b of s.bodies) b.vx = b.vy = 0; settle(); } } else st.quiet = 0;
      } else { pin(); s.events.length = 0; }
      st.fading = st.fading.filter(q => (q.t += dt) < 0.35);
    },
    draw(ctx) {
      // 门里亮着的格：一块黄
      for (let k = 0; k < SLOTS; k++) {
        const on = st.lit.includes(k), hot = st.flash && st.flash.slot === k && Math.sin(st.time * 40) > 0;
        if (on) MK.rect(ctx, Math.round(GOAL.x0 + SW * k) + 1, 30, Math.round(SW) - 2, 2, hot ? '#ffffff' : A.GOLD[0]);
      }
      MK.spr(ctx, KEEPER, Math.round(keeper.x - KEEPER.width / 2), Math.round(keeper.y - KEEPER.height / 2));
      for (const b of balls()) { const im = b.gold ? GOLDB : BALL; MK.spr(ctx, im, Math.round(b.x - im.width / 2), Math.round(b.y - im.height / 2)); }
      for (const q of st.fading) if (Math.floor(q.t * 20) % 2 === 0) MK.spr(ctx, q.im, Math.round(q.x - q.im.width / 2), Math.round(q.y - q.im.height / 2));
      // 罚球点上的球（还没踢）、拉的皮筋、出手方向
      if (st.state === 'aim' || st.state === 'drag') if (env.marbles() > 0) MK.spr(ctx, BALL, Math.round(SPOT.x - BALL.width / 2), Math.round(SPOT.y - BALL.height / 2));
      if (st.state === 'drag') {
        const { dx, dy, l } = pullVec();
        if (l >= 3) {
          const ux = -dx / l, uy = -dy / l;
          MK.dots(ctx, SPOT.x, SPOT.y, SPOT.x + dx, SPOT.y + dy, '#ffffff', 2);
          MK.dots(ctx, SPOT.x + ux * (BR + 2), SPOT.y + uy * (BR + 2), SPOT.x + ux * (12 + 40 * l / PULL), SPOT.y + uy * (12 + 40 * l / PULL), l >= PULL * 0.98 ? A.GOLD[0] : '#ffffff', 3, st.time * 3);
        }
      }
      if (st.state === 'aim' && env.marbles() > 0 && st.shotN < 3 && Math.sin(st.time * 5) > 0) MK.label(ctx, '按住往后拉', SPOT.x, SPOT.y + 8, A.GOLD[0], 'center');
      if (st.state === 'roll' && st.goals > 0) MK.label(ctx, '进 ' + st.goals, 64, 46, st.goals >= 3 ? '#ffffff' : A.GOLD[0], 'center');
      MK.led(ctx, env.marbles(), env.marbles() <= 0, st.time);
    },
    down(p) {
      if (p.btn !== 0) return false;
      if (st.state === 'aim') {
        if (env.marbles() <= 0) { env.deny('marbles'); return true; }
        return startDrag(p);
      }
      return true;
    },
    move(p) { if (st.state === 'drag' && st.drag.by !== 'auto') { st.drag.x = p.sx; st.drag.y = p.sy; } },
    up(p) { if (st.state === 'drag' && st.drag.by === p.id) release(); },
    key() { return false; },
    cancel() { if (st.state === 'drag') { st.drag = null; st.state = 'aim'; } },
    leave() { if (st.state === 'drag') { st.drag = null; st.state = 'aim'; } },
    auto,
    inPlay: () => st.state === 'roll' || st.state === 'drag',
    busy: () => st.state === 'drag',
    hint() {
      if (st.state === 'drag') return '松手踢出去（拉回原处不踢）';
      if (st.state !== 'aim' || env.marbles() <= 0) return '';
      return st.shotN < 3 ? '在卡上按住往后拉，松手踢。进门里亮着的格才算' : '';
    },
    info() {
      return [
        ['场上 ' + balls().length + ' 个 · 一脚滚进 ' + env.val('n') + ' 个（最多 ' + CAP + '）', null],
        ['进亮格一个吐 ' + env.val('v') + ' 张', null],
        ['一脚进 3 个 = 大奖', null],
      ];
    },
    onUpgrade() {},
    debug: () => ({ state: st.state, onField: balls().length, shots: st.shotN, marbles: env.marbles(), goals: m().kills || 0, lit: st.lit.join(',') }),
  };
});
