/*
 * 落袋为安（台球；俯视，小台 64 宽，11-11 粗做）。绿台呢、六个袋口，台上摆着几颗彩球；母球从开球点打。
 *   在卡上按住往后拉（拉多长 = 多快，方向反过来就是出手方向），松手打母球。彩球进袋一颗吐【价】张券。
 *   进了球、母球没掉袋、台上还有：下一杆从母球停的地方接着打，不花珠子；不然下一杆花一颗珠子，母球回开球点，台上补进【签】颗（最多 12 颗）。
 *   白打的那几杆不补球（跟弹无虚发一样，补货只跟着花钱那一下）。
 *   八号球（碰运气）：补进来的 3% 是八号球（×5）。巧克（手上功夫 = 大奖）：一杆进 4 颗。球杆架（打得深）：进袋 300 颗。
 */
Machines.def('pool', env => {
  'use strict';
  const { A, sfx } = env;
  const T = window.TopDown, INK = A.INK;
  const BOX = { x0: 16, x1: 112, y0: 30, y1: 152 }, HEAD = { x: 64, y: 130 };
  const POCKETS = [[17, 31], [111, 31], [14, 91], [114, 91], [17, 151], [111, 151]], PR = 6.5;
  const BR = 4, VMAX = 280, PULL = 44, CAP = 12;
  const s = T.create();
  const st = { state: 'aim', free: false, sunk: 0, scratch: false, drag: null, quiet: 0, acc: { t: 0 }, time: 0, fading: [], back: null, auto: null, shotN: 0 };
  const m = () => env.m();
  const COLS = [['#c47a10', '#ffd23a', '#fff3a0'], ['#1a5fb0', '#2f86ea', '#7ac0ff'], ['#b8322a', '#fe4c40', '#ff8a7a'], ['#6a3aa0', '#9a5ad8', '#c8a0ff'], ['#c86a10', '#ff9700', '#ffc070'], ['#22803a', '#36b24a', '#9af06a'], ['#7a1a2a', '#a8283a', '#e05a6a']];
  const IMS = COLS.map(C => A.ballSprite(BR, C, (k, c) => { k.P(Math.floor(c - 1), Math.floor(c - 2), '#ffffff'); }));
  const EIGHT = A.ballSprite(BR, ['#1b2628', '#2f3a3c', '#5f7378'], (k, c) => { for (const [dx, dy] of [[-1, -1], [0, -1], [-1, 0], [0, 0]]) k.P(Math.floor(c + dx), Math.floor(c + dy), '#ffffff'); });
  const CUE = A.ballSprite(BR, ['#c8d0d4', '#f2f6f6', '#ffffff']);
  const balls = () => s.bodies.filter(b => b.kind === 'ball' && b.alive);
  const mkBall = (x, y, o) => T.add(s, Object.assign({ kind: 'ball', x, y, r: BR, m: 1, mu: 38, drag: 0.4, e: 0.95, we: 0.72, box: BOX, look: Math.floor(Math.random() * COLS.length), born: 1 }, o));
  let cue = T.add(s, { kind: 'cue', x: HEAD.x, y: HEAD.y, r: BR, m: 1, mu: 38, drag: 0.4, e: 0.95, we: 0.72, box: BOX });

  // 摆球：开局一个三角；补球往上面三分之二随便放，别压着别的
  for (let r = 0, k = 0; r < 3; r++) for (let i = 0; i <= r; i++, k++) mkBall(64 + (i - r / 2) * (BR * 2 + 0.6), 62 - r * (BR * 1.8), { look: k % COLS.length });
  function placeOne(blink) {
    for (let k = 0; k < 60; k++) {
      const x = BOX.x0 + 12 + Math.random() * (BOX.x1 - BOX.x0 - 24), y = BOX.y0 + 12 + Math.random() * 70;
      if (s.bodies.some(b => b.alive && Math.hypot(b.x - x, b.y - y) < b.r + BR + 2)) continue;
      return mkBall(x, y, { eight: env.luck(0.03), born: blink ? 0.01 : 1 });
    }
    return null;
  }
  function refill(n) { let k = 0; for (let i = 0; i < n && balls().length < CAP; i++) if (placeOne(true)) k++; if (k) sfx.hop(4); }

  // ---------- 打 ----------
  function startDrag(p) { if (st.state !== 'aim') return false; st.drag = { x0: p.sx, y0: p.sy, x: p.sx, y: p.sy, by: p.id }; st.state = 'drag'; return true; }
  const pullVec = () => { const d = st.drag; let dx = d.x - d.x0, dy = d.y - d.y0; const l = Math.hypot(dx, dy); if (l > PULL) { dx *= PULL / l; dy *= PULL / l; } return { dx, dy, l: Math.min(l, PULL) }; };
  function release() {
    if (st.state !== 'drag') return;
    const { dx, dy, l } = pullVec();
    st.drag = null;
    if (l < 3) { st.state = 'aim'; return; }
    if (!st.free && !env.spend()) { st.state = 'aim'; return; }
    const v = T.shotFromDrag(dx, dy, PULL, VMAX);
    cue.vx = v.vx; cue.vy = v.vy;
    st.free = false; st.sunk = 0; st.scratch = false; st.quiet = 0; st.shotN += 1;
    st.state = 'roll';
    sfx.launch(v.p * 0.6);
  }
  const inPocket = b => POCKETS.some(([px, py]) => Math.hypot(b.x - px, b.y - py) < PR);
  function sink(b) {
    b.alive = false;
    st.fading.push({ x: b.x, y: b.y, im: b === cue ? CUE : b.eight ? EIGHT : IMS[b.look], t: 0 });
    if (b === cue) { st.scratch = true; sfx.miss(); return; }
    st.sunk += 1;
    const base = env.val('v') * (b.eight ? 5 : 1);
    env.award(base, { at: [b.x, b.y], n: Math.min(6, base) });
    m().kills = (m().kills || 0) + 1;
    if (b.eight) { env.toast('八号球！×5', A.GOLD[0]); env.find('luck'); }
    if (m().kills >= 300) env.find('deep');
    sfx.settle(Math.min(5, st.sunk));
  }
  // 一杆停了：进了球、母球还在、台上还有 → 白打；不然母球回开球点（回到了再补球）
  function settle() {
    if (st.sunk >= 4) env.jackpot();
    s.bodies = s.bodies.filter(b => b.alive || b === cue);
    const left = balls().length;
    if (st.sunk > 0 && !st.scratch && left > 0) {
      st.free = true;
      env.toast('进了 ' + st.sunk + ' 颗、母球还在：下一杆不花珠子', '#a8f07a');
      st.state = 'aim';
    } else {
      st.free = false;
      if (!left) env.toast('台打空了！换一颗母球，再补球', A.GOLD[0]);
      st.back = { x0: st.scratch ? HEAD.x : cue.x, y0: st.scratch ? 160 : cue.y, t: 0 };
      cue.alive = true; cue.vx = cue.vy = 0;
      st.state = 'back';
    }
    env.save();
  }
  function onEvent(e) {
    if (e.type === 'hit') sfx.clack(e.impact);
    else if (e.type === 'wall') sfx.wall(e.impact * 0.4);
  }

  // ---------- 瞄准线：画到第一颗撞上的、虚圈标出母球撞上时在哪，被撞的那颗往哪走 ----------
  function aimLines(ctx) {
    if (st.state !== 'drag') return;
    const { dx, dy, l } = pullVec();
    if (l < 3) return;
    const ux = -dx / l, uy = -dy / l;
    MK.dots(ctx, cue.x, cue.y, cue.x + dx, cue.y + dy, '#ffffff', 2);
    const hit = T.firstHit(s, cue.x, cue.y, BR, ux, uy, 130, cue);
    const endD = hit ? hit.t : 60;
    MK.dots(ctx, cue.x + ux * (BR + 2), cue.y + uy * (BR + 2), cue.x + ux * endD, cue.y + uy * endD, A.GOLD[0], 3, st.time * 3);
    if (hit) {
      MK.ring(ctx, hit.hx, hit.hy, BR, '#ffffff', 3);
      const b = hit.body, nx = b.x - hit.hx, ny = b.y - hit.hy, nl = Math.hypot(nx, ny) || 1;
      MK.dots(ctx, b.x + nx / nl * BR, b.y + ny / nl * BR, b.x + nx / nl * 30, b.y + ny / nl * 30, '#ff8a7a', 2);
    }
    MK.label(ctx, Math.round(l / PULL * 100) + '%', cue.x + 8, cue.y - 4, l >= PULL * 0.98 ? '#ff8a7a' : '#ffffff', 'left');
  }

  // ---------- 自动打：挑一颗球、一个袋，算"撞上时母球在哪"，切角小、路短的先 ----------
  function auto(dt) {
    const A_ = st.auto || (st.auto = { t: 0 });
    if (st.state !== 'aim') return;
    if (!st.free && env.marbles() <= 0) return;
    A_.t += dt; if (A_.t < 0.4) return; A_.t = 0;
    let best = null;
    for (const b of balls()) for (const [px, py] of POCKETS) {
      const tx = px - b.x, ty = py - b.y, tl = Math.hypot(tx, ty) || 1;
      const gx = b.x - tx / tl * BR * 2, gy = b.y - ty / tl * BR * 2;
      const vx = gx - cue.x, vy = gy - cue.y, vl = Math.hypot(vx, vy) || 1;
      const cut = (vx / vl) * (tx / tl) + (vy / vl) * (ty / tl);
      if (cut < 0.3) continue;
      const score = cut * 2 - vl / 150 - tl / 200;
      if (!best || score > best.score) best = { score, ux: vx / vl, uy: vy / vl, d: vl + tl };
    }
    if (!best) { const b = balls()[0]; if (!b) return; const vx = b.x - cue.x, vy = b.y - cue.y, vl = Math.hypot(vx, vy) || 1; best = { ux: vx / vl, uy: vy / vl, d: vl }; }
    const k = window.__autoNoise || 0, a = (Math.random() - 0.5) * 0.06 * k, c = Math.cos(a), sn = Math.sin(a);
    const ux = best.ux * c - best.uy * sn, uy = best.ux * sn + best.uy * c, p = Math.min(1, 0.45 + best.d / 220);
    st.drag = { x0: 0, y0: 0, x: -ux * PULL * p, y: -uy * PULL * p, by: 'auto' };
    st.state = 'drag';
    release();
  }

  return {
    s,
    fine(f) {
      // 袋口：黑洞、外面一圈深色皮边；台边一排小菱形点
      for (const [px, py] of POCKETS) for (let y = -8; y <= 8; y++) for (let x = -8; x <= 8; x++) {
        const d = Math.hypot(x + 0.5, y + 0.5), X = Math.floor(px + x), Y = Math.floor(py + y);
        if (X < 14 || X > 113 || Y < 28 || Y > 153) continue;
        if (d <= PR - 1) f.px(X, Y, '#0c0c10'); else if (d <= PR) f.px(X, Y, '#3a2410');
      }
      for (const x of [40, 64, 88]) { f.px(x, 29, '#fff3a0'); f.px(x, 152, '#fff3a0'); }
      for (const y of [60, 122]) { f.px(15, y, '#fff3a0'); f.px(112, y, '#fff3a0'); }
      f.px(HEAD.x, HEAD.y, '#8ad0a0');
    },
    update(dt) {
      st.time += dt;
      for (const b of s.bodies) if (b.born > 0 && b.born < 1) b.born = Math.min(1, b.born + dt / 0.25);
      if (st.state === 'roll') {
        T.advance(s, dt, st.acc, null, () => { for (const b of s.bodies) if (b.alive && inPocket(b)) sink(b); });
        for (const e of s.events.splice(0)) onEvent(e);
        if (!T.moving(s, 2)) { st.quiet += dt; if (st.quiet > 0.25) { for (const b of s.bodies) b.vx = b.vy = 0; settle(); } } else st.quiet = 0;
      } else s.events.length = 0;
      if (st.state === 'back') {
        st.back.t += dt / 0.35;
        const t = MK.ease(st.back.t);
        cue.x = st.back.x0 + (HEAD.x - st.back.x0) * t; cue.y = st.back.y0 + (HEAD.y - st.back.y0) * t;
        if (st.back.t >= 1) { st.back = null; cue.x = HEAD.x; cue.y = HEAD.y; st.state = 'aim'; refill(env.val('n')); }
      }
      st.fading = st.fading.filter(q => (q.t += dt) < 0.35);
    },
    draw(ctx) {
      for (const b of balls()) {
        if (b.born > 0 && b.born < 1 && Math.sin(b.born * 20) > 0) continue;
        const im = b.eight ? EIGHT : IMS[b.look];
        MK.spr(ctx, im, Math.round(b.x - im.width / 2), Math.round(b.y - im.height / 2));
      }
      for (const q of st.fading) if (Math.floor(q.t * 20) % 2 === 0) MK.spr(ctx, q.im, Math.round(q.x - q.im.width / 2), Math.round(q.y - q.im.height / 2));
      const showCue = cue.alive && (st.state !== 'aim' || st.free || env.marbles() > 0);
      if (showCue) MK.spr(ctx, CUE, Math.round(cue.x - CUE.width / 2), Math.round(cue.y - CUE.height / 2));
      aimLines(ctx);
      if (st.state === 'aim' && showCue && Math.sin(st.time * 5) > 0) MK.label(ctx, st.free ? '不花珠子' : '按住往后拉', cue.x, cue.y + 8, st.free ? '#a8f07a' : A.GOLD[0], 'center');
      if (st.state === 'roll' && st.sunk > 0) MK.label(ctx, '进 ' + st.sunk, 64, 33, st.sunk >= 4 ? '#ffffff' : A.GOLD[0], 'center');
      MK.led(ctx, env.marbles(), env.marbles() <= 0 && !st.free, st.time);
    },
    down(p) {
      if (p.btn !== 0) return false;
      if (st.state === 'aim') {
        if (!st.free && env.marbles() <= 0) { env.deny('marbles'); return true; }
        return startDrag(p);
      }
      return st.state !== 'aim';
    },
    move(p) { if (st.state === 'drag' && st.drag.by !== 'auto') { st.drag.x = p.sx; st.drag.y = p.sy; } },
    up(p) { if (st.state === 'drag' && st.drag.by === p.id) release(); },
    key() { return false; },
    cancel() { if (st.state === 'drag') { st.drag = null; st.state = 'aim'; } },
    leave() { if (st.state === 'drag') { st.drag = null; st.state = 'aim'; } },
    auto,
    inPlay: () => st.state === 'roll' || st.state === 'drag' || st.state === 'back' || st.free,
    busy: () => st.state === 'drag',
    hint() {
      if (st.state === 'drag') return '松手打出去（拉回原处不打）';
      if (st.state !== 'aim') return '';
      if (st.free) return '进了球、母球还在：接着打不花珠子';
      if (env.marbles() <= 0) return '';
      return st.shotN < 3 ? '在卡上按住往后拉，松手打母球。彩球进袋就算' : '';
    },
    info() {
      const out = [['台上 ' + balls().length + ' 颗 · 花钱那杆补进 ' + env.val('n') + ' 颗（最多 ' + CAP + '）', null], ['进袋一颗吐 ' + env.val('v') + ' 张', null]];
      if (st.free) out.push(['下一杆不花珠子', '#a8f07a']);
      out.push(['一杆进 4 颗 = 大奖', null]);
      return out;
    },
    onUpgrade() {},
    debug: () => ({ state: st.state, onTable: balls().length, free: st.free, shots: st.shotN, marbles: env.marbles(), sunk: m().kills || 0 }),
  };
});
