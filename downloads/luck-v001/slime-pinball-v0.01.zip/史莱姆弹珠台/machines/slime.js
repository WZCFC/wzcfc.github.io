/*
 * 第 2 台 · 草地史莱姆（打怪的第一台）。弹球台：拉弹簧把钢珠打上去，拍挡板把球留在台上，撞史莱姆。
 *   一只史莱姆几下碎（【速】），撞一下掉一块、身子缩一圈；碎了吐筹码（【价】× 层数倍率）。
 *   台上保持几只（【签】）：碎一只，1.5 秒后草丛里再掉一只下来。
 *   层数：每碎 10 只深一层，史莱姆每 4 层多一下才碎，一只值的筹码每层 +20%。
 *   金史莱姆（陈列柜·碰运气）：掉下来的时候 3% 是金的，碎了 ×5。
 *   绿宝石（手上功夫 = 这台的大奖）：一颗钢珠撞碎 10 只。草帽（打得深）：打到第 20 层。
 */
Machines.def('slime', env => {
  'use strict';
  const A = env.A, R = env.R;
  const MINT = A.MINT, DARK = ['#9ae8a8', '#36b060', '#1c6e3c'], GOLDS = ['#fff6c0', '#ffd23a', '#d89a10'];
  const fmt = v => String(Math.round(v * 10) / 10);
  const m = () => env.m();
  return PinKit.make(env, {
    bumpers: [],
    ballJack: 10,
    colors: o => (o.gold ? GOLDS : o.maxHp >= 4 ? DARK : MINT),
    target: () => env.val('n'),
    spawn: () => [{ hp: env.val('h') + R.layerHp(m().layer), size: 'big', gold: env.luck(0.03) }],
    died(o, t) {
      const base = env.val('v') * t.layerMult() * (o.gold ? 5 : 1);
      t.pay(base, o, o.gold ? '金史莱姆 ×5' : null);
      if (o.gold) env.find('luck');
      t.killCount(1);
    },
    info: t => {
      const out = [
        ['第 ' + t.layer() + ' 层：再碎 ' + (10 - m().lk) + ' 只到下一层', null],
        ['史莱姆 ' + env.val('n') + ' 只 · ' + (env.val('h') + t.layerHp()) + ' 下碎一只', null],
        ['碎一只吐 ' + fmt(env.val('v') * t.layerMult()) + ' 个' + (t.layer() > 1 ? '（层数 ×' + fmt(t.layerMult()) + '）' : ''), null],
      ];
      return out;
    },
  });
});
