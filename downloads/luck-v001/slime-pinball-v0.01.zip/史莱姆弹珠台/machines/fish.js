/*
 * 愿者上钩（钓鱼塘；进洞，小台 64 宽，11-11 粗做）。池塘底下 9 个窝，水里三团鱼影的是鱼窝（每竿重抽）。
 *   按住拉弹簧、松手把饵团打下去（发射道、力度同基础机）；饵落进哪个窝，浮漂就漂在哪。
 *   落进鱼窝【签】的几率咬钩，别的窝三分之一；咬了的话等一会儿浮漂一沉，沉着的那【准】秒里点一下（或空格）收竿，吐【价】张券。
 *   沉之前点 = 早了，鱼吓跑；沉完了没点 = 鱼跑了。一团饵最多一条鱼。
 *   金鱼（碰运气）：咬钩的 3% 是金鱼（×5）。老钓竿（手上功夫 = 大奖）：连着钓上 3 条，一条没跑。鱼篓（打得深）：钓满 100 条。
 */
Machines.def('fish', env => {
  'use strict';
  const { A, sfx } = env;
  const INK = A.INK;
  const s = Sim.createMachine((Date.now() ^ (Math.random() * 1e9)) >>> 0, { door: null });
  const pegList = Sim.pegPositions({ door: null });
  const pl = MK.plunger(sfx);
  const st = { phase: 'idle', acc: { t: 0 }, time: 0, trail: [], flash: new Map(), labels: [], bob: null, streak: 0, auto: null, catchT: 0 };
  const m = () => env.m();
  const BAIT = ['#8a5226', '#c89060', '#e8c090'];
  const ballIm = MK.ball7(BAIT);
  const bobIm = A.outlined(['.r.', 'rrr', 'www', '.w.'], { r: '#fe4c40', w: '#ffffff' }, INK);
  const fishIm = (gold) => A.outlined(['..bb...', '.bbbb.t', 'bebbbtt', '.bbbb.t', '..bb...'], gold ? { b: '#ffd23a', e: INK, t: '#e0a010' } : { b: '#ff9a5a', e: INK, t: '#e8603a' }, INK);
  const shadowIm = A.sprite(['..xx..', '.xxxx.', 'xxxxxx', '.xxxx.', '..xx..'], { x: '#2a5a8a' });

  // ---------- 鱼窝（用 Sim 的"骨头"：三个窝） ----------
  function newSpots() { Sim.drawBones(s, 3); st.phase = 'ready'; }
  newSpots();
  const isSpot = h => s.bones.includes(h);
  function startCharge(by) {
    if (st.phase === 'idle') newSpots();
    if (st.phase !== 'ready') return false;
    if (env.marbles() <= 0) { env.deny('marbles'); return false; }
    pl.start(by); st.phase = 'charge'; return true;
  }
  function release() {
    if (st.phase !== 'charge') return;
    const p = pl.release();
    if (!env.spend()) { st.phase = 'ready'; return; }
    Sim.launch(s, p);
    st.phase = 'fly'; st.acc.t = 0; st.trail.length = 0;
    sfx.launch(p);
  }
  function cancel() { if (st.phase === 'charge') { pl.cancel(); st.phase = 'ready'; } }
  // 饵落窝：抽咬不咬、什么时候沉
  function onLand(e) {
    const p = isSpot(e.hole) ? env.val('b') : env.val('b') / 3;
    const bite = Math.random() < p;
    st.bob = { hole: e.hole, x: Sim.holeCx(e.hole), t: 0, bite, at: 0.7 + Math.random() * 1.6, win: env.val('a'), gold: bite && env.luck(0.03), done: null };
    st.phase = 'wait';
    sfx.settle(3);
  }
  // 收竿：沉着 = 钓上；还没沉 = 早了；没咬 = 空竿
  function reel(by) {
    const b = st.bob;
    if (!b || b.done) return false;
    const sinking = b.bite && b.t >= b.at && b.t < b.at + b.win;
    if (sinking) {
      const base = env.val('v') * (b.gold ? 5 : 1);
      env.award(base, { at: [b.x, 132], n: Math.min(6, base) });
      b.done = { ok: true, t: 0 }; st.streak += 1;
      m().kills = (m().kills || 0) + 1;
      if (b.gold) { env.toast('金鱼！×5', A.GOLD[0]); env.find('luck'); }
      if (st.streak >= 3) { st.streak = 0; env.jackpot(); }
      if (m().kills >= 100) env.find('deep');
      sfx.win();
      st.labels.push({ s: '钓上了！', x: b.x, y: 120, t: 0, c: A.GOLD[0] });
    } else {
      b.done = { ok: false, t: 0 };
      if (b.bite) st.streak = 0;
      st.labels.push({ s: b.bite ? '早了，吓跑了' : '没鱼', x: b.x, y: 124, t: 0, c: '#9ad0ff' });
      sfx.miss();
    }
    if (by !== 'auto') st.reelBy = by;
    return true;
  }
  function endCast() { st.bob = null; Sim.next(s); newSpots(); env.save(); }

  // ---------- 自动打：照力度表瞄鱼窝；浮漂沉了一会儿收竿 ----------
  let fineTab = null;
  function holeTable() {
    if (fineTab) return fineTab;
    fineTab = [];
    for (let i = 0; i <= 200; i++) { const mm = Sim.createMachine(1, { door: null }); mm.quiet = true; const r = Sim.runShot(mm, i / 200); fineTab.push(r ? r.hole : -1); }
    return fineTab;
  }
  function auto(dt) {
    const A_ = st.auto || (st.auto = { t: 0, target: 0.5 });
    A_.t += dt;
    if ((st.phase === 'idle' || st.phase === 'ready') && A_.t > 0.4 && env.marbles() > 0) {
      A_.t = 0;
      if (st.phase === 'idle') newSpots();
      const T = holeTable(), good = []; T.forEach((h, i) => { if (h >= 0 && isSpot(h)) good.push(i); });
      const k = window.__autoNoise || 0;
      A_.target = Math.max(0.06, Math.min(0.99, (good.length ? good[Math.floor(Math.random() * good.length)] : 100) / 200 + (Math.random() - 0.5) * 0.04 * k));
      startCharge('auto');
    } else if (st.phase === 'charge' && pl.by === 'auto') {
      const now = Sim.holdPower(pl.t), next = Sim.holdPower(pl.t + dt);
      if (now >= A_.target || next - A_.target > A_.target - now) release();
    } else if (st.phase === 'wait' && st.bob && !st.bob.done) {
      const b = st.bob;
      if (b.bite && b.t > b.at + 0.18) reel('auto');
      else if (!b.bite && b.t > 2.4) reel('auto');
    }
  }

  return {
    sim: s,
    fine(f) {
      MK.fineHoles(f);
      MK.fineLane(f, Sim.DEFAULTS.guard);
      MK.finePegs(f, pegList);
      f.fineMeter();
    },
    update(dt) {
      st.time += dt;
      for (const [id, t] of st.flash) { if (t - dt <= 0) st.flash.delete(id); else st.flash.set(id, t - dt); }
      st.labels = st.labels.filter(l => (l.t += dt) < 0.9);
      if (st.phase === 'charge') pl.update(dt);
      if (st.phase === 'fly') {
        st.acc.t += dt * 1.3;
        let n = 0;
        while (st.acc.t >= Sim.DT && s.phase === 'flying' && n < 2000) { Sim.step(s); st.acc.t -= Sim.DT; n++; }
        if (s.ball) { st.trail.unshift([s.ball.x, s.ball.y]); if (st.trail.length > 6) st.trail.length = 6; }
        for (const e of s.events.splice(0)) {
          if (e.type === 'hit') { if (e.kind === 'peg') { sfx.pin(e.impact, e.id); st.flash.set(e.id, 0.12); } else if (e.kind !== 'head') sfx.wall(e.impact); }
          else if (e.type === 'fallback') { env.refund(); sfx.fallback(); st.phase = 'ready'; }
          else if (e.type === 'land') onLand(e);
        }
      }
      if (st.phase === 'wait' && st.bob) {
        const b = st.bob; b.t += dt;
        if (!b.done && b.bite && b.t >= b.at && b.t - dt < b.at) sfx.clink();
        if (!b.done && b.bite && b.t >= b.at + b.win) { b.done = { ok: false, t: 0 }; st.streak = 0; st.labels.push({ s: '鱼跑了', x: b.x, y: 124, t: 0, c: '#9ad0ff' }); sfx.miss(); }
        if (!b.done && !b.bite && b.t > 3) { b.done = { ok: false, t: 0 }; st.labels.push({ s: '没鱼', x: b.x, y: 124, t: 0, c: '#9ad0ff' }); }
        if (b.done) { b.done.t += dt; if (b.done.t > 0.7) endCast(); }
      }
    },
    draw(ctx) {
      // 鱼窝：洞口上方水里一团鱼影，慢慢晃
      const showSpots = st.phase !== 'idle';
      if (showSpots) for (const h of s.bones) MK.spr(ctx, shadowIm, Sim.holeCx(h) - 3 + Math.round(Math.sin(st.time * 2 + h) * 1.5), 134);
      MK.holeLamps(ctx, showSpots ? s.bones : []);
      for (const [id] of st.flash) { const c = s.colliders[id]; if (c && c.kind === 'peg') MK.spr(ctx, MK.sprites().pegHit, c.x - 2, c.y - 2); }
      if (st.phase === 'fly' && s.ball) MK.spr(ctx, ballIm, Math.round(s.ball.x - 3.5), Math.round(s.ball.y - 3.5));
      // 浮漂：咬了以后沉下去（只剩一点红），钓上来鱼往上蹦
      const b = st.bob;
      if (b) {
        const sinking = b.bite && b.t >= b.at && (!b.done || b.done.ok) && b.t < b.at + b.win + (b.done ? 1 : 0);
        const nib = b.bite && b.t > b.at - 0.4 && b.t < b.at && Math.sin(b.t * 40) > 0;
        const y = sinking ? 139 : 136 + Math.round(Math.sin(st.time * 3)) + (nib ? 1 : 0);
        MK.spr(ctx, bobIm, b.x - 2, y);
        if (b.done && b.done.ok) { const t = b.done.t / 0.7, fy = 136 - 40 * Math.sin(Math.PI * Math.min(1, t)); MK.spr(ctx, fishIm(b.gold), b.x - 4, Math.round(fy)); }
        if (sinking && !b.done) MK.label(ctx, '点！', b.x, 120, Math.sin(st.time * 16) > 0 ? '#ffffff' : A.GOLD[0], 'center');
      }
      MK.lane(ctx, st.phase === 'charge' ? pl.pull() : 0, env.marbles() > 0 && ['idle', 'ready', 'charge'].includes(st.phase) ? ballIm : null);
      A.drawMeter(ctx, pl.power(), st.phase === 'charge');
      for (const l of st.labels) MK.label(ctx, l.s, l.x, l.y - l.t * 10, l.c, 'center');
      MK.led(ctx, env.marbles(), env.marbles() <= 0, st.time);
    },
    down(p) {
      if (!p.inCard || p.btn !== 0) return false;
      if (st.phase === 'wait') { reel(p.id); return true; }
      if (st.phase === 'idle' || st.phase === 'ready') { startCharge(p.id); return true; }
      return true;
    },
    up(p) { if (st.phase === 'charge' && pl.by === p.id) release(); },
    key(code, down) {
      if (code !== 'Space' && code !== 'ArrowDown' && code !== 'Enter') return false;
      if (down) { if (st.phase === 'wait') reel('key'); else if (st.phase === 'idle' || st.phase === 'ready') startCharge('key'); }
      else if (st.phase === 'charge' && pl.by === 'key') release();
      return true;
    },
    cancel,
    leave: cancel,
    auto,
    inPlay: () => st.phase === 'fly' || st.phase === 'wait' || st.phase === 'charge',
    busy: () => st.phase === 'charge' || st.phase === 'fly' || st.phase === 'wait',
    hint() {
      if (st.phase === 'idle' || st.phase === 'ready') return env.marbles() > 0 ? '按住拉弹簧（鼠标或空格），把饵打进有鱼影的窝' : '';
      if (st.phase === 'charge') return '松手发射';
      if (st.phase === 'wait') return '浮漂一沉就点（或空格）收竿；早了吓跑';
      return '';
    },
    info() {
      const out = [
        ['鱼窝咬钩 ' + Math.round(env.val('b') * 100) + '%，别的窝 ' + Math.round(env.val('b') * 100 / 3) + '%', null],
        ['浮漂沉 ' + env.val('a') + ' 秒，钓上一条吐 ' + env.val('v') + ' 张', null],
      ];
      if (st.streak) out.push(['连着钓上 ' + st.streak + '/3（三条 = 大奖）', A.GOLD[0]]);
      return out;
    },
    onUpgrade() {},
    debug: () => ({ phase: st.phase, marbles: env.marbles(), shots: m().shots, caught: m().kills || 0, streak: st.streak, spots: s.bones.join(',') }),
  };
});
