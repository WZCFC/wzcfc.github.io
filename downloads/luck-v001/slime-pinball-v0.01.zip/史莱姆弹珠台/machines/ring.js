/*
 * 第 3 台 · 弹珠出圈（俯视的第一台）。泥地上一个粉笔圈，圈里摆着弹珠；母珠从圈外下边打进去。
 *   在卡上按住往后拉（拉多长 = 多快，方向反过来就是出手方向），松手弹出母珠。
 *   弹珠整颗出了圈就归你，一颗吐【价】个。换上一颗新母珠（母珠回到圈外）的时候，圈里补进【签】颗（圈里最多 14 颗）。
 *   撞出了、母珠又停在圈里：下一杆从母珠停的地方接着打，不花珠子；不然下一杆花一颗母珠，从圈外重来。
 *   白打的那几杆不补珠，圈打空了这颗母珠也收（照《珠子和小游戏 · 重新规划 v1》第三节：补货只跟着花钱的那一下）。
 *     所以一颗母珠最多拿走它出手时圈里那些；长期算，一颗平均最多拿【签】颗。
 *   连着白打，一杆比一杆值钱：一颗母珠这一串里，第一杆撞出的 ×1，白打的第二杆 ×1.5，第三杆 ×2……（每杆多几倍在 data.js 的 MINIS.chain）。
 *     颗数还是有上限，变的只是每颗值多少；打得准的吃得到，手潮的吃不到。
 *   【准】瞄准线：1 档一小截，2 档画到第一颗撞上的弹珠、标出母珠撞上时在哪，3 档再画出母珠撞完往哪走。
 *   技能树"瞄准线也画出被撞的那颗往哪走"。
 *   猫眼珠（陈列柜·碰运气）：补进来的 3% 是猫眼珠，撞出圈 ×5。冠军珠（手上功夫 = 大奖）：一杆撞出 5 颗。弹珠罐（打得深）：这一局撞出 300 颗。
 */
Machines.def('ring', env => {
  'use strict';
  const { A, sfx } = env;
  const T = window.TopDown, INK = A.INK, FX = A.FX, FY = A.FY;
  const RING = { x: 64, y: 86, r: 39 }, START = { x: 64, y: 141 }, BOX = { x0: 14, x1: 114, y0: 28, y1: 154 };
  const MR = 4.5, TR = 6.5, VMAX = 260, PULL = 44, CAP = 14;
  const s = T.create();
  const st = { state: 'aim', free: false, out: 0, drag: null, quiet: 0, acc: { t: 0 }, time: 0, fading: [], back: null, auto: null, shotN: 0, refills: 0, cleared: 0, chain: 0 };
  // 这一串的第 k 杆撞出的几倍；倍数写成 1、1.5、2
  const STEP = () => (env.mini && env.mini.chain) || 0;
  const multOf = k => 1 + STEP() * (Math.max(1, k) - 1);
  const xs = k => '×' + Math.round(multOf(k) * 10) / 10;
  // 弹珠的颜色：几种玻璃珠（里面一道彩）、猫眼珠（透明，中间一道细彩芯）
  const KINDS = [['#b8322a', '#fe4c40', '#ff8a7a'], ['#a8284a', '#ff5a8a', '#ffc0d8'], ['#1f8a44', '#3ccf6a', '#b8ffc8'], ['#c47a10', '#ffb21a', '#fff3a0'], ['#6a3ad8', '#a87aff', '#e0d0ff']];
  const swirl = C => A.ballSprite(MR, C, (k, c) => { for (let i = -2; i <= 2; i++) k.P(Math.floor(c + i), Math.floor(c - i * 0.5), '#ffffff'); });
  const IMS = KINDS.map(swirl);
  const CAT = A.ballSprite(MR, ['#9ad0e0', '#d8f4ff', '#ffffff'], (k, c) => { for (let j = -3; j <= 3; j++) { k.P(Math.floor(c), Math.floor(c + j), j % 2 ? '#ff6a3a' : '#ffd23a'); } });
  const TAW = A.ballSprite(TR, A.MARB.taw, (k, c) => { k.P(Math.floor(c - 2), Math.floor(c - 3), '#ffffff'); k.P(Math.floor(c - 3), Math.floor(c - 2), '#ffffff'); });
  const m = () => env.m();
  const inRing = (b, pad) => Math.hypot(b.x - RING.x, b.y - RING.y) < RING.r + (pad || 0);
  const marbles = () => s.bodies.filter(b => b.kind === 'marble' && b.alive);
  let taw = T.add(s, { kind: 'taw', x: START.x, y: START.y, r: TR, m: 1.6, mu: 55, drag: 0.5, e: 0.92, we: 0.5, box: BOX });

  // 往圈里补弹珠：别压着别的珠子、母珠
  function placeOne(cat, blink) {
    for (let k = 0; k < 60; k++) {
      const a = Math.random() * Math.PI * 2, d = Math.sqrt(Math.random()) * (RING.r - MR - 4), x = RING.x + Math.cos(a) * d, y = RING.y + Math.sin(a) * d;
      if (s.bodies.some(b => b.alive && Math.hypot(b.x - x, b.y - y) < b.r + MR + 2)) continue;
      const b = T.add(s, { kind: 'marble', x, y, r: MR, m: 1, mu: 55, drag: 0.5, e: 0.92, we: 0.5, box: BOX, cat: !!cat, look: Math.floor(Math.random() * KINDS.length), born: blink ? 0.01 : 1 });
      return b;
    }
    return null;
  }
  function refill(n, blink) {
    let k = 0;
    for (let i = 0; i < n && marbles().length < CAP; i++) if (placeOne(env.luck(0.03), blink)) k++;
    return k;
  }
  refill(7 + (env.lv('more') ? 2 : 0));

  // ---------- 打 ----------
  function startDrag(p) {
    if (st.state !== 'aim') return false;
    st.drag = { x0: p.sx, y0: p.sy, x: p.sx, y: p.sy, by: p.id };
    st.state = 'drag';
    return true;
  }
  const pullVec = () => { const d = st.drag; let dx = d.x - d.x0, dy = d.y - d.y0; const l = Math.hypot(dx, dy); if (l > PULL) { dx *= PULL / l; dy *= PULL / l; } return { dx, dy, l: Math.min(l, PULL) }; };
  function release() {
    if (st.state !== 'drag') return;
    const { dx, dy, l } = pullVec();
    st.drag = null;
    if (l < 3) { st.state = 'aim'; return; }
    if (!st.free) {
      if (!env.spend()) { st.state = 'aim'; return; }
    }
    const v = T.shotFromDrag(dx, dy, PULL, VMAX);
    taw.vx = v.vx; taw.vy = v.vy;
    st.chain = st.free ? st.chain + 1 : 1;   // 花钱的那杆是第 1 杆，白打一杆加一
    st.free = false; st.out = 0; st.quiet = 0; st.shotN += 1;
    st.state = 'roll';
    sfx.launch(v.p * 0.7);
  }
  function collect(b) {
    b.alive = false;
    st.out += 1;
    const base = env.val('v') * (b.cat ? 5 : 1) * multOf(st.chain);
    env.award(base, { at: [b.x, b.y], n: Math.min(6, base) });
    st.fading.push({ x: b.x, y: b.y, im: b.cat ? CAT : IMS[b.look], t: 0 });
    m().kills += 1;
    if (b.cat) { env.toast('猫眼珠！×5', A.GOLD[0]); env.find('luck'); }
    if (m().kills >= 300) env.find('deep');
    sfx.settle(Math.min(5, st.out));
  }
  // 一杆停下来：撞出了、母珠停在圈里、圈里还有，下一杆白打；不然母珠回圈外（回到了再补珠，见 update 的 back）
  function settle() {
    const tawIn = inRing(taw);
    if (st.out >= 5) env.jackpot();
    s.bodies = s.bodies.filter(b => b.alive);
    const left = marbles().length;
    if (st.out > 0 && tawIn && left > 0) {
      st.free = true;
      env.toast('撞出 ' + st.out + ' 颗、母珠停在圈里：下一杆不花珠子，撞出的 ' + xs(st.chain + 1), '#a8f07a');
    } else {
      st.free = false;
      if (st.out === 0) sfx.miss();
      else if (!left) { st.cleared += 1; env.toast('圈打空了！换一颗母珠，圈里再补', A.GOLD[0]); }
      st.back = { x0: taw.x, y0: taw.y, t: 0 };
    }
    st.state = st.back ? 'back' : 'aim';
    env.save();
  }
  // 母珠回到圈外，换上新的一颗：这时候才补珠
  function newTaw() {
    const added = refill(env.val('n'), true);
    st.refills += 1;
    if (added) sfx.hop(4);
  }
  function onEvent(e) {
    if (e.type === 'hit') { sfx.clack(e.impact); }
    else if (e.type === 'wall') sfx.wall(e.impact * 0.5);
  }

  // ---------- 瞄准线 ----------
  function aimLines(ctx) {
    if (st.state !== 'drag') return;
    const { dx, dy, l } = pullVec();
    if (l < 3) return;
    const ux = -dx / l, uy = -dy / l, p = l / PULL, a = env.val('a');
    // 往后拉的那一截（皮筋）：白
    MK.dots(ctx, taw.x, taw.y, taw.x + dx, taw.y + dy, '#ffffff', 2);
    // 往前：一档一小截；二档画到第一颗撞上的、画个虚圈；三档再画母珠撞完往哪走
    const reach = a >= 3 ? 150 : a >= 2 ? 110 : 20;
    const hit = a >= 2 ? T.firstHit(s, taw.x, taw.y, TR, ux, uy, reach, taw) : null;
    const endD = hit ? hit.t : reach;
    MK.dots(ctx, taw.x + ux * (TR + 2), taw.y + uy * (TR + 2), taw.x + ux * endD, taw.y + uy * endD, A.GOLD[0], 3, st.time * 3);
    if (hit) {
      MK.ring(ctx, hit.hx, hit.hy, TR, '#ffffff', 3);
      const b = hit.body, nx = (b.x - hit.hx), ny = (b.y - hit.hy), nl = Math.hypot(nx, ny) || 1;
      const kx = nx / nl, ky = ny / nl;
      // 被撞的那颗往哪走（技能树）：顺着两颗珠心连线
      if (env.lv('aim')) MK.dots(ctx, b.x + kx * MR, b.y + ky * MR, b.x + kx * 40, b.y + ky * 40, '#ff8a7a', 2);
      // 母珠撞完往哪走（三档）：去掉沿连线那一份，剩下的切向
      if (a >= 3) { const dot = ux * kx + uy * ky; let tx = ux - dot * kx, ty = uy - dot * ky; const tl = Math.hypot(tx, ty); if (tl > 0.05) { tx /= tl; ty /= tl; MK.dots(ctx, hit.hx + tx * TR, hit.hy + ty * TR, hit.hx + tx * 30, hit.hy + ty * 30, '#9ad0ff', 3); } }
    }
    // 力度：母珠旁边的小字
    MK.label(ctx, Math.round(p * 100) + '%', taw.x + 10, taw.y - 4, p >= 0.98 ? '#ff8a7a' : '#ffffff', 'left');
  }

  // ---------- 自动打（自测、截图用）：挑一颗靠圈边的，从里往外撞 ----------
  function auto(dt) {
    const A_ = st.auto || (st.auto = { t: 0 });
    if (st.state !== 'aim') return;
    A_.t += dt;
    if (A_.t < 0.4) return;
    A_.t = 0;
    let best = null;
    for (const b of marbles()) {
      const ox = b.x - RING.x, oy = b.y - RING.y, ol = Math.hypot(ox, oy) || 1;
      const gx = b.x - ox / ol * (MR + TR), gy = b.y - oy / ol * (MR + TR);   // 母珠要撞到的位置
      const vx = gx - taw.x, vy = gy - taw.y, vl = Math.hypot(vx, vy) || 1;
      const score = (vx / vl) * (ox / ol) + (vy / vl) * (oy / ol) + ol / RING.r * 0.5 - vl / 200;
      if (!best || score > best.score) best = { score, ux: vx / vl, uy: vy / vl, d: vl };
    }
    if (!best) return;
    const k = window.__autoNoise || 0;
    if (k) { const a = Math.sqrt(-2 * Math.log(1 - Math.random())) * Math.cos(2 * Math.PI * Math.random()) * 0.08 * k, c = Math.cos(a), sn = Math.sin(a); const ux = best.ux * c - best.uy * sn, uy = best.ux * sn + best.uy * c; best.ux = ux; best.uy = uy; }
    const p = Math.min(1, 0.55 + best.d / 160 + Math.random() * 0.15);
    st.drag = { x0: 0, y0: 0, x: -best.ux * PULL * p, y: -best.uy * PULL * p, by: 'auto' };
    st.state = 'drag';
    release();
  }

  return {
    s,
    fine(f) {
      // 粉笔圈：一圈白点（3 亮 1 暗，规整）；起手的地方一个粉笔叉
      const n = Math.round(RING.r * 2 * Math.PI / 1.2);
      for (let i = 0; i < n; i++) {
        const a = i / n * Math.PI * 2, x = RING.x + Math.cos(a) * RING.r, y = RING.y + Math.sin(a) * RING.r;
        f.px(Math.floor(x), Math.floor(y), i % 4 === 3 ? '#d8c8b0' : '#fff8ec');
      }
      for (let k = -3; k <= 3; k++) { f.px(START.x + k, START.y + 9 + k, '#fff8ec'); f.px(START.x + k, START.y + 9 - k, '#fff8ec'); }
    },
    update(dt) {
      st.time += dt;
      for (const b of s.bodies) if (b.born > 0 && b.born < 1) b.born = Math.min(1, b.born + dt / 0.25);
      if (st.state === 'roll') {
        T.advance(s, dt, st.acc, null, () => { for (const b of s.bodies) if (b.kind === 'marble' && b.alive && !inRing(b, b.r)) collect(b); });
        for (const e of s.events.splice(0)) onEvent(e);
        if (!T.moving(s, 2)) { st.quiet += dt; if (st.quiet > 0.25) { for (const b of s.bodies) { b.vx = b.vy = 0; } settle(); } } else st.quiet = 0;
      } else s.events.length = 0;
      if (st.state === 'back') {
        st.back.t += dt / 0.35;
        const t = MK.ease(st.back.t);
        taw.x = st.back.x0 + (START.x - st.back.x0) * t; taw.y = st.back.y0 + (START.y - st.back.y0) * t;
        if (st.back.t >= 1) { st.back = null; taw.x = START.x; taw.y = START.y; st.state = 'aim'; newTaw(); }
      }
      st.fading = st.fading.filter(f => (f.t += dt) < 0.35);
    },
    draw(ctx) {
      for (const b of s.bodies) {
        if (!b.alive || b.kind !== 'marble') continue;
        const im = b.cat ? CAT : IMS[b.look];
        if (b.born > 0 && b.born < 1 && Math.sin(b.born * 20) > 0) continue;
        MK.spr(ctx, im, Math.round(b.x - im.width / 2), Math.round(b.y - im.height / 2));
      }
      for (const f of st.fading) if (Math.floor(f.t * 20) % 2 === 0) MK.spr(ctx, f.im, Math.round(f.x - f.im.width / 2), Math.round(f.y - f.im.height / 2));
      const showTaw = st.state !== 'aim' || st.free || env.marbles() > 0;
      if (showTaw) MK.spr(ctx, TAW, Math.round(taw.x - TAW.width / 2), Math.round(taw.y - TAW.height / 2));
      aimLines(ctx);
      if (st.state === 'aim' && showTaw && Math.sin(st.time * 5) > 0) MK.label(ctx, st.free ? '不花珠子 ' + xs(st.chain + 1) : '按住往后拉', taw.x, taw.y + 9, st.free ? '#a8f07a' : A.GOLD[0], 'center');
      if (st.state === 'roll' && (st.out > 0 || st.chain > 1)) MK.label(ctx, (st.out > 0 ? '撞出 ' + st.out : '') + (st.chain > 1 ? (st.out > 0 ? ' · ' : '') + xs(st.chain) : ''), 64, 31, st.out >= 5 ? '#ffffff' : A.GOLD[0], 'center');
      MK.led(ctx, env.marbles(), env.marbles() <= 0 && !st.free, st.time);
    },
    down(p) {
      if (p.btn !== 0) return false;
      if (st.state === 'aim') {
        if (!st.free && env.marbles() <= 0) { env.deny('marbles'); return true; }
        return startDrag(p);
      }
      return st.state !== 'aim';
    },
    move(p) { if (st.state === 'drag' && st.drag.by !== 'auto') { st.drag.x = p.sx; st.drag.y = p.sy; } },
    up(p) { if (st.state === 'drag' && st.drag.by === p.id) release(); },
    key() { return false; },
    cancel() { if (st.state === 'drag') { st.drag = null; st.state = 'aim'; } },
    leave() { if (st.state === 'drag') { st.drag = null; st.state = 'aim'; } },
    auto,
    inPlay: () => st.state === 'roll' || st.state === 'drag' || st.free,
    busy: () => st.state === 'drag',
    hint() {
      if (st.state === 'drag') return '松手弹出去（拉回原处不打）';
      if (st.state === 'roll' || st.state === 'back') return '';
      if (st.free) return '母珠停在圈里：接着打不花珠子、不补珠，这一杆撞出的 ' + xs(st.chain + 1);
      if (env.marbles() <= 0) return '';
      if (st.shotN < 3) return '在卡上按住往后拉，拉得越长越快，松手弹出母珠。把弹珠撞出粉笔圈';
      return '';
    },
    info() {
      const out = [
        ['圈里 ' + marbles().length + ' 颗 · 换母珠补进 ' + env.val('n') + ' 颗（最多 ' + CAP + '）', null],
        ['撞出一颗吐 ' + env.val('v') + ' 个', null],
      ];
      if (st.free) out.push(['下一杆不花珠子，撞出的 ' + xs(st.chain + 1) + '（白打不补珠）', '#a8f07a']);
      else if (STEP() > 0) out.push(['连着白打：一杆比一杆值钱', null]);
      if (st.state === 'roll') out.push(['这一杆撞出 ' + st.out + ' 颗（5 颗 = 大奖）', A.GOLD[0]]);
      else out.push(['一杆撞出 5 颗 = 大奖', null]);
      return out;
    },
    onUpgrade() {},
    debug: () => ({ state: st.state, inRing: marbles().length, free: st.free, shots: st.shotN, refills: st.refills, cleared: st.cleared, chain: st.chain, next: st.free ? multOf(st.chain + 1) : 1 }),
  };
});
