/*
 * 第 4 台 · 冰窟的场地（小台：卡面 64 宽，台面 x 14..114，跟基础机一样大；11-11 从 96 宽改小）
 *   发射道、推头、弹簧、力度换算同基础机；顶上同样一条直顶加两个斜角。
 *   上面两排钉子；中间一堆冰块，2 列 × 3 层，一块 16×10，坐在一根冰笋上；底下 9 个洞。
 *   冰块：铁珠撞上去（够快）掉一格，格子掉光就碎，冻在里面的珠子蹦出来。
 *   碎了一块，同一列上面的往下掉；掉下来的那块落地自己裂一格（裂光了接着碎，一列就塌了）。
 *   珠子之间不互相撞（同火山弹），蹦出来的珠子撞冰块不掉格。冰块顶是平的：珠子停在上面不动，过一会儿往边上拨一下。
 * 随机：冰块里冻几颗、哪块有金珠是抽的（s.rng）；亮哪几个洞由台子抽。同一个力度、同一堆冰，铁珠走的路一样。
 */
(function (root, factory) {
  const Sim = typeof module === 'object' && module.exports ? require('../sim.js') : root.Sim;
  const api = factory(Sim);
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.Ice = api;
}(typeof self !== 'undefined' ? self : globalThis, function (Sim) {
  'use strict';
  const DT = Sim.DT;
  const DX = 0;
  const X0 = 14, X1 = 114, Y0 = 20, STRIP = 146, YB = 154, CH = 20;
  const LANE_X = Sim.LANE_X + DX, LANE_TOP = Sim.LANE_TOP, LANE_CX = Sim.LANE_CX + DX, HEAD_Y = Sim.HEAD_Y, REST_Y = Sim.REST_Y;
  const HOLES = 9, HOLE_W = 10;
  const BALL_R = 3.5, GEM_R = 2.5, PEG_R = Sim.PEG_R;
  // 冰块：一块 16×10。一堆两列；BASE 是最底下那层冰块的底
  const BW = 16, BH = 10, ROWS = 3, BASE = 118;
  const PILES = [{ x: 44 }];
  const COLS = [];
  PILES.forEach((p, k) => { COLS.push({ x: p.x, pile: k }); COLS.push({ x: p.x + BW, pile: k }); });
  const pileCx = k => PILES[k].x + BW;
  // 冰笋：上窄下宽，顶在 BASE，冰块坐在上面
  const SPIKES = PILES.map((p, k) => ({ x0: pileCx(k) - 4, x1: pileCx(k) + 4, b0: pileCx(k) - 7, b1: pileCx(k) + 7, y: BASE }));
  const CFG = Object.assign({}, Sim.DEFAULTS, {
    blockE: 0.28, blockF: 0.12, // 冰块滑、弹得不高
    dmgMin: 38,                 // 铁珠撞冰块这么快才掉一格
    shotTimeLimit: 14,
  });
  const rowTop = r => BASE - (r + 1) * BH;

  // 钉子：上面三排错开；冰块、冰笋、发射道附近不钉
  function pegs() {
    const out = [];
    const rows = [[58, 22], [74, 30]];
    for (const [y, x0] of rows) for (let x = x0; x <= LANE_X - 12; x += 16) out.push([x, y, PEG_R]);
    // 冰堆两边各一颗，让珠子往冰块侧面撞
    for (const [x, y] of [[24, 100], [92, 102]]) out.push([x, y, PEG_R]);
    // 底下一排：碎出来的珠子打散一点（冰笋那一带不钉）
    for (let x = 22; x <= 92; x += 12) if (!SPIKES.some(sp => x > sp.b0 - 6 && x < sp.b1 + 6)) out.push([x, 130, PEG_R]);
    const clear = ([x, y]) => !COLS.some(c => x > c.x - 6 && x < c.x + BW + 6 && y > rowTop(ROWS - 1) - 7 && y < BASE + 4);
    return out.filter(clear);
  }
  function create(seed) {
    const c = CFG;
    const s = { cfg: c, colliders: [], cells: null, stamp: 0, quiet: false, events: [], balls: [], blocks: [], rng: Sim.rng(seed >>> 0), time: 0 };
    Sim.addSeg(s, X0, Y0 + CH, X0, YB, 'wall', c.wallE, c.wallF, 90, 90);
    Sim.addSeg(s, X1, Y0 + CH, X1, YB, 'wall', c.wallE, c.wallF, 90, 90);
    Sim.addSeg(s, X0, Y0 + CH, X0 + CH, Y0, 'roof', c.roofE, c.roofF, 90, 90);
    Sim.addSeg(s, X0 + CH, Y0, X1 - CH, Y0, 'roof', c.roofE, c.roofF, 90, 90);
    Sim.addSeg(s, X1 - CH, Y0, X1, Y0 + CH, 'roof', c.roofE, c.roofF, 90, 90);
    Sim.addWall(s, LANE_X, LANE_TOP, LANE_X, YB, 'lane', c.laneE, 0.02);
    Sim.addSeg(s, LANE_X, HEAD_Y, X1, HEAD_Y, 'head', 0.1, 0.2, LANE_CX, 100);
    Sim.addSeg(s, LANE_X, LANE_TOP, LANE_X - c.guard[0], LANE_TOP + c.guard[1], 'guard', 0.3, 0.02, LANE_X - 8, LANE_TOP - 4);
    for (const sp of SPIKES) {
      Sim.addSeg(s, sp.x0, sp.y, sp.b0, STRIP, 'spike', 0.3, 0.05, sp.x0 + 4, STRIP);
      Sim.addSeg(s, sp.x1, sp.y, sp.b1, STRIP, 'spike', 0.3, 0.05, sp.x1 - 4, STRIP);
      Sim.addSeg(s, sp.x0, sp.y, sp.x1, sp.y, 'spike', 0.3, 0.05, (sp.x0 + sp.x1) / 2, sp.y + 4);
    }
    for (const [x, y, r] of pegs()) Sim.addCircle(s, x, y, r, 'peg', c.pegE, c.pegF);
    Sim.buildGrid(s);
    return s;
  }
  const emit = (s, e) => { if (!s.quiet) s.events.push(e); };

  // ---------- 冰块 ----------
  // 补满：每一列从底往上补到 ROWS 块。n = 每块最多冻几颗（【救】），hp = 几下碎（【速】），gold = 这一块有没有金珠的几率
  function refill(s, n, hp, goldP, rnd) {
    rnd = rnd || s.rng;
    const added = [];
    COLS.forEach((c, ci) => {
      const have = s.blocks.filter(b => b.col === ci && b.alive).length;
      for (let r = have; r < ROWS; r++) {
        const k = Math.max(1, Math.ceil(n / 2) + Math.floor(rnd() * (n - Math.ceil(n / 2) + 1)));
        const b = { col: ci, row: r, x: c.x, y: rowTop(r), vy: 0, hp, hp0: hp, n: k, gold: rnd() < goldP, alive: true, falling: false, born: 0 };
        s.blocks.push(b); added.push(b);
      }
    });
    s.blocks = s.blocks.filter(b => b.alive);
    return added;
  }
  // 【速】升了：已经在台上的冰块血也跟着降
  function capHp(s, hp) { for (const b of s.blocks) { b.hp0 = hp; b.hp = Math.min(b.hp, hp); } }
  function breakBlock(s, b, by) {
    if (!b.alive) return;
    b.alive = false;
    const cx = b.x + BW / 2, cy = b.y + BH / 2;
    for (let i = 0; i < b.n; i++) {
      const gold = b.gold && i === 0;
      const ang = -Math.PI / 2 + (s.rng() - 0.5) * 2.4, sp = 30 + 50 * s.rng();
      s.balls.push({ x: cx + (i - (b.n - 1) / 2) * 3, y: cy, vx: Math.cos(ang) * sp, vy: Math.sin(ang) * sp, r: GEM_R, kind: 'gem', gold, t: 0, alive: true, slow: 0 });
    }
    emit(s, { type: 'break', b, by, x: cx, y: cy });
    settle(s);
  }
  // 一列里面碎了几块：上面的往下掉
  function settle(s) {
    COLS.forEach((c, ci) => {
      const col = s.blocks.filter(b => b.col === ci && b.alive).sort((a, b) => a.row - b.row);
      col.forEach((b, r) => { if (b.row !== r) { b.row = r; b.falling = true; } });
    });
  }
  function hitBlock(s, b, by) {
    b.hp -= 1;
    emit(s, { type: 'crack', b, by, x: b.x + BW / 2, y: b.y + BH / 2 });
    if (b.hp <= 0) breakBlock(s, b, by);
  }
  // 圆和冰块（长方形）：最近点
  function boxContact(b, k) {
    const qx = Math.max(k.x, Math.min(k.x + BW, b.x)), qy = Math.max(k.y, Math.min(k.y + BH, b.y));
    let dx = b.x - qx, dy = b.y - qy, d2 = dx * dx + dy * dy;
    if (d2 >= b.r * b.r) return null;
    if (d2 < 1e-9) {   // 圆心进了冰块：往最近的那条边推出去
      const l = b.x - k.x, rr = k.x + BW - b.x, t = b.y - k.y, bt = k.y + BH - b.y, m = Math.min(l, rr, t, bt);
      const n = m === t ? [0, -1] : m === bt ? [0, 1] : m === l ? [-1, 0] : [1, 0];
      return { depth: b.r + m, nx: n[0], ny: n[1], px: qx, py: qy };
    }
    const d = Math.sqrt(d2);
    return { depth: b.r - d, nx: dx / d, ny: dy / d, px: qx, py: qy };
  }

  // ---------- 一发 ----------
  function launch(s, p) {
    const b = { x: LANE_CX, y: REST_Y, vx: 0, vy: -Sim.launchSpeed(s.cfg, Math.max(0, Math.min(1, p))), r: BALL_R, kind: 'iron', t: 0, alive: true, slow: 0, lastBlock: null, lastT: -1 };
    s.balls.push(b);
    emit(s, { type: 'launch', p });
    return b;
  }
  const holeAt = x => Math.max(0, Math.min(HOLES - 1, Math.floor((x - X0) / HOLE_W)));
  const holeCx = i => X0 + HOLE_W * i + 4;
  function step(s) {
    s.time += DT;
    const c = s.cfg;
    // 掉下来的冰块
    for (const k of s.blocks) {
      if (!k.alive || !k.falling) continue;
      k.vy += c.gravity * DT; k.y += k.vy * DT;
      const ty = rowTop(k.row);
      if (k.y >= ty) { k.y = ty; k.falling = false; const v = k.vy; k.vy = 0; emit(s, { type: 'thud', b: k, v }); hitBlock(s, k, 'fall'); }
    }
    for (const b of s.balls) {
      if (!b.alive) continue;
      b.t += DT;
      b.vy += c.gravity * DT;
      b.x += b.vx * DT; b.y += b.vy * DT;
      for (let it = 0; it < 4; it++) {
        let h = Sim.deepest(s, b), hk = null;
        for (const k of s.blocks) {
          if (!k.alive) continue;
          const bh = boxContact(b, k);
          if (bh && (!h || bh.depth > h.depth)) { h = bh; hk = k; }
        }
        if (!h) break;
        if (hk) {
          const vn = b.vx * h.nx + b.vy * h.ny;
          h.col = { kind: 'block', id: -1, e: c.blockE, f: c.blockF };
          Sim.resolve(s, b, h);
          if (b.kind === 'iron' && -vn > c.dmgMin && (b.lastBlock !== hk || b.t - b.lastT > 0.15)) { b.lastBlock = hk; b.lastT = b.t; hitBlock(s, hk, 'iron'); }
          else if (-vn > 12) emit(s, { type: 'tink', b: hk, x: h.px, y: h.py, impact: -vn, gem: b.kind === 'gem' });
        } else Sim.resolve(s, b, h);
      }
      // 停在冰块顶上不动：往离堆中间远的那边拨一下
      const sp = Math.hypot(b.vx, b.vy);
      b.slow = sp < 6 && b.y < STRIP - 8 ? b.slow + DT : 0;
      if (b.slow > 0.35) { let k = 0; PILES.forEach((p, i) => { if (Math.abs(b.x - pileCx(i)) < Math.abs(b.x - pileCx(k))) k = i; }); const dir = b.x < pileCx(k) ? -1 : 1; b.vx = dir * 40; b.vy = -12; b.slow = 0; }
      if (b.kind === 'iron') {
        if (b.x > LANE_X && b.y >= REST_Y - 0.5 && b.vy >= 0 && b.t > 0.05) { b.alive = false; emit(s, { type: 'fallback', b }); continue; }
      }
      if (b.x < LANE_X && b.y >= STRIP - b.r) { b.alive = false; emit(s, { type: 'land', b, hole: holeAt(b.x), x: b.x, y: b.y }); continue; }
      if (b.t > c.shotTimeLimit) { b.alive = false; emit(s, b.kind === 'iron' && b.x > LANE_X ? { type: 'fallback', b, stuck: true } : { type: 'land', b, hole: holeAt(Math.min(b.x, LANE_X - 1)), x: b.x, y: b.y }); }
    }
    s.balls = s.balls.filter(b => b.alive);
    s.blocks = s.blocks.filter(b => b.alive);
  }
  function advance(s, dt, acc) {
    acc.t += dt;
    let n = 0;
    while (acc.t >= DT && n < 600) { step(s); acc.t -= DT; n++; }
  }
  const busy = s => s.balls.length > 0 || s.blocks.some(b => b.falling);
  // 试一发（自动打、力度刻度用）：照现在这堆冰，力度 p 的铁珠先碰到哪块冰（{ col, row, hard }），没碰到就是落哪个洞（{ hole }，退回 = null）
  let PT = null;   // 试发用的那张台子：只建一次，每次换上现在这堆冰
  function probe(s, p) {
    const t = PT || (PT = create(7));
    t.blocks = s.blocks.map(b => Object.assign({}, b));
    t.balls = []; t.events = []; t.time = 0;
    const b = launch(t, p);
    for (let i = 0; i < 480 * 12; i++) {
      step(t);
      for (const e of t.events) if ((e.type === 'crack' && e.by === 'iron') || (e.type === 'tink' && !e.gem)) return { col: e.b.col, row: e.b.row, hard: e.type === 'crack' };
      t.events.length = 0;
      if (!b.alive) return { hole: b.x > LANE_X ? null : holeAt(b.x) };
    }
    return { hole: null };
  }
  return {
    DX, X0, X1, Y0, STRIP, YB, CH, LANE_X, LANE_TOP, LANE_CX, HEAD_Y, REST_Y, HOLES, HOLE_W, BALL_R, GEM_R, BW, BH, ROWS, BASE, PILES, COLS, SPIKES, CFG,
    rowTop, pileCx, pegs, create, refill, capHp, launch, step, advance, busy, probe, holeAt, holeCx,
  };
}));
