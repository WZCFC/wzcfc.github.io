/*
 * 俯视那一类的圆盘（弹珠出圈、保龄球共用）。坐标跟卡面一致：卡面一格 = 这里两格；俯视台面 x 14..114、y 28..154。
 *   每个圆盘：位置、速度、半径、质量、摩擦（每秒减多少速度 mu + 跟速度成正比的 drag）、弹性 e。
 *   圆盘之间：弹性碰撞（冲量按质量分），互相撞了发 hit 事件。墙：每个圆盘自己带一个框（bx0..by1，可以没有）。
 *   发射：往后拉着打——拉的方向反过来就是出手方向，拉得越长越快。
 * 定步长 1/240 秒（最快 260 一秒，一步走 1.1 格，比最小的珠子半径小得多，不会穿过去）。
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.TopDown = api;
}(typeof self !== 'undefined' ? self : globalThis, function () {
  'use strict';
  const DT = 1 / 240;
  let nextId = 1;
  function create() { return { bodies: [], events: [], quiet: false, time: 0 }; }
  function add(s, o) {
    const b = Object.assign({ id: nextId++, x: 0, y: 0, vx: 0, vy: 0, r: 4, m: 1, mu: 60, drag: 0.6, e: 0.9, we: 0.5, alive: true, solid: true, box: null, kind: 'disc', moved: 0 }, o);
    s.bodies.push(b);
    return b;
  }
  const emit = (s, e) => { if (!s.quiet) s.events.push(e); };
  function step(s, filter) {
    s.time += DT;
    const B = s.bodies;
    for (const b of B) {
      if (!b.alive) continue;
      const sp = Math.hypot(b.vx, b.vy);
      if (sp > 0) {
        const dec = (b.mu + b.drag * sp) * DT;
        if (dec >= sp) { b.vx = 0; b.vy = 0; } else { const k = (sp - dec) / sp; b.vx *= k; b.vy *= k; }
      }
      b.x += b.vx * DT; b.y += b.vy * DT;
      b.moved += Math.hypot(b.vx, b.vy) * DT;
      const w = b.box;
      if (w) {
        let hit = 0;
        if (w.x0 != null && b.x - b.r < w.x0) { b.x = w.x0 + b.r; if (b.vx < 0) { hit = -b.vx; b.vx = -b.vx * b.we; } }
        if (w.x1 != null && b.x + b.r > w.x1) { b.x = w.x1 - b.r; if (b.vx > 0) { hit = b.vx; b.vx = -b.vx * b.we; } }
        if (w.y0 != null && b.y - b.r < w.y0) { b.y = w.y0 + b.r; if (b.vy < 0) { hit = -b.vy; b.vy = -b.vy * b.we; } }
        if (w.y1 != null && b.y + b.r > w.y1) { b.y = w.y1 - b.r; if (b.vy > 0) { hit = b.vy; b.vy = -b.vy * b.we; } }
        if (hit > 15) emit(s, { type: 'wall', b, impact: hit });
      }
    }
    for (let i = 0; i < B.length; i++) {
      const a = B[i];
      if (!a.alive || !a.solid) continue;
      for (let j = i + 1; j < B.length; j++) {
        const b = B[j];
        if (!b.alive || !b.solid || (filter && !filter(a, b))) continue;
        const dx = b.x - a.x, dy = b.y - a.y, rr = a.r + b.r, d2 = dx * dx + dy * dy;
        if (d2 >= rr * rr) continue;
        const d = Math.sqrt(d2) || 1e-6, nx = dx / d, ny = dy / d, ia = 1 / a.m, ib = 1 / b.m;
        const pen = rr - d;
        a.x -= nx * pen * ia / (ia + ib); a.y -= ny * pen * ia / (ia + ib);
        b.x += nx * pen * ib / (ia + ib); b.y += ny * pen * ib / (ia + ib);
        const vn = (b.vx - a.vx) * nx + (b.vy - a.vy) * ny;
        if (vn >= 0) continue;
        const e = Math.min(a.e, b.e), jj = -(1 + e) * vn / (ia + ib);
        a.vx -= jj * ia * nx; a.vy -= jj * ia * ny;
        b.vx += jj * ib * nx; b.vy += jj * ib * ny;
        emit(s, { type: 'hit', a, b, impact: -vn, x: a.x + nx * a.r, y: a.y + ny * a.r });
      }
    }
  }
  const moving = (s, v) => s.bodies.some(b => b.alive && Math.hypot(b.vx, b.vy) > (v || 1.5));
  function advance(s, dt, acc, filter, after) {
    acc.t += dt;
    let n = 0;
    while (acc.t >= DT && n < 200) { step(s, filter); if (after) after(); acc.t -= DT; n++; }
  }
  // 往后拉：拉的向量 (dx, dy)（从球心到手指），出手速度朝反方向；len 是拉满的长度
  function shotFromDrag(dx, dy, len, vmax) {
    const d = Math.hypot(dx, dy), p = Math.min(1, d / len);
    if (d < 1e-6) return { vx: 0, vy: 0, p: 0 };
    return { vx: -dx / d * vmax * p, vy: -dy / d * vmax * p, p };
  }
  // 预测：从 (x, y) 沿 (ux, uy) 直走，第一个碰上的圆盘（瞄准线用）。返回 { t, body, hx, hy }，t 是走了多远
  function firstHit(s, x, y, r, ux, uy, maxD, skip) {
    let best = null;
    for (const b of s.bodies) {
      if (!b.alive || !b.solid || b === skip) continue;
      const rr = r + b.r, fx = b.x - x, fy = b.y - y, t = fx * ux + fy * uy;
      if (t < 0) continue;
      const q = fx * fx + fy * fy - t * t;
      if (q > rr * rr) continue;
      const tt = t - Math.sqrt(rr * rr - q);
      if (tt < 0 || tt > maxD || (best && tt >= best.t)) continue;
      best = { t: tt, body: b, hx: x + ux * tt, hy: y + uy * tt };
    }
    return best;
  }
  return { DT, create, add, step, advance, moving, shotFromDrag, firstHit };
}));
